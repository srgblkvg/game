.env прод: JWT, VK*, YOOKASSA_SHOP_ID=1391221, YA_CLIENT_ID=7d28f8…, DISABLE_RATE_LIMIT=true. DB: GRANT ALL ON castle_treasury/treasury_log TO game.
§
VK: Arch_(118) осн. TODD(314),Sallarik(131),Некрохирург(1),Хорс(461),Derkitys(693),runaway(692). Гильдия Адепты Тьмы(4).
§
equip-sets I/II/III через equipment_1/2/3 JSONB + switch-equip. fetchCharacter() при смене. parseEq обёртка JSONB→объект. upgradeLevel: item.upgradeLevel ?? item.upgradelevel.
§
Бой: runBattle/runTurn. PvE: mobHp×2, applyHpRegen, кулдаун 5мин/2.5мин, pveCdSec в /me. PvP: Bandit ±4ур×2таймер, Guard +10%. Коллекция: табы<7/>=7, total×2=450.
§
Гильдия: передача лидерства обновляет guilds.leaderId + старый→officer.
§
Фракции: полные описания без сленга. Иконки (hood/anvil/shield) у ника: PlayerBadge,CharacterCard,Top3,рейтинг,арена.
§
Гильд-босс: 100k+50k/убийство, респаун 5мин, 12 эффектов, макс.HP. Таланты 5 типов, личные/гильдийские раздельно. Сброс по средам. Сундуки: x5=999₽.
§
Тест юзеры: Oz777zy(28),TODD(314),Некрохирург(1),Боба(35). JWT: sign({userId,role,username}, JWT_SECRET).
§
collectGuildTax: ВСЕ точки дохода (PvE/PvP/квесты/работы). Новый доход → всегда налог.
§
Данж: COMBAT_SPEED=1/3, бой из battle.ts (вампиризм/fullBlock/blockPen/добивание). playerExtra+playerVamp из buildPlayerStats. Реген без замедл. Автоатака⚔️в карточке. Стан⚡. Лут при выходе. Дроп: камни+шмот. Чекпоинт: UPDATE не DELETE. Мёртвые в списке+targetIndex. КД 30мин. Рейтинг: 2 колонки, профиль/гильдия по ID. Десктоп: слева/справа. Тестер Oz777zy(28).
§
Деплой сервера: PM2=node dist/index.js. rm -rf dist && npx tsc && rsync dist/ на VPS && pm2 restart. dist кеширует старый код без удаления! Клиент: npm run build && rsync client/dist/.
§
PG raw→колонки в нижнем регистре. Гильдия: навигация по ID. Фиксы: один за раз, смотреть БД, commit+push+deploy.
§
Sallarik(131): Берсерк3/4+Страж4/4,vamp5%,resil30%,coll508,fullBlock30%. Некро(1)база S83A39D41M82,coll338,сет3=Страж4/4+Крушитель2/4,curse S/A 50/50. Симуляция на VPS: npx tsx+runBattle.