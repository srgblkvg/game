---
name: mmo-guild-systems
description: Use for guild bosses, talents, buildings, quests, war.
category: software-development
---

# MMO Guild Systems

Common patterns for guild-scoped features: bosses, talents, buildings, quests, wars.

## Architecture Pattern

Every guild feature follows the same structure:

```
server/src/game/guild<Feature>.ts   — game logic (pure functions, constants, DB helpers)
server/src/routes/guild<Feature>.ts — Express routes
server/src/routes/guild/guildCore.ts — base guild info + member data
```

Routes auto-create tables on first use (no separate migration step needed in production).

## Guild Bosses (2026-08-05)

`server/src/game/guildBoss.ts` + `server/src/routes/guildBoss.ts`

**Mechanics:**
- One boss per guild (`guild_bosses.guildId` PRIMARY KEY)
- Attack cooldown: 1 hour per player (`guild_members.lastBossAttackAt`)
- Battle: PvE-style via `runTurn()` — uses scout_hq building bonus + guard faction bonus
- Boss stats: base S=80/A=50/D=60/M=50, level=20, HP=100k
- Scaling per kill: +50k HP, +10% stats, +5 level (formula-based, `scaleStat(base, killCount)`)
- After each rebirth, boss gets `min(killCount, 6)` random effects from pool (super dodge, vampirism, poison, etc.)
- Effects scale with killCount via same stat formula
- Effects stored as JSON in `effects` column, applied via `Object.assign(bossStats, flatFx)` before battle

**Endpoints:**
- `GET /guild/boss` — boss state + player cooldown + talents
- `POST /guild/boss/attack` — fight boss (runTurn battle loop)
- `GET /guild/talents` — talent trees + points
- `POST /guild/talents/upgrade` — spend points (cost: `10*(level+1)`, 1 level = 1% anti-effect)

**Pitfalls:**
- Boss stats must use `currentStats()` then override `hp` (boss has manual HP, not S+A+M)
- Boss effects must be flattened via `flattenBossEffects()` before `Object.assign`
- `targetAntiVampiric` (player's anti-vamp) goes in ctx2 (boss attacks player), not ctx1
- `sendToGuild` for kill announcement — use dynamic import to avoid circular deps
- Guild quest PvE progress and `markDirty('quests')` on player win (like mobs.ts)

## Guild Talents

Five talent trees, each providing counter-extra-stats:
- accuracy → antiDodge
- fortitude → antiCrit
- penetration → antiBlock
- control → antiCounter
- vampiric → antiVampiric (target-side, reduces attacker healing)

**Cost:** `10 * (currentLevel + 1)` per upgrade. 1 level = 1% reduction.

**Personal talents:** per-player, tied to guild. Points earned per boss attack.
**Guild talents:** guild-wide, chosen by leader/officer with buildings permission. Points earned per boss kill.

Applied to battle via `getAntiStats()` → TurnContext fields. See `battle-engine` skill for formula details.

## Guild Buildings

`server/src/game/guildBuildings.ts` + `server/src/routes/guildBuildings.ts`

Buildings provide %-bonus to stats in specific contexts (arena, tournament, PvE, war_attack, war_defense).
Building bonus applied in `buildPlayerStats()` via `getGuildBonus(userId, context)`.

## DB Tables

```sql
guild_bosses        — boss state per guild (guildId PK)
guild_members       — +lastBossAttackAt, +talentPoints
player_guild_talents — personal talents (userId+guildId+talentType PK)
guild_talents       — guild-wide talents (guildId+talentType PK)
guilds              — +talentPoints
guild_buildings     — building levels (guildId+buildingType PK)
```

## Pitfalls

- Always pass `context` to `buildPlayerStats()` for correct building bonus
- Guard faction bonus (+10% PvE) applied AFTER buildPlayerStats
- Boss damage = `boss.currentHp - bossCurrentHp` (pre-attack minus post-attack)
- HP regen via `applyHpRegen()` before boss fight (same as mobs.ts)
- Guild chat notification via dynamic `import('../events')` — avoids circular deps

### ⛔ Guild navigation in ratings: use guild ID, NOT guild name ⛔

When rendering guild names as clickable links in rating blocks (guild boss top-5, dungeon leaderboard, etc.), navigate by guild ID, not guild name:

```tsx
// ❌ WRONG — Cyrillic names get URL-encoded, guild page fails
<span onClick={() => navigate(`/guild/${r.guildName}`)}>[{r.guildName}]</span>

// ✅ CORRECT — guild page accepts numeric ID
<span onClick={() => navigate(`/guild/${r.guildid}`)}>[{r.guildName}]</span>
```

The guild route `/guild/:id` calls `parseInt(req.params.id)` — it expects a numeric ID. A Cyrillic name like `Соратники` gets URL-encoded to `%D0%A1%D0%BE...` and `parseInt` returns `NaN`.

**Server must include `guildid` in API responses** — the `ratings` endpoint for guild boss was missing `guildid` in the mapped response for `guildTop`, `personalTop`, AND `topHits`. All three needed `guildid` added to both the SQL query (`u.guildId as guildid`) and the response mapper.

**Check ALL rating blocks** — the same bug existed in 7 places across the codebase:
- Guild boss: `guildTop`, `personalTop`, `topHits` (API + client)
- Guild boss: `guildTopList`, `topGuildKills` (client only — used `r.name` instead of `r.id`)
- Dungeon leaderboard: `topFloor`, `topReward` (API + client)

**`db.raw()` column names:** PostgreSQL lowercases all unquoted column aliases. `guildid` stays `guildid`, `guildName` becomes `guildname`. Client must use the exact lowercase key.
