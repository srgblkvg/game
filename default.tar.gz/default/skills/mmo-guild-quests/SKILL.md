---
name: mmo-guild-quests
description: "Guild quest bugs: GET increment, no type filter."
---

# MMO Arena — Guild Quest Pitfalls & Fixes

## GET /guild/quest — questType hardcoded to 'pve' (non-pve quests invisible) (2026-07-30)

GET эндпоинт всегда передавал `questType='pve'` в `updateGuildQuestProgress`. Если активный квест типа `donate`, `pvp`, `craft` или `jobs`, фильтр `activeQuest.questType !== questType` отсекает его → активный квест НИКОГДА не возвращается клиенту.

**Симптомы:**
- Квесты «не берутся» — клиент не видит активный квест, не может отслеживать прогресс
- «Сразу завершаются» — при повторном заходе активный квест невидим, генерируются новые опции (старые очищены при TAKE)

**Fix:** сначала получить активный квест из БД, затем передать его РЕАЛЬНЫЙ `questType`:
```typescript
const activeQuest = await db.one(
    "SELECT * FROM guild_quests WHERE guildId = ? AND status = 'active' ORDER BY id DESC LIMIT 1",
    [member.guildId]
) as any;
if (activeQuest) {
    const questData = await updateGuildQuestProgress(member.guildId, activeQuest.questType as GuildQuestType, 0);
    if (questData) return res.json({ activeQuest: questData, options: null });
}
```

## GET /guild/quest increments progress on page load (OLD — fixed)

## updateGuildQuestProgress has no questType filter

Any action (PvE kill, craft, PvP win) incremented ANY active quest regardless of type.
If «Казна» (donate) is active, killing a mob gives +1 to donation progress.

**Fix:** Function now requires `questType: GuildQuestType`. Skips if active quest doesn't match:
```typescript
export async function updateGuildQuestProgress(guildId: number, questType: GuildQuestType, increment: number = 1) {
  if (activeQuest.questType !== questType) return;
```

**All call sites:**

| File | questType |
|------|-----------|
| craft.ts | 'craft' |
| mobs.ts | 'pve' |
| battle.ts | 'pvp' |
| massacre.ts | 'pvp' |
| guildTreasury.ts | 'donate' |
| helpers.ts (collectGuildTax) | 'donate' |
| character.ts (jobs) | 'jobs' |
| guildQuests.ts (GET) | actual questType from active quest (increment=0) |

## Guild XP doesn't update dynamically after claim

Server sends `guildExp`/`guildLevelUp` via `sendToGuild()` but client never listens.

**Fix — ChatContext.tsx:** Dispatch `guildExp` and `guildLevelUp` as CustomEvents.
**Fix — GuildPage.tsx:** useEffect listeners update `guild.exp`/`guild.level` via `setGuild`.
