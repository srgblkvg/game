---
name: battle-analysis
description: Analyze battle logs. Use when reviewing combat outcomes.
category: software-development
---

# Battle Analysis

Методика анализа боевых логов для выявления дисбаланса формул.

## Workflow

### 1. Получение лога
Бои в таблице `battles`, первый шаг `info` содержит stats1/stats2.
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT id, steps FROM battles WHERE id = <N>;\""
```

### 2. Загрузка экипировки
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT id, username, equipment FROM users WHERE id IN (<id1>, <id2>);\""
```
Суммировать extra-статы (dodge, crit, counter, fullBlock) по всем предметам.

### 3. Расчёт сет-бонусов
Сеты из `server/src/game/stats.ts` — множители на extra-статы:
- Буревестник 4/4: `extra.dodge = Math.round(extra.dodge * 1.2)`
- Подкова удачи: +5% ко всем шансам (luckBonus)

### 4. Расчёт шансов (battle.ts)

**dodge:** `A/(A+500) * (1 - M_враг/(M_враг+250)) / 1.5 + extra/(extra+300) + luck`

**crit:** `min(0.8, M/(M+500)/1.5 + extra/(extra+300)) + luck`

**block:** `min(0.75, D/(D+500)/1.5 + extra/(extra+300))`

**counter:** Только после уклонения. Бьёт от сырой S.

**fullBlock:** `extra/(extra+300)` — независимо от D.

### 5. Сравнение с фактом
Подсчитать срабатывания в логе, сравнить с расчётными.

## Gotchas

- Dodge: до 2026-08-03 знаменатель 500, исправлен на 250
- Контратака бьёт от сырой S без модификаторов
- fullBlock — отдельный бросок ДО обычного блока
- Сет-бонусы — множители extra, не плоские %
