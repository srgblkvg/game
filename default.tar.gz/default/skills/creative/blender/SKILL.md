---
name: blender
description: Blender 3D via Python API — models, rendering, automation.
---

# Blender via Hermes

Blender has a full Python API via `blender --background --python script.py`.

## Setup

```bash
which blender && blender --version
sudo apt install blender  # if missing
```

## Patterns

```bash
# Run script
blender --background --python script.py

# Render
blender --background file.blend --render-output //render_ -f 1 -a

# Export
blender --background file.blend --python -c "import bpy; bpy.ops.export_scene.gltf(filepath='out.glb')"
```

## Python API

```python
import bpy

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()

bpy.ops.mesh.primitive_cube_add(size=2)
bpy.ops.mesh.primitive_uv_sphere_add(radius=1)

obj = bpy.context.active_object
obj.modifiers.new('Subsurf', 'SUBSURF')
bpy.ops.object.modifier_apply(modifier='Subsurf')

bpy.ops.wm.save_as_mainfile(filepath='out.blend')
```

## AI 3D (external)
- Meshy.ai, Luma Genie, CSM — text-to-3D
- API → download .glb → import Blender

## Pitfalls
- `bpy` only inside Blender, not standalone Python
- `--background` no GUI, paths must be absolute
