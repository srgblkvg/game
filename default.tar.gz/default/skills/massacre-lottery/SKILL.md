---
name: massacre-lottery
description: Кровавая лотерея — кулачный бой без экипировки.
category: mmo-content-100
---

# Кровавая лотерея (Massacre)

Хаотичный кулачный бой без экипировки. Голые статы (база + лудус), случайный выбор цели. Призовой фонд = сборы + 1000.

## Правила

- Только база + лудус (`baseX + trained_X`), без экипировки/напитков/гильдии/коллекций
- Случайный выбор цели каждый ход
- Победитель один, приз = `участники × взнос + 1000`
- Сбор 30 мин, вход 100 сер.
- Иконка `game-icons:fist`, название «Кровавая лотерея»

## Сервер: статы при вступлении

```typescript
const s = user.baseS + (user.trained_s || 0);
const a = user.baseA + (user.trained_a || 0);
const d = user.baseD + (user.trained_d || 0);
const m = user.baseM + (user.trained_m || 0);
const hp = s + a + m;
const stats = { s, a, d, m, hp, bonuses: {}, extra: {}, drinks: {}, collection: 0 };
```

## Сервер: выбор цели

```typescript
const aliveTargets = Array.from(state.entries())
    .filter(([id, t]) => t.alive && id !== userId);
const entry = aliveTargets[Math.floor(Math.random() * aliveTargets.length)]!;
```

## Сервер: призовой фонд

`prizePool = participants.length * entryFee + 1000` (временный бонус)

`/massacre/state` возвращает `prizePool`.

## Сервер: порядок шагов в логе

`ORDER BY turn_number, id` — обязателен, иначе шаги внутри хода в случайном порядке.

## Добавление игроков вручную (SQL)

```sql
INSERT INTO massacre_participants (event_id, user_id, level, base_s, base_a, base_d, base_m, hp_current, hp_max, stats_json)
SELECT <event_id>, u.id, u.level,
       u.baseS + COALESCE(u.trained_s, 0),
       u.baseA + COALESCE(u.trained_a, 0),
       u.baseD + COALESCE(u.trained_d, 0),
       u.baseM + COALESCE(u.trained_m, 0),
       u.baseS + COALESCE(u.trained_s, 0) + u.baseA + COALESCE(u.trained_a, 0) + u.baseM + COALESCE(u.trained_m, 0),
       u.baseS + COALESCE(u.trained_s, 0) + u.baseA + COALESCE(u.trained_a, 0) + u.baseM + COALESCE(u.trained_m, 0),
       json_build_object(
         's', u.baseS + COALESCE(u.trained_s,0),
         'a', u.baseA + COALESCE(u.trained_a,0),
         'd', u.baseD + COALESCE(u.trained_d,0),
         'm', u.baseM + COALESCE(u.trained_m,0),
         'hp', u.baseS+COALESCE(u.trained_s,0)+u.baseA+COALESCE(u.trained_a,0)+u.baseM+COALESCE(u.trained_m,0),
         'bonuses','{}','extra','{}','drinks','{}','collection',0
       )
FROM users u WHERE u.id IN (<ids>);
```

## Питфолы

- **НЕ использовать `buildPlayerStats` для резни** — с июля 2026 только голые статы
- **Порядок ходов:** всегда `ORDER BY turn_number, id`
- **Разрыв HP ×3** (15–77) вместо ×94 с экипировкой — у всех есть шанс
- **Клиентский лог:** `renderBattleLog(visibleSteps, false, true)` — live-режим как в резне
- **Приоритет цели:** был 70% max HP → удалён, теперь полностью случайный
- **HP в логе:** брать `step.hp1`/`step.hp2` из шага (runTurn их заполняет), НЕ финальный `s.hp`/`target.hp` после runTurn. Иначе все шаги показывают HP конца хода, а не момент шага. Фолбэк: `step.hp1 ?? s.hp`.
