# Dodge Formula Fix (2026-08-03)

## Problem

Derkitys (A=623, extraDodge=42) had 22.3% dodge chance vs Некрохирург (M=1351).
With `atkW / (atkW + 500)`, the mastery penalty was only 27% instead of reasonable 15.6%.
Derkitys dodged 5/5 attacks (probability 0.055%).

## Fix

Changed dodge pen denominator from 500 to 250 in `battle.ts:40`:

```
- (1 - atkW / (atkW + 500)) / 1.5
+ (1 - atkW / (atkW + 250)) / 1.5
```

## Impact (Derkitys vs Некрохирург)

| | Before (500) | After (250) |
|---|---|---|
| Penalty from M=1351 | 27.0% | 15.6% |
| Base dodge | 10.0% | 4.1% |
| +extra (42) | 12.3% | 12.3% |
| **Total dodge** | **22.3%** | **16.4%** |

## Battle Analysis Pattern

To debug formula issues, look at real battles with steps data:
1. Get battle logs from `battles` table (column `steps` — JSON with HP, stats per step)
2. Get equipment from `users.equipment` to calculate actual extra stats + set bonuses
3. Compare expected probabilities vs actual outcomes
4. Check if set bonuses are multiplicative (they are — `stats.ts` lines 161-203)<｜end▁of▁thinking｜>