# Equip Sets (Слоты I/II/III)

## DB

```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS equipment_1 JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS equipment_2 JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS equipment_3 JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS active_equip_slot INTEGER DEFAULT 1;
```

`equipment` (TEXT) — always the active set for battle code compatibility.
`equipment_1/2/3` (JSONB) — persistent storage.

## API

- `GET /character/me` — returns `equipment`, `equipment1/2/3`, `activeEquipSlot`
- `POST /character/switch-equip { slot: 1|2|3 }` — saves current→old slot, loads new→equipment
- `POST /character/save-equip-set { slot, equipment }` — saves to specific slot

## Client

CharacterCard tabs I/II/III via props: `equipSets`, `activeEquipSlot`, `onSwitchSet`.
Works in both LeftSidebar and ArenaPage.

## Critical Pitfall: JSONB vs TEXT

`equipment_1/2/3` are JSONB — pg returns objects. `equipment` is TEXT — pg returns string.
Must use `parseEq(v) = typeof v === 'string' ? JSON.parse(v) : v` everywhere.

The `?::jsonb` cast is needed in UPDATE statements for JSONB columns.

## Critical Pitfall: Arena switch — do NOT reload opponent

After switching sets on Arena page, do NOT call `loadOpponent`. The opponent's stats are independent of our equipment — they're loaded from DB. Calling `loadOpponent(true)` costs 10 money and fails with 400 if insufficient funds.

Just reload character via `fetchCharacter()` and `setCharacter(fresh)`.

## Pitfall: manual setCharacter vs full reload

Don't manually update `character.equipment` after switch-equip — the `stats` field stays stale. Always call `fetchCharacter()` for a full `/character/me` reload.
