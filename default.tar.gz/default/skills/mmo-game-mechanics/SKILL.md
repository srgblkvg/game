---
name: mmo-game-mechanics
description: "MMO Arena combat formulas, sets, artifacts, curse, equip."
category: software-development
---

# MMO Arena — Game Mechanics Reference

## Dodge Formula (updated Aug 03, 2026)

```typescript
dodgeChance = A/(A+500) * (1 - M_врага/(M_врага+250)) / 1.5 + extraDodge/(extraDodge+300) + luckBonus
```

Знаменатель 250 для пенальти от M (было 500, исправлено 2026-08-03). При M=1351 пенальти 15.6% вместо 27%.

## All Combat Formulas

| Механика | База (свой стат) | Пенальти (враг) | Extra | Кап |
|---|---|---|---|---|
| dodge | A/(A+500) | M_враг/(M_враг+250) | extra/(extra+300) | — |
| crit | M/(M+500)/1.5 | — | extra/(extra+300) | 80% |
| block | D/(D+500)/1.5 | — | extra/(extra+300) | 75% |
| blockReduction | D_защ / S_атак × 0.9 | — | — | 75% |
| counter | ratio × 0.5/1.5 | ratio | extra/(extra+300) | 50% |
| fullBlock | — | — | fb/(fb+300) | независимый |
| stun | S+M / sum × 0.3 | S+D / sum | — | — |
| luck | — | — | luckBoost/100 | плоский бонус |

## Set Bonuses (stats.ts)

| Сет | Слоты | 2/4 | 3/4 | 4/4 |
|---|---|---|---|---|
| Буревестник | helmet,gloves,amulet,boots | A×1.1 | alwaysFirst | extra dodge×1.2 |
| Гладиатор | weapon1,shield,helmet,amulet | +15% dmg+ctr | fb×1.1 | all stats×1.1 |
| Берсерк | weapon1,gloves,boots,belt | +10% dmg | rage 20% HP<50% | blockPen 20% |
| Страж | helmet,chest,shield,ring | fb×1.1 | all stats×1.15 | counterOnHit 30% |
| Крушитель | weapon1,shield,gloves,belt | blockPen 25% | crit×1.1 | +15% dmg |
| Жнец | weapon1,chest,gloves,belt | vamp +5% | +15% dmg | execute <10%HP |
| Дуэлянт | weapon1,shield,ring,amulet | ctr×1.1 | crit×1.15 | vamp +5% |
| Отшельник | helmet,chest,boots,ring | +100% HP regen | poison 3%HP×3 | dodge×1.15 |

**Key:** set bonuses are MULTIPLIERS on extra stats, not flat bonuses. E.g. Буревестник 4/4: `extra.dodge = Math.round(extra.dodge * 1.2)`.

## Artifacts (rarity_id=7)

| Название | Слот | Эффект | Extra |
|---|---|---|---|
| Подкова удачи | belt | luck +5% all chances | crit 15, dodge 15, ctr 10 |
| Кольцо вампира | ring | vampirism 5% | crit 22, ctr 18 |
| Талисман стойкости | amulet | resilience 30% | fb 22 |
| Амулет ярости | amulet | rage +20% HP<30% | crit 20, ctr 20 |

## Anti-stats (контр-экстра статы) — гильдийские таланты (2026-08-05)

Гильдийские таланты дают контр-статы, вычитаемые из вражеских шансов. 1 уровень = −1% (плоский штраф).

| Талант | Тип | Что снижает | Формула в runTurn |
|--------|-----|-------------|-------------------|
| Меткость | accuracy | Вражеский dodge | `Math.max(0, dodgeChance − antiDodge/100)` |
| Стойкость | fortitude | Вражеский crit (при контратаке) | `Math.max(0, critChance − antiCrit/100)` |
| Пробивание | penetration | Вражеский block | `Math.max(0, blockChance − antiBlock/100)` |
| Контроль | control | Вражеский counter | `Math.max(0, counterChance − antiCounter/100)` |
| Антивампиризм | vampiric | Вампиризм атакующего | `vamp = Math.max(0, vamp − targetAntiVampiric)` |

Первые 4 — статы атакующего (снижают шансы защитника). Антивампиризм — стат цели (снижает вампиризм атакующего).

Стоимость прокачки: `10 × 2^level` (0→1=10, 1→2=20, 2→3=40, ...). Личные (player_guild_talents) + гильдийские (guild_talents) — одинаково.

Реализация: `server/src/game/guildBoss.ts` → `getAntiStats()`, `server/src/game/battle.ts` → TurnContext + runTurn.

## Curse System

- Soul Crystal (craft_items id=23) проклинает предмет
- curseValue добавляется к статам НАПРЯМУЮ, без масштабирования от upgradeLevel
- Проклятие = БАФФ, не дебафф

| Rank | Range | Weight | % |
|---|---|---|---|
| I | 10-20 | 160 | 80% |
| II | 20-30 | 24 | 12% |
| III | 30-40 | 12 | 6% |
| IV | 40-50 | 3 | 1.5% |
| V | 50-60 | 1 | 0.5% |

## Equip Sets (I/II/III)

Три слота экипировки. Переключение через CharacterCard табы.

API: `POST /character/switch-equip { slot }`, `POST /character/save-equip-set { slot, equipment }`.

DB: `equipment_1/2/3` (JSONB) + `active_equip_slot`. `equipment` (TEXT) — активный для совместимости с боевым кодом.

Pitfall: JSONB vs TEXT — `equipment_N` возвращается как объект, `equipment` как строка. `parseEq(v) = typeof v === 'string' ? JSON.parse(v) : v`.
