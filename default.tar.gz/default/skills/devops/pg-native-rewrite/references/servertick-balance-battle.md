# ServerTick Architecture — Single WS Bus Pattern

## Overview

Replaced scattered WS push calls (`sendDailyQuestsUpdate()`, etc.) with a centralized
per-user serverTick that sends `{ time, money, bank }` every second, plus
conditional `{ quests, rating, notifications }` on dirty flags.

## Server-side (websocket.ts)

### Dirty flags + markDirty()

```typescript
type DirtyType = 'quests' | 'rating' | 'notifications';
const userDirtyFlags = new Map<number, Set<DirtyType>>();

export function markDirty(userId: number, ...types: DirtyType[]) {
  if (!clients.has(userId)) return;
  let flags = userDirtyFlags.get(userId);
  if (!flags) { flags = new Set(); userDirtyFlags.set(userId, flags); }
  for (const t of types) flags.add(t);
}
```

Replaces all `sendDailyQuestsUpdate(userId).catch(...)` with synchronous
`markDirty(userId, 'quests')` — no `.catch()` needed.

### ServerTick loop

```typescript
const tickInterval = setInterval(() => {
  const time = Math.floor(Date.now() / 1000);
  clients.forEach((_, userId) => {
    sendServerTick(userId, time).catch(e => console.error('serverTick err:', e?.message));
  });
}, 1000);
```

### Per-user payload

```typescript
async function sendServerTick(userId: number, time: number) {
  const payload: any = { type: 'serverTick', time };

  // Money/bank — always (lightweight query)
  const stats = await db.one('SELECT money, bank FROM users WHERE id = ?', [userId]);
  if (stats) { payload.money = stats.money || 0; payload.bank = stats.bank || 0; }

  // Conditional on dirty flags
  const flags = userDirtyFlags.get(userId);
  if (flags?.has('quests')) { payload.quests = await computeQuestData(userId); }
  if (flags?.has('rating')) { payload.rating = await computeRatingData(userId); }
  if (flags?.has('notifications')) { /* drain queue */ }

  ws.send(JSON.stringify(payload));
}
```

### Notification queue

```typescript
export function pushNotification(userId: number, notification: {type, message, data}) {
  if (!clients.has(userId)) return;
  const queue = notificationQueues.get(userId) || [];
  queue.push({ ...notification, id: ++_notificationSeq, createdAt: Math.floor(Date.now()/1000) });
  notificationQueues.set(userId, queue);
  markDirty(userId, 'notifications');
}
```

## Client-side

### ChatContext dispatches enriched serverTick

```typescript
if (data.type === 'serverTick') {
  window.dispatchEvent(new CustomEvent('serverTick', { detail: data.time }));
  if (data.money !== undefined) {
    window.dispatchEvent(new CustomEvent('balance', { detail: { money: data.money, bank: data.bank } }));
  }
  if (data.quests) window.dispatchEvent(new CustomEvent('dailyQuests', { detail: data.quests }));
  if (data.rating) window.dispatchEvent(new CustomEvent('rating', { detail: data.rating }));
  if (data.notifications) window.dispatchEvent(new CustomEvent('notifications', { detail: data.notifications }));
}
```

### Header — WS balance with battle freeze

```typescript
// Balance via WS — instant money update (frozen during battle)
const onBalance = (e: Event) => {
  if ((window as any).__battling) return; // freeze during battle animation
  const { money } = (e as CustomEvent).detail;
  if (money !== undefined) setCharacter(prev => prev ? { ...prev, money } : prev);
};
window.addEventListener('balance', onBalance);
```

### Battle timing: `window.__battling` flag

```typescript
// Set BEFORE fetch to block WS balance during battle
(window as any).__battling = true;
const result = await startBattle(opponent.id);
// ...
// Clear AFTER animation completes or user clicks finish/skip
(window as any).__battling = false;
```

## Battle Rewards Timing

### Problem
`showAcquire()` drops were called with `setTimeout` during battle animation.
`setCharacter()` was called before animation. Money updated via WS balance
before animation finished.

### Fix: Deferred apply via refs (Bestiary)

```typescript
const pendingCharRef = useRef<any>(null);
const pendingDropsRef = useRef<any[]>([]);

// In battle handler: store, don't apply
pendingCharRef.current = fresh;  // character data
pendingDropsRef.current = drops; // loot items

// In nextStep: apply when animation ends
const nextStep = useCallback(async () => {
  if (next >= steps.length) {
    stopAuto();
    applyPending();
    return;
  }
  // ...
}, [...]);

const applyPending = useCallback(() => {
  if (pendingCharRef.current) { setCharacter(pendingCharRef.current); pendingCharRef.current = null; }
  if (pendingDropsRef.current.length > 0) {
    pendingDropsRef.current.forEach((d, i) => setTimeout(() => showAcquire(d, 1, 'Добыто'), i * 400));
    pendingDropsRef.current = [];
  }
  (window as any).__battling = false;
}, []);
```

### Craft
Same pattern: `setCharacter` deferred to CraftPopup `onDone` callback via `pendingData`.
