# Client-side Stat Calculation Pitfalls

## 🔴 `calculateStats()` НЕ включает гильд-бонус (2026-06-23)

**Симптом:** maxHP на странице Охоты (BestiaryPage) отличается от реального. Карточка показывает «824/785» — серверный HP (824) включает гильд-бонус, клиентский (785) — нет.

**Причина:** `calculateStats(character, drinkBonuses, collectionBonus)` вызывался на клиенте и НЕ знал о гильд-бонусе. Серверный `buildPlayerStats` включает ВСЕ бонусы (drinks, collection, guild), клиентский `calculateStats` — только drinks + collection.

**Фикс:** Убрать `calculateStats` из BestiaryPage полностью. Использовать `character.stats` с сервера:
```tsx
// БЫЛО
const pStats = calculateStats(character, (character as any).drinkBonuses, (character as any).collectionCount || 0);

// СТАЛО
const pStats = character.stats || { hp: character.currentHp || 100 };
```

**Правило:** клиент НИКОГДА не вычисляет статы сам. Всегда брать `character.stats` с сервера (вычисляется через `buildPlayerStats` → `currentStats`).

## `calculateStats()` called without `collectionBonus`

**Симптом:** maxHP на арене не совпадает с реальным maxHP. У игрока HP-бар не доходит до конца, статы в CharacterCard отличаются от значений HP-бара.

**Причина:** `calculateStats(character, drinkBonuses)` вызван без третьего параметра `collectionBonus`. Функция имеет сигнатуру:
```ts
calculateStats(char: Character, drinkBonuses?: {...}, collectionBonus?: number): StatBreakdown
```

Без `collectionBonus` бонус коллекции (каждый предмет = +1% к S/A/D/M/HP) не применяется. Результат: для игроков с предметами в коллекции maxHP занижен.

**Где случилось:** `client/src/hooks/useBattleLogic.ts:73` — в `loadOpponent()`:
```ts
// БЫЛО — collectionBonus не передаётся
const pStats = calculateStats(character, (character as any).drinkBonuses);

// СТАЛО
const pStats = calculateStats(character, (character as any).drinkBonuses, (character as any).collectionCount || 0);
```

**Проверка:** grep по всему клиенту — все вызовы `calculateStats` должны передавать `collectionBonus`:
```bash
grep -rn "calculateStats(" client/src/ --include="*.tsx" --include="*.ts" | grep -v "collectionCount\|collectionBonus"
```

**Затронутые места (проверены/исправлены):**
- `ArenaPage.tsx:86` — передаёт `collectionCount` ✓
- `useBattleLogic.ts:73` — БЫЛО без, ИСПРАВЛЕНО ✓
- `LeftSidebar.tsx:17` — передаёт `collectionCount` ✓

## Сервер vs клиент: разница в округлении

Сервер (`currentStats`): `hp = Math.round(s*m) + Math.round(a*m) + Math.round(d*m) + Math.round(m*m)`
Клиент (`calculateStats`): `hp = Math.round((s + a + d + m) * m)`

Разница до 3 HP из-за округления — не критично, но может сбивать с толку при точном сравнении.
