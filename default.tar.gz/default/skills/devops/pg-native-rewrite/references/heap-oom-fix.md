# Heap OOM на low-RAM VPS

## Симптом
`FATAL ERROR: Reached heap limit Allocation failed - JavaScript heap out of memory`

Node.js на VPS с 2GB RAM крашится из-за исчерпания кучи.

## Причина
Node по умолчанию выделяет до ~1.4GB под кучу на машине с 2GB RAM. С учётом ОС, nginx, PostgreSQL свободной памяти не остаётся.

## Фикс
Ограничить кучу флагом `--max-old-space-size`:

```bash
# PM2
pm2 restart game-server --node-args='--max-old-space-size=512'
pm2 save

# Или в ecosystem.config.js / pm2 start
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" --name game-server
```

512MB достаточно для game-server, GC срабатывает раньше.

## Диагностика
```bash
# Проверить текущий лимит
pm2 show game-server | grep 'interpreter args'
# Проверить память процесса
cat /proc/<pid>/status | grep VmRSS
# Общая память VPS
free -h
```
