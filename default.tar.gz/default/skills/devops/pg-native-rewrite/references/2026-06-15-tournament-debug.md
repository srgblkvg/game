# Debugging Tournament Bracket Generation

Session: 2026-06-15. Tournament 639 stuck in in_progress with 0 matches and 8 participants.
The `[bracket] tid=N participants=8` log appeared but no matches were created.

## Root cause
`generateBracket` was called, participants found, but INSERT silently failed.
The `db.run` catch block (when RETURNING id fails) sets `lastInsertRowid: 0`.
Bye-handling code then attempts `UPDATE ... WHERE id = 0` (no-op).
The bye match stays with `winnerId IS NULL`, `resolveCurrentRound` can't resolve it
(because player2Id is NULL), loops forever.

## Key debugging steps

### 1. Check tournament state directly
```sql
SELECT id,status FROM tournaments WHERE status IN ('in_progress','registration');
SELECT * FROM tournament_matches WHERE tournamentid = <id>;
SELECT tp.*, u.username FROM tournament_participants tp JOIN users u ON tp.userid=u.id WHERE tp.tournamentid = <id>;
```

### 2. Test generateBracket INSERT in isolation
```js
// From server directory
const sql = "INSERT INTO tournament_matches (...) VALUES (?, 1, ?, ?, NULL)";
const q = pgParams(pgLower(sql));
const r = await pool.query(q, [tid, p1Id, p2Id]);
// Check: r.rowCount should be 1
```

### 3. Test camelRows on participant data
The participant query returns lowercase PG keys. Verify camelRows adds `userId`, `tournamentId`:
```js
const rows = camelRows(r.rows);
console.log(rows[0].userId, rows[0].tournamentId);
```

### 4. Check for `p.userId` vs `p.userid`
If camelRows didn't add the camelCase key, `p.userId` is undefined → `p1Id = null` → both null → `continue` → no match created.
Fallback: use `p.userid` (PG lowercase key) directly.

## Infinite loop pattern in autoAdvance
```
[bracket] tid=639 participants=8
[autoAdv] tid=639 in_progress but 0 matches - regenerating bracket
[bracket] tid=639 participants=8
[autoAdv] tid=639 in_progress but 0 matches - regenerating bracket
... (repeats until timeout)
```
Fix: add matchCount==0 check that calls generateBracket, then recurses. After bracket created,
the recursive call finds matchCount>0 and proceeds through resolveCurrentRound → advanceWinners → finishTournament.

## Verifying the fix
After restart + GET /api/tournament (as authenticated user):
```sql
SELECT id,status FROM tournaments WHERE id=<id>;
-- Should show 'completed'
SELECT round,player1id,player2id,winnerid FROM tournament_matches WHERE tournamentid=<id>;
-- Should have matches with winnerid set
```
