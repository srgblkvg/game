# Гильдийские войны: таймеры на клиенте

## Паттерн countdown с useState(Date.now())

Для бегущих таймеров на кнопках атаки в `GuildWarPage.tsx` используется паттерн
с состоянием `now`, которое обновляется каждую секунду через `setInterval`:

```tsx
const [now, setNow] = useState(Date.now());

useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(iv);
}, []);
```

Функция `countdown()` принимает `until` (ISO-строка или null) и `now` (текущее время из state):

```tsx
function countdown(until: string | null, now: number): string {
    if (!until) return '';
    const sec = Math.max(0, Math.ceil((new Date(until).getTime() - now) / 1000));
    if (sec <= 0) return '';
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m > 0 ? `${m}:${String(s).padStart(2, '0')}` : `0:${String(s).padStart(2, '0')}`;
}
```

**Важно:** `now` передаётся как ПАРАМЕТР в `countdown()`, а не используется `Date.now()` внутри.
Это нужно чтобы React видел зависимость и перерисовывал компонент при изменении `now`.

**НЕ работает паттерн с `useState(0)` + `setTick(t => t + 1)`** — React не видит связь
между tick и Date.now() внутри countdown и не перерисовывает.

### Использование в JSX

```tsx
const attackCd = countdown(data.attackCooldownUntil, now);
const protCd = countdown(m.protectedUntil, now);
```

### Отображение на кнопке атаки

```tsx
<Button disabled={cantAttack} onClick={...}>
  {hasCooldown ? `⏳${attackCd}` : protCd ? '🛡️' : myLimit ? '⛔' : defLimit ? '🔒' : '⚔️'}
</Button>
```

Таймер защиты (`🛡️59:23`) показывается ОТДЕЛЬНО в строке игрока, НЕ на кнопке:
```tsx
{protCd && <span>🛡️{protCd}</span>}
```
