# Синхронное применение отложенных данных через refs в nextStep

## Проблема: useEffect + pendingState — гонка на быстрой анимации

Паттерн: бой возвращает результат → данные персонажа (деньги, опыт, дроп) откладываются через `useState` → `useEffect` применяет когда `currentStep >= battleSteps.length - 1`.

На скорости ×2/×5 анимация заканчивается быстрее чем срабатывает `useEffect`:
1. `setBattleSteps(result.steps)` → рендер → старт анимации
2. `fetchCharacter()` → `setPendingCharacter(fresh)` → рендер
3. Анимация на ×2 заканчивается за 2-3 секунды
4. `setCurrentStep(lastStep)` → эффект проверяет условие
5. **Но React может сбатчить обновления state'ов** → эффект срабатывает с устаревшим `currentStep`

**Симптом:** награда (деньги, дроп) зачисляется до того как анимация визуально закончилась. Баланс в Header обновляется, showAcquire показывается, а бой ещё «идёт» на экране.

## Решение: refs + синхронный вызов в nextStep

```tsx
// Вместо useState для pending данных:
const pendingCharRef = useRef<any>(null);
const pendingDropsRef = useRef<any[]>([]);

// applyPending — вызывается СИНХРОННО при достижении конца анимации
const applyPending = useCallback(() => {
    if (pendingCharRef.current) {
        setCharacter(pendingCharRef.current);
        pendingCharRef.current = null;
    }
    if (pendingDropsRef.current.length > 0) {
        pendingDropsRef.current.forEach((d, i) => {
            setTimeout(() => showAcquire(d, 1, 'Добыто'), i * 400);
        });
        pendingDropsRef.current = [];
    }
    window.dispatchEvent(new CustomEvent('battleEnd'));
    (window as any).__battling = false;
}, [setCharacter, showAcquire]);

// В nextStep — при достижении конца:
const nextStep = useCallback(async () => {
    // ...
    if (next >= steps.length) {
        stopAuto();
        applyPending();  // ← синхронно, без задержки useEffect
        return;
    }
    // ...
}, [/* ... */, applyPending]);

// При старте боя — пишем в refs:
pendingDropsRef.current = drops;
pendingCharRef.current = fresh;
```

## Почему useEffect ломается именно на быстрой скорости

`useEffect` срабатывает ПОСЛЕ рендера. На ×1 анимация длится 10-15 секунд — fetchCharacter успевает за 300ms, pendingCharacter установлен задолго до конца анимации. Когда `currentStep` доходит до конца, эффект сразу видит и `pendingCharacter`, и правильный `currentStep` — всё работает.

На ×2 анимация длится 3-5 секунд. `fetchCharacter` всё ещё 300ms. Но React может сбатчить обновления `setPendingCharacter` и `setCurrentStep` в одном рендере — эффект срабатывает ДО того как `currentStep` реально обновился в DOM/визуально.

## Где применено

- `client/src/pages/BestiaryPage.tsx` — PvE бои
- `client/src/hooks/useBattleLogic.ts` — Арена (там applyPending не нужен — награды применяются по кнопке «Вернуться»)

## Антипаттерн: useEffect с несколькими зависимостями для отложенного применения

```tsx
// ❌ НЕ ДЕЛАТЬ
useEffect(() => {
    if (currentStep >= battleSteps.length - 1 && pendingCharacter) {
        setCharacter(pendingCharacter);
        // ...
    }
}, [currentStep, battleSteps.length, pendingCharacter, pendingDrops]);
```

Причина: каждая зависимость может измениться в разных рендерах, и эффект срабатывает в непредсказуемый момент относительно визуального состояния анимации.
