# db.run() — НИКОГДА не добавлять RETURNING id в SQL

`db.run()` (db/index.ts:140) автоматически добавляет `RETURNING id` для всех INSERT-запросов.

**Если SQL уже содержит `RETURNING id`**, результат будет `RETURNING id RETURNING id` → синтаксическая ошибка. catch-блок выполняет запрос заново без RETURNING, но всегда возвращает `lastInsertRowid: 0`.

**Симптомы:**
- `result.lastInsertRowid` всегда 0
- `gameId` всегда 0, последующие `SELECT WHERE id = 0` не находят запись
- Логика, полагающаяся на вставленный ID, молча ломается

**Пример (неправильно):**
```typescript
const result = await db.run(
    "INSERT INTO dice_games (user_id, entry_fee, dice, rerolls, status) VALUES (?, ?, ?, 0, 'active') RETURNING id",
    [userId, bet, JSON.stringify(dice)]
);
const gameId = result.lastInsertRowid; // всегда 0!
```

**Пример (правильно):**
```typescript
const result = await db.run(
    "INSERT INTO dice_games (user_id, entry_fee, dice, rerolls, status) VALUES (?, ?, ?, 0, 'active')",
    [userId, bet, JSON.stringify(dice)]
);
const gameId = result.lastInsertRowid; // реальный ID
```

**Правило:** INSERT через `db.run()` — без `RETURNING id`. Он добавится сам.
