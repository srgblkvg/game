# Low-Memory VPS Optimization

Session: 2026-06-21. Server OOM crashes every 1-2 minutes, 256+ PM2 restarts. Final resolution: Node.js + correct heap sizing + disabled serverTick + database cleanup.

## Root Cause Evolution

### Phase 1: 955MB VPS with 50 bots + PostgreSQL
`serverTick` every 1s per user + 50 bots active + 427K tournament_matches (334MB DB) = guaranteed OOM on 1GB VPS.

### Phase 2: 2GB VPS, bots deleted, database cleaned
Remaining issue: tsx compilation overhead + serverTick + large response processing. Stack traces showed `FatalProcessOutOfMemory` with `NewStringFromUtf8` — heap exhausted during string allocations from large DB responses (427K rows loaded into memory).

### Phase 3: Node.js with correct heap sizing
`--max-old-space-size=512` still OOM. `--max-old-space-size=1024` with compiled JS + serverTick disabled = STABLE. But compiled JS had issues with `export default router` being commented out by sed, causing `TypeError: argument handler must be a function`.

### Phase 4: Final stable config
```bash
pm2 start "PORT=3001 node --max-old-space-size=1024 --require .../tsx/... server/src/index.ts" \
  --name game-server --max-memory-restart 1300M
```
- tsx runtime (source TypeScript, no tsc compilation)
- heap 1024MB, PM2 limit 1300MB
- serverTick TODO (balance + quests + rating every 1s)
- DISABLE_RATE_LIMIT=true
- Database cleaned (379MB → 46MB)
- Bots deleted from DB (50 accounts removed)
- Tournament N+1 queries fixed
- 0 crashes, 135MB RSS, 1.5GB available

## Tool Quirks Discovered

### write_file corrupts `process.env.JWT_SECRET!`
The `write_file` tool replaces `process.env.JWT_SECRET!` with `proces...CRET` in the written file. The `!` character (TypeScript non-null assertion) triggers internal truncation. **Workaround:** use `patch` or `terminal` with heredoc/printf for files containing `!` after all-caps identifiers. Verified via `xxd` that terminal DISPLAY also shows truncation but actual bytes are correct.

### terminal truncates `process.env.*` in output
Commands like `head -4 file.ts` display `proces...CRET` but the file contains the correct bytes. Use `xxd` to verify actual content.

## camelRows Memory Impact

The `camelRows` function in `db/index.ts` processes every DB query result row-by-row with:
- 80+ alternative regex for suffix detection
- 30+ individual `.replace()` chains for compound words
- String-to-number conversion for bigint detection

Each API call triggers 1-5 DB queries, each going through `camelRows`. At 3-5 queries per page load × hundreds of replacements = significant GC pressure.

**Cannot easily remove** — every route uses camelCase property names (`row.userId`, `row.guildName`, etc.).
