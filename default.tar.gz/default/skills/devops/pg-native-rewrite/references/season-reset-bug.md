# Сезонный сброс — баг с camelCase `date`

## Симптом
При каждом логине ELO игрока мягко сбрасывается: `1000 + (ELO−1000)×0.5`. За ночь при нескольких входах ELO падает на сотни очков.

## Причина
В `camelRows` не было суффикса `date` → колонка `enddate` не конвертировалась в `endDate`.
В `checkSeasonReset()` условие `if (now < endDate)` при `endDate = undefined` всегда `false` → сброс сезона при каждом логине.

```typescript
// season.endDate === undefined (не enddate, не camelCase)
const now = new Date();
const endDate = new Date(season.endDate);  // Invalid Date
if (now < endDate) return false;  // always false → reset runs
```

## Фикс
1. Добавить `date` в суффикс-регулярку `camelRows`
2. Убрать автосброс при логине — перенести в ручную админку
3. Почистить сломанные дубликаты сезонов в БД

## Админ-эндпоинт
`POST /admin/seasons/finish` — завершает текущий сезон, архивирует топ-10, мягко сбрасывает ELO, создаёт новый.
`GET /admin/seasons` — список последних 10 сезонов.
