# Base64 image upload (без файлового сервера)

Паттерн для загрузки изображений когда нет файлового сервера (multer, S3, etc).

## Клиент: File → base64 data URL → JSON

```tsx
<input
    type="file"
    accept="image/*"
    className="hidden"
    onChange={(e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
            const dataUrl = reader.result as string;  // "data:image/png;base64,..."
            // Отправить на сервер как JSON
            fetch('/api/endpoint', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image: dataUrl }),
            });
        };
        reader.readAsDataURL(file);
    }}
/>
```

## Сервер: принять и сохранить в TEXT колонку

```typescript
// schema.sql
ALTER TABLE guilds ADD COLUMN image TEXT;

// route
const { image } = req.body;
if (image !== undefined) {
    await db.run('UPDATE guilds SET image = ? WHERE id = ?', [image, guildId]);
}
```

## Отображение

```tsx
{guild.image && <img src={guild.image} alt="Герб" className="w-12 h-12 object-cover rounded" />}
```

## Ограничения

- Размер: base64 увеличивает размер на ~33%. Рекомендовать маленькие изображения (до 100KB).
- PG TEXT колонка вмещает до ~1GB, но лучше держать в разумных пределах.
- Для production с большими изображениями — перейти на файловый сервер (S3, local storage).
