# Мобильные тач-события: useLongPress и защита от синтетического click

## useLongPress — touchMove вызывает cancel, не end

Баг: `onTouchMove` вызывал `end()`, которая не только отменяла таймер, но и вызывала `onClick`. На мобильных малейшее движение пальца → `touchmove` → `onClick` → затем `touchend` → `onClick` повторно. Двойное срабатывание и потеря короткого тапа.

Фикс: разделить `cancel()` (только сброс таймера) и `end()` (сброс таймера + вызов onClick если короткий тап):

```typescript
const cancel = useCallback(() => {
    if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
    }
}, []);

const end = useCallback((e) => {
    cancel();
    if (!isLongPress.current && onClick) {
        onClick(e);
    }
    isLongPress.current = false;
}, [onClick, cancel]);

return {
    onTouchStart: start,
    onTouchEnd: end,
    onTouchMove: cancel,  // только отмена таймера, без onClick
    onMouseDown: start,
    onMouseUp: end,
};
```

## Синтетический click закрывает попап на мобильных

Симптом: попап открывается и мгновенно закрывается (видно на долю секунды).

Причина: на мобильных браузер генерирует синтетический `click` через ~300мс после `touchend`. Попап открывается по `touchend`, но через 300мс `click` попадает в оверлей (затемнённый фон с `onClick={() => close()}`) и мгновенно закрывает попап.

Фикс: записывать время открытия попапа и игнорировать клики по оверлею в первые 400мс:

```typescript
const confirmOpenTime = useRef(0);

// При открытии:
confirmOpenTime.current = Date.now();

// В оверлее:
onClick={() => {
    if (Date.now() - confirmOpenTime.current > 400) {
        close();
    }
}}
```

## Прямой onClick для гарантии на мобильных

При использовании `useLongPress` на мобильных тач-события могут не всегда корректно доставляться. Добавление прямого `onClick` на элемент гарантирует срабатывание через синтетический `click` браузера:

```jsx
<div
    {...longPress}  // для тултипов по долгому нажатию
    onClick={canAdd ? onAdd : undefined}  // прямой клик для действия
>
```
