# guild_quests: 500 — Express routing + sequence permissions

**Дата:** 2026-06-17
**Ветка:** pg-native
**Эндпоинт:** `GET /api/guild/quest` → 500

## Настоящая причина (Express routing)

`router.get('/guild/:id', ...)` (стр. 234) зарегистрирован **раньше** чем `router.get('/guild/quest', ...)` (стр. 1016). Express матчит `/guild/quest` как `/guild/:id` с `id = "quest"` → `parseInt("quest")` → `NaN` → PG `invalid input syntax for type integer: "NaN"` → 500.

Серверный лог показывал ошибку на `guild.ts:236` (строка `:id`-обработчика), а не на `/quest`-обработчике — это сбило с толку при диагностике.

**Фикс:** 
```typescript
router.get('/guild/:id', async (req, res, next) => {  // добавлен next
    const guildId = parseInt(req.params.id);
    if (isNaN(guildId)) return next();                 // пропускаем /guild/quest
```

**Почему работало на SQLite:** `NaN` в `WHERE id = NaN` молча возвращал 0 rows → 404, а PG жёстко падает с ошибкой типа.

## Вторичная проблема (последовательность — red herring)

После фикса routing, при АКТИВНОМ квесте (INSERT через `db.run`) могла проявиться ошибка `permission denied for table guild_quests` — sequence `guild_quests_id_seq` во владении `postgres`, у `game` нет USAGE.

## Структура таблицы на проде (до фикса)

| column      | type      | nullable | default           |
|-------------|-----------|----------|-------------------|
| id          | integer   | NO       | nextval(seq)      |
| guildid     | integer   | NO       | null              |
| questtype   | text      | NO       | null              |
| difficulty  | text      | NO       | null              |
| requirement | integer   | NO       | null              |
| progress    | integer   | YES      | 0                 |
| rewardxp    | integer   | NO       | **null** (нет DEFAULT) |
| status      | text      | YES      | 'active'::text    |
| snapshot    | text      | YES      | null              |
| createdat   | timestamptz | YES    | now()             |

Владелец: `postgres`. Sequence `guild_quests_id_seq` — владелец `postgres`.

## Фикс

```sql
-- От имени postgres (через скрипт на VPS)
GRANT USAGE, SELECT ON SEQUENCE guild_quests_id_seq TO game;
```

После GRANT и `pm2 restart game-server` ошибка исчезла. `rewardxp` без DEFAULT не критично — INSERT всегда передаёт значение.

## Профилактика

- Любая новая таблица на проде → сразу `GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO game`.
- `schema.sql` должен быть каноническим источником — проверить grep-ом все `CREATE TABLE`.
