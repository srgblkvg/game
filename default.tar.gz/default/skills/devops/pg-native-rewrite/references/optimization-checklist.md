# Оптимизации для low-RAM VPS (2GB)

Актуальный чеклист — применено в сессии 2026-06-21.

## 1. Pre-compile tsc (убрать tsx)

tsx/esbuild жрёт ~80-100MB при компиляции и периодически крашится с OOM на 2GB.

**Решение:** компилировать через `npx tsc` и запускать скомпилированный `dist/index.js`:

```bash
cd /opt/game/server && npx tsc
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" --name game-server --max-memory-restart 900M
```

Результат: 94MB vs 146MB RAM, 0 крашей vs каждые 10 секунд с tsx.

## 2. Индексы БД

После миграции есть только PRIMARY KEY индексы. Критические:

```sql
CREATE INDEX idx_users_level ON users(level);
CREATE INDEX idx_users_elo ON users(elo);
CREATE INDEX idx_users_guildid ON users(guildid);
CREATE INDEX idx_users_lastaction ON users(lastaction);
CREATE INDEX idx_tournament_participants_tid ON tournament_participants(tournamentid);
CREATE INDEX idx_tournament_matches_tid ON tournament_matches(tournamentid);
CREATE INDEX idx_chat_messages_createdat ON chat_messages(createdat);
CREATE INDEX idx_chat_messages_senderid ON chat_messages(senderid);
CREATE INDEX idx_battles_attackerid ON battles(attackerid);
CREATE INDEX idx_auction_lots_sellerid ON auction_lots(sellerid);
CREATE INDEX idx_collections_userid ON collections(userid);
CREATE INDEX idx_daily_quests_userid_date ON daily_quests(userid, date);
CREATE INDEX idx_pve_battles_userid ON pve_battles(userid);
CREATE INDEX idx_job_history_userid ON job_history(userid);
```

## 3. Батчинг serverTick

БЫЛО: N запросов для N пользователей (money/bank per-user).
СТАЛО: один `SELECT ... WHERE id IN (...)` для всех, потом раздача per-ws.

```typescript
const userIds = Array.from(clients.keys());
const rows = await db.query(
  `SELECT id, money, bank, COALESCE(auction_sales,0) as auctionSales FROM users WHERE id IN (${placeholders})`,
  userIds
);
const batch = new Map(rows.map(r => [r.id, r]));
for (const userId of userIds) {
  const stats = batch.get(userId);
  // send to ws...
}
```

Квесты/рейтинг/нотификации — только если есть dirty-флаги (per-user, редко).

## 4. nginx кеширование статики

```nginx
location /assets/ {
    alias /opt/game/client/dist/assets/;
    expires 30d;
    add_header Cache-Control "public, immutable";
}
location /uploads/ {
    alias /opt/game/server/uploads/;
    expires 7d;
    add_header Cache-Control "public, immutable";
}
```

WebSocket прокси:
```nginx
location /ws {
    proxy_pass http://127.0.0.1:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}
```

## 5. Pool БД: max 5

Было `max: 20` — каждый коннект ~25MB = 500MB потенциал.
Стало `max: 5, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000`.

Расчёт: 100 игроков × 2 запроса/мин = 3 запроса/сек. Каждый коннект обрабатывает запрос за ~20ms. 5 коннектов = 250 запросов/сек. Запас ×80.

## 6. Очистка старых данных (>7 дней)

Боты (50 шт.) за ночь нагенерили:
- 427K tournament_matches (334MB)
- 7.5K chat_messages
- DB выросла с ~50MB до 379MB

**Фикс:** cleanup.ts с ежедневным удалением:
```typescript
// Удалить tournament_matches старше 7 дней
await db.run('DELETE FROM tournament_matches WHERE tournamentId IN (SELECT id FROM tournaments WHERE completedAt IS NOT NULL AND completedAt::bigint < ?)', [cutoff]);
// Удалить chat_messages старше 7 дней
await db.run('DELETE FROM chat_messages WHERE createdAt < ?', [cutoffIso]);
// Удалить pve_battles, battles, auction_history старше 7 дней
// VACUUM после очистки
```

Вызов: `setInterval(cleanupOldData, 24 * 3600 * 1000)` в index.ts.

## 7. Боты: защита от перегрузки

- НЕ запускать ботов без лимита по времени
- 50 ботов = 50× нагрузка = OOM даже на 2GB
- После очистки ботов: `DELETE FROM bot_accounts WHERE active = 1`
- Боты хранятся в `bot_accounts` таблице, запускаются через админку

## 8. Важные конфиги PM2

```bash
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" \
  --name game-server \
  --max-memory-restart 900M
pm2 save --force
systemctl enable pm2-root  # автостарт при ребуте
```

## Результат (2GB VPS, 100 игроков)

| Метрика | До | После |
|---|---|---|
| RAM процесса | 146MB (tsx) | 94-123MB |
| Краши | каждые 10с | 0 |
| DB запросов/тик | N (per-user) | 1 (batched) |
| Пулы БД | 20 | 5 |
| Индексы | только PK | 14 |
| Статика | через Node | nginx cache 30d |
| Очистка данных | ручная | авто (7 дней) |
