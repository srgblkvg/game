# Overflow Storage — склад переполнения для аукциона

## Проблема
При выкупе предмета с аукциона, если инвентарь покупателя заполнен, предмет теряется. Нужно временное хранилище.

## Схема БД
```sql
CREATE TABLE overflow_storage (
  id SERIAL PRIMARY KEY,
  userId INTEGER NOT NULL,
  item JSONB NOT NULL,
  auctionLotId INTEGER,
  createdAt INTEGER DEFAULT EXTRACT(EPOCH FROM NOW())::INTEGER
);
CREATE INDEX idx_overflow_userid ON overflow_storage(userId);
```

**После создания — GRANT:**
```sql
GRANT ALL ON overflow_storage TO game;
GRANT ALL ON overflow_storage_id_seq TO game;
```

## API

### GET /api/overflow
Возвращает массив предметов на складе для текущего пользователя.

### POST /api/overflow/take/:id
Забирает предмет в инвентарь. Проверяет заполненность инвентаря (только снаряжение со `.slot`). Материалы/камни — всегда помещаются.

## Подсчёт слотов инвентаря
**Только снаряжение** занимает слоты (`!!item.slot`). Материалы (`craft_item`, `material`, `upgrade`) НЕ занимают слоты. Камни улучшения тоже НЕ занимают.

```typescript
const isGear = !!item.slot;
const equipCount = inventory.filter(i => !!i.slot).length;
if (isGear && equipCount >= maxSlots) {
  // Инвентарь полон — на склад
}
```

## Интеграция в аукцион

### При покупке (buyout)
- Инвентарь полон → ошибка «Инвентарь заполнен»

### При авто-завершении (auto-resolution)
- Инвентарь полон → `addToOverflow(buyerId, itemData, lot.id)`
- Есть место → push в инвентарь

## Клиент
- Компонент `OverflowStorage.tsx` — под инвентарём
- Иконка `game-icons:locked-chest`
- Тултипы через `ItemTooltip`
- Drag-and-drop в инвентарь
- Клик → `POST /api/overflow/take/:id` → обновление character
