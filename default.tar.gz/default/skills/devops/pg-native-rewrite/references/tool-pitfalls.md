# Tool Pitfalls

## write_file corrupts `process.env.JWT_SECRET`

**Symptom:** `write_file` truncates `process.env.JWT_SECRET!` to `proces...CRET!` — three dots in the middle. JWT verification fails silently.

**Check:** `grep JWT_SECRET file.ts` shows `const JWT_SECRET=proces...T!;`

**Fix:** always verify with `xxd file.ts | grep JWT_SECRET` after write_file. If corrupted, rewrite the line via Python or sed.

**Alternative:** use `patch` tool for small changes instead of `write_file` for whole files.

## patch tool introduces escaped quotes

`patch` with `old_string` containing `\"` or `\\"` can introduce literal backslashes in the file. TypeScript/esbuild fails with `Syntax error '"'`.

**Symptom:** `TransformError: Syntax error '\"'` at the patched line.

**Fix:** verify the line with `sed -n 'LINEP' file.ts | cat -A`. If it shows `\"`, rewrite via Python:
```python
lines = open('file.ts').readlines()
lines[LINE-1] = 'correct line\n'
open('file.ts','w').writelines(lines)
```

## Shell heredoc with `$` and `!` breaks

Heredoc syntax `cat > file << 'EOF'` inside `terminal()` can break on `$` and `!` characters. Use Python to write files on the server, or scp from local.

## SSH commands with `$()` break

`$()` inside shell commands through `terminal()` gets evaluated by the local shell. Use single-quoted heredocs or write scripts to files on the server.

## pkill kills SSH session

`pkill -9 -f "bun run"` inside SSH can kill the SSH process itself if it matches the pattern. Use more specific patterns or separate commands.
