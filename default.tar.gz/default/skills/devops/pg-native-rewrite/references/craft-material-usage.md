# CraftPage: materialUsage и камни улучшения

## Баг: камень улучшения исчезал из инвентаря при возврате из слота

**Симптом:** при переносе камня улучшения из блока крафта обратно в инвентарь (клик по слоту или drag-and-drop), камень в инвентаре не отображается.

**Причина:** `handleMaterialClick` (добавление в слот) увеличивал `materialUsage[stoneId]` для ВСЕХ craft-предметов, включая камни улучшения. Но `handleSlotClick` (возврат из слота) НЕ уменьшал `materialUsage` для камней улучшения — было условие `if (item.itemType !== 'upgrade')`.

Это приводило к тому, что `displayInventory` считал `remaining = count - used = 0`, и камень фильтровался из отображения.

**Фикс:** убрать условие `itemType !== 'upgrade'` в `handleSlotClick` и `handleDropOnInventory` — теперь `materialUsage` корректно уменьшается для ВСЕХ craft-предметов, включая upgrade-камни.

```typescript
// handleSlotClick — было:
if (isCraftItem(item)) {
    if (item.itemType !== 'upgrade') {
        setMaterialUsage(prev => { ... decrement ... });
    }
}

// Стало:
if (isCraftItem(item)) {
    setMaterialUsage(prev => { ... decrement ... });
}
```

## Баг: перетаскивание стака камней — весь стак в слот

**Симптом:** при перетаскивании камня улучшения с `count: 3` в слот крафта, в слот помещается весь стак (3 камня), а не 1.

**Причина:** в `handleDropOnSlot` и `handleItemClick` условие `isCraftItem(item) && item.itemType !== 'upgrade'` пропускало камни улучшения в else-ветку, где предмет помещался в слот целиком (`n[index] = item`), без `{ ...item, count: 1 }` и без отслеживания `materialUsage`.

**Фикс:** унифицировать логику — все craft-предметы (включая upgrade-камни) помещаются в слот с `count: 1` и отслеживаются через `materialUsage`:

```typescript
if (isCraftItem(item)) {
    const used = materialUsage[item.id] || 0;
    if (used >= getOriginalCraftItemCount(item.id)) return;
    setMaterialUsage(prev => ({ ...prev, [item.id]: (prev[item.id] || 0) + 1 }));
    setCraftSlots(prev => { const n = [...prev]; n[index] = { ...item, count: 1 }; return n; });
} else {
    setCraftSlots(prev => { const n = [...prev]; n[index] = item; return n; });
}
```

## displayInventory — как работает фильтрация

Ключевая функция в CraftPage, которая вычисляет что показывать в инвентаре:

```typescript
const displayInventory = useMemo(() => {
    // ID предметов экипировки, которые сейчас в слотах крафта
    const slotIds = new Set(craftSlots.filter(s => s !== null && !isCraftItem(s)).map(s => s.id));
    return character.inventory
        .filter(item => !slotIds.has(item.id))  // убрать экипировку в слотах
        .map(item => {
            if (isCraftItem(item)) {
                const used = materialUsage[item.id] || 0;
                const remaining = item.count - used;  // вычесть использованные материалы/камни
                return remaining > 0 ? { ...item, count: remaining } : null;
            }
            return item;
        })
        .filter(Boolean);
}, [character.inventory, craftSlots, materialUsage]);
```

Правило: любой craft-предмет (материал или камень), добавленный в слот, ДОЛЖЕН увеличивать `materialUsage`. При возврате — уменьшать. Иначе `displayInventory` покажет неверное количество.
