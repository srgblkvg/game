# Аукцион: FOR UPDATE и история сделок

## Гонка ставок (race condition)

Два одновременных запроса читают `SELECT * FROM auction_lots WHERE id = N` и видят `currentBid = null`.
Оба проходят проверку `amount >= startPrice` и делают UPDATE. Вторая ставка перезаписывает первую,
деньги первого игрока теряются.

**Фикс:** обернуть всю логику ставки в `db.tx()` + `SELECT ... FOR UPDATE`:

```typescript
await db.tx(async (client) => {
    const lot = (await client.query(
        'SELECT * FROM auction_lots WHERE id = $1 AND endsAt > $2 FOR UPDATE',
        [lotId, now]
    )).rows[0];
    // ... вся логика ставки внутри транзакции
});
```

`FOR UPDATE` блокирует строку до конца транзакции — конкурентные запросы ждут друг друга.

**Важно:** внутри `db.tx` используется `client.query()` напрямую (сырой PG). Ключи в ответе — lowercase.
Нужно явно делать `parseInt(lot.currentbid)`, `parseInt(lot.startprice)` и т.д.

## История сделок

Таблица `auction_history`:
```sql
CREATE TABLE IF NOT EXISTS auction_history (
    id SERIAL PRIMARY KEY,
    sellerId INTEGER NOT NULL,
    buyerId INTEGER NOT NULL,
    itemName TEXT NOT NULL,
    itemData TEXT,
    price INTEGER NOT NULL,
    commission INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL
);
```

INSERT при каждом выкупе (buyout, buy-partial). Эндпоинт `GET /auction/history` — общий для всех.

## Уведомление продавца

При выкупе — `pushNotification(sellerId, { type: 'auction_sold', message: '...' })`.
Клиентский бейдж на карточке Аукциона отслеживает `auction_sold` через глобальную переменную
`window.__auctionBadge` (чтобы бейдж переживал навигацию между страницами).
