# Auction bid race condition — full analysis

## The Bug

Two simultaneous bids on the same lot could both read `currentBid = null` 
and both be accepted at `startPrice`. Occurs because:

1. Bid A: `SELECT * FROM auction_lots WHERE id = 96` → `currentBid = null`
2. Bid B: `SELECT * FROM auction_lots WHERE id = 96` → `currentBid = null` (Bid A hasn't committed yet)
3. Bid A: `UPDATE ... SET currentBid = 1100`
4. Bid B: `UPDATE ... SET currentBid = 1100` (overwrites Bid A's value)
5. Both return `{ success: true }` — both accepted at same price

## The Fix

`db.tx()` + `SELECT ... FOR UPDATE` locks the row for the duration of the transaction:

```typescript
await db.tx(async (client) => {
    const lot = (await client.query(
        'SELECT * FROM auction_lots WHERE id = $1 AND endsAt > $2 FOR UPDATE',
        [lotId, now]
    )).rows[0];
    // Lot row is now locked — concurrent bids wait here
    // ... check minBid, deduct money, update ...
    await client.query('UPDATE auction_lots SET currentBid = $1, currentBidderId = $2 WHERE id = $3', [...]);
});
```

`FOR UPDATE` ensures Bid B's SELECT waits until Bid A's transaction commits.
On commit, Bid B sees the updated `currentBid = 1100` and minBid = 1155 → 
Bid B's 1100 is below minBid → rejected with error.

## Key Lessons

1. Any financial operation with read-then-write MUST use transactions
2. `FOR UPDATE` is PG's row-level lock — essential for concurrent safety
3. Inside `db.tx` callback, use `client.query()` → lowercase PG keys
4. `parseInt()` all numeric values from PG results (they may be strings)
