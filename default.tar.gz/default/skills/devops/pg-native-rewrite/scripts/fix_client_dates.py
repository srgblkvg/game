#!/usr/bin/env python3
"""Fix all new Date(... * 1000) patterns in client code to use safeDate/fmtSafeDate."""
import re, os

BASE = '/opt/game/client/src'

FILES = [
    ('pages/BankPage.tsx', [
        (r"import \{ getHeaders, BASE_URL \} from '\.\./api/helpers';",
         r"import { getHeaders, BASE_URL } from '../api/helpers';\nimport { fmtSafeDate, safeDate } from '../utils/date';"),
        (r"new Date\(b\.createdAt \* 1000\)\.getTime\(\)-new Date\(a\.createdAt \* 1000\)\.getTime\(\)",
         r"(safeDate(b.createdAt)?.getTime()||0)-(safeDate(a.createdAt)?.getTime()||0)"),
        (r"\{new Date\(h\.createdAt \* 1000\)\.toLocaleString\(\)\}",
         r"{fmtSafeDate(h.createdAt)}"),
        (r"\{new Date\(o\.createdAt \* 1000\)\.toLocaleString\(\)\}",
         r"{fmtSafeDate(o.createdAt)}"),
        (r"\{new Date\(t\.createdAt \* 1000\)\.toLocaleString\(\)\}",
         r"{fmtSafeDate(t.createdAt)}"),
    ]),
    ('pages/TournamentPage.tsx', [
        (r"import \{ getHeaders, BASE_URL \} from '\.\./api/helpers';",
         r"import { getHeaders, BASE_URL } from '../api/helpers';\nimport { fmtSafeDate } from '../utils/date';"),
        (r"\{new Date\(t\.createdAt \* 1000\)\.toLocaleDateString\('ru-RU'\)\}",
         r"{fmtSafeDate(t.createdAt, { day:'2-digit', month:'2-digit', year:'2-digit' })}"),
    ]),
    ('pages/AdminPanel/AdminUsers.tsx', [
        (r"import \{ getHeaders, BASE_URL \} from '\.\./\.\./api/helpers';",
         r"import { getHeaders, BASE_URL } from '../../api/helpers';\nimport { safeDate, fmtSafeDate } from '../../utils/date';"),
        (r"return new Date\(value \* 1000\)\.toLocaleDateString\('ru-RU', \{ day: '2-digit', month: '2-digit' \}\);",
         r"return fmtSafeDate(value, { day:'2-digit', month:'2-digit' });"),
        (r"\{user\.bannedUntil \? new Date\(user\.bannedUntil \* 1000\)\.toLocaleString\('ru-RU'\) : 'Нет'\}",
         r"{user.bannedUntil ? fmtSafeDate(user.bannedUntil) : 'Нет'}"),
    ]),
    ('pages/AdminPanel/AdminTournaments.tsx', [
        (r"return new Date\(ts \* 1000\)\.toLocaleString\('ru-RU', \{ day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' \}\);",
         r"return fmtSafeDate(ts, { day:'2-digit', month:'2-digit', year:'2-digit', hour:'2-digit', minute:'2-digit' });"),
        (r"const d = new Date\(ts \* 1000\);",
         r"const d = safeDate(ts);"),
    ]),
    ('pages/AdminPanel/AdminChat.tsx', [
        (r"\{new Date\(u\.chatBannedUntil \* 1000\)\.toLocaleString\(\)\}",
         r"{fmtSafeDate(u.chatBannedUntil)}"),
    ]),
    ('contexts/ChatContext.tsx', [
        (r"setChatError\(`Вы заблокированы в чате до \$\{new Date\(data\.until \* 1000\)\.toLocaleString\(\)\}`\)",
         r'setChatError(`Вы заблокированы в чате до ${fmtSafeDate(data.until)}`)'),
    ]),
    ('components/chat/ChatInput.tsx', [
        (r"Вы заблокированы в чате до \{new Date\(bannedUntil! \* 1000\)\.toLocaleString\('ru-RU', \{ timeZone: 'UTC' \}\)\}",
         r"Вы заблокированы в чате до {fmtSafeDate(bannedUntil!)}"),
    ]),
]

for rel_path, replacements in FILES:
    fpath = os.path.join(BASE, rel_path)
    if not os.path.exists(fpath):
        print(f"SKIP (not found): {fpath}")
        continue
    with open(fpath, 'r') as f:
        content = f.read()
    original = content
    for pattern, replacement in replacements:
        content = re.sub(pattern, replacement, content)
    if content != original:
        with open(fpath, 'w') as f:
            f.write(content)
        print(f"FIXED: {rel_path}")

# Verify
result = os.popen(f"grep -rn 'new Date.*\* 1000' {BASE} --include='*.tsx' | grep -v utils/date.ts").read()
if result:
    print("REMAINING:", result)
else:
    print("All fixed!")
