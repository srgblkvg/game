#!/bin/bash
# Проверить все файлы клиента на использование safeDate/fmtSafeDate без импорта
# Запускать после массовых замен дат перед npx vite build
echo "=== Проверка импортов safeDate/fmtSafeDate ==="
for f in client/src/pages/**/*.tsx client/src/components/**/*.tsx client/src/contexts/*.tsx; do
  if grep -q "fmtSafeDate\|safeDate" "$f" 2>/dev/null; then
    if ! grep -q "import.*fmtSafeDate\|import.*safeDate" "$f" 2>/dev/null; then
      echo "MISSING: $f"
    fi
  fi
done
echo "=== Готово ==="
