---
name: pg-native-rewrite
description: PG native rewrite branch for MMO Arena — setup, common pitfalls, and workflow.
---

# PG Native Rewrite (ветка pg-native)

Полный переход с pg-promise враппера на нативный `pg` (node-postgres).  
39 файлов переписано, 0 зависимостей от better-sqlite3.

## Локальный запуск

```bash
# Сервер
cd /mnt/c/project/game/server && PORT=3002 npx tsx src/index.ts
# Клиент (прокси на :3002 в vite.config.ts)
cd /mnt/c/project/game/client && npx vite --host
```

PG доступ: `sudo -u postgres psql -d game`
Схема: `server/src/db/schema.sql` (42 таблицы)
Модуль БД: `server/src/db/index.ts` — `{ db, pool }`

API:
- `db.one(sql, [params])` → row с camelCase ключами или null
- `db.query(sql, [params])` → rows[]
- `db.run(sql, [params])` → `{ changes, lastInsertRowid }`
- `db.tx(async (client) => { client.query(...) })` → транзакция
- `? → $N` конвертация внутри модуля (ВСЕГДА использовать `?`, НЕ `$1`/`$2` напрямую — иначе `pgLowerIdentifiers` может сломать запрос, симптом: 500 «could not determine data type of parameter $1»)

## Частые баги и фиксы

### 🧠 pgLowerIdentifiers: авто-конвертация camelCase в SQL

Ключевая функция в `db/index.ts`, которая решает 95% проблем после миграции. SQLite был нечувствителен к регистру в именах колонок — PG строгий и сворачивает unquoted идентификаторы в lowercase. Код писался под SQLite и использует `tp.userId`, `tp.tournamentId` прямо в SQL-запросах.

**pgLowerIdentifiers** прогоняет SQL перед отправкой в PG:
1. Временно вырезает строковые литералы (всё в `''` кавычках) — чтобы не испортить данные
2. Находит все camelCase-слова (строчная → заглавная → любые буквы/цифры) и приводит к lowercase
3. Возвращает строковые литералы на место

```typescript
function pgLowerIdentifiers(sql: string): string {
  const strings: string[] = [];
  let cleaned = sql.replace(/'[^']*'/g, (m) => {
    strings.push(m);
    return '__STR_' + (strings.length - 1) + '__';
  });
  cleaned = cleaned.replace(/\b([a-z]+[A-Z][a-zA-Z0-9]*)\b/g, (m) => m.toLowerCase());
  return cleaned.replace(/__STR_(\d+)__/g, (_, i) => strings[parseInt(i)]);
}
```

Пример: `WHERE tp.userId = u.id AND tp.tournamentId = ?` → `WHERE tp.userid = u.id AND tp.tournamentid = $1`

**Где вызывается:** в `db.query()`, `db.one()`, `db.run()` — ПЕРЕД `pgParams()` (замена `? → $N`).

**Симптомы отсутствия этой функции:**
- Турниры: `[bracket] participants=2` но матчи не создаются → `tp.userId` не резолвится в PG
- Молчаливые ошибки (PG возвращает пустой результат вместо ошибки для несуществующих колонок)
- Турниры зависают в `in_progress` с 0 матчей

**Ловушка: идентификаторы с цифрами (`player1Id`, `player2Id`)**

Регулярка `\b([a-z]+[A-Z][a-zA-Z0-9]*)\b` НЕ матчит `player1Id` — после `[a-z]+` (захватило `player`) ожидается `[A-Z]`, но следующий символ `1` (цифра). PG сворачивает unquoted идентификаторы в lowercase: `player1Id` → `player1id`. Поэтому INSERT с `player1Id` в SQL РАБОТАЕТ в PG без pgLowerIdentifiers. НО если колонка в кавычках (`"player1Id"`) — PG сохранит регистр и сравнение сломается. Правило: не использовать кавычки для имён колонок в PG-миграции.

### 🔴 Двойные кавычки = case-sensitive: `"senderGuild"` ≠ `senderguild`

**Корень проблемы:** в PostgreSQL идентификаторы без кавычек сворачиваются в lowercase. Идентификаторы в двойных кавычках сохраняют точный регистр. `senderguild` (без кавычек) → PG ищет колонку `senderguild` (lowercase). `"senderGuild"` (в кавычках) → PG ищет колонку с именем `senderGuild` (camelCase). Это **разные** имена.

**Симптом:** `column "senderguild" of relation "chat_messages" does not exist` — при том что `SELECT column_name FROM information_schema` показывает колонку `senderguild` (она существует, но код использует `"senderGuild"` с кавычками и другим регистром).

**Реальный пример (websocket.ts + chat.ts, 7 INSERT'ов):**
```sql
-- БЫЛО — кавычки + camelCase → PG ищет senderGuild (camelCase), не находит
INSERT INTO chat_messages (..., "senderGuild", "senderGuildId") VALUES (...)
-- СТАЛО — без кавычек → PG фолдит в lowercase → матчит senderguild
INSERT INTO chat_messages (..., senderguild, senderguildid) VALUES (...)
```

**Диагностика:** если ошибка `column "X" does not exist`, но `information_schema` показывает колонку — проверить greb-ом исходники на `"X"` (с кавычками). Если имя в кавычках отличается регистром от реального — это баг.

**Правило:** НИКОГДА не использовать двойные кавычки для имён колонок в SQL. Все имена колонок в PG-native ветке — lowercase, pgLowerIdentifiers конвертирует camelCase в SQL-запросах автоматически.

**Где искать:** любые INSERT/UPDATE/SELECT с `"ColumnName"` в двойных кавычках. Grep: `grep -rn '"[A-Z]' server/src/ --include="*.ts"` (ищет кавычки вокруг идентификаторов с заглавной буквы).

### camelCase конвертер — суффиксы
Регулярка в `/db/index.ts`:
```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|score|number|players|ticket|stats|place|tag|text|chat|from|guild|role|last|first|ip|url|path|size|width|height|color|tier|slot|icon|attacked|made|round)$/i
```
**Составные замены (полный список в коде `db/index.ts`):** `attacktime→AttackTime`, `pveattacktime→PveAttackTime`, `attacksec→AttackSec`, `pveattacksec→PveAttackSec`, `taxrate→taxRate`, `verified→Verified`, `hpupdate→HpUpdate`, `bases→baseS`, `basea→baseA`, `based→baseD`, `basem→baseM`, `statpoints→statPoints`, `totalbattles→totalBattles`, `pvetotalbattles→pveTotalBattles`, `pvewins→pveWins`, `totalpvpmoneywon→totalPvpMoneyWon` (и lost), `totalpvemoneywon→totalPveMoneyWon` (и lost), `totaljobmoney→totalJobMoney`, `totaljobseconds→totalJobSeconds`, `craftcreated→craftCreated`, `craftupgraded→craftUpgraded`, `craftbroken→craftBroken`, `tournamentcount→tournamentCount`, `tournamentwins→tournamentWins`, `rewardxp→rewardXp`, `accountnumber→accountNumber`, `fromaccount→fromAccount`, `toaccount→toAccount`, `currentbiddername→currentBidderName`, `attackerguildid→attackerGuildId`, `defenderguildid→defenderGuildId`, `arenatopponentid→arenaOpponentId`, `emailverified→emailVerified`, `emailcode→emailCode`, `emailcodeexpires→emailCodeExpires`, `isguest→isGuest`, `oauthprovider→oauthProvider`, `oauthid→oauthId`, `([a-z])guildid→$1GuildId`, `lastattackedat→lastAttackedAt`.

**Почему `emailcode` и `emailcodeexpires` требуют явных замен:** JS `.replace()` без флага `/g` заменяет только ПЕРВОЕ совпадение. В `emailcodeexpires` два суффикса: `code` и `expires`. Регулярка находит `expires` (последний в альтернации) → `emailcodeExpires`, но `code` остаётся lowercase. Явная замена решает проблему.

**Недостающие суффиксы (добавлены после багов):**
`players` (maxplayers→maxPlayers), `ticket` (goldenticket→goldenTicket), `stats` (snapshotstats→snapshotStats), `attacked` (timesattacked→timesAttacked), `made` (attacksmade→attacksMade), `round` (maxround→maxRound — без него `finalRound` всегда 1, 3-е место в турнирах никогда не присуждается!), `log` (battlelog→battleLog — без него `attack.battleLog` всегда undefined, логи гильдий не открываются!), `drink` (activedrink→activeDrink — без него напитки не работают: таймер не показывается, статы не прибавляются, `user.activeDrink` всегда undefined, условие `user.activeDrink && user.drinkUntil > now` всегда false).

**Наезд суффиксов (overlap bug):** суффикс `count` в regex матчит конец `fromaccount` → `fromacCount` (съедает букву `c`). Аналогично `toaccount` → `toacCount`. Поле `t.fromAccount` в истории переводов всегда undefined. **Фикс:** добавить явные замены ДО общего regex:
```\n.replace(/^fromaccount$/i, 'fromAccount')\n.replace(/^toaccount$/i, 'toAccount')\n```\n\n**Неполный CamelCase в составных словах (attackerguildid/defenderguildid):**\nСуффиксный regex находит только `id` на конце `attackerguildid` → `attackerguildId`. Клиент ждёт `attackerGuildId` (большая G в Guild) → `undefined`, противник в гильдийских войнах не определяется. **Фикс:** явная замена ДО общего regex:\n```\n.replace(/^attackerguildid$/i, 'attackerGuildId')\n.replace(/^defenderguildid$/i, 'defenderGuildId')\n```\n\n**Неполный CamelCase в составных словах (currentbiddername):**
Суффиксный regex капитализирует ТОЛЬКО последний суффикс. `currentbiddername` → `currentbidderName` (маленькая `b` в `bidder`). Клиент ждёт `currentBidderName` → `undefined`, лидер ставки не показывается. **Фикс:** явная замена ДО общего regex:
```
.replace(/^currentbiddername$/i, 'currentBidderName')
```

**Текущий полный regex суффиксов (актуальный):**
`/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|score|number|players|ticket|stats|place|tag|text|chat|from|guild|role|last|first|ip|url|path|size|width|height|color|tier|slot|icon|attacked|made|round|log|code|expires|verified|drink|date|bid|by)$/i`

**Добавленные суффиксы (сессия 18.06.2026):**
- `bid` — `currentbid` → `currentBid`. **Критический: без него весь аукцион сломан.** `lot.currentBid === undefined` → условие `lot.currentBid &&` ложно → строка «Ставка: N» не показывается, мин. ставка считается от `startPrice` вместо `currentBid + 5%`, лидер ставки не отображается. Каскадный баг, маскируется под несколько разных проблем.
- `by` — `invitedby` → `invitedBy` (приглашения в гильдию)

**Явные замены, добавленные:**
- `taxrate` → `taxRate` (было `TaxRate` — PascalCase, клиент ждал camelCase → `guild.taxRate === undefined`)
- `attackerguildid` → `attackerGuildId` (regex давал `attackerguildId` — только `id` капитализировался, `guild` оставался lowercase)
- `defenderguildid` → `defenderGuildId` (аналогично — противник в гильдийских войнах не определялся)
- `currentbiddername` → `currentBidderName` (regex давал `currentbidderName` — только `name` капитализировался, клиент ждал `currentBidderName` → лидер ставки не показывался)

**Составная замена для `lastattackedat`:**
`lastattackedat` — суффикс `at` даёт `lastattackedAt`, а нужно `lastAttackedAt`. Добавлена явная замена:
```
.replace(/lastattackedat$/i, 'lastAttackedAt')
```
Без неё `protectedUntil` в гильдийских войнах всегда null — защита не работала.

**Составная замена для `lastloginat`:**
`lastloginat` — суффикс `at` даёт `lastloginAt` (маленькая `l`), а клиент ждёт `lastLoginAt` (большая `L`). Добавлена явная замена:
```
.replace(/lastloginat$/i, 'lastLoginAt')
```
**Диагностика:** `PGPASSWORD=... psql -c "SELECT id, username, lastLoginAt, pg_typeof(lastLoginAt) FROM users LIMIT 3"` — если `pg_typeof = text` и значение `"1783235808"` (Unix timestamp как строка), то `camelRows` без явной замены даст `lastloginAt` (маленькая `l`), и клиент получит `undefined`. Симптом: «Посл. вход» в админке всегда `—`.

**Ловушка: `lastAt + 'Z'` на PG timestamptz**

PG `timestamptz` возвращает строку уже с таймзоной (`+00:00` или `Z`). Код, добавляющий `+ 'Z'`, создаёт невалидную дату:
```
"2026-06-15T09:47:24.548+00:00" + 'Z' → "2026-06-15T09:47:24.548+00:00Z" → NaN
```

**Правильный фикс (работает для ВСЕХ форматов PG):** просто `new Date(lastAt).getTime()` — без каких-либо манипуляций. JS Date парсит ISO-строки с таймзоной корректно.

**Где было исправлено:** guild.ts (кулдаун атаки, защита цели, attackCooldownUntil, protectedUntil), battle.ts, auction.ts (история).

**Важно:** НЕ добавлять односимвольные суффиксы (`s`, `a`, `d`, `m`) — они ломают `statpoints→statpointS`, `battles→battleS`. Всегда использовать явные составные замены.

### 🔴 SQL с голыми `s`, `a`, `d`, `m` — pgLowerIdentifiers не трансформирует

Колонки статов в PG: `bases`, `basea`, `based`, `basem`. pgLowerIdentifiers конвертирует camelCase (`baseS` → `bases`, `baseA` → `basea`), но **не трогает уже-lowercase строки**. SQL вида `UPDATE users SET s=5, a=5, d=5, m=5` пройдёт через pgLowerIdentifiers без изменений → PG не найдёт колонки `s` → `column "s" of relation "users" does not exist` → 500.

**Симптом:** `[VK Bridge Auth] Error: column "s" of relation "users" does not exist` при попытке входа. Аналогично в любом SQL с голыми `s/a/d/m`.

**Фикс:** всегда писать `baseS=5, baseA=5, baseD=5, baseM=5` в SQL-запросах — pgLowerIdentifiers корректно сконвертирует в `bases, basea, based, basem`.

**Где искать:** любые UPDATE/INSERT с `s=`, `a=`, `d=`, `m=` в SQL-строках. Grep: `grep -rn "[^a-zA-Z][sadm]=" server/src/routes/ --include="*.ts"`.

### 🔴 `oauthProvider` mismatch: `'vk'` vs `'vkontakte'` — дубликаты аккаунтов

Разные роуты используют разные строки для одного и того же OAuth-провайдера:
- VK Bridge Auth (`vkBridgeAuth.ts`) — `'vk'`
- OAuth web flow (`oauth.ts`) — `'vkontakte'`

Оба ищут `WHERE oauthProvider = ? AND oauthId = ?`. При несовпадении строки — существующий аккаунт не находится, создаётся дубликат с level 1.

**Симптом:** пользователь заходит → видит level 1 (дубликат). В БД два аккаунта на один `oauthId` с разными `oauthProvider`.

**Фикс:** унифицировать строку провайдера во всех роутах. Выбрать одну (`'vk'`) и использовать везде. После фикса удалить дубликаты:
```sql
-- Найти дубликаты
SELECT oauthid, count(*) FROM users WHERE oauthprovider IN ('vk', 'vkontakte') GROUP BY oauthid HAVING count(*) > 1;
-- Удалить дубликат (проверить FK references сначала)
DELETE FROM users WHERE id = <duplicate_id>;
```

### PG lowercase: код читает camelCase, PG возвращает lowercase — guildId всегда null

**Симптом:** `sendToGuild` не отправляет данные никому. `onlineUser.guildId` всегда `null`, хотя в БД `guildid` не null.

**Причина:** PG сворачивает unquoted идентификаторы в lowercase. `user.guildid` существует, но код читает `user.guildId` → `undefined` → `|| null` → null.

**Фикс:** ВСЕГДА `guildid || guildId`, `guildname || guildName`. Критические места:
- WebSocket подключение (onlineUsers)
- sendToGuild (broadcast гильд-квестов)
- Все ответы где есть guildName/guildId

**Симптомы отсутствия суффикса:** поле в API = `undefined` / `0` / дефолт. `baseS=5` вместо `8` → нет `s/a/d/m`. `statPoints=0` → нет составной замены. `rewardXp=undefined` → `exp=NULL` (обнуление опыта!). `registrationEnd=undefined` → турниры не стартуют. `activeJob=undefined` → работы не работают. `user.activeDrink=undefined` → напитки не работают (таймер не показывается, статы не прибавляются), хотя `user.drinkUntil` корректный (суффикс `until` есть).

**Диагностика:** `SELECT column_name FROM information_schema.columns WHERE table_name='...'` → сравнить с именами в коде.

### PG типы: сравнение timestamptz с text
Если схема имеет микс типов (часть колонок `TEXT`, часть `TIMESTAMPTZ`), сравнение ломается:
`gm.joinedat TIMESTAMPTZ <= declaredat TEXT` → `operator does not exist: timestamp with time zone <= text`.

**Фикс:** явный каст в SQL: `declaredAt::timestamptz` или `joinedAt::text` (на усмотрение).
**Где искать:** guild_wars (declaredat/acceptedat/expiresat — TEXT), guild_members (joinedat — TIMESTAMPTZ).

**Быстрая проверка типов:**
```sql
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name IN ('guild_wars', 'guild_members') AND column_name LIKE '%at';
```

### BigInt → Number (осторожно!)
`COUNT(*)` возвращает string в PG. НО авто-конвертация `parseInt` ЛЮБЫХ цифровых строк ломает контент чата (`"2"→2`, `.split()` краш).
**Правило:** конвертировать только если: (1) число > 2^31 (реальный bigint), ИЛИ (2) колонка в списке числовых: `id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round|year|month|day|hour|min|sec|limit|offset|page|rank`.
**Симптом:** `e.content.split is not a function` в чате → контент стал числом. Проверить BigInt-конвертер.

### SQLite-специфичные функции
- `MAX(a, b)` (SQLite scalar) → **`GREATEST(a, b)`** (PG). `MAX()` в PG только агрегатная.
- `last_insert_rowid()` → не существует в PG. Использовать `RETURNING id` в INSERT, или `db.run()` возвращает `lastInsertRowid`.
- **Ловушка db.run catch-блока:** если первый INSERT с `RETURNING id` падает (таблица без id, синтаксис), catch-блок выполняет запрос ЗАНОВО без RETURNING, но **всегда возвращает `lastInsertRowid: 0`**. Код, полагающийся на `info.lastInsertRowid` после db.run, получит 0 и UPDATE по id=0 молча не сработает. Симптом: bye-матчи в турнирах не получают winnerId.
- `datetime('now', '-5 minutes')` → `new Date(Date.now() - 5*60*1000).toISOString()`
- `INSERT OR REPLACE` → `ON CONFLICT ... DO UPDATE`

### Колонки schema.sql, отсутствующие в PG

После неполной миграции некоторые колонки из `schema.sql` могут отсутствовать в реальной PG-базе. SQLite-миграции добавляли колонки через `ALTER TABLE ADD COLUMN`, но PG-миграция могла пропустить часть колонок (особенно добавленных поздно).

**Симптом:** `column "X" of relation "Y" does not exist` в логах сервера → 500 на соответствующий эндпоинт.

**Диагностика:** сравнить schema.sql с реальной структурой:
```sql
SELECT column_name FROM information_schema.columns
WHERE table_name = 'pve_battles' ORDER BY ordinal_position;
```
Сравнить вывод с `schema.sql` (колонки перечислены в секции CREATE TABLE).

**Фикс:** добавить отсутствующую колонку вручную:
```bash
sudo -u postgres psql -d game -c "ALTER TABLE pve_battles ADD COLUMN itemsdropped TEXT;"
```
После ALTER TABLE перезапуск сервера не обязателен (применяется мгновенно), но для очистки логов: `pm2 restart game-server && pm2 flush game-server`.

**Известные пропущенные колонки:**
- `pve_battles.itemsdropped` — добавлена после миграции, хранит JSON-массив выпавших предметов

**Проактивная проверка всех таблиц:**
```bash
# Сравнить все колонки schema.sql с PG
grep -E "^\s+\w+\s+(TEXT|INTEGER|TIMESTAMPTZ|BOOLEAN|FLOAT)" server/src/db/schema.sql | \
  awk '{print $1}' | sort > /tmp/schema_cols.txt
# Затем для каждой таблицы сверить через information_schema
```

### 🔴 Express: route `:id` перехватывает литеральные пути (`/quest`, `/requests`, etc.)

**Паттерн-баг:** `router.get('/guild/:id', ...)` регистрируется РАНЬШЕ чем `router.get('/guild/quest', ...)` в том же файле. Express матчит `/guild/quest` как `/guild/:id` с `id = "quest"` → `parseInt("quest")` → `NaN` → PG `invalid input syntax for type integer: "NaN"` → 500.

Клиент видит 500 на `/api/guild/quest`, серверные логи показывают ошибку на строке `:id`-обработчика — NOT на `/quest`-обработчике. Это сбивает с толку.

**Фикс:** добавить `next` в параметры обработчика и проверку `isNaN`:
```typescript
router.get('/guild/:id', async (req, res, next) => {  // ← добавить next
    const guildId = parseInt(req.params.id);
    if (isNaN(guildId)) return next();                 // ← пропустить /guild/quest и др.
    // ... остальная логика
```

**Почему это проявляется именно после PG-миграции:** на SQLite `NaN` в `WHERE id = NaN` молча возвращал 0 rows (404), а PG жёстко падает с ошибкой типа. Маршруты работали «случайно» на SQLite.

**Где искать:** любые `router.get('/prefix/:id', ...)` + `router.get('/prefix/something', ...)` в одном файле — проверить порядок регистрации. Правило: литеральные маршруты ДО параметризованных, или `isNaN` guard с `next()`.

> Конкретный кейс (guild_quests): `references/guild-quests-permissions.md`

### Таблица существует, но INSERT/UPDATE падает с «permission denied»

### Таблица существует, но INSERT/UPDATE падает с «permission denied»

**Симптом:** `error: permission denied for table X` в логах, хотя `\dt` показывает таблицу, и `SELECT` работает. Ошибка именно на `db.run()` (INSERT/UPDATE/DELETE).

**Причина:** таблица создана не тем пользователем (обычно `postgres` вместо `game`). `GRANT ALL ON ALL TABLES` из начальной миграции не покрывает таблицы, созданные позже другим пользователем. Более того — даже если `GRANT INSERT/UPDATE/SELECT` на таблицу выдан, **SEQUENCE для SERIAL-колонки остаётся во владении создателя**. `db.run()` делает `INSERT ... RETURNING id`, что вызывает `nextval('seq')` — и падает с `permission denied`, если USAGE на sequence не выдан.

**Диагностика:**
```sql
-- Кто владелец таблицы?
SELECT tableowner FROM pg_tables WHERE tablename = 'castle_treasury';
-- Кто владелец sequence?
SELECT c.relname, pg_get_userbyid(c.relowner) as owner
FROM pg_class c WHERE c.relkind = 'S' AND c.relname LIKE '%treasury%';
-- Какие права у game на таблицу?
SELECT privilege_type FROM information_schema.table_privileges
WHERE table_name = 'castle_treasury' AND grantee = 'game';
```

**Фикс (от имени владельца, обычно `postgres`):**
```sql
GRANT ALL ON castle_treasury TO game;
GRANT ALL ON treasury_log TO game;
GRANT USAGE, SELECT ON SEQUENCE treasury_log_id_seq TO game;
```

**Профилактика:** после создания НОВЫХ таблиц на проде всегда выполнять:
```sql
GRANT ALL ON ALL TABLES IN SCHEMA public TO game;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO game;
```

Это особенно важно после `CREATE TABLE` через `sudo -u postgres psql` или при добавлении таблиц мимо schema.sql (treasury, overflow_storage, guild_quests).

### NOT NULL constraint: `createdat` без дефолта

После миграции многие таблицы имеют `createdat TEXT NOT NULL` без `DEFAULT NOW()`. Любой INSERT без явного `createdat` падает:
`null value in column "createdat" violates not-null constraint`

**Известные таблицы без дефолта:**
- `feedback_messages` — фикс: добавить `createdat` в INSERT + `new Date().toISOString()`
- `guild_treasury_log` — 4 места INSERT: (1) deposit через client.query — `NOW()`, (2) war_win — `new Date().toISOString()`, (3) war_loss — аналогично, (4) helpers.ts налог — аналогично
- `guild_war_attacks` — уже имеет `createdAt` в INSERT

**Диагностика всех таблиц с проблемой:**
```sql
SELECT table_name FROM information_schema.columns WHERE column_name='createdat' AND is_nullable='NO';
```
Список: `auction_lots, feedback_messages, guild_treasury_log, guild_war_attacks, orders, tournaments`.

**Поиск INSERT без createdat:**
```bash
grep -rn "INSERT INTO" server/src/routes/ --include="*.ts" | grep -v "createdat\|createdAt"
```

### Зависшие турниры после миграции (диагностика)

**Симптом:** турниры в статусе `in_progress`, матчей нет (0 rows в `tournament_matches`), висят сутками. Вызов GET /api/tournament зависает (timeout) — бесконечный цикл в autoAdvance.

**Типичный сценарий бесконечного цикла:**
1. Турнир перешёл registration→in_progress (registrationEnd истекло)
2. `generateBracket()` был вызван при переходе, но НЕ создал матчи (camelCase SQL issue в момент перехода)
3. `autoAdvance(tournamentId)` рекурсивно вызывает себя: видит `in_progress`, вызывает `resolveCurrentRound` → 0 матчей → возвращает 0 → ничего не делает
4. В логах циклично: `[bracket] participants=N` и `[autoAdv] 0 matches - regenerating bracket` — матчи не создаются, счётчик не растёт

**Причины неудачного generateBracket (матчи не создаются):**
- **camelCase SQL**: `tp.userId`, `tp.tournamentId` в JOIN — PG требует lowercase (фикс: pgLowerIdentifiers)
- **`last_insert_rowid()`**: SQLite-функция не существует в PG (фикс: `info.lastInsertRowid` из результата `db.run`)
- **`p.userId === undefined`**: если camelRows не добавил camelCase-ключ (фикс: добавить суффикс или использовать `p.userid`)

**Авто-исправление в autoAdvance:** в блок `if (t.status === 'in_progress')` добавлена проверка:
```typescript
const matchCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_matches WHERE tournamentid = ?', [tournamentId]) as any).cnt;
if (matchCount === 0) {
    await generateBracket(tournamentId);
    await autoAdvance(tournamentId);
    return;
}
```
Это регенерирует брекет для турниров, которые перешли в `in_progress` без матчей (из-за ошибок при первом generateBracket). После регенерации авто-продвижение продолжается: resolveCurrentRound → advanceWinners → finishTournament.

**Проверка типов колонок tournament_matches:**
```sql
SELECT column_name FROM information_schema.columns WHERE table_name='tournament_matches';
-- id, tournamentid, round, player1id, player2id, winnerid, log
```
Убедиться что имена колонок совпадают с тем, что ожидает INSERT (в lowercase).

**Ручное исправление зависшего турнира:**
```sql
-- Посмотреть участников
SELECT * FROM tournament_participants WHERE tournamentid = <id>;
-- Создать матч вручную (если 2 участника)
INSERT INTO tournament_matches (tournamentid, round, player1id, player2id)
VALUES (<id>, 1, <uid1>, <uid2>);
```
После ручного INSERT следующий GET /api/tournament подхватит и завершит турнир через autoAdvance.

### INSERT без явных колонок — съезд позиционных параметров в PG

SQLite позволяет `INSERT INTO battles VALUES (?, ?, ...)` без указания колонок — автоинкрементный `id` пропускается, первый `?` идёт во вторую колонку. **PG так не работает.** PG заполняет колонки строго по ordinal position, начиная с первой. `INSERT INTO battles VALUES (?, ...)` без `id` → первый параметр попадает в `id` → все колонки съезжают.

**Симптом:** `invalid input syntax for type integer: "["⚔ ...", ...]"` — JSON-лог боя попадает в колонку `winnerId` (integer).

**Фикс:** всегда указывать явный список колонок при INSERT без id:
```sql
INSERT INTO battles (attackerId, defenderId, winnerId, log, steps, attackerHpAfter, defenderHpAfter, expGained, moneyGained, moneyStolen)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
```

### Сравнение дат: `lastAt + 'Z'` на PG timestamptz

Код повсеместно делает `new Date(lastAttack.lastAt + 'Z').getTime()`. На SQLite `lastAt` был текстом без таймзоны → `+'Z'` работало. **PG `timestamptz` возвращает строку уже с `+00:00` на конце** → `"2026-06-15T09:47:24.548+00:00" + 'Z'` → `"...+00:00Z"` → `new Date()` → `NaN`.

**Симптомы:**
- Кулдаун 5 мин в гильдваре никогда не срабатывает (проверка `Date.now() - NaN < 300000` всегда false)
- `attackCooldownUntil` всегда null (условие `NaN > Date.now()` всегда false)
- Защита цели 1 час никогда не срабатывает

**Фикс:** просто `new Date(lastAt).getTime()` — JS Date парсит ISO-строки с таймзоной корректно.

**Где искать:** все `+ 'Z'` конкатенации с PG-результатами. В коде было минимум 5 мест: guild.ts (кулдаун атаки, защита цели, attackCooldownUntil, protectedUntil), battle.ts (m.lastAttackedAt). Плюс та же проблема в `client/src/utils/date.ts` (safeDate v1/v2/v3).

### Raw PG client.query: lowercase ключи в db.tx callback

При использовании `db.tx(async (client) => { ... })` запросы идут через `client.query()` напрямую (НЕ через `db.one()`/`db.query()`). **PG driver возвращает строки с lowercase ключами** (имя колонки как в PG, без camelCase-конвертера). `camelRows()` применяется только в `db.query()`/`db.one()`.

**Симптом:** `sender.accountNumber` → `undefined`, хотя `sender.accountnumber` существует. Аналогично `target.accountNumber`.

**Фикс:** использовать lowercase имена в raw-клиенте: `sender.accountnumber`, `target.accountnumber`. Либо переписать на `db.one()` (получить camelCase, но потерять транзакционность для одного запроса).

**Затронутые эндпоинты:** `/bank/transfer` (fromAccount/toAccount были null вместо реальных номеров счетов).

### accountNumber: колонка есть, но новые пользователи без номера счёта

Колонка `accountNumber` (PG: `accountnumber`) есть в схеме, но генерация 6-значного номера при регистрации отсутствует. Старые пользователи имеют номера (из ранней миграции), новые — `NULL`.

**Симптом:** перевод по номеру счёта не работает для новых игроков — `WHERE accountNumber = $1` не находит получателя с `NULL`.

**Фикс:** авто-генерация при первом GET `/bank`:
```typescript
if (!user.accountNumber) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let accNum = '';
    for (let i = 0; i < 6; i++) accNum += chars[Math.floor(Math.random() * chars.length)];
    await db.run('UPDATE users SET accountNumber = ? WHERE id = ?', [accNum, userId]);
    user.accountNumber = accNum;
}
```

### Гильдийские войны

> Подробный разбор сессии: `references/2026-06-14-guild-war.md`
> Реализация таймеров на клиенте: `references/guildwar-timers.md`

**Схема `guild_war_attacks`:**
- `createdat` — `TEXT NOT NULL` без дефолта. INSERT обязан включать `createdAt`.
- Без него: `null value in column "createdat" violates not-null constraint` → 500 на `/guild/war/attack`.

**INSERT атаки (правильный):**
```sql
INSERT INTO guild_war_attacks (warId, attackerId, defenderId, attackerGuildId, defenderGuildId, won, battleLog, createdAt)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
```
**INSERT атаки (правильный):**
```sql
INSERT INTO guild_war_attacks (warId, attackerId, defenderId, attackerGuildId, defenderGuildId, won, battleLog, createdAt)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
```
Параметр `createdAt`: `new Date().toISOString()` (ISO формат). **НЕ использовать** `.replace('T', ' ').slice(0, 19)` — старый формат без T/Z несовместим с PG timestamptz и ломает строковое сравнение дат.

### Нормализация дат гильдий: ISO формат

В коде гильдий (`guild.ts`) повсеместно использовался паттерн:
```typescript
new Date().toISOString().replace('T', ' ').slice(0, 19)
// → "2026-06-15 09:14:00" — без T, без Z
```

Этот формат создаёт проблемы:
- Строковое сравнение с ISO-строками из PG (timestamptz → "2026-06-15T09:14:00.000Z") ломается: пробел < 'T' лексикографически
- Каст `::timestamptz` в SQL работает, но неявное сравнение падает
- `new Date("2026-06-15 09:14:00")` работает не во всех браузерах

**Фикс:** заменить ВСЕ `.replace('T', ' ').slice(0, 19)` на просто `.toISOString()`.
```bash
sed -i "s|\.toISOString()\.replace('T', ' ')\.slice(0, 19)|\.toISOString()|g" server/src/routes/guild.ts
```
**Затронутые таблицы:** guild_wars (declaredat, acceptedat, expiresat, endedat), guild_war_attacks (createdat). Все они TEXT — ISO-строки корректно хранятся и сравниваются.

**Кража денег в гильдийских битвах:**
`runBattle()` из `server/src/game/battle.ts` добавляет шаги типа `money` в лог («забирает X монет»). В гильдийских войнах деньги не должны вороваться — ни в логе, ни в БД.

**Фикс:** после `runBattle()` отфильтровать money-шаги:
```ts
const warSteps = steps.filter((s: any) => s.type !== 'money');
const warLog = warSteps.map((s: any) => s.message);
// Использовать warSteps вместо steps в INSERT и ответе
```

**Счёт очков:**
После победы атакующего — `UPDATE guild_wars SET attackerScore = attackerScore + 1` (или `defenderScore`). Колонки `attackerscore`/`defenderscore` в PG — `INTEGER DEFAULT 0`. PG сворачивает `attackerScore` → `attackerscore`, конфликта имён нет.

**Сравнение дат в JS (не SQL):**
`member.joinedAt > war.declaredAt` — `joinedAt` это JS Date (из PG `timestamptz`), `declaredAt` — строка (из PG `text`). JS сравнение работает (`Date > string` → string парсится), но **в SQL нужно кастить** (см. секцию «PG типы»).

#### Последовательные UPDATE инвентаря: синхронизация in-memory состояния

**Паттерн-баг:** когда в одном запросе несколько раз читается `user.inventory`, модифицируется, и пишется в БД — НО `user.inventory` в памяти не обновляется между записями. В SQLite это работало потому что SQLite был синхронным и каждый вызов читал актуальное состояние из файла. В PG `user` — это снэпшот на момент первого `SELECT`, и все последующие `JSON.parse(user.inventory)` читают один и тот же оригинальный инвентарь.

**Симптом:** при выпадении нескольких предметов с моба (материал + камень + шмотка) в инвентаре остаётся только последний — каждая секция дропа перезаписывает БД оригинальным инвентарём + своим предметом.

**Реальный пример (mobs.ts):**
```typescript
// Секция 1: материал — читает оригинальный инвентарь, добавляет материал, пишет в БД
const inventory = JSON.parse(user.inventory);  // оригинальный!
inventory.push(materialDrop);
await db.run('UPDATE users SET inventory = ? ...', [JSON.stringify(inventory), userId]);
// user.inventory ВСЁ ЕЩЁ оригинальный!

// Секция 2: камень — читает ОРИГИНАЛЬНЫЙ инвентарь (без материала!)
const inventory2 = JSON.parse(user.inventory);  // БЕЗ материала!
inventory2.push(stoneDrop);
await db.run('UPDATE users SET inventory = ? ...', [JSON.stringify(inventory2), userId]);
// Материал потерян!
```

**Фикс:** после каждого `UPDATE ... SET inventory` добавлять `user.inventory = JSON.stringify(inventory)`:
```typescript
await db.run('UPDATE users SET inventory = ? ...', [JSON.stringify(inventory), userId]);
user.inventory = JSON.stringify(inventory);  // ← синхронизация in-memory!
```

**Где искать:** любые эндпоинты где в рамках одного запроса несколько раз модифицируется одно и то же поле через `JSON.parse(user.field)` + `db.run(UPDATE)`.

## Прод-деплой

> **Оптимизация памяти на low-RAM VPS:** `references/low-memory-vps-optimization.md`
> — SSE вместо WebSocket, serverTick отключён, V8-флаги, диагностика утечек.

### Иконки: tree-shaking перед билдом
Полный `game-icons` содержит 4134 иконки (~6.5MB в бандле). Используется ~65. Скрипт `scripts/filter-icons.cjs` сканирует исходники, вырезает только используемые иконки в `src/icons-filtered.json`. `main.tsx` импортирует фильтрованный файл.

```bash
node scripts/filter-icons.cjs  # перед каждым билдом
npx vite build                 # бандл ~388KB вместо 6.5MB
```

После добавления новых иконок в код — перезапустить фильтр. Без него новые иконки не отобразятся (отсутствуют в фильтрованном наборе).

### Pre-compile tsc (production only)

tsx (esbuild) компилирует на лету — занимает ~50MB доп. памяти и может крашиться при высоком heap. Для продакшена — компилировать tsc и запускать dist:

```bash
cd /opt/game/server && npx tsc
pm2 delete game-server
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" --name game-server --max-memory-restart 900M
pm2 save --force
```

Результат: 94MB вместо 146MB с tsx, heap 512MB вместо 1024MB, 0 крашей.

**Важно:** после изменений исходников — перекомпилировать: `npx tsc && pm2 restart game-server`.

### DB pool sizing

PG pool по умолчанию `max: 20`. Каждый коннект ~25MB → 500MB. Для VPS 2GB достаточно `max: 5`:
```typescript
const pool = new Pool({ ..., max: 5, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000 });
```
5 коннектов выдают ~250 запросов/сек при 20ms latency. Запас ×80 для 100 пользователей.

### Nginx кеширование статики

```nginx
location /assets/ {
    alias /opt/game/client/dist/assets/;
    expires 30d;
    add_header Cache-Control "public, immutable";
}
location /uploads/ {
    alias /opt/game/server/uploads/;
    expires 7d;
    add_header Cache-Control "public, immutable";
}
```

### Бэкап перед деплоем:
```bash
ssh root@VPS "cp /opt/game/server/game.db /opt/game_backup_pre_pg_$(date +%Y%m%d_%H%M).db"
```

**Заливка и переключение:**
```bash
git push origin pg-native
ssh root@VPS "cd /opt/game && git stash && git pull origin pg-native"
# Миграция данных — скрипт migrate_prod.js в корне server/
ssh root@VPS "cd /opt/game/server && node migrate_prod.js"
# Клиент нужно пересобрать (Vite) — ОБЯЗАТЕЛЬНО ПОСЛЕ ЛЮБЫХ ИЗМЕНЕНИЙ КЛИЕНТА
ssh root@VPS "cd /opt/game/client && npx vite build"
# PM2 — важно: cd /opt/game ПЕРЕД запуском, иначе ERR_MODULE_NOT_FOUND
ssh root@VPS "pm2 delete game-server; cd /opt/game && pm2 start 'PORT=3001 npx tsx server/src/index.ts' --name game-server"
```
**Важно:** без `npx vite build` клиент использует старый JS-бандл → несовместимость → краши `money.toLocaleString`, `content.split`.

**Важно:** `npm run build` не работает — `tsc -b` падает на предсуществующих TS-ошибках. Всегда использовать `npx vite build` напрямую.

**Вариант: работа напрямую на VPS (без локального клона):**
```bash
ssh root@mmoarena.ru "cd /opt/game && git add <файлы> && git commit -m '...'"
ssh root@mmoarena.ru "cd /opt/game/client && npx vite build"
ssh root@mmoarena.ru "pm2 restart game-server"
```
После деплоя проверить: `curl -s http://localhost:3001/api/...` с валидным JWT.

### Типы колонок для миграции
- Все TIMESTAMPTZ → TEXT (код шлёт и ISO строки и epoch int'ы)
- Epoch-second колонки → INTEGER
- **Перед миграцией ALTER COLUMNS:**
```sql
ALTER TABLE tournaments ALTER COLUMN createdat TYPE TEXT;
ALTER TABLE tournaments ALTER COLUMN completedat TYPE TEXT;
ALTER TABLE users ALTER COLUMN lastloginat TYPE TEXT;
ALTER TABLE users ALTER COLUMN createdat TYPE TEXT;
GRANT ALL ON ALL TABLES IN SCHEMA public TO game;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO game;
```

## Турниры

### 🔴 N+1 запросов на GET /tournament — 200+ запросов при загрузке

Каждый GET вызывает `getOrCreateTournament()` (10+ запросов + INSERT новых турниров) и `autoAdvance()` для каждого турнира. Плюс для каждого матча — 3 отдельных запроса за именами игроков. При 10 турнирах × 3 матча = 180+ запросов только на имена.

**Симптом:** `/api/tournament` таймаутит (10+ секунд), страница «Турниры» не грузится, 502/504.

**Фикс (3 шага):**
1. Убрать `getOrCreateTournament()` и `autoAdvance()` из GET — только читаем данные
2. Ограничить `LIMIT 10` (активные) и `LIMIT 5` (завершённые)
3. Батч-запросы матчей и имён:
```typescript
// Все матчи одним запросом
const allMatches = await db.query(
    `SELECT * FROM tournament_matches WHERE tournamentId IN (${ids})`, ids);
// Все имена одним запросом
const playerIds = new Set(allMatches.flatMap(m => [m.player1Id, m.player2Id, m.winnerId]));
const users = await db.query(`SELECT id, username FROM users WHERE id IN (${[...playerIds]})`, [...playerIds]);
```

Результат: 200+ запросов → ~13, ответ 10+ секунд → 0.8ms.

Продвижение — ТОЛЬКО при заходе на страницу `/api/tournament` (вызов `autoAdvance` для всех `registration`/`in_progress`). То же что на SQLite.

> Боевой лог с HP и компонент BracketTree: `references/battle-log-hp.md`
> Сезонный сброс и баг с camelCase `date`: `references/season-reset-bug.md`
> Мобильные тач-события (useLongPress, синтетический click): `references/mobile-touch-patterns.md`
> Крафт: materialUsage и камни улучшения: `references/craft-material-usage.md`
> Загрузка изображений через base64 (без файлового сервера): `references/base64-image-upload.md`

**Кража серебра в турнирных боях:** `runBattle()` добавляет шаги `money` в лог. В турнирах (и гильд-войнах) серебро не воруем — фильтровать после `runBattle()`:
```typescript
const result = runBattle(p1, p2);
const tourSteps = result.steps.filter((s: any) => s.type !== 'money');
```

**Призы — 3 места:** если >2 участников — 50/30/20% от призового фонда. Логика в `finishTournament`. Третье место определяется из полуфинала: проигравший, который не чемпион и не второе место.

**Честный bye (только 1-й раунд, топ-ELO):**
Исходная реализация добивала массив игроков null-ами до степени 2 и создавала матчи попарно: `(1vs2), (3vs4), ..., (null vs null)`. Это приводило к бай-игрокам в нечётных раундах после первого — один и тот же игрок мог получить несколько bye подряд (несправедливо).

**Правильная реализация:** все bye даются ТОЛЬКО в 1-м раунде сильнейшим по ELO игрокам. После 1-го раунда количество игроков = ровно `slots/2` (степень 2) — дальше сетка чистая без bye.

```typescript
// Сортируем по ELO DESC (сильнейшие → выше)
const byes = slots - n;           // сколько игроков проходят без боя
const playInRound1 = n - byes;    // сколько играют в 1-м раунде
// Топ-ELO получают bye:
for (let i = 0; i < byes; i++) {
    INSERT ... (player1Id = participants[i], player2Id = NULL, winnerId = participants[i])
}
// Остальные играют попарно (соседние по ELO):
for (let i = 0; i < playInRound1 / 2; i++) {
    INSERT ... (participants[byes + i*2] vs participants[byes + i*2 + 1])
}
```

**Результат:** 38 игроков → 26 bye + 6 боёв = 32 для раунда 2 → 16 → 8 → 4 → 2 → финал. Ни одного bye после 1-го раунда.

**Бай для нечётных победителей (advanceWinners):**
В `advanceWinners` добавлена обработка нечётного числа победителей после основного цикла создания пар:
```typescript
if (n % 2 === 1) {
    INSERT ... (player1Id = winners[n-1], player2Id = NULL, winnerId = winners[n-1])
}
```
Без этого последний победитель вылетал из турнира (при 38 игроках: 19→9 пар→1 потерян, каждый раунд теряли). После введения честного bye в generateBracket эта ветка не должна срабатывать, но оставлена как safety net.

**generateBracket — прямой `pool.query` вместо `db.run`:**
`db.run` для INSERT с RETURNING id в catch-блоке всегда возвращает `lastInsertRowid: 0`, что ломает обработку bye (UPDATE по id=0). Для надёжности generateBracket переписан на прямой `pool.query` с нативными `$1, $2, ...` параметрами, минуя `pgLowerIdentifiers` и `pgParams`. Это исключает все проблемы с camelCase-идентификаторами и RETURNING id в контексте генерации брекета.

**Подробный лог боя с HP:** см. `references/battle-log-hp.md`

**Все async-вызовы в турнирной логике — с `await`:**
- `await getOrCreateTournament()` — без `await` вернётся Promise, турниры не отобразятся
- `await generateBracket(tournamentId)` — без `await` матчи не создадутся
- `await autoAdvance(tournamentId)` — рекурсивные вызовы должны быть awaited для полного цикла регистрация→бой→завершение
- `await resolveCurrentRound(tournamentId)` — симулирует бои моментально (runBattle)
- `await loadPlayerForBattle(userId)` — загрузка статов игрока для боя

### Ответ API: даты для клиента
Клиент делает `new Date(t.createdAt * 1000)` — ждёт **epoch-число (секунды)**.
Сервер: `Number(t.createdAt)` для epoch-строк, или `Math.floor(new Date(iso).getTime()/1000)` для ISO.
**Симптом:** `Invalid Date` на клиенте → сервер отдал ISO-строку вместо числа.
**Где применять:** турниры, банк (transfers, operations), любые ответы с `createdAt`/`completedAt`.

### Ловушка: `completedAt + 'Z'`
Никогда не делать `new Date(completedAt + 'Z')` — если `completedAt` уже ISO с `Z` на конце
(например `"2026-06-14T10:17:56.086Z"`), то `+ 'Z'` даёт `"...086ZZ"` → Invalid Date → проверка
задержки пропускается. Использовать универсальный парсер:
```js
const ts = typeof completedAt === 'number' ? completedAt * 1000
  : Number(completedAt) || new Date(completedAt).getTime();
```

### Массовый фикс дат на клиенте: `new Date(* 1000)` → `safeDate`/`fmtSafeDate`

После миграции на PG многие поля `createdAt`, `declaredAt`, `expiresAt`, `bannedUntil` возвращаются как ISO-строки, а не Unix timestamp (число). Клиентский код повсеместно делает `new Date(X * 1000)` — для строки это `NaN` → Invalid Date.

**Скрипт массовой замены** (`scripts/fix_client_dates.py`): патчит все `new Date(... * 1000)` → `safeDate(...)`/`fmtSafeDate(...)` с добавлением нужных импортов.

**Затронутые файлы клиента:**
- `pages/BankPage.tsx` — сортировка по дате + отображение (5 замен)
- `pages/TournamentPage.tsx` — createdAt в списке завершённых
- `pages/AdminPanel/AdminUsers.tsx` — bannedUntil + рендерер дат
- `pages/AdminPanel/AdminTournaments.tsx` — формат дат
- `pages/AdminPanel/AdminChat.tsx` — chatBannedUntil
- `contexts/ChatContext.tsx` — WebSocket chat ban
- `components/chat/ChatInput.tsx` — bannedUntil в интерфейсе
- `pages/GuildViewPage.tsx` — declaredAt/expiresAt войны
- `pages/GuildWarPage.tsx` — formatTime с `new Date(iso)`

**После замены — обязательный ребилд:** `cd client && npx vite build` (не `npm run build` — tsc упадёт).

**Проверка:** `grep -rn "new Date.*\* 1000" client/src/ --include="*.tsx" | grep -v utils/date.ts` — должно быть пусто.

**Проверка импортов после замены:** скрипт `scripts/check_safedate_imports.sh` проверяет все файлы клиента. Или вручную:
```bash
for f in client/src/pages/**/*.tsx client/src/components/**/*.tsx client/src/contexts/*.tsx; do
  if grep -q "fmtSafeDate\|safeDate" "$f" 2>/dev/null; then
    if ! grep -q "import.*fmtSafeDate\|import.*safeDate" "$f" 2>/dev/null; then
      echo "MISSING IMPORT: $f"
    fi
  fi
done
```
Известные файлы где импорт был пропущен: `AdminTournaments.tsx`, `AdminChat.tsx`, `AdminUsers.tsx`.

**⚠️ Питфол: `npx vite build` успешен, но страница падает в рантайме.** `fmtSafeDate is not defined` / `safeDate is not defined` — это НЕ ошибка билда. Vite успешно собирает бандл, но если в чанке используется `fmtSafeDate` без импорта в исходном файле, в рантайме будет `ReferenceError`. Симптом: страница (админка, профиль) белая или выбрасывает ошибку в консоли. Билд при этом зелёный. Фикс: добавить недостающий импорт `import { fmtSafeDate } from '../../utils/date';` в проблемный файл (путь относительно `client/src/pages/AdminPanel/`).

## Клиентские pitfalls

### HistoryPage: N+1 запросов личных сообщений
`fetchAllPrivateMessagesNew()` делает запрос списка собеседников + для КАЖДОГО собеседника отдельный запрос сообщений. При 20 собеседниках = 21 запрос. **Фикс:** заменить на один `fetch(/chat/recent?limit=50)` + клиентский filter.

### AuctionPage: `_.filter is not a function`
API возвращает `{error:"Не авторизован"}` когда нет токена, а клиент ждёт массив. **Фикс:** `Array.isArray(data.lots) ? data.lots : []`.

### rate-limit на low-RAM VPS
`express-rate-limit` хранит per-IP счётчики в памяти (~20-50MB). На VPS <1GB отключать: `DISABLE_RATE_LIMIT=true` в `.env`.

### Клиент: `safeDate()` — та же ловушка `+ 'Z'`

В `client/src/utils/date.ts` функция `safeDate` имела ровно тот же баг:
```typescript
// БЫЛО — ломает ISO-строки которые уже заканчиваются на Z:
return new Date(value.replace(' ', 'T') + 'Z');
// "2026-06-15T09:16:28.243Z" → "2026-06-15T09:16:28.243ZZ" → Invalid Date!
```
**Фикс v1 (дубль Z):**
```typescript
// СТАЛО — добавляет Z только если его ещё нет:
return new Date(value.endsWith('Z') ? value.replace(' ', 'T') : value.replace(' ', 'T') + 'Z');
```

**Фикс v2 (таймзона +00 от `NOW()`):** PG `NOW()` возвращает `"2026-06-15 09:39:56.772895+00"` — это не Z, не число, не стандартная строка. После фикса v1 в конец добавлялся Z → `"...+00Z"` → Invalid Date. Нужно детектить **любую** таймзону:

**Фикс v3 (нормализация +00 → +00:00):** `new Date("...+00:00")` — стандартный ISO, работает везде. `new Date("...+00")` — НЕ стандарт (таймзона без минут), некоторые браузеры (особенно мобильные) не парсят. ФИНАЛЬНАЯ версия (`client/src/utils/date.ts`):
```typescript
export function safeDate(value: any): Date | null {
    if (value == null) return null;
    if (typeof value === 'number') return new Date(value * 1000);
    if (typeof value === 'string') {
        if (/^\d+$/.test(value)) return new Date(Number(value) * 1000);
        let s = value.replace(' ', 'T');
        s = s.replace(/([+-]\d{2})$/, '$1:00');  // +00 → +00:00
        const hasTZ = s.endsWith('Z') || /[+-]\d{2}:\d{2}$/.test(s);
        return new Date(s + (hasTZ ? '' : 'Z'));
    }
    return null;
}
```

**Покрываемые форматы:**
- `"2026-06-13 08:05:41"` → `+ 'Z'` → `"...T08:05:41Z"` ✓
- `"2026-06-15T09:16:28.243Z"` → already has Z → no change ✓
- `"2026-06-15 09:39:56.772895+00"` → space→T, +00→+00:00 → `"...T09:39:56.772895+00:00"` ✓
- Unix timestamp (number) → `* 1000` → Date ✓
- Цифровая строка (`"1781443712"`) → `Number * 1000` → Date ✓

**Симптомы:**
- v1: в UI все даты фидбеков показывают «Invalid Date» — ISO-строка из PG дублирует Z.
- v2: история казны гильдии показывает «Invalid Date» — PG `NOW()` даёт `+00` вместо `Z`, а safeDate добавляет лишний Z.

### Админка: `completedAt` при ручном завершении
Эндпоинт `POST /tournaments/:id/complete` обновляет статус на `completed`,
но НЕ ставит `completedAt`. Без этого часовая задержка перед новым турниром пропускается.
**Фикс:** `UPDATE tournaments SET status = 'completed', completedAt = ?` (ISO сейчас).
**Проверка:** после ручного завершения `completedAt` НЕ должен быть NULL.

### `UPDATE SET exp = exp + ?` без `applyExp()` — опыт копится, уровень не растёт

**Паттерн-баг:** эндпоинт начисляет опыт через сырой `UPDATE users SET exp = exp + ?` без вызова `applyExp()`. Опыт в БД растёт, но уровень никогда не проверяется и не повышается. Очки статов тоже не начисляются.

**Симптом:** игроки жалуются что после сдачи квеста/другого действия опыт прибавился, но уровень не повысился. В БД `exp` больше чем нужно для следующего уровня, а `level` старый.

**Реальный пример (quests.ts — `/tavern/quests/claim`):**
```typescript
// БЫЛО — сырой UPDATE, уровень не проверяется
await db.run('UPDATE users SET money = money + ?, exp = exp + ? WHERE id = ?',
    [quest.rewardMoney, quest.rewardXp, userId]);
```

**Фикс:** после начисления денег отдельно получить текущие `exp/level/statPoints`, вызвать `applyExp()`, и обновить все три поля:
```typescript
await db.run('UPDATE users SET money = money + ? WHERE id = ?', [quest.rewardMoney, userId]);
const user = await db.one('SELECT exp, level, statPoints FROM users WHERE id = ?', [userId]) as any;
const { newExp, newLevel, levelsGained, newStatPoints } = await applyExp(userId, quest.rewardXp, user.exp, user.level, user.statPoints || 0);
await db.run('UPDATE users SET exp = ?, level = ?, statPoints = ? WHERE id = ?',
    [newExp, newLevel, newStatPoints, userId]);
```

**Где уже правильно:** бои (`battle.ts`, `mobs.ts`), работы (`character.ts` — через `applyExp` при завершении активной работы). Квесты — исправлены.

**Где искать ещё:** любые эндпоинты где `UPDATE ... SET exp = exp + ?` без последующего `applyExp()`. Grep: `grep -rn "SET exp = exp +" server/src/routes/`.

## PvE жалование (зарплата)

> Клиентские pitfalls расчёта статов: `references/client-stat-pitfalls.md`

Система в `server/src/index.ts`: каждый час в :00 минут всем игрокам начисляется `pveWins` серебра на руки.
Сообщение в ЛС: `💰 Жалование: +N серебра`. Вкладка «💰 Зарплата» в Истории.

### Клиент: `formatGameDateTime` — guard от NaN
Если `createdAt` приходит null/undefined/пустой строкой, `new Date(undefined)` → Invalid Date → `getUTCDate()` = NaN → `NaN.NaN NaN:NaN` в UI.

**Фикс:** добавить guard в `client/src/utils/time.ts`:
```ts
export function formatGameDateTime(date: string | number | Date): string {
    if (date === null || date === undefined || date === "") return "—";
    const d = ...;
    if (isNaN(d.getTime())) return "N/A";
    ...
}
```

## Зарплата (PvE жалование) и системные сообщения

Система в `server/src/index.ts`: каждый час в :00 минут всем игрокам начисляется `pveWins` серебра. Сообщение в `chat_messages` от `senderId=0` с `targetId=userId`: `💰 Жалование: +N серебра`.

### Баг: `u.pvewins` vs `u.pveWins` (camelCase)

После camelRows `pvewins` → `pveWins`, но код читает `u.pvewins` (undefined). Симптом: сообщения `💰 Жалование: +undefined серебра`. Фикс: `u.pveWins || u.pvewins`.

### Баг: системные сообщения не попадают в сводку

`fetchAllPrivateMessagesNew()` получает только сообщения между пользователями (senderId/targetId ≠ 0). Системные сообщения от `senderId=0` не видны.

**Фикс:** endpoint `/chat/system` возвращает сообщения где `senderId=0 AND targetId=userId AND content LIKE '💰%'`. Клиент добавляет их в `privateMessages` при загрузке сводки.

### Клиент: `formatGameDateTime` — guard от NaN

Если `createdAt` null/undefined/пустая строка → `new Date(undefined)` → Invalid Date → `getUTCDate()=NaN` → `NaN.NaN NaN:NaN` в UI.

**Фикс:** добавить guard в `client/src/utils/time.ts`:
```ts
if (date === null || date === undefined || date === "") return "—";
const d = ...;
if (isNaN(d.getTime())) return "N/A";
```

## Аукцион

### Гонка ставок: `db.tx` + `FOR UPDATE`

При ставке SELECT и UPDATE разделены — между ними другой запрос может прочитать старый `currentBid`. Две одновременные ставки видят `currentBid=null` и обе принимаются по стартовой цене. **Симптом:** повторная ставка по той же цене принимается.

**Фикс:** вся логика ставки внутри `db.tx()` с `SELECT ... FOR UPDATE`:
```typescript
await db.tx(async (client) => {
    const lot = (await client.query(
        'SELECT * FROM auction_lots WHERE id = $1 AND endsAt > $2 FOR UPDATE',
        [lotId, now]
    )).rows[0];
    if (!lot) throw new Error('Лот не найден');
    const currentBid = lot.currentbid ? parseInt(lot.currentbid) : null;
    const minBid = currentBid ? currentBid + Math.max(1, Math.floor(currentBid * 0.05)) : parseInt(lot.startprice);
    if (amount < minBid) throw new Error(`Мин. ставка: ${minBid}`);
    // возврат предыдущему лидеру, списание, обновление
});
```

**Важно:** внутри `client.query()` ключи lowercase (`currentbid`, `sellerid`, `startprice`), НЕ camelCase. `parseInt()` для числовых значений.

### История сделок

Лоты удаляются при выкупе → история теряется. Таблица `auction_history` (sellerId, buyerId, itemName, itemData, price, commission, createdAt). INSERT при buyout и partial-buy. GET `/auction/history` — общая (без фильтра по userId).

### 🛒 Доставка предметов при auto-resolution (pitfall)

При завершении истекшего лота (auto-resolution в `GET /auction`) код доставки проверяет `equipCount` и `isGear`. Если сервер использует старый скомпилированный JS (после `pm2 restart` без `delete + start`), предметы молча теряются: серебро списывается, история пишется, но ни в инвентарь ни на склад предмет не попадает.

**Диагностика:** `SELECT count(*) FROM overflow_storage WHERE userId=X`, `jsonb_array_length(inventory)`. Если оба 0 после завершения — баг.

**Фикс:** всегда `pm2 delete` + свежий `pm2 start` после `npx tsc`. См. "PM2 restart НЕ подхватывает перекомпилированный JS".

**PG lowercase pitfall:** `lot.currentBidderId` в коде — PG возвращает `currentbidderid` (lowercase). Без `buyerId = lot.currentbidderid || lot.currentBidderId` код доставки НЕ находит победителя → предметы молча теряются. **Все `lot.sellerId`, `lot.currentBidderId`, `lot.currentBid` должны использовать `||` паттерн в auto-resolution коде.**

**PG lowercase pitfall — SQL WHERE clause:** запрос `WHERE currentBidderId IS NOT NULL` (camelCase) в auto-resolution истекающих лотов. В PG колонка называется `currentbidderid` (lowercase). pgLowerIdentifiers конвертирует идентификаторы в SQL, но `currentBidderId` → `currentbidderid` (lowercase) — это РАБОТАЕТ. Однако если pgLowerIdentifiers не применяется (какой-то крайний случай), camelCase в WHERE даёт `column does not exist`. Для надёжности писать `WHERE currentbidderid IS NOT NULL` прямо в SQL. Также добавить guard: `if (!buyerId) continue;` после парсинга buyerId — если победителя нет (лот без ставок), пропустить обработку вместо падения на `NOT NULL constraint` в `auction_history`.

### Подсчёт слотов инвентаря — только снаряжение

Материалы (`craft_item`, `material`, `upgrade`) НЕ занимают слоты инвентаря. Только предметы со свойством `.slot` (helmet, gloves, boots, amulet, weapon, ring, etc.) считаются за 1 слот.

**Фикс:** `items.filter(i => !!i.slot).length` вместо `items.length`.

Применяется везде: аукцион (покупка, авто-завершение), overflow take, создание лота.

### 🔴 Аукцион: PG lowercase — предметы молча теряются

**Корень проблемы:** PG возвращает `currentbidderid`, `sellerid`, `buyoutprice`, `startprice` (lowercase). Код читает `lot.currentBidderId`, `lot.sellerId` — **undefined**. Победитель не находится (`WHERE id = undefined` → 0 rows), предмет не доставляется, но лот удаляется и серебро списывается. Часы отладки.

**Фикс:** в auto-resolution коде ВСЕГДА паттерн `||`:
```typescript
const buyerId = lot.currentbidderid || lot.currentBidderId;
const sellerId = lot.sellerid || lot.sellerId;
```
И дальше использовать `buyerId`/`sellerId` вместо `lot.sellerId`/`lot.currentBidderId` во ВСЕХ местах: запрос победителя, UPDATE инвентаря, INSERT в историю, markDirty.

**Проверка:** после завершения лота инвентарь должен увеличиться. Если `jsonb_array_length(inventory)` не изменился — баг.

### Склад переполнения (overflow storage)

Предметы с аукциона, не влезшие в инвентарь (только снаряжение — материалы/камни всегда в инвентарь), попадают в `overflow_storage`. Склад — безлимитный. Клиент: клик → забор в инвентарь, тултипы, drag-and-drop.

**Сервер:** таблица `overflow_storage` (userId, item JSONB, auctionLotId, createdAt). Эндпоинты: `GET /api/overflow`, `POST /api/overflow/take/:id`.

**Права:** таблицы созданные через `sudo -u postgres` недоступны для `game` пользователя. После CREATE:
```sql
GRANT ALL ON overflow_storage TO game;
GRANT ALL ON overflow_storage_id_seq TO game;
GRANT ALL ON ALL TABLES IN SCHEMA public TO game;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO game;
```

### PM2 restart НЕ подхватывает перекомпилированный JS

`pm2 restart game-server` перезапускает процесс, но если используется скомпилированный JS (`dist/index.js`), старый код может остаться в кеше Node/V8. **Всегда `pm2 delete` + `pm2 start` после `npx tsc`:**

```bash
pm2 delete game-server
cd /opt/game/server
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" --name game-server --max-memory-restart 900M
pm2 save --force
```

### Склад переполнения (overflow storage)

Предметы с аукциона, не влезшие в инвентарь (только снаряжение — материалы/камни всегда в инвентарь), попадают в `overflow_storage`. Склад — безлимитный. Клиент: клик → забор в инвентарь, тултипы, drag-and-drop.

**Сервер:** таблица `overflow_storage` (userId, item JSONB, auctionLotId, createdAt). Эндпоинты: `GET /api/overflow`, `POST /api/overflow/take/:id`.

**Права:** таблицы созданные через `sudo -u postgres` недоступны для `game` пользователя. После CREATE:
```sql
GRANT ALL ON overflow_storage TO game;
GRANT ALL ON overflow_storage_id_seq TO game;
```

> Полный референс: `references/overflow-storage.md`

### 🕐 Клиент: время в UTC (не локальное браузера)

`fmtSafeDate` использует `toLocaleString('ru-RU', { timeZone: 'UTC', ... })`. Сервер работает в UTC, все даты в UI должны быть UTC.

### 📦 ItemStats: проверка коллекции в тултипе

В `ItemStats.tsx` добавлена проверка: если предмет есть в `character.collectedItems` (по `itemName` + `slot`) — показывается «✓ В коллекции» (зелёный), иначе «✗ Нет в коллекции» (жёлтый).

Сервер возвращает `collectedItems` в `/api/character/me`:
```typescript
const collectedItems = await db.query(
  'SELECT itemname as itemName, slot FROM collections WHERE userId = ?', [userId]
);
```

### WS-уведомления + бейдж

- `pushNotification(sellerId, { type: 'auction_sold', ... })` — тост продавцу
- `broadcast('auction_changed', {})` — live-обновление списка всем (при ставке, выкупе, создании лота, отмене)
- Бейдж на карточке через `window.__auctionBadge` (глобальная переменная, переживает размонтирование Actions). Сбрасывается при клике.

**pushNotification для офлайн-пользователей:** изначально был guard `if (!clients.has(userId)) return;` — уведомления дропались если адресат офлайн. Убран: уведомления копятся в очереди и доставляются при следующем подключении. `markDirty(userId, 'notifications')` вызывается даже для офлайн — флаги обрабатываются на следующем serverTick после коннекта.

**Бейдж через серверный счётчик (auction_sales):** localStorage/глобальные переменные теряются при смене устройства. Правильный подход: колонка `auction_sales INTEGER DEFAULT 0` в таблице `users`. Инкремент при выкупе (`UPDATE users SET auction_sales = COALESCE(auction_sales, 0) + 1 WHERE id = ?`). Сброс при заходе на страницу аукциона (`POST /auction/reset-badge`). Значение отправляется в serverTick: `SELECT money, bank, COALESCE(auction_sales, 0) as auctionSales FROM users`. Клиент читает `data.auctionSales` из serverTick и синхронизирует localStorage для быстрого доступа. **Паттерн: всегда хранить состояние на сервере, localStorage — только как кеш/оптимизация.** Путь эволюции: локальный state (теряется при навигации) → глобальная переменная (теряется при refresh) → localStorage (теряется при смене устройства) → серверная колонка (работает везде).

**Синхронное применение отложенных данных (refs вместо useEffect):** при быстрой анимации (×2/×5) useEffect с `pendingCharacter`/`pendingDrops` срабатывает с задержкой → награды до конца боя. Фикс: refs + вызов `applyPending()` синхронно в `nextStep`. `references/apply-pending-refs.md`.

**Ловушка: CardGrid секции world vs castle.** Карточка «Аукцион» находится в секции **🏰 Площадь** (castle), а не 🌍 МИР (world). Пропсы `auctionBadge` и `onAuctionClick` нужно передавать в ОБА вызова `<CardGrid>`. Если передать только в world — бейдж никогда не появится. Симптом: всё работает, но бейджа нет. Диагностика: проверить `actions_config` → в какой `section` находится карточка. Часы отладки потрачены на этот баг — всегда проверять ОБА CardGrid при добавлении новых пропсов.

### Чат: сохранение текста при ошибке валидации

Сервер валидирует WS-сообщения через Zod (`wsPublicMessageSchema`, `wsPrivateMessageSchema`). При ошибке отправлял глухое «Некорректное сообщение». Клиентский `ChatInput` очищал поле ДО получения ответа от сервера → текст терялся.

**Фикс сервер:** отправлять конкретную ошибку из Zod:
```typescript
const err = parsed.error.errors[0]?.message || 'Некорректное сообщение';
sendToUser(userId, { type: 'error', message: err });
```
Теперь клиент видит: «Сообщение слишком длинное» / «Сообщение не может быть пустым».

**Фикс клиент:** сохранять текст в `window.__lastChatInput` перед отправкой, восстанавливать при `chatError`:
```typescript
// При отправке
(window as any).__lastChatInput = trimmed;
// При ошибке (useEffect на chatError)
if (chatError && (window as any).__lastChatInput) {
    setInput((window as any).__lastChatInput);
    (window as any).__lastChatInput = null;
}
```

**Ловушка: `sendToUser` молча игнорирует офлайн-пользователей.** Функция проверяет `clients.get(userId)` — если пользователь не в сети, сообщение не отправляется. Для критичных уведомлений (бейдж аукциона) использовать серверное состояние (колонка в БД) + serverTick, а не полагаться на `sendToUser`.

## Банк: фикс дат

Те же правила конвертации `createdAt` что для турниров: конвертить в epoch-число в ответах
`/bank/transfers` и `/bank/operations`.

### `.map(async` без `Promise.all`
Все `.map(async` где есть `await` внутри → обернуть в `await Promise.all(...)`.
Где нет `await` → убрать `async`.
### Пропущенные `await`

Самые частые: `loadPlayerForBattle`, `resolveCurrentRound`, `isGuildAtWar` (8 мест в guild.ts!), `finishTournament` (в advanceWinners — без await статус не обновится!), `enrichEquipment`, `getOrCreateTournament`, `generateBracket`.
После bulk-конвертации ВСЕГДА проверять grep-ом вызовы async-функций без await.

### `currentHp > 0` — ресает мёртвых до 100% HP

После PG-миграции `currentHp = 0` у мёртвого игрока. Проверка `(currentHp != null && currentHp > 0) ? currentHp : maxHp` даёт `false` при `currentHp === 0` → подставляет `maxHp` → мёртвый игрок ресается до 100% HP. Симптом: проиграл PvE (0 HP) → зашёл в PvP → HP стал 100% (максимум).

**Фикс:** убрать `> 0` — `(currentHp != null) ? currentHp : maxHp`. Плюс валидация в роуте: `if ((attacker.currentHp ?? 0) <= 0) return 400`.

**Где:** `server/src/game/battle.ts` — `runBattle()`. Затронуты и attacker, и defender.

### 🔴 PM2 restart НЕ подхватывает перекомпилированный JS

`pm2 restart game-server` перезапускает процесс, но если используется скомпилированный JS (`dist/index.js`), старый код может остаться в кеше Node/V8. **Всегда использовать `pm2 delete` + свежий `pm2 start` после `npx tsc`:**

```bash
pm2 delete game-server
cd /opt/game/server
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" --name game-server --max-memory-restart 900M
pm2 save --force
```

**Симптом:** ошибка из старой версии кода продолжает появляться в логах, хотя исходник и dist исправлены. Например `ReferenceError: Cannot access 'item' before initialization` — переменная в новом коде объявлена правильно, но процесс всё ещё выполняет старый dist.

### Overflow storage — отдельный референс

Таблицы, созданные через `sudo -u postgres psql`, НЕ доступны для пользователя `game`. 

**Симптом:** `error: permission denied for table overflow_storage` → 500 на `/api/overflow`.

**Фикс:** после CREATE TABLE всегда GRANT:
```sql
GRANT ALL ON overflow_storage TO game;
GRANT ALL ON overflow_storage_id_seq TO game;
```

**Профилактика:** после любых DDL на проде:
```sql
GRANT ALL ON ALL TABLES IN SCHEMA public TO game;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO game;
```

### 🔴 PM2 restart НЕ подхватывает перекомпилированный JS

`pm2 restart game-server` перезапускает процесс, но если используется скомпилированный JS (`dist/index.js`), старый код может остаться в кеше Node/V8. **Всегда использовать `pm2 delete` + свежий `pm2 start` после `npx tsc`:**

```bash
pm2 delete game-server
cd /opt/game/server
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" --name game-server --max-memory-restart 900M
pm2 save --force
```

**Симптом:** ошибка из старой версии кода продолжает появляться в логах, хотя исходник и dist исправлены. Например `ReferenceError: Cannot access 'item' before initialization` — переменная в новом коде объявлена правильно, но процесс всё ещё выполняет старый dist.

### Подсчёт слотов инвентаря — только снаряжение

Материалы (`craft_item`, `material`, `upgrade`) НЕ занимают слоты инвентаря. Только предметы со свойством `.slot` (helmet, gloves, boots, amulet) считаются за 1 слот.

**Фикс:** `items.filter(i => !!i.slot).length` вместо `items.length`.

### Сортировка аукциона: лоты «не мои» вверху

При сортировке по ставке (`price_asc`/`price_desc`) добавлять первичный ключ:
```sql
ORDER BY CASE WHEN l.currentBidderId = $userId THEN 1 ELSE 0 END, ...
```
Лоты где игрок ещё не участвует → 0 → вверху. Где уже поставил → 1 → ниже.

### Турниры: `IN ()` с пустым массивом → syntax error

Когда таблица tournament_matches пуста, `allTournaments.map(() => '?')` даёт пустую строку, и SQL становится `WHERE tournamentId IN ()` — невалидный SQL, PG падает с `syntax error at or near ")"`.

**Фикс — guard перед запросом:**
```typescript
let allMatches: any[] = [];
if (allTournaments.length > 0) {
    allMatches = await db.query(
        `SELECT * FROM tournament_matches WHERE tournamentId IN (${...})`, [...]
    ) as any[];
}
```

### Турниры: авто-отмена при <2 участников

При завершении регистрации (`registrationEnd` истекло) проверять количество участников:
```typescript
const pCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_participants WHERE tournamentId = ?', [tId]) as any).cnt;
if (pCount < 2) {
  await db.run('UPDATE tournaments SET status = ?, completedAt = ? WHERE id = ?', ['cancelled', now, tournamentId]);
  return;
}
```

### Турниры: `IN ()` с пустым массивом → syntax error

Когда таблица tournament_matches пуста, `allTournaments.map(() => '?')` даёт пустую строку, и SQL становится `WHERE tournamentId IN ()` — невалидный SQL, PG падает с `syntax error at or near ")"`.

**Фикс — guard перед запросом:**
```typescript
let allMatches: any[] = [];
if (allTournaments.length > 0) {
    allMatches = await db.query(
        `SELECT * FROM tournament_matches WHERE tournamentId IN (${...})`, [...]
    ) as any[];
}
```

### Турниры: авто-отмена при <2 участников

При завершении регистрации (`registrationEnd` истекло) проверять количество участников:
```typescript
const pCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_participants WHERE tournamentId = ?', [tId]) as any).cnt;
if (pCount < 2) {
  await db.run('UPDATE tournaments SET status = ?, completedAt = ? WHERE id = ?', ['cancelled', now, tournamentId]);
  return;
}
```

### Квесты: миграция на новый день (сохранение прогресса)

При `GET /tavern/quests`: если квестов на сегодня нет, перенести ВСЕ незавершённые квесты с ЛЮБЫХ прошлых дней (не только вчера). **Критично: НЕ обновлять `snapshot`** — иначе прогресс обнулится (текущие статы - новый снапшот = 0).

```typescript
// Было: WHERE date = ? (только вчера) + SET snapshot = ? (обнуление!)
// Стало:
const activeOld = await db.query(
  "SELECT * FROM daily_quests WHERE userId = ? AND date < ? AND status = 'active'",
  [userId, today]
);
for (const aq of activeOld) {
  await db.run('UPDATE daily_quests SET date = ? WHERE id = ?', [today, aq.id]);
  // snapshot НЕ трогаем — прогресс сохраняется
}
```

### Работы: награда × уровень + premiumBonus в ответе

Макс. награда умножается на уровень при старте. Премиум-бонус нужно включить в JSON ответа (`premiumBonus`), иначе клиент покажет его с задержкой (через serverTick):

```typescript
const scaledMax = job.rewardMax * (user.level || 1);
let reward = Math.floor(Math.random() * (scaledMax - job.rewardMin + 1)) + job.rewardMin;
// ...
res.json({ success: true, ..., premiumBonus, rewardMax: scaledMax });
```

Клиент (`JobsPage.tsx`) должен использовать `premiumBonus` из ответа при создании `activeJob` в `setCharacter`.

### Работы: награда × уровень

Максимальная награда за работу умножается на уровень игрока:
```typescript
const scaledMax = job.rewardMax * (user.level || 1);
let reward = Math.floor(Math.random() * (scaledMax - job.rewardMin + 1)) + job.rewardMin;
```

Премиум-бонус должен быть включён в ответ при старте работы (`premiumBonus` в JSON), иначе клиент покажет его с задержкой после serverTick.

### ServerTick батчинг: один запрос на всех

Вместо N отдельных запросов `SELECT money, bank FROM users WHERE id = ?` для каждого пользователя — один батч:
```typescript
const userIds = Array.from(clients.keys());
if (userIds.length === 0) return;
const placeholders = userIds.map(() => '?').join(',');
const rows = await db.query(
  `SELECT id, money, bank, COALESCE(auction_sales, 0) as auctionSales FROM users WHERE id IN (${placeholders})`,
  userIds
);
const batch = new Map<number, any>();
for (const r of rows) batch.set(r.id, r);
// Раздать данные по WebSocket-клиентам из batch
for (const userId of userIds) {
  const ws = clients.get(userId);
  if (!ws || ws.readyState !== WebSocket.OPEN) continue;
  const stats = batch.get(userId);
  ws.send(JSON.stringify({ type: 'serverTick', time, money: stats.money || 0, bank: stats.bank || 0 }));
}
```

Сокращает N запросов до 1.

### CharacterCard: оверлей на изображениях

Радиальный градиент для затемнения фона персонажей/мобов:
```tsx
<div className="absolute inset-0 z-[1]"
  style={{
    background: 'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.1) 100%)',
  }} />
```
Прозрачный центр, 10% затемнение по краям. Добавляется ПОСЛЕ фонового изображения в `CharacterCard.tsx`.

### Bots: cleanup after overnight run

50 bots overnight generate 427K+ tournament_matches records (334MB), hundreds of chat_messages, and corrupted tournament data. **Cleanup:**
```sql
DELETE FROM tournament_matches WHERE id NOT IN (
  SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 100
);
DELETE FROM tournaments WHERE status IN ('completed', 'cancelled');
DELETE FROM chat_messages WHERE id NOT IN (
  SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500
);
VACUUM;
```
Table `bot_accounts`: delete inactive: `DELETE FROM bot_accounts WHERE active = 1;`

### Daily quests: migration on new day (progress carry-over)

When `GET /tavern/quests` finds no quests for today, it migrates active quests from previous days. Original code only looked at `yesterday` — quests from 2+ days ago were lost. Progress was reset because `snapshot` was updated to current stats (zeroing progress).

**Fix:** query ALL old quests (`date < today`), preserve original `snapshot`:
```typescript
const activeOld = await db.query(
  "SELECT * FROM daily_quests WHERE userId = ? AND date < ? AND status = 'active'",
  [userId, today]
);
for (const aq of activeOld) {
  await db.run('UPDATE daily_quests SET date = ? WHERE id = ?', [today, aq.id]);
  // Do NOT update snapshot — preserves progress
}
```

### ServerTick batching: one query for all users

Instead of N separate `SELECT money, bank FROM users WHERE id = ?` per user — one batch:
```typescript
const userIds = Array.from(clients.keys());
const rows = await db.query(
  `SELECT id, money, bank, COALESCE(auction_sales, 0) as auctionSales FROM users WHERE id IN (${placeholders})`,
  userIds
);
const batch = new Map(rows.map(r => [r.id, r]));
// Distribute data to WS clients from batch map
```

### Economic: job reward × player level

Max reward scales with level: `reward = rand(rewardMin, scaledMax)` where `scaledMax = rewardMax * (user.level || 1)`. Premium bonus must be included in the start-job response JSON (`premiumBonus`), otherwise client shows it with delay after serverTick.

### 🔴 КРИТИЧЕСКИ: `async function` без `await` — возвращает Promise вместо значения

После миграции с синхронного SQLite на асинхронный PG многие функции были помечены `async` «на всякий случай». Если внутри `async function` нет ни одного `await`, она возвращает `Promise<T>` вместо `T`. Любые арифметические/логические операции над возвращаемым значением дают `NaN`/`falsy` без единой ошибки в логах.

**Реальный пример — турниры (4+ часа отладки):**
```typescript
// БЫЛО — async без await, функция чисто синхронная
async function nextPowerOfTwo(n: number): number {
    let p = 1;
    while (p < n) p *= 2;
    return p;
}

const slots = nextPowerOfTwo(n);  // Promise<number>, НЕ число!
const half = slots / 2;           // NaN!
for (let i = 0; i < half; i++) {} // цикл не выполняется ни разу
```

Все логи писали `participants=3`, но матчи не создавались — цикл `i < NaN` всегда false. Бесконечный цикл в `autoAdvance` (регенерирует брекет, опять 0 матчей, рекурсия).

**Фикс:** убрать `async` с функций, которым он не нужен:
```bash
grep -rn "async function" server/src/ | grep -v "await"  # найти подозрительные
```
Правило: `async` ТОЛЬКО если внутри есть `await`. Иначе TypeScript пропускает (нет ошибки компиляции!), но рантайм ломается молча.

**Симптомы:**
- Значения в логах: `[object Promise]`, `NaN`, `undefined`
- Циклы не выполняются (условие с NaN)
- Операции молча пропускаются (нет exception — Promise это объект, не undefined)
- TypeScript НЕ выдаёт ошибку: `Promise<number>` присваивается в `const n: number` без warning

**Где ещё может проявиться:** любые «async для порядка» функции в коде после миграции. Проверить grep-ом.

### `r[0]` vs `r.rows[0]` — raw client.query возвращает объект

При использовании `db.tx(async (client) => { ... })` запросы идут через `client.query()` напрямую (не через `db.one()`). PG driver возвращает `{ rows: [...], rowCount: N }`, а НЕ массив. `r[0]` → `undefined`, `r.rows[0]` → первый ряд.

**Симптом:** `Cannot read properties of undefined (reading 'treasury')` при успешном deposit в казну — операция в БД прошла, но сервер крашнулся на `return r[0]`.

**Где искать:** все `client.query(...).then(r => r[0])` или `const r = await client.query(...); return r[0]`.
`db/helpers.ts` — функции больше не принимают `db` параметром.
Проверить все вызовы: `getUserById(db,` → `getUserById(`, `addPveRating(db,` → `addPveRating(`, и т.д.
