# Client-Side State Sync Patterns

## Pattern 1: DELETE + Broadcast

When you delete a row from the database that is ALSO cached in client state
(React state, localStorage, etc.), the delete alone is NOT enough. You MUST also
broadcast a removal event via WebSocket so clients can update their local state.

```ts
// Server: delete + broadcast
await db.run('DELETE FROM some_table WHERE id = ?', [recordId]);
broadcast('record_removed', { id: recordId });

// Client: listen and filter
case 'record_removed': {
  setState(p => p.filter(item => item.id !== data.id));
  break;
}
```

**Real case**: auction chat messages — deleted from `chat_messages` on lot expiry,
but client still showed them from localStorage. Adding `broadcast('auction_message_removed')`
+ client-side filter fixed it.

## Pattern 2: localStorage Cleanup on Init

When the client caches ephemeral data in localStorage (chat messages, auction
messages), stale entries can persist across sessions. Filter them out when
initializing state from localStorage.

```tsx
const [messages, setMessages] = useState(() => {
  try {
    const raw = localStorage.getItem('chat_messages');
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    // Strip ephemeral message types that may be stale
    return parsed.filter(m => !m.item?.type?.startsWith('auction_'));
  } catch { return []; }
});
```

## Pattern 3: DB Cleanup for Orphaned Messages

When a parent record is deleted (e.g., auction lot), also delete its child
messages to prevent orphaned data:

```ts
await db.run('DELETE FROM auction_lots WHERE id = ?', [lotId]);
await db.run('DELETE FROM chat_messages WHERE item_data LIKE ?', [`%"lotId":${lotId}%`]);
```

Use `LIKE` with the JSON field since PG JSON operators may not be available.
The pattern `%"key":value%` works reliably for simple JSON string matching.
