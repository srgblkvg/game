# Аукцион — график истории цен

## Сервер: GET /api/auction/price-history

Запрос: `?name=...&slot=...&rarity=...`

Возвращает агрегированные по дням данные за 30 дней из `auction_history`:
```json
{ "points": [{ "day": "2026-08-07", "count": 5, "avg_price": 15000, "min_price": 10000, "max_price": 20000 }, ...] }
```

### Критично: COALESCE для slot
У материалов/рун нет поля `slot` → `->>'slot'` возвращает NULL → `NULL = ''` не матчит.
```sql
AND COALESCE(itemData::jsonb->>'slot', '') = ?
```

## Клиент: Chart.js + react-chartjs-2

```bash
npm install chart.js react-chartjs-2
```

Регистрировать только нужные компоненты:
```tsx
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler } from 'chart.js';
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);
```

### Компонент PriceChart — ленивая загрузка + сброс при смене предмета

```tsx
function PriceChart({ item }: { item: any }) {
    const [points, setPoints] = useState<any[] | null>(null);
    const itemKey = `${item.name}|${item.slot || ''}|${item.rarity_id ?? 0}`;
    useEffect(() => { setPoints(null); }, [itemKey]); // сброс кеша!
    // кнопка «📈 История цен» → fetch → график
}
```

### Формат дат: p.day = ISO timestamp → DD.MM
```tsx
labels: points.map(p => { const d = p.day.slice(0,10).split('-'); return `${d[2]}.${d[1]}`; })
```

### Y-axis: компактные k/M вместо formatMoney
```tsx
callback: v => v >= 1_000_000 ? `${(v/1_000_000).toFixed(1)}M` : v >= 1000 ? `${(v/1000).toFixed(1)}k` : v
```

### write_file pitfall на AuctionPage.tsx (700+ строк)
`tsc --noEmit` молчит (root tsconfig: `"files": []`). `tsc -b` ловит ошибки. После write_file всегда `npx tsc -b`.
