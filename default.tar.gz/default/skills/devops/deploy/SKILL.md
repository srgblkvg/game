---
name: deploy
description: Deploy MMO Arena server and client to production VPS, backup uploads and .env.
---

# Deploy MMO Arena

## Paths (production VPS: 194.226.142.237)

| What | Local | Production |
|---|---|---|
| Server (compiled) | `server/dist/` | `/opt/game/server/dist/` |
| Client (built) | `client/dist/` | `/opt/game/client/dist/` |
| Uploads (images) | `server/uploads/` | `/opt/game/server/uploads/` |
| .env | `server/.env` | `/opt/game/server/.env` |
| Nginx config | — | `/etc/nginx/sites-enabled/mmoarena` |
| PM2 app name | — | `game-server` |

## Deploy commands

```bash
# Server — build + deploy (PM2 runs node dist/index.js — deploy dist/ only)
cd server && npx tsc && rsync -avz dist/ root@194.226.142.237:/opt/game/server/dist/ && ssh root@194.226.142.237 pm2 restart game-server

# Client — build + deploy (use npm, not npx vite directly)
# NOTE: 'npm run build' runs tsc -b && vite build.
# The terminal tool sometimes rejects 'npx vite build' in foreground mode.
# Use background=true + notify_on_complete=true + process wait for npm run build too.
cd client && npm run build && sshpass -p 're8XyUoMH2PD6UCn' rsync -avz --delete dist/ root@194.226.142.237:/opt/game/client/dist/

# Uploads — deploy new files only (never use --delete!)
rsync -avz uploads/ root@194.226.142.237:/opt/game/server/uploads/

# .env — deploy manually when changed
scp .env root@194.226.142.237:/opt/game/server/.env && ssh root@194.226.142.237 "pm2 restart game-server"
```

### NEVER guess the server IP — always load this skill first 🔴

The production server IP is `194.226.142.237`. Do NOT guess, do NOT use a different IP from memory or another project. Any SSH/rsync/scp command must use this exact IP.

**Real case**: agent guessed `194.87.200.95` — wrong server, SSH failed, user frustrated. The correct IP is in THIS skill, always load it first.

### NEVER use `--delete` with rsync for server dist — IT DESTROYS .env 💀

`rsync -avz --delete dist/ root@...:/opt/game/server/dist/` will DELETE every file on the production server that isn't in your local `dist/`. Since `.env` is NOT in `dist/` (it's in the parent `server/` folder), it survives ONLY IF you rsync to `dist/`. But the real danger is that if you accidentally rsync --delete to the WRONG path, or if .env was somehow inside dist/, it's gone forever.

**Concrete scenario that happened**: first deploy to a server where .env was previously set up → rsync --delete → .env GONE → server crashes with `JWT_SECRET не задан` → all API returns 502 → need to reconstruct .env from memory/backups/dashboards.

**Prevention**: 
- NEVER use `--delete` in any rsync command for production
- Always check `curl -s http://localhost:3001/api/time` after server deploy
- If 502: `ssh root@... "pm2 logs game-server --lines 5"` to see the actual crash error

### .env is NOT in git
The `.env` file is excluded from git. You must copy it manually when needed. If the production .env is lost, you need to:
- Get JWT_SECRET from backup or regenerate
- Get VK keys, Yookassa keys, Yandex OAuth keys from their respective dashboards
- Use `DISABLE_RATE_LIMIT=true` on production

### Uploads are separate from dist
`server/uploads/` contains admin-uploaded images (floors, mobs, jobs, actions, items, craft, avatars). This is NOT in the dist folder. Deploy it separately with `rsync -avz uploads/` (no `--delete`).

### Backups
Cron job backs up uploads and .env every hour to `/opt/game/backups/`. Keeps 72 copies (3 days).

```bash
# Set up backup cron (run once on server):
cat > /opt/game/backup-uploads.sh << 'EOF'
#!/bin/bash
D=/opt/game/backups
mkdir -p $D/uploads $D/env
tar czf "$D/uploads/uploads-$(date +%Y%m%d-%H%M).tgz" -C /opt/game/server uploads
cp /opt/game/server/.env "$D/env/.env-$(date +%Y%m%d-%H%M)"
ls -t $D/uploads/*.tgz 2>/dev/null | tail -n +73 | xargs -r rm
ls -t $D/env/.env-* 2>/dev/null | tail -n +73 | xargs -r rm
EOF
chmod +x /opt/game/backup-uploads.sh
(crontab -l 2>/dev/null | grep -v backup-uploads; echo "0 * * * * /opt/game/backup-uploads.sh") | crontab -
```

### Nginx CORS for VK
If VK WebView can't load images, add CORS headers to nginx image locations:

```nginx
location ~* \.(webp|png|jpg|jpeg|svg|ico|woff2|woff|ttf)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
    add_header Access-Control-Allow-Origin "*";
}
```

### DB migrations (ALTER TABLE)

When adding new columns to existing tables as part of a deploy, the schema.sql is only documentation — you must run ALTER TABLE on production manually.

```bash
# Always use IF NOT EXISTS for idempotency
# The 'users' table is OWNED by 'postgres', NOT by 'game' — use sudo -u postgres
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"ALTER TABLE users ADD COLUMN IF NOT EXISTS new_column INTEGER DEFAULT 0;\""
```

**Table ownership**: `\dt` shows owners. Most tables are owned by `postgres`. The `game` user has GRANT (SELECT/INSERT/UPDATE/DELETE) but NOT ALTER. Always run migrations as the table owner.

**camelCase converter**: When adding a column like `tutorial_completed`, add the suffix (e.g. `completed`) to the suffix regex in `server/src/db/index.ts` line ~60 in the `camelRows` function. Without this, `row.tutorial_completed` stays lowercase in JS — no `tutorialCompleted` alias is created.

### DB field naming for new tables (CRITICAL)

When creating NEW tables (`forum_threads`, `forum_posts`, etc.), always use **snake_case** field names in client code. The camelCase converter in `db/index.ts` only handles a fixed set of suffixes — new columns like `created_at` from a newly created table may resolve to `created_At` (with underscore!) instead of `createdAt`.

**Rule**: In client code, reference `post.created_at`, `post.updated_at` — NOT `post.createdAt`, `post.updatedAt`. Same for any column with `_at`, `_id`, `_count` suffixes on tables created after the initial schema.

### Client-state sync patterns (CRITICAL)

When deleting DB rows that clients cache locally, always broadcast a removal event.
See `references/client-state-sync.md` for full patterns (DELETE+broadcast, localStorage cleanup, orphaned message cleanup).

### After deploy
- Client: Ctrl+Shift+R (new JS hashes)
- Server: `pm2 restart game-server` then `curl -s http://localhost:3001/api/time` to verify

### Stale PM2 logs trap (CRITICAL)

PM2 does NOT rotate error logs by default. `pm2 logs --nostream --lines 30` shows the LAST 30 lines of the log FILE, which may be days old if the error log hasn't been written to recently. Errors from before a server restart look current but aren't.

**Always do this when diagnosing server errors:**
```bash
# 1. Check when the error log was last modified
ssh root@194.226.142.237 "stat -c '%y' /root/.pm2/logs/game-server-error.log"

# 2. If timestamp is older than server uptime — FLUSH before diagnosing
ssh root@194.226.142.237 "pm2 flush && pm2 restart game-server"

# 3. Wait a few seconds, then check fresh logs
ssh root@194.226.142.237 "cat /root/.pm2/logs/game-server-error.log"
```

**Real case**: `pm2 logs` showed `column "senderguild" does not exist` — column actually existed, but the error log was from 3 days ago and had never been cleared.

### Troubleshooting: 502 on all API endpoints
If server returns 502 for every API call after deploy:
1. Check if server is running: `ssh root@... "pm2 status"`
2. Check actual error: `ssh root@... "tail -5 /root/.pm2/logs/game-server-error.log"`
3. If log says `JWT_SECRET не задан` or `MODULE_NOT_FOUND` → .env is missing or broken
4. Recover .env: check `/opt/game/backups/env/` for hourly snapshots, or reconstruct from memory/dashboards
5. After restoring .env: `scp .env root@...:/opt/game/server/.env && ssh root@... "pm2 restart game-server"`
6. If `MODULE_NOT_FOUND` for dependencies: `ssh root@... "cd /opt/game/server && npm install --omit=dev && pm2 restart game-server"`
7. If DB permission errors (e.g. `castle_treasury`): `GRANT ALL ON <table> TO game; GRANT USAGE, SELECT ON SEQUENCE <seq> TO game;`
