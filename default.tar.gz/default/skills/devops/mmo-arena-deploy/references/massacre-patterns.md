# Massacre (Резня) Implementation Patterns

## Feature Overview
Mass PvP chaotic battles — 30-min gathering, auto-battle with random targets, detailed log + animated visualization.

## File Map

| Layer | File | Purpose |
|---|---|---|
| DB | server/src/db/schema.sql | 3 tables: events, participants, turns |
| Server route | server/src/routes/massacre.ts | /state, /join, /log/:id |
| Battle logic | server/src/game/massacre.ts | runMassacreBattle() |
| Scheduler | server/src/schedulers/massacre.ts | 10s poll, auto-start |
| WebSocket | server/src/websocket.ts | serverTick massacre field |
| Client card | client/src/components/Actions.tsx | Card with counter + timer |
| Client page | client/src/pages/MassacrePage.tsx | Gathering, log, visualization |
| History | client/src/pages/HistoryPage.tsx | Tab with entries |
| Notifications | client/src/components/NotificationToast.tsx | Clickable battle result |
| Navigation | client/src/components/Header.tsx | Breadcrumb entry |
| Routes | client/src/App.tsx | Lazy import + route |

## ServerTick Pattern

The massacre state is pushed to ALL connected users via WebSocket serverTick every second. Query once per tick, add to every user's payload.

## HistoryPage Tab Checklist

When adding a new tab: state, fetch, allEntries, currentData switch, render chain, renderEntry, tabs array. The render chain has NO default safety — it falls through to renderMessageRow.

## VK WebView: No Opacity

Use solid hex colors: `bg-[#3d2e00]` instead of `bg-yellow-500/20`.

## Notification Data Must Be JSON String

React cannot render objects. Use `data: JSON.stringify({...})` and parse in toast.

## Battle HP Tracking

Track current HP in a Map, apply damage to target, then snapshot ALL participants' HP on every turn frame.

## SQL for Test Battles

```sql
INSERT INTO massacre_events (status, gathering_end) VALUES ('gathering', EXTRACT(EPOCH FROM NOW())::INT - 99);

INSERT INTO massacre_participants (event_id, user_id, level, base_s, base_a, base_d, base_m, hp_current, hp_max, stats_json)
SELECT 99, id, level, bases, basea, based, basem,
       (bases+basea+basem), (bases+basea+basem),
       json_build_object('s', bases, 'a', basea, 'd', based, 'm', basem, 'hp', (bases+basea+basem), 'bonuses', '{}'::json, 'extra', '{}'::json)
FROM users WHERE id IN (30,31,47,84,168);
```
