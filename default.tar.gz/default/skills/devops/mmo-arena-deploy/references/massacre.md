# Резня (Massacre PvP)

Mass chaotic PvP battle feature. Players join with 100 silver, gather for 30 min, then auto-battle with random targets.

## DB Tables

- `massacre_events` — id, status (gathering/in_progress/finished), entry_fee, gathering_end, turn_order
- `massacre_participants` — event_id, user_id, level, base_s/a/d/m, hp_current, hp_max, stunned, alive, stats_json
- `massacre_turns` — event_id, turn_number, actor_id, actor_name, target_id, target_name, action_type, damage, message

## Server Files

- `routes/massacre.ts` — GET /state (returns current gathering + lastEvent), POST /join, GET /log/:id
- `game/massacre.ts` — `runMassacreBattle(eventId)` — full battle loop with turn-by-turn combat
- `schedulers/massacre.ts` — checks every 10s, runs battle when gathering ends, creates new event
- `routes/log.ts` — GET /massacre-battles (history for сводка)

## Key Design Decisions

- **Stats snapshot**: `buildPlayerStats(user, 'arena')` is called at JOIN time, full CharStats saved as JSON in `stats_json`. Battle uses this snapshot directly — no recalculation. Includes equipment, drinks, collections, guild bonuses.
- **Turn order**: sorted by agility (base_a) DESC at battle start.
- **Stun**: stunned target skips next turn. Attacker does NOT get an extra turn.
- **Reward**: winner gets +10 XP + entire prize pool (N × 100 silver).
- **Treasury**: entry fees go to castle_treasury via `addToTreasury()`.
- **Real-time**: serverTick pushes `massacre` object (id, status, timeLeft, participant_count) to all connected clients every 1s.
- **History**: massacre battles appear in /history with tab "Резня", clicking navigates to /massacre?eventId=X.
- **Notifications**: pushNotification sent to ALL participants with JSON.stringify({eventId, ...}). `path` leads to `/massacre?eventId=X` for click-to-navigate. Notification `data` field MUST be a JSON string (React error #31 if object).
- **HistoryPage keys**: Always use snake_case directly (`data.participant_count`, `data.turn_count`, `data.winner_id`). PG camelCase converter preserves original keys — never guess the converted name.
- **VK WebView colors**: No opacity/tailwind alpha. Use solid hex: `bg-[#3d2e00]`, `text-[#f0c040]`, `border-[#5a4200]`.
- **serverTick**: Added massacre query to websocket.ts tick loop (once per tick, cached). Client listens via `massacreTick` CustomEvent.

## Client Files

- `components/Actions.tsx` — massacre card in world section, listens to massacreTick event for countdown
- `pages/MassacrePage.tsx` — full page with gathering/battle/log states, accepts ?eventId= param
- `pages/HistoryPage.tsx` — added massacre tab
- `components/NotificationToast.tsx` — onClick navigates if data.path exists
- `components/Header.tsx` — breadcrumbMap entry: massacre → 'Резня'
- `contexts/ChatContext.tsx` — dispatches massacreTick CustomEvent from serverTick

## CSS Notes

- Card uses solid colors only (no opacity) for VK WebView compatibility
- My turns: bg `#3d2e00`, border `#5a4200`, text `#f0c040`
- Dead players: bg `#2a2a2a`, text `#777`
