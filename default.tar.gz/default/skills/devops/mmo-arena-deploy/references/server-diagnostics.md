# Server Diagnostics — Activity Queries

Быстрые SQL-запросы для проверки состояния продакшн-сервера.

## Column type pitfalls

Таблицы используют разные типы для одинаковых по смыслу колонок:

| Таблица | Колонка | Тип | Как сравнивать с датой |
|---|---|---|---|
| `users` | `lastaction` | `integer` (Unix timestamp) | `to_timestamp(lastaction) > NOW() - INTERVAL '1 hour'` |
| `users` | `createdat` | `text` (ISO string) | `createdat::timestamp > NOW() - INTERVAL '7 days'` |
| `battles` | `createdat` | `timestamp with time zone` | `createdat > NOW() - INTERVAL '24 hours'` |
| `pve_battles` | `createdat` | `timestamp with time zone` | `createdat > NOW() - INTERVAL '24 hours'` |
| `guild_boss_battles` | `createdat` | `integer` (Unix timestamp) | `to_timestamp(createdat) > NOW() - INTERVAL '24 hours'` |

**Golden rule**: всегда проверяй тип колонки перед сравнением с датой:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -t -c \"SELECT column_name, data_type FROM information_schema.columns WHERE table_name='<table>' AND column_name='<column>'\""
```

## Активность пользователей

```bash
# Онлайн за последний час / сутки / всего
ssh root@194.226.142.237 "sudo -u postgres psql -d game -t -c \"
SELECT 
  (SELECT COUNT(*) FROM users WHERE to_timestamp(lastaction) > NOW() - INTERVAL '1 hour') as active_1h,
  (SELECT COUNT(*) FROM users WHERE to_timestamp(lastaction) > NOW() - INTERVAL '24 hours') as active_24h,
  (SELECT COUNT(*) FROM users) as total_users
\""

# Кто сейчас онлайн (последний час, топ-15)
ssh root@194.226.142.237 "sudo -u postgres psql -d game -t -c \"
SELECT username, to_timestamp(lastaction)::timestamp as last_seen 
FROM users WHERE to_timestamp(lastaction) > NOW() - INTERVAL '1 hour' 
ORDER BY lastaction DESC LIMIT 15
\""
```

## Бои за 24 часа

```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -t -c \"
SELECT 
  (SELECT COUNT(*) FROM battles WHERE createdat > NOW() - INTERVAL '24 hours') as pvp_24h,
  (SELECT COUNT(*) FROM pve_battles WHERE createdat > NOW() - INTERVAL '24 hours') as pve_24h,
  (SELECT COUNT(*) FROM guild_boss_battles WHERE to_timestamp(createdat) > NOW() - INTERVAL '24 hours') as boss_24h
\""
```

## Новые игроки за N дней

```bash
# За 7 дней (createdat — text, нужно явное приведение)
ssh root@194.226.142.237 "sudo -u postgres psql -d game -t -c \"
SELECT username, createdat::timestamp::date as registered, level
FROM users 
WHERE createdat::timestamp > NOW() - INTERVAL '7 days'
ORDER BY createdat::timestamp DESC
\""
```

## Состояние сервера

```bash
# PM2 статус
ssh root@194.226.142.237 "pm2 status"

# API health
curl -s -o /dev/null -w "%{http_code}" https://mmoarena.ru/api/time

# Лог ошибок (проверить свежесть перед чтением)
ssh root@194.226.142.237 "stat -c '%y' /root/.pm2/logs/game-server-error.log && tail -5 /root/.pm2/logs/game-server-error.log"
```
