# PG CamelCase Converter Pitfalls

The server's `db/index.ts` has a `pgLowerIdentifiers` function that transforms SQL before execution and a `camelRows` function that transforms query results.

## How it works

1. **SQL Transformer** (`pgLowerIdentifiers`): Finds camelCase words in SQL and lowercases them. `senderGuild` → `senderguild`.
2. **Result Transformer** (`camelRows`): Takes column names and creates camelCase variants. `participant_count` → ALSO creates `participant_Count` (capitalizes suffix, KEEPS underscore). BOTH keys exist on the result object.

## ⚠️ Critical Rule: Always Use Lowercase Column Names

If you create a column with double quotes: `"senderGuild" TEXT`, the column in PG is literally `senderGuild` (case-sensitive).

When your SQL INSERT runs through `pgLowerIdentifiers`, it becomes `INSERT INTO ... (senderid, targetid, senderguild)`. The lowercase `senderguild` DOES NOT MATCH the mixed-case column `senderGuild`.

**Always use lowercase column names in CREATE/ALTER TABLE without quotes.**

```
✅ senderguild TEXT          — matches after lowercasing
❌ "senderGuild" TEXT        — won't match after lowercasing
```

## Result columns: snake_case works, camelCase also works

The result transformer creates BOTH keys:
- `row.participant_count` ✅ (original, always works)
- `row.participant_Count` ✅ (camelCase variant, also present)

**Always use snake_case in client code** for new tables. It's simpler and more predictable.

## ⚠️ JSONB columns: use `db.raw` with `$N` and explicit `::jsonb` cast

When INSERTing into JSONB columns (`equipment_1`, `equipment_2`, `equipment_3`, `inventory`), do NOT use `db.run` with `?` placeholders. The `pgLowerIdentifiers` may strip new columns from the INSERT, and passing JSON strings through the `?` → `$N` converter may cause them to be stored as empty objects (`{}`).

**Symptoms**: Column value is `{}` (empty JSONB) or `0` (integer default) when you inserted a non-empty value.

**Fix**: Use `db.raw` with explicit `$1, $2, ...` placeholders and `::jsonb` cast for JSONB columns. Pass JavaScript objects (not strings) for JSONB parameters.

```ts
// ❌ BROKEN — money=0, equipment_1={}
await db.run(`INSERT INTO users (..., money, equipment_1) VALUES (..., 1000, ?)`, [equipmentStr]);

// ✅ CORRECT
const eqObj = JSON.parse(getStarterEquipment());
await db.raw(`INSERT INTO users (..., money, equipment_1)
    VALUES ($1, ..., $2, $3::jsonb) RETURNING id`,
    [param1, 1000, eqObj]);
```

**Real case**: Added `equipment_1` and `money=1000` to all 4 registration INSERTs. Direct psql INSERT worked, but app INSERTs stored `{}` and `0`. After switching to `db.raw` with `$N` params, the issue persisted — the root cause required further investigation. In the meantime, the safest pattern is `db.raw` with explicit casts.

## For new query aliases

When writing `SELECT ... AS alias_name`:
- The alias comes through as `alias_name` (snake_case)
- The converter also creates `alias_Name` (capitalized suffix)
- Both keys exist on the result

**Client code should use `data.alias_name` directly** — it's the simplest and always works.

## ⚠️ `db.query` silently returns 0 rows for some queries — use `db.raw`

The `db.query` function applies `pgLowerIdentifiers` which can CORRUPT certain SQL patterns. In particular, queries with boolean conditions (`mp.alive = TRUE`) or complex JOINs may silently return 0 rows even when the same query works in raw psql.

**Symptoms**: Query returns `[]` when you can verify the data exists via `psql` directly.

**Fix**: Use `db.raw` instead of `db.query`. `db.raw` bypasses all transformations. Use `$1, $2` parameter placeholders instead of `?`.

```ts
// BROKEN — db.query may return [] for boolean columns
const rows = await db.query('SELECT * FROM t WHERE alive = TRUE', []) as any[];

// WORKS — db.raw bypasses the transformer
const result = await db.raw('SELECT * FROM t WHERE alive = $1', [true]);
const rows = result.rows as any[];
```

This was discovered when `runMassacreBattle()` kept getting 0 participants from a query that had 5+ rows in the DB.
