# JSONB + pg driver pitfalls

## The problem

When inserting into JSONB columns with the pg driver, `db.run` (which applies `pgLowerIdentifiers`) may silently produce `{}` instead of the actual JSON data. The exact mechanism is unclear but consistently reproducible.

## Symptoms

- `SELECT length(equipment_1::text)` returns 2 (empty object `{}`)
- Money literals (e.g., `1000`) in INSERT VALUES also fail silently
- Direct `psql` INSERT works fine — problem is in the app layer

## Solution

Use `db.raw` with `$N` parameterized queries and JavaScript objects (not JSON strings):

```ts
// ✅ CORRECT
const eqObj = JSON.parse(equipment1); // or construct directly
const result = await db.raw(
  `INSERT INTO users (..., equipment_1) VALUES ($1, $2, ..., $N) RETURNING id`,
  [val1, val2, ..., eqObj]
);
const newId = result.rows[0].id;

// ❌ WRONG — produces {} in JSONB column
await db.run(
  `INSERT INTO users (..., equipment_1) VALUES (?, ?, ..., ?)`,
  [val1, val2, ..., JSON.stringify(eqObj)]
);
```

## Also applies to money

Pass money as a parameter, not a literal:

```ts
// ✅ CORRECT
const result = await db.raw(`INSERT INTO users (..., money, ...) VALUES ($1, ..., $N, ...)`, [..., 1000, ...]);

// ❌ WRONG — money ends up as 0
await db.run(`INSERT INTO users (..., money, ...) VALUES (?, ..., 1000, ...)`, [...]);
```

## All affected registration endpoints

- `auth.ts` (email + guest)
- `vkBridgeAuth.ts`
- `oauth.ts`

All now use `db.raw` pattern.
