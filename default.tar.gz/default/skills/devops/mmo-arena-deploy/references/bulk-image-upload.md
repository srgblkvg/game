# Bulk Image Upload for Admin Panel

When images are missing from production (e.g., after uploads folder was lost), the admin panel has a mass upload tool that saves files under existing DB paths without renaming.

## Server endpoint

`POST /api/admin/upload-bulk`

Body:
```json
{
  "images": [
    { "targetPath": "/uploads/admin/floors/1782041412583_n99rni.webp", "dataUrl": "data:image/webp;base64,..." }
  ]
}
```

The endpoint saves each file directly to the `targetPath`, overwriting if exists. No filename generation — uses the exact path from DB.

## Client component

`BulkImageUploader` in `client/src/components/BulkImageUploader.tsx`

Props:
- `items: { id: number; name: string; imagePath: string | null }[]`
- `title?: string`

Usage in admin tabs:
```tsx
<BulkImageUploader
  items={floors.map(f => ({ id: f.id, name: f.name, imagePath: f.background }))}
  title="Массовая загрузка фонов этажей"
/>
```

## Where it's installed

- **AdminGame** → Действия, Мобы, Этажи (floors)
- **AdminJobs** → Работы
- **AdminItems** → Предметы
- **AdminCraft** → Ресурсы (craft items)

Each tab shows items with DB paths and file inputs. "Загрузить всё" button sends all selected files to the bulk endpoint.
