# Client Build Pitfalls

## Pre-existing TS errors block deploy

`npm run build` runs `tsc -b && vite build`. TypeScript errors from previous commits will block YOUR deploy.

### Common causes

- **Unused variables (TS6133)**: Most frequent. Someone removed code that used a `useState` or local var but left the declaration.
- **Missing imports**: Refactored imports not updated everywhere.

### Workflow

```bash
# Always verify clean baseline BEFORE your changes
cd client && npx tsc -b --noEmit

# If errors, fix them — they're not yours but they block your deploy
```

**Real case (2026-08-06)**: `respawnTimer`/`setRespawnTimer` + `canTalents` in GuildPage.tsx — 3 TS6133 errors from removing client-side boss timer in commit a379ca69. Removed the declarations, build succeeded.
