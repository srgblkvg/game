# .env structure for MMO Arena production

Required keys (values are secrets, not stored here):

```
JWT_SECRET=<64-char hex>
PORT=3001
DISABLE_RATE_LIMIT=true

# VK Mini App
VK_CLIENT_ID=54620033
VK_CLIENT_SECRET=<OAuth secret>
VK_APP_SECRET=pQk1mzeHiwkjVSWZ7kyp
VK_SERVICE_KEY=<64-char service key>

# Yookassa payments
YOOKASSA_SHOP_ID=<number>
YOOKASSA_SECRET_KEY=live_<string>

# Yandex OAuth
YA_CLIENT_ID=<32-char hex>
YA_CLIENT_SECRET=<32-char hex>

# PostgreSQL (defaults usually work)
PGHOST=localhost
PGPORT=5432
PGDATABASE=game
PGUSER=game
PGPASSWORD=game123
```

## Protection

- `.env` is in `.gitignore` — NEVER commit it
- Deploy server with `rsync -avz` (NO `--delete`) to avoid wiping `.env`
- Backup system: hourly cron saves both uploads/ and .env to `/opt/game/backups/`
  - `backups/uploads/uploads-<date>.tgz` — all images
  - `backups/env/.env-<date>` — the .env file
- 72 rotating backups (3 days), ~450MB total
- The backup-cron script is at `/opt/game/backup-uploads.sh`
