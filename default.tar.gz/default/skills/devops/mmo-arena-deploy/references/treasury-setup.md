# Castle Treasury Setup

## Tables

```sql
CREATE TABLE IF NOT EXISTS castle_treasury (
    id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    amount INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO castle_treasury (id, amount) VALUES (1, 0) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS treasury_log (
    id SERIAL PRIMARY KEY,
    amount INTEGER NOT NULL,
    source TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

## Permissions (both local and production)

```sql
GRANT ALL ON castle_treasury TO game;
GRANT ALL ON treasury_log TO game;
GRANT USAGE, SELECT ON SEQUENCE treasury_log_id_seq TO game;
```

## Sources of treasury contributions

- **Bank**: 2% commission on deposits and transfers
- **Shop**: 100% of item purchase price
- **Auction**: 5% listing fee + 10% sale commission
- **Craft**: 100% of recipe `money_cost` and upgrade cost
- **Tavern**: 100% of drink cost, healing cost, and room rental cost

## API

- `GET /api/treasury` — returns `{ amount: number }` (public, no auth)
- Server code: `server/src/game/treasury.ts` (addToTreasury helper)
- Client: `Actions.tsx` fetches and displays on castle card
