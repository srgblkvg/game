---
name: mmo-arena-deploy
description: Deploy MMO Arena client and server to production VPS (194.226.142.237). Correct sequences, pitfall prevention, and post-deploy verification.
category: devops
---

# MMO Arena Deploy

Deploy server and client to production VPS at 194.226.142.237.

## Server Deploy

**Auth**: `sshpass -p 're8XyUoMH2PD6UCn'` for all SSH/rsync commands.

**Paths on VPS:**
- Server code: `/opt/game/server/`
- Server dist: `/opt/game/server/dist/`
- Server .env: `/opt/game/server/.env`
- Client dist: `/opt/game/client/dist/`
- Nginx root: `/opt/game/client/dist/`

### ⛔ NEVER USE `rsync --delete` FOR SERVER — IT DESTROYS `.env` AND `node_modules/` ⛔

This kills the server: `JWT_SECRET не задан`, then `MODULE_NOT_FOUND` for dotenv, then 502 for ALL API calls. The user will be very angry.

**Correct sequence (CRITICAL — order matters):**

```bash
# 1. Build
cd server && npx tsc

# 2. Copy .env FIRST (MUST be done before anything else)
scp server/.env root@194.226.142.237:/opt/game/server/

# 3. Copy package.json (needed for npm install)
scp server/package.json root@194.226.142.237:/opt/game/server/

# 4. Install dependencies on VPS
ssh root@194.226.142.237 "cd /opt/game/server && npm install --omit=dev"

# 5. Rsync dist/ (WITHOUT --delete to preserve node_modules)
#    PM2 now runs node dist/index.js — deploy dist/ only, not src/
rsync -avz server/dist/ root@194.226.142.237:/opt/game/server/dist/

# 6. Restart
ssh root@194.226.142.237 "pm2 restart game-server"
```

## Client Deploy

```bash
cd client
rm -rf node_modules/.vite dist
npx vite build
rsync -avz --delete dist/ root@194.226.142.237:/opt/game/client/dist/
```

`--delete` is safe for client because it's a fresh build output directory.

## Uploads & Backup

The `server/uploads/` folder (avatars, floor backgrounds, mob images, job backgrounds) is NOT part of `server/dist/`. Deploy it separately without --delete:

```bash
rsync -avz server/uploads/ root@194.226.142.237:/opt/game/server/uploads/
```

### Set up automatic backup (cron)

After deploy, set up hourly backup for both uploads/ and .env:

```bash
ssh root@194.226.142.237 'cat > /opt/game/backup-uploads.sh << '"'"'EOF'"'"'
#!/bin/bash
D=/opt/game/backups
mkdir -p $D/uploads $D/env
tar czf "$D/uploads/uploads-$(date +%Y%m%d-%H%M).tgz" -C /opt/game/server uploads
cp /opt/game/server/.env "$D/env/.env-$(date +%Y%m%d-%H%M)"
ls -t $D/uploads/*.tgz 2>/dev/null | tail -n +73 | xargs -r rm
ls -t $D/env/.env-* 2>/dev/null | tail -n +73 | xargs -r rm
EOF
chmod +x /opt/game/backup-uploads.sh
(crontab -l 2>/dev/null | grep -v backup-uploads; echo "0 * * * * /opt/game/backup-uploads.sh") | crontab -
/opt/game/backup-uploads.sh'
```

This creates hourly backups in `/opt/game/backups/`:
- `uploads/` — all images (floors, mobs, jobs, avatars, items, resources)
- `env/` — the .env file with all secrets
Keeps last 72 backups (3 days). Total size ~450MB max.

## Post-Deploy Verification

**ALWAYS verify after deploy, before telling user it's done:**

```bash
# 1. Check server is running
ssh root@194.226.142.237 "pm2 status"

# 2. Test API
curl -s https://mmoarena.ru/api/time

# 3. Test treasury (after creating DB tables)
curl -s https://mmoarena.ru/api/treasury

# 4. Check for new errors in log
ssh root@194.226.142.237 "tail -5 /root/.pm2/logs/game-server-error.log"
```

## Critical Pitfalls

### 0. NEVER guess the server IP — always load this skill first 🔴

Production IP is `194.226.142.237`. Do NOT guess from memory, do NOT use a different IP. Every SSH/rsync/scp must use this exact IP.

**Real case**: agent used `194.87.200.95` (invented) instead of `194.226.142.237` — wrong server, SSH failed, user said "больше не придумывай".

### 0b. Stale PM2 error logs — flush before diagnosing

PM2 does NOT rotate error logs. `pm2 logs --nostream --lines 30` shows last 30 lines of the file, which may be days old. Errors from before a restart look current but aren't.

**Diagnosis workflow:**
```bash
# 1. Check when error log was last modified
ssh root@194.226.142.237 "stat -c '%y' /root/.pm2/logs/game-server-error.log"

# 2. If older than server uptime — flush + restart before investigating
ssh root@194.226.142.237 "pm2 flush && pm2 restart game-server"

# 3. Check fresh logs
ssh root@194.226.142.237 "cat /root/.pm2/logs/game-server-error.log"
```

**Real case**: `senderguild` column-not-found errors appeared in logs but column actually existed — log was 3 days stale, never flushed.

### 0c. Vite build detected as server process

The terminal tool sometimes rejects `npx vite build` as a "long-lived server". Workaround:
```bash
# Use background mode
terminal(background=true, notify_on_complete=true, command="cd client && npx vite build")
# Then wait
process(action='wait', session_id='...')
```

### 1. rsync --delete WIPES .env and node_modules
`rsync --delete server/dist/` on the server directory deletes everything not in local dist/, including `.env` and `node_modules/`. This kills the server (JWT_SECRET missing, MODULE_NOT_FOUND).

**Fix**: Always use `rsync -avz` (without --delete) for server. Copy `.env` and `package.json` separately before npm install.

### 2. DB tables created by postgres user lack permissions for game user
When creating tables via `sudo -u postgres psql`, the application's `game` user doesn't get automatic access.

**Fix**: After CREATE TABLE, always run:
```sql
GRANT ALL ON <table> TO game;
GRANT USAGE, SELECT ON SEQUENCE <seq> TO game;
```

### 3. npm install silently fails if package.json is missing
If dist/ is deployed without package.json, `npm install` on VPS does nothing because there's no manifest.

**Fix**: `scp package.json` before `npm install`.

### 4. Server crash = 502 for ALL API calls
When server is down, nginx returns 502. User sees "Failed to load character", "Ошибка загрузки рейтинга", WebSocket disconnects. All come from the same root cause.

**Fix**: Check `pm2 status` and `tail -5 /root/.pm2/logs/game-server-error.log`.

### 5. Browser cache hides updates after deploy
After client deploy, old JS bundles are cached. User must Ctrl+Shift+R.

**Fix**: Always mention Ctrl+Shift+R after client deploy.

### 6. VK WebView images break with <base href> tag
Adding `<base href="https://mmoarena.ru/">` to index.html breaks image loading in VK iframe. Do NOT add base tag for VK compatibility — it makes things worse.

**Fix**: WebP images work fine in VK WebView without base tag. For cross-origin, add CORS headers in nginx:
```nginx
location ~* \.(webp|png|jpg|jpeg|svg|ico|woff2|woff|ttf)$ {
    add_header Access-Control-Allow-Origin "*";
}
```

### 7. Uploads folder must be deployed separately
The `server/uploads/` folder (avatars, floor backgrounds, mob images, job backgrounds) is NOT part of `server/dist/`. It must be deployed separately:

```bash
rsync -avz server/uploads/ root@194.226.142.237:/opt/game/server/uploads/
```

**IMPORTANT**: The uploads folder may contain files uploaded through the admin panel that are NOT in your local copy. Always rsync uploads FIRST (without --delete) BEFORE any other deploy operations. This ensures production files are preserved and merged with local files.

### 8. CamelCase converter doesn't work for new tables
The DB layer has a camelCase converter that transforms `created_at` → `created_At` (NOT `createdAt`). The converter doesn't remove underscores. For new tables, reference columns by their **snake_case** names in client code.

**⚠️ Also: the `pgLowerIdentifiers` SQL transformer lowercases ALL unquoted identifiers.** This includes camelCase column names in INSERT/ALTER statements. See `references/pg-camelcase-pitfalls.md` for full details.

**Golden rule**: ALWAYS use `ALTER TABLE ... ADD COLUMN lowercase_name` without quotes. Never create columns with mixed case using double quotes — they won't match the lowercased SQL that the converter produces.

```ts
// WRONG — PG column is "senderGuild", converter sends "senderguild" → column not found!
ALTER TABLE t ADD COLUMN "senderGuild" TEXT;

// CORRECT — PG column is senderguild, converter sends senderguild → match!
ALTER TABLE t ADD COLUMN senderguild TEXT;
```

### 10. VK WebView: CSS opacity/alpha colors don't render 🔴

CSS colors with alpha channel (e.g. `bg-red-500/20`, `bg-[var(--x)]/10`) do not work in VK WebView. The modern `rgb(var(--color) / 0.5)` syntax that Tailwind v4 emits for opacity modifiers is not supported.

**Systemic fix — LightningCSS target (preferred)**: In `client/vite.config.ts`, set the LightningCSS target low enough to force `rgba()` fallbacks:

```ts
css: {
  transformer: 'lightningcss',
  lightningcss: {
    targets: {
      chrome: 50 << 16,  // Chrome 50+ — forces rgba() for rgb() with alpha
    },
    include: 1113088, // Colors (oklch→hex, lab→rgb, p3→rgb)
    exclude: 1,        // Nesting
  },
},
```

With `chrome: 50`, LightningCSS converts ALL `rgb(var(--x) / 0.5)` to `rgba(128, 128, 128, 0.5)` — fully legacy-compatible. No manual hex replacements needed.

**Verification**: `grep -o 'rgb(var(' dist/assets/index-*.js` — must return ZERO matches.

**Manual fallback** (only for edge cases LightningCSS misses): `bg-red-900/20` → `bg-[#2a1515]`, `text-blue-300/70` → `text-[#7373d4]`.

### 12. Scripts MUST be under src/ — tsconfig rootDir is ./src 🔴

Server `tsconfig.json` has `rootDir: "./src"` and `include: ["src"]`. Scripts placed in `server/scripts/` (outside `src/`) are **silently ignored** by `npx tsc` — no error, no output file, `MODULE_NOT_FOUND` on VPS.

**Fix**: Always create DB/admin scripts under `server/src/scripts/`. After build they land in `dist/scripts/`.

**Real case**: `fix-corrupted-cursed-items.ts` put in `server/scripts/`, `npx tsc` succeeded with no errors, `node dist/scripts/fix-...js` → MODULE_NOT_FOUND. Moved to `src/scripts/`, rebuilt, worked.

### 13. Running one-off DB scripts on production — pattern

For data fixes, compensations, or inventory cleanup that don't belong in the main server code:

```bash
# 1. Create script under src/scripts/ (see pitfall #12)
# 2. Build
cd server && npx tsc
# 3. Deploy dist only
rsync -avz dist/ root@194.226.142.237:/opt/game/server/dist/
# 4. Run on VPS (DOES NOT restart the server — one-off script)
ssh root@194.226.142.237 "cd /opt/game/server && node dist/scripts/<name>.js"
```

Scripts use the same `db` import and can call exported functions from `routes/` (e.g. `addToOverflow` for warehouse). Backup output goes to `dist/` (accessible via `path.join(__dirname, '..', 'backup.json')`).

### 14. PM2 runs node dist/index.js — ensure tsc succeeds before deploy 🔴🔴🔴

PM2 is configured as `node dist/index.js` — it runs compiled JavaScript. If `npx tsc` fails silently, old dist is deployed and server runs stale code.

**Check with:** `pm2 show game-server | grep 'script args'`

**Correct deploy:**
```bash
npx tsc && rsync -avz server/dist/ root@194.226.142.237:/opt/game/server/dist/ && ssh root@194.226.142.237 pm2 restart game-server
```

**Real case:** 2 hours debugging why balance changes had no effect. npx tsc compiled but PM2 ran tsx src/index.ts — deployed dist/ was useless. Changed PM2 to node dist/index.js.

### 15. JSONB inserts — use db.raw with JS objects, not db.run with strings 🔴

When inserting JSONB columns, `db.run` may silently corrupt the value. See `references/pg-jsonb-inserts.md` for detailed pattern and examples. All 4 registration endpoints now use `db.raw` with `$N` params + JS objects.

### 16. `parseEq({})` is TRUTHY — don't use `||` for fallback 🔴

`parseEq(undefined)` returns `{}` which is truthy. `parseEq(a) || parseEq(b)` always returns `{}` from the left side.

**Fix**: check for empty object explicitly:
```ts
let equip = parseEq(userRow[equipKey]);
if (!equip || Object.keys(equip).length === 0) equip = parseEq(userRow.equipment_1);
if (!equip || Object.keys(equip).length === 0) equip = parseEq(userRow.equipment);
```

**Real case**: Switched `buildPlayerStats` to read `equipment_1`. Old players with equipment in `equipment` column got zero bonuses — `parseEq(undefined) || parseEq(equipment)` → `{}`.

### 11. New feature checklist (MMO Arena project pattern)
1. **DB tables** — add to `schema.sql`, create locally AND on prod with GRANT
2. **Server route** — new file in `routes/`, register in `setupRoutes.ts`
3. **Scheduler** (if needed) — new file in `schedulers/`, start in `index.ts`
4. **actions_config SQL** — INSERT row locally AND on prod (this is often forgotten!)
5. **Client card** — add rendering in `Actions.tsx` (special-card block or generic)
6. **Client page** — new page component, add to `App.tsx` routes + lazy import
7. **Breadcrumbs** — add entry to `breadcrumbMap` in `Header.tsx`
8. **Deploy** — server tsc + rsync + pm2 restart, then client vite build + rsync
9. **Verify** — check API, check logs, mention Ctrl+Shift+R

## DB Schema Changes

When adding new tables (like castle_treasury, treasury_log), create them on BOTH local and production, and grant permissions:

```bash
# Local
PGPASSWORD=game123 psql -h localhost -U game -d game -c "CREATE TABLE ..."
PGPASSWORD=game123 psql -h localhost -U game -d game -c "GRANT ALL ON ... TO game"

# Production
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"CREATE TABLE ...\""
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"GRANT ALL ON ... TO game\""
```

## Git Commit

After deploy, always commit and push:
```bash
git add -A && git commit -m "компонент: что сделано" && git push
```
Commits in Russian, format: "компонент: описание".

## References

- `references/env-structure.md` — required .env keys and backup setup
- `references/treasury-setup.md` — castle treasury DB table setup
- `references/bulk-image-upload.md` — admin panel bulk image upload tool for restoring missing files
- `references/pg-camelcase-pitfalls.md` — PG camelCase converter behaviour, column naming rules
- `references/massacre-patterns.md` — massacre feature: serverTick pattern, history tab template, VK opacity fix
- `references/server-diagnostics.md` — activity queries (online, battles, new players) with column type pitfalls
