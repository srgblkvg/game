// migrate-new-tables.js — migrates data for tables created by create-missing-tables.js
const D = require("better-sqlite3");
const { Pool } = require("pg");
const s = new D("game.db");
const p = new Pool({ database: "game", user: "game", password: "game123" });

// Tables NOT covered by the main migrate-pg.ts — update to match create-missing-tables.js
const newTables = [
  "craft_recipe_categories", "stat_names", "auction_lots", "orders",
  "order_members", "pve_battles", "transfers", "bank_operations",
  "actions_config", "guild_war_attacks", "upgrade_chances", "tournaments_new"
];

async function main() {
  for (const table of newTables) {
    try {
      const rows = s.prepare("SELECT * FROM [" + table + "]").all();
      if (!rows.length) { console.log("EMPTY:", table); continue; }
      const cols = Object.keys(rows[0]).map(c => c.toLowerCase()).join(", ");
      const ph = Object.keys(rows[0]).map((_, i) => "$" + (i + 1)).join(", ");
      const sql = "INSERT INTO " + table + " (" + cols + ") VALUES (" + ph + ")";
      let ok = 0;
      for (const row of rows) {
        try {
          await p.query(sql, Object.values(row));
          ok++;
        } catch (e) {
          if (!e.message.includes("duplicate key")) console.log("ERR:", table, e.message.substring(0, 50));
        }
      }
      console.log("OK:", table, "(" + ok + "/" + rows.length + ")");
    } catch (e) {
      console.log("SKIP:", table, e.message.substring(0, 50));
    }
  }
  await p.end(); s.close();
}
main();
