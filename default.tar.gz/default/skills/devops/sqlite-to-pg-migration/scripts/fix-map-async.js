// Fix `.map(async ...)` issues across all route files.
// — If map callback has NO `await` in its body → remove `async`
// — If map callback HAS `await` → leave async (needs manual Promise.all wrap)
// Run: node scripts/fix-map-async.js (from server/src directory)

const fs = require('fs');
const path = require('path');

const dir = process.argv[2] || './routes';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.ts'));

for (const file of files) {
  const fp = path.join(dir, file);
  let content = fs.readFileSync(fp, 'utf8');
  let changed = false;

  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('.map(async (')) {
      // Check next 15 lines for 'await' keyword
      let hasAwait = false;
      for (let j = i; j < Math.min(i + 15, lines.length); j++) {
        if (lines[j].includes('await ')) { hasAwait = true; break; }
      }
      if (!hasAwait) {
        // WARNING: Pitfall 50 — check for stmt.get()/stmt.all()/stmt.run() calls.
        // These return Promises even without 'await' keyword because stmt = db.prepare(sql)
        // and .get()/.all()/.run() return Promises in the PG wrapper.
        // If found, undo this removal and handle manually with Promise.all + await.
        lines[i] = lines[i].replace('.map(async (', '.map((');
        changed = true;
        console.log(`  ${file}:${i+1} — removed async (no await in body) [verify no stmt.get() calls!]`);
      } else {
        console.log(`  ${file}:${i+1} — KEPT async (has await, needs manual Promise.all)`);
      }
    }
  }

  if (changed) {
    fs.writeFileSync(fp, lines.join('\n'));
    console.log(`Fixed: ${file}`);
  }
}
console.log('\nDone. Remaining .map(async calls need manual Promise.all wrap.');
