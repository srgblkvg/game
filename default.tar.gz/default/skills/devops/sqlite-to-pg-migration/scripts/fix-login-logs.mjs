// Fix: wrap login_logs INSERTs in try/catch to prevent 500 on duplicate key
// Run AFTER bulk async conversion (line-number-based sed breaks after conversion)
// Usage: scp to VPS, run with `node fix-login-logs.mjs`

import fs from 'fs';
let c = fs.readFileSync('/opt/game/server/src/routes/auth.ts', 'utf8');

// Guest login — line with user.id
c = c.replace(
  "try { await db.prepare('INSERT INTO login_logs (userId, ip) VALUES (?, ?)').run(user.id, req.ip);",
  "try { await db.prepare('INSERT INTO login_logs (userId, ip) VALUES (?, ?)').run(user.id, req.ip); } catch {}"
);

// Normal/OAuth login — line with userRow.id
c = c.replace(
  "try { await db.prepare('INSERT INTO login_logs (userId, ip) VALUES (?, ?)').run(userRow.id, req.ip);",
  "try { await db.prepare('INSERT INTO login_logs (userId, ip) VALUES (?, ?)').run(userRow.id, req.ip); } catch {}"
);

fs.writeFileSync('/opt/game/server/src/routes/auth.ts', c);
console.log('Fixed login_logs try/catch');
