// fix-all-cols.js — compares SQLite vs PG schemas and adds EVERY missing column
// Run AFTER rebuild-pg.ts (table creation) and BEFORE migrate-pg.ts (data migration)
// This prevents migration failures on columns that exist in SQLite but not in the PG schema

const { Pool } = require("pg");
const D = require("better-sqlite3");

const p = new Pool({ database: "game", user: "game", password: "game123" });
const s = new D("game.db");  // adjust path to SQLite DB

async function f() {
  const tables = s.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  
  for (const { name: table } of tables) {
    if (table === 'sqlite_sequence') continue;
    
    const sqliteCols = s.prepare("PRAGMA table_info('" + table + "')").all();
    const pgCols = await p.query(
      "SELECT column_name FROM information_schema.columns WHERE table_name='" + table.toLowerCase() + "'"
    );
    const pgSet = new Set(pgCols.rows.map(r => r.column_name));
    
    for (const col of sqliteCols) {
      const pgColName = col.name.toLowerCase();
      if (!pgSet.has(pgColName)) {
        // Type inference: timestamp-like columns → INTEGER, everything else → TEXT
        const isEpoch = /time$|at$|until$|updated$|expires$|count$|id$|date$/.test(pgColName);
        const type = isEpoch ? "INTEGER DEFAULT 0" : "TEXT";
        try {
          await p.query("ALTER TABLE " + table + " ADD COLUMN " + pgColName + " " + type);
          console.log("ADDED:", table + "." + pgColName, type);
        } catch (e) {
          // silently skip duplicates
        }
      }
    }
  }
  
  console.log("Done");
  await p.end();
  s.close();
}
f();
