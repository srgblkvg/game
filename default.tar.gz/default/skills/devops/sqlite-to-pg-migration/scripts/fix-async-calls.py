#!/usr/bin/env python3
"""Add await before async helper function calls that were made async by bulk conversion.
Run AFTER the bulk async conversion of route files.
Targets: getUserById, enrichEquipment, getBaseStats, applyHpRegen, etc."""

import re, glob, os

ASYNC_HELPERS = [
    'getUserById', 'getUserWithStats', 'enrichEquipment',
    'getItemDataStmt', 'transferMoney', 'addMoney', 'spendMoney',
    'collectGuildTax', 'applyExp', 'applyHpRegen',
    'applyDecay', 'addPveRating', 'checkSeasonReset',
    'findOrCreateUser', 'getBaseStats',
]

def fix_file(fp):
    with open(fp) as f: content = f.read()
    old = content
    for func in ASYNC_HELPERS:
        # Pattern: = funcName( or , funcName(
        content = re.sub(rf'([=,]\s*)(?<!\bawait\s)({func})\(', rf'\1await \2(', content)
        # Pattern: return funcName(
        content = re.sub(rf'(return\s+)(?<!\bawait\s)({func})\(', rf'\1await \2(', content)
        # Pattern: standalone funcName( at line start
        content = re.sub(rf'^(\s*)(?<!\bawait\s)({func})\(', rf'\1await \2(', content, flags=re.MULTILINE)
    content = re.sub(r'await await ', 'await ', content)
    if content != old:
        with open(fp, 'w') as f: f.write(content)
        return True
    return False

if __name__ == '__main__':
    src = os.environ.get('SRC', './server/src')
    for fp in glob.glob(f'{src}/**/*.ts', recursive=True):
        if fix_file(fp):
            print(fp.split('/')[-1])
    print('Done')
