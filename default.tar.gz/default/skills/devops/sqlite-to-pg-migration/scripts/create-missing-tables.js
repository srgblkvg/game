// create-missing-tables.js — finds SQLite tables not in rebuild-pg.ts and creates them in PG
const D = require("better-sqlite3");
const { Pool } = require("pg");
const s = new D("game.db");
const p = new Pool({ database: "game", user: "game", password: "game123" });

// Tables already in rebuild-pg.ts — update this list if schema changes
const existing = new Set([
  "rarities", "items", "craft_items", "users", "admins", "battles", "chat_messages",
  "guilds", "guild_members", "guild_invites", "guild_wars", "guild_treasury_log",
  "tournaments", "tournament_participants", "tournament_matches", "daily_quests",
  "quest_history", "job_history", "login_logs", "feedback_messages", "seasons",
  "hall_of_fame", "collections", "collection_sets", "collection_set_items",
  "craft_recipes", "craft_recipe_ingredients", "shop_items", "mobs", "mob_drops",
  "floors", "jobs", "drinks"
]);

async function main() {
  const tables = s.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
  for (const { name } of tables) {
    if (existing.has(name)) continue;
    console.log("Missing table:", name);
    
    const cols = s.prepare("PRAGMA table_info('" + name + "')").all();
    const pgCols = cols.map(c => {
      let type = "TEXT";
      if (c.type && c.type.toUpperCase().includes("INT")) type = "INTEGER DEFAULT 0";
      if (c.type && c.type.toUpperCase().includes("REAL") || c.type.toUpperCase().includes("FLOAT")) type = "REAL DEFAULT 0";
      return c.name.toLowerCase() + " " + type;
    }).join(", ");
    
    try {
      await p.query("CREATE TABLE IF NOT EXISTS " + name + " (" + pgCols + ")");
      console.log("  CREATED:", name);
    } catch (e) {
      console.log("  ERROR:", e.message.substring(0, 80));
    }
  }
  await p.end(); s.close();
  console.log("Done");
}
main();
