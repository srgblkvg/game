const http = require('http');

// Quick API smoke test — hits critical endpoints after PG migration
// Usage: node test_api.js
// Expects server on localhost:3002 with test user testhero/Test123!@

function req(method, path, token, data) {
  return new Promise((resolve, reject) => {
    const body = data ? JSON.stringify(data) : undefined;
    const opts = {
      hostname: 'localhost', port: 3002, path, method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (token) opts.headers['Authorization'] = `Bearer ${token}`;
    if (body) opts.headers['Content-Length'] = Buffer.byteLength(body);
    const r = http.request(opts, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, body: d.slice(0, 200) }); }
      });
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}

async function main() {
  const login = await req('POST', '/api/login', null, { username: 'testhero', password: 'Test123!@' });
  if (login.status !== 200) { console.log('LOGIN FAILED:', login.status, login.body); process.exit(1); }
  console.log('LOGIN OK');
  const token = login.body.token;

  const tests = [
    ['GET', '/api/character/me'],
    ['GET', '/api/mobs'],
    ['GET', '/api/shop/items'],
    ['GET', '/api/rating'],
    ['GET', '/api/tavern'],
    ['GET', '/api/users/list'],
    ['GET', '/api/arena'],
    ['GET', '/api/jobs'],
    ['GET', '/api/account'],
    ['GET', '/api/inventory'],
    ['GET', '/api/bank'],
    ['GET', '/api/auction'],
    ['GET', '/api/craft'],
    ['GET', '/api/guild/list'],
    ['GET', '/api/collections'],
    ['GET', '/api/tournament'],
    ['GET', '/api/orders'],
    ['GET', '/api/quests'],
    ['GET', '/api/chat/history'],
    ['GET', '/api/actions'],
  ];

  let ok = 0, fail = 0;
  for (const [method, path] of tests) {
    const r = await req(method, path, token);
    if (r.status === 200 || r.status === 404) {
      console.log(`  OK ${r.status} ${path}${Array.isArray(r.body) ? ` [${r.body.length}]` : ''}`);
      ok++;
    } else {
      console.log(`  FAIL ${r.status} ${path} ${JSON.stringify(r.body).slice(0,80)}`);
      fail++;
    }
  }

  console.log(`\n=== ${ok} OK, ${fail} FAIL ===`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => { console.error('CRASH:', e.message); process.exit(1); });
