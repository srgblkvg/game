// Comprehensive column discovery and fix script for SQLite → PG migration.
// Reads SQLite PRAGMA table_info for every table, checks against PG information_schema,
// and adds missing columns with auto-detected types.
//
// Usage: scp to /opt/game/server/ and run with `node fix-all-columns.js`
// Prereqs: both better-sqlite3 and pg must be installed in cwd.

const { Pool } = require("pg");
const D = require("better-sqlite3");
const p = new Pool({ database: "game", user: "game", password: "game123" });
const s = new D("game.db");  // path relative to cwd

async function findMissingColumns() {
  const tables = s.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  
  for (const { name: table } of tables) {
    if (table === 'sqlite_sequence') continue;
    
    // Get SQLite columns
    const sqliteCols = s.prepare("PRAGMA table_info('" + table + "')").all();
    // Get PG columns
    const pgCols = await p.query(
      "SELECT column_name FROM information_schema.columns WHERE table_name=$1",
      [table.toLowerCase()]
    );
    const pgSet = new Set(pgCols.rows.map(r => r.column_name));
    
    for (const col of sqliteCols) {
      const pgColName = col.name.toLowerCase();
      if (!pgSet.has(pgColName)) {
        // Auto-detect type: INTEGER for epoch-like numeric columns, TEXT for everything else
        let type = "TEXT";
        if (col.type && col.type.toUpperCase().includes("INT")) {
          type = "INTEGER DEFAULT 0";
        }
        // Override: timestamp columns that hold epoch seconds should be INTEGER
        const epochCols = [
          "protectionuntil", "lockeduntil", "banneduntil", "lastloginat",
          "lastattacktime", "lastpveattacktime", "lastpvptime", "drinkuntil",
          "roomuntil", "premiumuntil", "chatbanneduntil", "lastbankvisit",
          "lasthpupdate", "failedlogins", "lastelodecay", "lastpveratingtime",
        ];
        if (epochCols.includes(pgColName)) {
          type = "INTEGER DEFAULT 0";
        }
        
        try {
          await p.query("ALTER TABLE " + table + " ADD COLUMN " + pgColName + " " + type);
          console.log("ADDED:", table + "." + pgColName, type);
        } catch (e) {
          // Column may already exist (race condition) or invalid type
          if (!e.message.includes("already exists")) {
            console.log("ERR:", table + "." + pgColName, e.message.split("\n")[0].substring(0, 60));
          }
        }
      }
    }
  }
  await p.end();
  s.close();
  console.log("Done");
}

findMissingColumns();
