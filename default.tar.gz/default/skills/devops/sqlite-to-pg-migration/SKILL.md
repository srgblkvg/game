---
name: sqlite-to-pg-migration
description: Migrate a better-sqlite3 Node.js codebase to PostgreSQL with pg (node-postgres). Compatibility wrapper, column name handling, async conversion, data migration, common pitfalls.
triggers:
  - migrating from SQLite/better-sqlite3 to PostgreSQL
  - moving from synchronous DB to async pg
  - SQLite → PG wrapper needed
  - column name mismatch between SQLite and PG
---

# SQLite → PostgreSQL Migration

Full migration playbook for moving a better-sqlite3 codebase to node-postgres (pg).

## SQL camelCase → lowercase Transformer

**This is the single most important migration fix.** SQLite is case-insensitive for column names; PostgreSQL is case-sensitive and folds unquoted identifiers to lowercase. Every SQL query using camelCase column names (like `tp.userId`, `tp.tournamentId`) will fail in PG.

### pgLowerIdentifiers

Add this function to your DB wrapper, applied BEFORE `pgParams` in every `query`/`one`/`run`:

```typescript
function pgLowerIdentifiers(sql: string): string {
  const strings: string[] = [];
  let cleaned = sql.replace(/'[^']*'/g, (m) => {
    strings.push(m);
    return '__STR_' + (strings.length - 1) + '__';
  });
  cleaned = cleaned.replace(/\b([a-z]+[A-Z][a-zA-Z0-9]*)\b/g, (m) => m.toLowerCase());
  return cleaned.replace(/__STR_(\d+)__/g, (_, i) => strings[parseInt(i)]);
}
```

Usage: `const q = pgParams(pgLowerIdentifiers(sql));`

**Caveat:** The regex `[a-z]+[A-Z]` does NOT match identifiers with digits before the uppercase (e.g., `player1Id`). However, PG natively folds unquoted identifiers to lowercase, so `player1Id` → `player1id` works automatically.

### camelRows — Results Converter

PG returns all column names lowercase. Rebuild camelCase keys with a suffix-based converter:

```typescript
function camelRows(rows: any[]): any[] {
  for (const row of rows) {
    // Null JSON fields → empty string
    const nullFields = ['inventory','equipment','activejob',...];
    for (const k of nullFields) if (row[k] === null) row[k] = '';
    
    for (const key of Object.keys(row)) {
      let cc = key.replace(
        /(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|score|number|players|ticket|stats|place|tag|text|chat|from|guild|role|last|first|ip|url|path|size|width|height|color|tier|slot|icon|attacked|made|round|log|code|expires|verified)$/i,
        m => m.charAt(0).toUpperCase() + m.slice(1)
      );
      cc = cc.replace(/([a-z])guildid$/i, '$1GuildId')
             .replace(/^bases$/i, 'baseS').replace(/^basea$/i, 'baseA')
             .replace(/^based$/i, 'baseD').replace(/^basem$/i, 'baseM')
             .replace(/lastattackedat$/i, 'lastAttackedAt');
      if (cc !== key) row[cc] = row[key];
    }
  }
  return rows;
}
```

**Keep suffix list in sync with ALL column names.** Missing suffixes = undefined properties = silent bugs.

## Critical Pitfalls

### 1. async function without await = Promise, not value

```typescript
// BROKEN — returns Promise<number>, used in arithmetic → NaN
async function nextPowerOfTwo(n: number): number {
    let p = 1;
    while (p < n) p *= 2;
    return p;
}
const slots = nextPowerOfTwo(n);  // [object Promise]!
const half = slots / 2;           // NaN
for (let i = 0; i < half; i++) {} // never executes!
```

**Fix:** Remove `async` from functions that don't use `await`. If you see `NaN` or `[object Promise]` in logs, trace to find the `async` without `await`.

### 2. Date Format: PG NOW() → +00, not +00:00

PG returns `"2026-06-15 09:39:56.772895+00"`. JS `new Date()` needs `+00:00` (with colon). Normalize on client:

```typescript
s = s.replace(/([+-]\d{2})$/, '$1:00');  // +00 → +00:00
```

Also: NEVER blindly append `'Z'` to date strings. If already ends with `Z` or `+00`, doubling produces `Invalid Date`. Grep for `\\+ 'Z'` — every instance is a bug on PG. See `references/date-and-camelcase-pitfalls.md`.

### 3b. Transaction patterns for race conditions

`db.one()` + `db.run()` are separate operations → race condition window between SELECT and UPDATE. Use `db.tx()` with `SELECT ... FOR UPDATE` for bid/auction-like flows. See `references/transaction-patterns.md`.

### 3. Missing createdat — NOT NULL constraint

Tables like `feedback_messages`, `guild_treasury_log` have `createdat NOT NULL`. Every INSERT must include it. Audit all INSERTs after migration.

### 4. client.query returns { rows }, not array

`pool.query()` returns `{ rows: [...], rowCount: N }`. Access as `r.rows[0]`, NOT `r[0]`.

### 5. SELECT last_insert_rowid() — SQLite only

Doesn't exist in PG. Use `RETURNING id` or capture `lastInsertRowid` from your INSERT wrapper.

### 6. Shell escaping hell — always use script files

When running queries via SSH, shell escaping of quotes/special chars is error-prone. Write scripts to `.js` files, scp them, run with `node`. Do NOT inline complex SQL via `ssh ... node -e "..."` — the escaping will fail.

### 7. INSERT VALUES without explicit columns — column shift

`INSERT INTO t VALUES (?, ?, ...)` omitting the auto-increment `id` column works in SQLite but SHIFTS all values by one position in PG. Always list columns explicitly: `INSERT INTO t (col1, col2, ...) VALUES (?, ?, ...)`. See `references/date-and-camelcase-pitfalls.md`.

### 8. camelCase suffix collisions

The `camelRows` suffix regex matches substrings — e.g. `count` in `fromaccount` → `fromacCount`, `name` in `item_name` → `item_Name`. Any column containing a known suffix needs an explicit full-key `.replace()` rule BEFORE the generic suffix regex. See `references/date-and-camelcase-pitfalls.md`. Fixes shipped for `fromAccount`, `toAccount`, `accountNumber`, `itemName`.

### 7. Tournament & Guild War specifics

See `references/tournament-guild-fixes.md` for:
- `generateBracket` rewrite with raw `pool.query` (bypasses `db.run` RETURNING issues)
- Bracket regeneration when `in_progress` with 0 matches
- `lastAttackedAt` camelCase fix for guild war protection timers
- `maxPlayers` column addition
- Battle log HP tracking

### 9. Sequence ownership — INSERT permission denied

When tables are created by `postgres` but the app runs as `game`, `SERIAL` column sequences are owned by `postgres`. The app user may have `INSERT` on the table but lacks `USAGE` on the sequence → `INSERT ... RETURNING id` fails with `permission denied for table <name>` even though `SELECT`/direct `INSERT` work.

**Fix:** `GRANT USAGE, SELECT ON SEQUENCE <table>_id_seq TO game;` — or set default privileges. Full details in `references/sequence-ownership.md`.

### 8. SafeDate must handle +00 timezone

PG `NOW()` returns `+00` (no colon). Normalize: `s.replace(/([+-]\d{2})$/, '$1:00')`. Never append `Z` to strings that already have timezone info.

### 10. db.query returns 0 rows when pgLowerIdentifiers corrupts the SQL

Complex queries with JOINs, boolean conditions (`= TRUE`, `= FALSE`), or multi-table aliases may silently return 0 rows when `pgLowerIdentifiers` processes them — even though the same SQL in psql works. **Use `db.raw()` with `$1`-style params** to bypass the converter entirely. Note: `db.raw` does NOT apply `camelRows` — keys stay as raw PG output (lowercase snake_case, no suffix capitalization). See `references/db-raw-vs-query.md`. This was validated in the massacre battle feature where `db.query` returned 0 participants for 119 inserted rows.