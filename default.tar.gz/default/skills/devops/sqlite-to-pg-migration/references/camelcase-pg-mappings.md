# CamelCase Converter — Complete Reference

PG lowercases ALL identifiers. The camelCase converter rebuilds camelCase from lowercase.
This reference documents every edge case discovered during the full PG migration.

## Suffix-Based Converter (generic)

The suffix regex matches KNOWN endings and capitalizes the first letter:

```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo)$/i
```

**DO NOT add single-letter suffixes** (`s`, `a`, `d`, `m`) — they match too broadly and break other columns (e.g., `statpoints` → `statpointS` instead of `statPoints`).

## Explicit Mappings (compound words)

The suffix converter cannot handle compound words where MULTIPLE words are joined (e.g., `totalPvpMoneyWon`). These must be explicit:

```
bases → baseS      basea → baseA       based → baseD        basem → baseM
statpoints → statPoints
totalbattles → totalBattles
pvetotalbattles → pveTotalBattles
pvewins → pveWins
totalpvpmoneywon → totalPvpMoneyWon
totalpvpmoneylost → totalPvpMoneyLost
totalpvemoneywon → totalPveMoneyWon
totalpvemoneylost → totalPveMoneyLost
totaljobmoney → totalJobMoney
totaljobseconds → totalJobSeconds
craftcreated → craftCreated
craftupgraded → craftUpgraded
craftbroken → craftBroken
tournamentcount → tournamentCount
tournamentwins → tournamentWins
auctiontrades → auctionTrades
emailverified → emailVerified
isguest → isGuest
oauthprovider → oauthProvider
oauthid → oauthId
arenatopponentid → arenaOpponentId
rewardxp → rewardXp
attacktime → AttackTime
pveattacktime → PveAttackTime
attacksec → AttackSec
pveattacksec → PveAttackSec
taxrate → TaxRate
verified → Verified
hpupdate → HpUpdate
```

## BigInt / Numeric Conversion

PG returns BIGINT (COUNT, SUM) as STRINGS. The converter parses numeric strings ONLY if:
1. The value is > 2^31 (actual bigint), OR
2. The column name matches a numeric pattern: `id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round|year|month|day|hour|min|sec|limit|offset|page|rank`

**Why not convert all numeric strings?** Chat messages like `"2"` or `"123"` would become numbers, breaking `.split()` and other string operations.

## Date/Timestamp Handling

Original SQLite used epoch integers for timestamps. During migration:
- Columns that receive ISO strings → change to TEXT
- Columns that receive epoch integers → keep as TEXT, convert at read time
- The `createdAt` column in `tournaments` exists in BOTH formats (epoch and ISO) — must handle both

Key tables with timestamp issues:
- `tournaments.createdAt/completedAt` — mixed epoch/ISO
- `users.lastLoginAt/createdAt` — epoch
- All TIMESTAMPTZ columns changed to TEXT during migration
