# Transaction Patterns for Race Conditions

## Auction Bid Race Condition

**Bug:** Two simultaneous bids both read `currentBid = null` → both accepted at `startPrice` → second bid at same price should have been rejected.

**Root cause:** `db.one()` (SELECT) and `db.run()` (UPDATE) are separate operations. Between SELECT and UPDATE, another request can read stale data (READ COMMITTED isolation).

**Fix:** Use `db.tx()` with `SELECT ... FOR UPDATE`:

```typescript
router.post('/auction/bid', async (req, res) => {
    try {
        await db.tx(async (client) => {
            // FOR UPDATE locks the row — concurrent bids wait
            const lot = (await client.query(
                'SELECT * FROM auction_lots WHERE id = $1 AND endsAt > $2 FOR UPDATE',
                [lotId, now]
            )).rows[0];
            
            // Inside tx, use raw PG client.query with $1/$2 params
            // Column keys are lowercase (no camelCase converter)
            const currentBid = lot.currentbid ? parseInt(lot.currentbid) : null;
            const minBid = currentBid 
                ? currentBid + Math.max(1, Math.floor(currentBid * 0.05)) 
                : parseInt(lot.startprice);
            
            if (amount < minBid) throw new Error(`Мин. ставка: ${minBid}`);
            
            // ... money transfers ...
            await client.query('UPDATE auction_lots SET currentBid = $1, currentBidderId = $2 WHERE id = $3', ...);
        });
        res.json({ success: true });
    } catch (e: any) {
        res.status(400).json({ error: e.message });
    }
});
```

**Key points:**
- `db.tx()` wraps in BEGIN/COMMIT/ROLLBACK
- `SELECT ... FOR UPDATE` locks row until transaction ends
- Inside tx, use raw `client.query()` with `$1`/`$2` params (not `db.one()`/`db.run()`)
- PG column keys are lowercase — use `lot.currentbid` not `lot.currentBid`
- `parseInt()` on PG values that might be strings
