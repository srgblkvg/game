# Complete camelCase Suffix Guide

The suffix-based camelCase converter MUST cover ALL compound column names. Missing a suffix produces silent `undefined` field values. This is the #1 source of "works on SQLite, broken on PG" bugs.

## Base Suffix Regex (FINAL — as of 2026-06-14)
```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|number)$/i
```
Added after production deployment: `battles`, `money`, `created`, `upgraded`, `broken`, `seconds`, `xp`, `end`, `start`, `elo`, `number`.

## Compound Corrections (applied AFTER base — FINAL)
```ts
cc = cc.replace(/attacktime$/i, 'AttackTime')
       .replace(/pveattacktime$/i, 'PveAttackTime')
       .replace(/attacksec$/i, 'AttackSec')
       .replace(/pveattacksec$/i, 'PveAttackSec')
       .replace(/taxrate$/i, 'TaxRate')
       .replace(/verified$/i, 'Verified')
       .replace(/hpupdate$/i, 'HpUpdate')
       .replace(/^bases$/i, 'baseS').replace(/^basea$/i, 'baseA')
       .replace(/^based$/i, 'baseD').replace(/^basem$/i, 'baseM')
       .replace(/^statpoints$/i, 'statPoints')
       .replace(/^totalbattles$/i, 'totalBattles')
       .replace(/^pvetotalbattles$/i, 'pveTotalBattles')
       .replace(/^pvewins$/i, 'pveWins')
       .replace(/^totalpvpmoneywon$/i, 'totalPvpMoneyWon')
       .replace(/^totalpvpmoneylost$/i, 'totalPvpMoneyLost')
       .replace(/^totalpvemoneywon$/i, 'totalPveMoneyWon')
       .replace(/^totalpvemoneylost$/i, 'totalPveMoneyLost')
       .replace(/^totaljobmoney$/i, 'totalJobMoney')
       .replace(/^totaljobseconds$/i, 'totalJobSeconds')
       .replace(/^craftcreated$/i, 'craftCreated')
       .replace(/^craftupgraded$/i, 'craftUpgraded')
       .replace(/^craftbroken$/i, 'craftBroken')
       .replace(/^tournamentcount$/i, 'tournamentCount')
       .replace(/^tournamentwins$/i, 'tournamentWins')
       .replace(/^emailverified$/i, 'emailVerified')
       .replace(/^isguest$/i, 'isGuest')
       .replace(/^oauthprovider$/i, 'oauthProvider')
       .replace(/^oauthid$/i, 'oauthId')
       .replace(/^rewardxp$/i, 'rewardXp')
       .replace(/^accountnumber$/i, 'accountNumber')
       .replace(/^arenatopponentid$/i, 'arenaOpponentId');
```

## CRITICAL: Single-letter suffixes (s, a, d, m)
Do NOT add single-letter suffixes to the base regex. They match too broadly (e.g. `statpoints$` → `statpointS`). Use explicit `^exactmatch$` replacements instead — see `^bases$`→`baseS` above.

## Mapping Table
| PG column | Suffix used | Result | Code expects |
|-----------|------------|--------|-------------|
| passwordhash | hash | passwordHash | passwordHash |
| currenthp | hp | currentHp | currentHp |
| lasthpupdate | hpupdate→HpUpdate | lastHpUpdate | lastHpUpdate |
| rewardmax | max | rewardMax | rewardMax |
| rewardmin | min | rewardMin | rewardMin |
| activejob | job | activeJob | activeJob |
| sort_order | order | sortOrder | sortOrder |
| successchance | chance | successChance | successChance |
| bg_image | image | bgImage | bgImage |
| lastattacktime | attacktime→AttackTime | lastAttackTime | lastAttackTime |
| lastpveattacktime | pveattacktime→PveAttackTime | lastPveAttackTime | lastPveAttackTime |
| attackcooldownsec | attacksec→AttackSec | attackCooldownSec | attackCooldownSec |
| guild_treasury_log | (no compound) | guildTreasuryLog | guildTreasuryLog |
| elo | (no suffix match) | elo | elo |
| emailverified | verified→Verified | emailVerified | emailVerified |

## BigInt→Number Conversion (SAFE VERSION)
PG returns COUNT(*) and other bigint values as strings. A naive converter that turns ALL numeric strings to numbers will break TEXT columns like chat messages (content: "2" → 2, breaks .split()).

USE THIS SAFE CONVERTER that only converts:
1. Actual bigints (value > 2^31 from COUNT/SUM), OR
2. Known numeric column names

```ts
for (const key of Object.keys(row)) {
  if (typeof row[key] === 'string' && /^\d+$/.test(row[key])) {
    const n = parseInt(row[key], 10);
    if (n > 2147483647 || /^(id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round)$/i.test(key)) {
      row[key] = n;
    }
  }
}
```

DO NOT convert purely by numeric pattern — TEXT columns like `content`, `username`, `name` can legitimately contain numeric-only values.

## Null→Empty String for JSON Columns
PG returns NULL for TEXT columns where SQLite returned empty strings. JSON.parse(null) crashes:
```ts
const nullFields = ['inventory','equipment','activejob','openprivatetabs','snapshot',
  'log','item_data','bonuses','extra'];
for (const k of nullFields) {
  if (row[k] === null) row[k] = '';
}
// Special defaults
if (row.inventory === '' || row.inventory === null) row.inventory = '[]';
if (row.equipment === '' || row.equipment === null) row.equipment = '{}';
```
