# PG Native — Common SQL Translation Pitfalls

## `MAX(a, b)` → `GREATEST(a, b)`
SQLite/MySQL `MAX()` works as a scalar function. PostgreSQL does not.
- **PG**: `GREATEST(a, b)` for scalar max
- **Hit in**: `tournament.ts` line 320 — `MAX(100, tournamentElo + ?)` → `GREATEST(100, tournamentElo + ?)`

## `datetime()` → ISO string or epoch
SQLite `datetime('now')` returns a formatted string. PG uses:
- `NOW()` for TIMESTAMPTZ
- `EXTRACT(EPOCH FROM NOW())` for epoch seconds
- Or just compute in JS: `new Date().toISOString()`

## `last_insert_rowid()` → `RETURNING id`
SQLite `last_insert_rowid()` doesn't exist in PG.
- **PG**: Use `RETURNING id` in INSERT, or the `db.run()` wrapper already returns `lastInsertRowid` from RETURNING
- **Hit in**: `tournament.ts` lines 94, 98 (bye handling)

## `INSERT OR REPLACE` → `ON CONFLICT DO UPDATE`
SQLite syntax not supported in PG.
- **PG**: `INSERT ... ON CONFLICT (id) DO UPDATE SET col = EXCLUDED.col`

## TIMESTAMPTZ columns receiving epoch strings
When server code sends epoch integers as strings (e.g., `"1781344545"`), PG's TIMESTAMPTZ rejects them.
- **Fix**: ALTER affected columns to TEXT
- **Affected**: `tournaments.createdAt/completedAt`, `users.lastLoginAt/createdAt`

## BigInt auto-conversion trap
PG node-postgres returns COUNT(*) as string. Auto-converting ALL numeric strings to numbers breaks text columns that happen to be all-digits.
- **Fix**: Only convert if value > 2^31 OR column name matches numeric pattern
- **Hit in**: chat messages with content "2" being converted to number 2, breaking `.split()`
