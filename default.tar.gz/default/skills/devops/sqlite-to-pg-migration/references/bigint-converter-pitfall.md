# BigInt Converter Pitfall

## Problem

PG returns `COUNT(*)`, `SUM()`, and other aggregate results as strings (BigInt). A naive converter that turns all numeric-looking strings into numbers will break text columns.

## The Broken Converter (DO NOT USE)

```ts
// Converts ALL numeric-looking strings to numbers
for (const key of Object.keys(row)) {
  if (typeof row[key] === 'string' && /^\d+$/.test(row[key])) {
    row[key] = parseInt(row[key], 10);
  }
}
```

This converts chat messages like `content: "2"` to `content: 2`, breaking `.split()` and other string methods. Any text column containing purely numeric content will be corrupted.

## The Safe Converter

Only convert strings that are:
1. **Actual bigints** (value > 2^31 — from COUNT/SUM aggregates), OR
2. **Known numeric columns** (id, count, level, elo, price, etc.)

```ts
for (const key of Object.keys(row)) {
  if (typeof row[key] === 'string' && /^\d+$/.test(row[key])) {
    const n = parseInt(row[key], 10);
    if (n > 2147483647 || /^(id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round|year|month|day|hour|min|sec|limit|offset|page|rank)$/i.test(key)) {
      row[key] = n;
    }
  }
}
```

## Symptom When Broken

- `TypeError: e.content.split is not a function` — chat messages with numeric content
- Silent data corruption in any TEXT column containing only digits
