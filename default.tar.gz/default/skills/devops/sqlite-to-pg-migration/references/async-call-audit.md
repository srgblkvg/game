# Async Function Call Audit — Common Missing `await` Patterns

After a PG migration or bulk async conversion, these project-specific async functions are frequently called without `await`:

## Detected patterns (from real MMO game migration)

| Function | Call sites | Symptom when missing `await` |
|----------|-----------|------------------------------|
| `isGuildAtWar(guildId)` | 8+ | `if (war)` always true (Promise is truthy), `war.attackerGuildId` = undefined → `null.name` crash |
| `loadPlayerForBattle(userId)` | 2 | `runBattle(Promise, Promise)` → `Object.values(undefined)` → crash loop |
| `resolveCurrentRound(id)` | 2 | Doesn't wait for round resolution, tournament state inconsistent |
| `addPveRating(userId, ...)` | 1 | Still called with `db` as first arg after signature change → `"{}" in INTEGER` crash |
| `enrichEquipment(equipment)` | 10+ | Returns `{ enriched: undefined }` → `currentStats(base, undefined)` → crash |
| `getUserById(userId)` | 3 | Returns Promise → `getBaseStats(Promise)` → `{ s: null, a: null, ... }` |

## Detection commands

```bash
# Find async function calls without await
grep -rn "isGuildAtWar(" routes/ | grep -v "await " | grep -v "async function"
grep -rn "loadPlayerForBattle(" routes/ | grep -v "await " | grep -v "async function"
grep -rn "resolveCurrentRound(" routes/ | grep -v "await " | grep -v "async function"

# Find functions still called with old db parameter
grep -rn "addPveRating(db," routes/
grep -rn "applyDecay(db," routes/
grep -rn "checkSeasonReset(db," routes/
```

## Fix approach

1. Add `await` before the call: `const x = await funcName(args)`
2. Remove `db,` from parameter list if the function no longer takes it
3. Verify NO double-await: `grep -rn "await await" routes/`
