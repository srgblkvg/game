# PG Native — CamelCase Converter Issues

## Problem
PostgreSQL lowercases all unquoted identifiers. The code expects camelCase (e.g. `baseS`, `activeJob`, `registrationEnd`). A converter in `db/index.ts` rebuilds camelCase using suffix-based regex + explicit compound mappings.

## Discovered missing suffixes (added to regex)
- `job` — `activejob` → `activeJob`
- `order` — `sortorder` → `sortOrder`
- `image` — `bgimage` → `bgImage`
- `chance` — `successchance` → `successChance`
- `battles` — `totalbattles` / `pvetotalbattles` → `totalBattles` / `pveTotalBattles`
- `money` — `totaljobmoney` etc → `totalJobMoney`
- `created` — `craftcreated` → `craftCreated`
- `upgraded` — `craftupgraded` → `craftUpgraded`
- `broken` — `craftbroken` → `craftBroken`
- `seconds` — `totaljobseconds` → `totalJobSeconds`
- `xp` — `rewardxp` → `rewardXp`
- `end` — `registrationend` → `registrationEnd`
- `start` — `registrationstart` → `registrationStart`
- `elo` — `tournamentelo` → `tournamentElo`
- `number` — `accountnumber` → `accountNumber`

## Explicit compound mappings (added to chain)
Single-letter columns (S/A/D/M) and compound words that regex can't handle:

```
.replace(/^bases$/i, 'baseS')
.replace(/^basea$/i, 'baseA')
.replace(/^based$/i, 'baseD')
.replace(/^basem$/i, 'baseM')
.replace(/^statpoints$/i, 'statPoints')
.replace(/^totalbattles$/i, 'totalBattles')
.replace(/^pvetotalbattles$/i, 'pveTotalBattles')
.replace(/^pvewins$/i, 'pveWins')
.replace(/^totalpvpmoneywon$/i, 'totalPvpMoneyWon')
.replace(/^totalpvpmoneylost$/i, 'totalPvpMoneyLost')
.replace(/^totalpvemoneywon$/i, 'totalPveMoneyWon')
.replace(/^totalpvemoneylost$/i, 'totalPveMoneyLost')
.replace(/^totaljobmoney$/i, 'totalJobMoney')
.replace(/^totaljobseconds$/i, 'totalJobSeconds')
.replace(/^craftcreated$/i, 'craftCreated')
.replace(/^craftupgraded$/i, 'craftUpgraded')
.replace(/^craftbroken$/i, 'craftBroken')
.replace(/^tournamentcount$/i, 'tournamentCount')
.replace(/^tournamentwins$/i, 'tournamentWins')
.replace(/^auctiontrades$/i, 'auctionTrades')
.replace(/^emailverified$/i, 'emailVerified')
.replace(/^isguest$/i, 'isGuest')
.replace(/^oauthprovider$/i, 'oauthProvider')
.replace(/^oauthid$/i, 'oauthId')
.replace(/^rewardxp$/i, 'rewardXp')
.replace(/^accountnumber$/i, 'accountNumber')
.replace(/^arenatopponentid$/i, 'arenaOpponentId')
```

## Audit technique
When a feature shows all-zero or default values, suspect missing camelCase:
1. `grep` the column name in `db/index.ts` suffix regex
2. If not found, check if explicit mapping exists
3. Add to suffix list OR add explicit compound mapping
4. Restart server
