// Working migration script — Node.js, reads SQLite, inserts into PG
// Maps camelCase SQLite columns → lowercase PG columns
// Usage: node migrate-sqlite-pg.js

const Database = require('better-sqlite3');
const pgPromise = require('pg-promise')();

const sqlite = new Database('/tmp/prod_game.db');
const pg = pgPromise({
  host: 'localhost', port: 5432, database: 'game', user: 'game', password: 'game123',
});

function camelToSnake(s) {
  return s.replace(/([A-Z])/g, '_$1').toLowerCase().replace(/^_/, '');
}

async function migrate() {
  // Get PG tables
  const pgTables = (await pg.manyOrNone("SELECT tablename FROM pg_tables WHERE schemaname='public'"))
    .map(r => r.tablename).filter(t => !t.includes('_seq'));

  // Truncate all (order: dependent tables first)
  const orderedTables = [
    'guild_war_attacks', 'guild_wars', 'guild_treasury_log', 'guild_invites', 'guild_members', 'guilds',
    'bank_operations', 'transfers', 'pve_battles', 'login_logs', 'tournament_matches', 'tournament_participants',
    'tournaments_new', 'tournaments', 'auction_lots', 'quest_history', 'daily_quests', 'job_history',
    'chat_messages', 'battles', 'collections', 'feedback_messages', 'orders', 'order_members', 'seasons',
    'admins', 'users', 'items', 'craft_recipe_ingredients', 'craft_recipes', 'craft_recipe_categories',
    'craft_items', 'mobs', 'jobs', 'rarities', 'stat_names', 'actions_config', 'floors', 'upgrade_chances',
    'drinks', 'collection_set_items', 'collection_sets',
  ].filter(t => pgTables.includes(t));

  await pg.none(`TRUNCATE ${orderedTables.join(', ')} RESTART IDENTITY CASCADE`);

  const tables = sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all();

  for (const { name } of tables) {
    const count = sqlite.prepare(`SELECT COUNT(*) as c FROM [${name}]`).get().c;
    if (count === 0 || name === 'sqlite_sequence') { console.log(`  ${name}: empty`); continue; }

    const pgName = name.toLowerCase();
    if (!pgTables.includes(pgName)) { console.log(`  ${name}: no PG table`); continue; }
    
    const pgCols = (await pg.manyOrNone(
      `SELECT column_name FROM information_schema.columns WHERE table_name=$1 ORDER BY ordinal_position`, [pgName]
    )).map(r => r.column_name);

    const rows = sqlite.prepare(`SELECT * FROM [${name}]`).all();
    if (rows.length === 0) continue;

    const sqliteCols = Object.keys(rows[0]);
    
    // Map SQLite columns → PG columns
    const mapping = {};
    for (const sc of sqliteCols) {
      const scLower = sc.toLowerCase();
      const scSnake = camelToSnake(sc);
      let match = pgCols.find(pc => pc === scLower || pc === scSnake);
      if (match) mapping[sc] = match;
    }
    
    const matchedPgCols = sqliteCols.map(sc => mapping[sc]).filter(Boolean);
    const placeholders = matchedPgCols.map((_, i) => `$${i + 1}`).join(', ');
    const colNames = matchedPgCols.map(c => `"${c}"`).join(', ');
    const sql = `INSERT INTO "${pgName}" (${colNames}) VALUES (${placeholders})`;

    let inserted = 0;
    for (const row of rows) {
      const values = sqliteCols.map(sc => {
        if (!mapping[sc]) return undefined;
        const v = row[sc];
        if (v === null || v === undefined) return null;
        if (['log', 'steps', 'bonuses', 'extra', 'itemData', 'item_data', 'snapshot', 'openPrivateTabs', 'snapshotStats', 'activeJob'].includes(sc)) {
          return typeof v === 'string' ? v : JSON.stringify(v);
        }
        return v;
      }).filter(v => v !== undefined);
      
      if (values.length !== matchedPgCols.length) continue;
      
      try {
        await pg.none(sql, values);
        inserted++;
      } catch (e) {
        console.error(`  ${name} row error: ${e.message}`);
      }
    }
    console.log(`  ${name}: ${inserted}/${count}`);
  }

  // Reset sequences
  const seqs = await pg.manyOrNone("SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema='public'");
  for (const s of seqs) {
    const tableName = s.sequence_name.replace('_id_seq', '');
    try {
      await pg.none(`SELECT setval('${s.sequence_name}', COALESCE((SELECT MAX(id) FROM "${tableName}"), 1))`);
    } catch {}
  }

  console.log('Done!');
}

migrate().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
