# Sequence Ownership Pitfall (INSERT permission denied)

## Symptom

```
error: permission denied for table guild_quests
    at async Object.run (db/index.ts)
    at async <anonymous> (routes/guild.ts)
```

But `SELECT` works fine, and the user has INSERT/UPDATE/DELETE privileges on the table.

## Root Cause

The table was created by a different PostgreSQL user (e.g., `postgres`) than the application user (e.g., `game`). The `SERIAL` column's sequence (`tablename_id_seq`) is owned by the table owner. The application user may have table privileges via `GRANT ALL ON table TO game`, but lacks `USAGE` on the sequence.

When `INSERT ... RETURNING id` executes, PG internally calls `nextval('seq')` which requires `USAGE` on the sequence — even though the app user has `INSERT` on the table.

## Detection

```sql
-- Check table owner
SELECT tableowner FROM pg_tables WHERE tablename = 'guild_quests';

-- Check sequence owner
SELECT c.relname, pg_get_userbyid(c.relowner) as owner
FROM pg_class c WHERE c.relkind = 'S' AND c.relname LIKE '%guild_quest%';
```

If the owners differ from the app user, you have this bug.

## Fix

```sql
GRANT USAGE, SELECT ON SEQUENCE guild_quests_id_seq TO game;
```

Or, if many sequences are affected:

```sql
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN SELECT c.relname FROM pg_class c
           JOIN pg_namespace n ON c.relnamespace = n.oid
           WHERE c.relkind = 'S' AND n.nspname = 'public'
           AND pg_get_userbyid(c.relowner) != 'game'
  LOOP
    EXECUTE 'GRANT USAGE, SELECT ON SEQUENCE ' || r.relname || ' TO game';
  END LOOP;
END $$;
```

## Prevention

Always create tables as the application user, or ensure `GRANT ALL` includes sequences:

```sql
-- After CREATE TABLE as postgres:
GRANT ALL ON TABLE tablename TO game;
GRANT USAGE, SELECT ON SEQUENCE tablename_id_seq TO game;
```

Or set default privileges so future sequences auto-grant:

```sql
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO game;
```
