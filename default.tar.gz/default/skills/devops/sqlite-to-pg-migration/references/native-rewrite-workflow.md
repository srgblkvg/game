# Native PG Rewrite Workflow — Full Step-by-Step

When the compatibility wrapper approach has failed 3+ times OR the user explicitly demands a full rewrite, use this workflow.

## Steps

### 1. Dump SQLite schema
```bash
cd server && node -e "
const D=require('better-sqlite3'); const db=new D('game.db');
db.prepare(\"SELECT name FROM sqlite_master WHERE type='table' ORDER BY name\").all().forEach(t => {
  console.log('\\n=== ' + t.name + ' ===');
  db.prepare('PRAGMA table_info(' + t.name + ')').all().forEach(c =>
    console.log(c.name, c.type, c.pk ? 'PK' : '', c.notnull ? 'NOTNULL' : '', 'default='+c.dflt_value));
});
"
```

### 2. Generate PG schema
- `INTEGER PRIMARY KEY` → `SERIAL PRIMARY KEY`
- `DATETIME DEFAULT CURRENT_TIMESTAMP` → `TEXT`
- `strftime('%s','now')` → `EXTRACT(EPOCH FROM NOW())::INTEGER`
- Column names: LOWERCASE (unquoted)
- All date/timestamp columns → `TEXT` (code sends ISO strings, not epoch)

### 3. Write native PG module
Copy `references/native-pg-module.ts` → `server/src/db/index.ts`. Key features:
- BigInt string → number conversion
- Suffix-based camelCase with compound corrections (hpupdate → HpUpdate)
- ? → $N placeholder conversion
- RETURNING id with try/catch fallback
- Transaction wrapper

### 4. Bulk rewrite all files
Use delegate_task with 3 subagents, each handling a group of files:
  - Group 1: core (auth, character, middleware, setupRoutes, websocket, hpRegen, seed, helpers)
  - Group 2: game routes (battle, arena, users, rating, shop, jobs, account, chat, craft, mobs, bank)
  - Group 3: remaining routes + admin (tavern, auction, tournament, orders, quests, guild, feedback, collections, inventory, characterStats, actions, log, admin*)

**Rewrite rules for subagents:**
- `import db from '../database'` → `import { db } from '../db/index'`
- `db.prepare(sql).get(a,b)` → `db.one(sql, [a,b])`
- `db.prepare(sql).all(a)` → `db.query(sql, [a])`
- `db.prepare(sql).run(a,b)` → `db.run(sql, [a,b])`
- `db.transaction(fn)` → `db.tx(async (client) => { ... })`
- Inside tx: `client.query(sql, [$1,$2])` with `.rows[0]` (NOT `[0]`)
- Module-level `const stmt = db.prepare(sql)` → `const SQL = '...'` + inline `db.one(SQL, [...])`

### 5. Rewrite helpers (db/helpers.ts)
- Remove `db: DB` parameter from ALL functions
- Import `{ db }` from '../db/index' directly
- `getItemDataStmt(db)` → remove, use `const SQL = '...'` + `db.one(SQL, [...])`
- Keep pure functions sync: `getBaseStats`, `getMaxHp`, `recalcHpOnEquip`, `expForLevel`, `applyExp`
- Make DB functions async: `getUserById`, `getUserWithStats`, `enrichEquipment`, `transferMoney`, `addMoney`, `spendMoney`, `collectGuildTax`

### 6. Fix helper call sites
- `getUserById(db, userId)` → `getUserById(userId)` in ALL files
- `enrichEquipment(db, equip)` → `enrichEquipment(equip)`
- `collectGuildTax(db, userId, ...)` → `collectGuildTax(userId, ...)`
- `applyExp(db, userId, ...)` → `applyExp(userId, ...)`
- `addMoney(db, userId, amount)` → `addMoney(userId, amount)`
- `transferMoney(db, ...)` → `transferMoney(...)`

### 7. Fix SQLite-specific SQL
- `datetime(?)` → `?` (pass ISO string directly)
- `datetime('now', '-5 minutes')` → compute in JS, pass as param
- `INSERT OR REPLACE` → `INSERT ... ON CONFLICT ... DO UPDATE SET`

### 8. Seed essential data
After creating tables, seed:
- rarities (0-6), items (189), mobs (30), jobs (20)
- craft_items (14), craft_recipes (20), upgrade_chances (70)
- stat_names (9), actions_config (9), floors (14)
- collection_sets + collection_set_items

### 9. Fix column types to match actual data
- Check for `TIMESTAMPTZ` columns → convert to TEXT (code sends ISO strings)
- Check for INTEGER columns receiving ISO strings → convert to TEXT
- Check for TEXT columns receiving epoch integers → convert to INTEGER

### 10. Test
Run full endpoint test (login, character/me, shop, mobs, rating, tavern, users, jobs, bank, auction, guild, collections, tournament, orders, actions). ALL must return 200. No `[{},{},{}]`.

## Common Post-Rewrite Bugs

| Bug | Symptom | Fix |
|-----|---------|-----|
| `.map(async` without Promise.all | `[{},{},{},{}]` | Wrap in `await Promise.all(.map(async ...))` or remove `async` |
| Missing `await` on helper call | `Object.values(undefined)` crash | Add `await` before `loadPlayerForBattle`, `resolveCurrentRound`, `enrichEquipment` |
| BigInt string `"0" !== 0` | Seed says OK but tables empty | Add numeric string → number conversion in camelRows |
| `hpupdate` → `lastHpupdate` not `lastHpUpdate` | HP regen never triggers | Add `.replace(/hpupdate$/i, 'HpUpdate')` |
| TIMESTAMPTZ receiving epoch int | `date/time field value out of range` | ALTER COLUMN to INTEGER |
| INTEGER receiving ISO string | `invalid input syntax for type integer` | ALTER COLUMN to TEXT |
| `client.query()[0]` in tx | TS Error 7053, runtime `undefined` | Use `.rows[0]` |
| `datetime()` in SQL | `function datetime(unknown) does not exist` | Remove wrapper, pass ISO string directly |
| `INSERT OR REPLACE` | `syntax error at or near "OR"` | Use `ON CONFLICT ... DO UPDATE` |
| RETURNING id on composite key | `column "id" does not exist` | try/catch fallback in db.run() |
| Missing actions_config/floors seed | Empty main page / empty floors | Dump from SQLite and insert into PG |
