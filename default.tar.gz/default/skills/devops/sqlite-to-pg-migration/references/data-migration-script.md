# Data Migration Script — SQLite → PG

Working approach for migrating production SQLite database to local PostgreSQL.

## Prerequisites

```bash
# Copy prod DB from VPS
scp root@VPS_IP:/opt/game/server/game.db server/game_prod.db

# Drop PG schema and recreate
sudo -u postgres psql -d game -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public; GRANT ALL ON SCHEMA public TO game;"
sudo -u postgres psql -d game -f server/src/db/schema.sql
```

## Migration Script

Core approach: for each table, read SQLite → map columns → INSERT into PG.

```js
const Database = require('better-sqlite3');
const { Pool } = require('pg');
const sqlite = new Database('game_prod.db');
const pg = new Pool({ host:'localhost', port:5432, database:'game', user:'game', password:'game123' });

async function migrateTable(tn) {
  // Get SQLite columns
  const sqliteCols = sqlite.prepare(`PRAGMA table_info('${tn}')`).all();
  // Get PG columns
  const { rows: pgRows } = await pg.query(
    `SELECT column_name FROM information_schema.columns WHERE table_name=$1 ORDER BY ordinal_position`, [tn]
  );
  const pgCols = pgRows.map(r => r.column_name);
  
  // Build mapping: SQLite name → PG name
  const map = {};
  for (const c of sqliteCols) {
    const lower = c.name.toLowerCase();
    if (pgCols.includes(lower)) {
      map[c.name] = lower; // passwordHash → passwordhash ✓
    }
  }
  
  const rows = sqlite.prepare(`SELECT * FROM ${tn}`).all();
  if (rows.length === 0) return;
  
  const pgNames = Object.values(map);
  const cols = pgNames.join(', ');
  const ph = pgNames.map((_, i) => `$${i + 1}`).join(', ');
  const sql = `INSERT INTO ${tn} (${cols}) VALUES (${ph})`;
  
  for (const row of rows) {
    const vals = Object.keys(map).map(k => row[k]);
    await pg.query(sql, vals);
  }
}
```

## Key Pitfalls

1. **Permissions**: after `DROP SCHEMA ... CREATE SCHEMA`, the `game` user needs GRANT: 
   `GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO game; GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO game;`

2. **NULL → 0 for critical columns**: users table has columns (currentHp, bank, elo, seasonWins, etc.) that should be 0 not NULL. Map these:
   ```js
   const nullToZero = ['currentHp','bank','elo','seasonWins','seasonLosses',...];
   // In the value mapper:
   const vals = Object.keys(map).map(k => {
     let v = row[k];
     if (v === null && nullToZero.includes(k)) return 0;
     return v;
   });
   ```

3. **Type mismatches**: after migration, check columns that got TEXT data but need to accept epoch integers:
   ```sql
   ALTER TABLE users ALTER COLUMN lastloginat TYPE TEXT USING lastloginat::TEXT;
   ALTER TABLE tournaments ALTER COLUMN createdat TYPE TEXT USING createdat::TEXT;
   ```

4. **Sequence reset**: after migration, reset ALL SERIAL sequences:
   ```sql
   SELECT setval('users_id_seq', (SELECT MAX(id) FROM users));
   ```

5. **Verification**: compare row counts for every table:
   ```js
   for (const t of tables) {
     const sc = sqlite.prepare(`SELECT count(*) FROM "${t}"`).get()['count(*)'];
     const { rows: [{ cnt }] } = await pg.query(`SELECT count(*) as cnt FROM "${t}"`);
     if (parseInt(cnt) !== sc) console.log(`${t}: MISMATCH SQLite=${sc} PG=${cnt}`);
   }
   ```

## Failures and Retries

If some tables fail (type mismatch, missing columns):
1. Fix the PG column type: `ALTER TABLE t ALTER COLUMN c TYPE TEXT`
2. `DELETE FROM t` in PG (clear failed rows)
3. Re-run migration for that table only
4. Re-verify
