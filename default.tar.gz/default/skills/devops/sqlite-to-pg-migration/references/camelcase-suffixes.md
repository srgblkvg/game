# CamelCase Suffix Registry

Complete list of suffixes handled by the PG camelCase converter. When PG returns lowercase column names (e.g., `totalpvpmoneywon`), these suffixes are capitalized to match the original SQLite camelCase names.

## Full Suffix Regex

```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|number|code|expires|verified)$/i
```

## Pitfall: Single-Letter Suffixes

DO NOT add single letters (`s`, `a`, `d`, `m`) to the generic regex — they match too broadly (e.g., `statpoints` → `statpointS`).

Instead use explicit compound replacements:
```ts
.replace(/^bases$/i, 'baseS')
.replace(/^basea$/i, 'baseA')
.replace(/^based$/i, 'baseD')
.replace(/^basem$/i, 'baseM')
```

## Compound Replacements (Essential)

These handle multi-word column names where the generic suffix regex produces wrong results:

```ts
// Base stats (single-letter suffixes — handled explicitly)
.replace(/^bases$/i, 'baseS')
.replace(/^basea$/i, 'baseA')
.replace(/^based$/i, 'baseD')
.replace(/^basem$/i, 'baseM')

// Stats
.replace(/^statpoints$/i, 'statPoints')
.replace(/^totalbattles$/i, 'totalBattles')
.replace(/^pvetotalbattles$/i, 'pveTotalBattles')
.replace(/^pvewins$/i, 'pveWins')

// PvP money
.replace(/^totalpvpmoneywon$/i, 'totalPvpMoneyWon')
.replace(/^totalpvpmoneylost$/i, 'totalPvpMoneyLost')

// PvE money
.replace(/^totalpvemoneywon$/i, 'totalPveMoneyWon')
.replace(/^totalpvemoneylost$/i, 'totalPveMoneyLost')

// Jobs
.replace(/^totaljobmoney$/i, 'totalJobMoney')
.replace(/^totaljobseconds$/i, 'totalJobSeconds')

// Craft
.replace(/^craftcreated$/i, 'craftCreated')
.replace(/^craftupgraded$/i, 'craftUpgraded')
.replace(/^craftbroken$/i, 'craftBroken')

// Tournament
.replace(/^tournamentcount$/i, 'tournamentCount')
.replace(/^tournamentwins$/i, 'tournamentWins')

// Misc
.replace(/^auctiontrades$/i, 'auctionTrades')
.replace(/^emailverified$/i, 'emailVerified')
.replace(/^emailcode$/i, 'emailCode')
.replace(/^emailcodeexpires$/i, 'emailCodeExpires')
.replace(/^isguest$/i, 'isGuest')
.replace(/^oauthprovider$/i, 'oauthProvider')
.replace(/^oauthid$/i, 'oauthId')
.replace(/^rewardxp$/i, 'rewardXp')
.replace(/^accountnumber$/i, 'accountNumber')
.replace(/^arenatopponentid$/i, 'arenaOpponentId')
```

## Suffixes Added After Initial Migration

These were missed in the first pass and caused silent data loss (columns returned as `undefined`):
- `battles` — `totalBattles`, `pveTotalBattles`
- `money` — `totalPvpMoneyWon`, `totalPveMoneyLost`, `totalJobMoney`, etc.
- `created` — `craftCreated`
- `upgraded` — `craftUpgraded`
- `broken` — `craftBroken`
- `seconds` — `totalJobSeconds`
- `xp` — `rewardXp` (missing caused `exp = exp + NULL` → exp zeroed!)
- `end` — `registrationEnd` (missing caused tournament auto-advance to never trigger)
- `start` — `registrationStart`
- `elo` — `tournamentElo`
- `number` — `accountNumber`
- `code` — `emailCode` (missing caused `user.emailCode === undefined`, compare with code → always `false` → "Неверный код")
- `expires` — `emailCodeExpires` (multi-suffix: JS `.replace()` without `/g` only hits ONE suffix — explicit compound replacement required for `emailcodeexpires` → `emailCodeExpires`)
- `verified` — `emailVerified` (was already handled by explicit `.replace(/^emailverified$/i, 'emailVerified')` but missing from generic suffix regex)

## Debugging Missing Suffixes

When a column returns `undefined` unexpectedly, check the raw PG column name and trace through the camelCase converter:

1. `SELECT column_name FROM information_schema.columns WHERE table_name='users'`
2. For each SQLite column name, lowercase it and check if the suffix regex matches
3. If not, add to the list or add an explicit compound replacement

### Quick Symptom-to-Fix Table

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| "Неверный код" / "Invalid code" despite correct input | `emailcode` → `emailCode` fails (missing `code` suffix) | Add `code` to suffix regex + `.replace(/^emailcode$/i, 'emailCode')` |
| Code expiry check always passes/fails | `emailcodeexpires` → `emailCodeExpires` fails (multi-suffix, `.replace()` without `/g` hits only one) | Add `expires` to suffix regex + `.replace(/^emailcodeexpires$/i, 'emailCodeExpires')` |
| Any `undefined` comparison in auth/account | Any camelCase field after PG migration | Check `camelRows` — grep for the field name, verify suffix is in regex
