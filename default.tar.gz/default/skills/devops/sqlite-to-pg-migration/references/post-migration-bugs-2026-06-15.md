# Post-Migration Bugs — June 15, 2026 (Tournament Deep-Dive)

## `async` without `await` = Promise → NaN

**Bug**: `async function nextPowerOfTwo(n: number): number { let p = 1; while (p < n) p *= 2; return p; }`  
TypeScript added `async`, function now returns `Promise<number>`.  
Code `const slots = nextPowerOfTwo(n)` → slots = `Promise {}`.  
`const half = slots / 2` → `NaN`.  
`for (let i = 0; i < half; i++)` → never executes.  
Bracket never generated → infinite loop in autoAdvance.

**Fix**: Remove `async` from functions with no `await`.

## `SELECT last_insert_rowid()` — SQLite only

SQLite `last_insert_rowid()` doesn't exist in PG.  
**Fix A**: Use `info.lastInsertRowid` from `db.run()` return value (db.run adds `RETURNING id`).  
**Fix B**: Use raw `pool.query('INSERT ... RETURNING id', [...])` → `ins.rows[0].id`.

## `pool.query()` returns `{rows, rowCount}`, NOT array

`const r = await pool.query(...)` → `r.rows[0]`, NOT `r[0]`.  
Accessing `r[0]` gives `undefined` → "Cannot read properties of undefined (reading 'treasury')".

## PG `NOW()` timezone format

`NOW()` returns `"2026-06-15 09:39:56.772895+00"` — `+00` without minutes.  
`new Date("...+00Z")` = Invalid Date (double timezone).  
**Fix**: `safeDate` must normalize: `s.replace(/([+-]\d{2})$/, '$1:00')` → `+00:00`.  
Then check `hasTZ = s.endsWith('Z') || /[+-]\d{2}:\d{2}$/.test(s)`.

## pgLowerIdentifiers regex limitation

`\b([a-z]+[A-Z][a-zA-Z0-9]*)\b` — requires `[a-z]+[A-Z]`.  
`player1Id` → `player` (lowercase) then `1` (digit, not [A-Z]) → NO match.  
PG auto-folds unquoted identifiers to lowercase, so `player1Id` → `player1id` anyway.  
But for safety in data access: `p.userId || p.userid`.

## `ALTER TABLE` permissions

`game` user doesn't own tables (created by migration).  
Use: `sudo -u postgres psql -d game -c "ALTER TABLE ..."` for schema changes.

## Shell escaping for inline SQL

Double-nested quotes (`"...'...'..."`) reliably break in bash.  
**Best practice**: Write script to local file → `scp` to server → `node script.js`.  
Never use inline `-e` with SQL containing single quotes.
