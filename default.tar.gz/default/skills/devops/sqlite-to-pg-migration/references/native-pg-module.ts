// server/src/db/index.ts — Native PG module (battle-tested)
// Copy this file and import { db } from './db/index' in all files.
// Replaces better-sqlite3/pg-promise completely. No wrapper.

import { Pool, PoolClient } from 'pg';

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: parseInt(process.env.PGPORT || '5432'),
  database: process.env.PGDATABASE || 'game',
  user: process.env.PGUSER || 'game',
  password: process.env.PGPASSWORD || 'game123',
  max: 20,
});

function camelRows(rows: any[]): any[] {
  for (const row of rows) {
    // BigInt → Number
    for (const key of Object.keys(row)) {
      if (typeof row[key] === 'string' && /^\d+$/.test(row[key])) {
        const n = parseInt(row[key], 10);
        if (n <= Number.MAX_SAFE_INTEGER) row[key] = n;
      }
    }
    // Null → empty string for JSON/text fields
    const nullFields = ['inventory','equipment','activejob','openprivatetabs','snapshot','log','item_data','bonuses','extra'];
    for (const k of nullFields) { if (row[k] === null) row[k] = ''; }
    if (row.inventory === '' || row.inventory === null) row.inventory = '[]';
    if (row.equipment === '' || row.equipment === null) row.equipment = '{}';

    for (const key of Object.keys(row)) {
      let cc = key.replace(
        /(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance)$/i,
        m => m.charAt(0).toUpperCase() + m.slice(1)
      );
      cc = cc.replace(/attacktime$/i, 'AttackTime')
             .replace(/pveattacktime$/i, 'PveAttackTime')
             .replace(/attacksec$/i, 'AttackSec')
             .replace(/pveattacksec$/i, 'PveAttackSec')
             .replace(/taxrate$/i, 'TaxRate')
             .replace(/verified$/i, 'Verified')
             .replace(/hpupdate$/i, 'HpUpdate');
      if (cc !== key) row[cc] = row[key];
    }
  }
  return rows;
}

function pgParams(sql: string): string {
  let i = 0;
  return sql.replace(/\?/g, () => `$${++i}`);
}

export const db = {
  async query(sql: string, params?: any[]): Promise<any[]> {
    const q = pgParams(sql);
    const r = await pool.query(q, params || []);
    return camelRows(r.rows);
  },
  async one(sql: string, params?: any[]): Promise<any | null> {
    const rows = await db.query(sql, params);
    return rows[0] || null;
  },
  async run(sql: string, params?: any[]): Promise<{ changes: number; lastInsertRowid: number }> {
    const q = pgParams(sql);
    if (/^\s*INSERT\s+/i.test(q)) {
      try {
        const r = await pool.query(q.replace(/;?\s*$/, '') + ' RETURNING id', params || []);
        return { changes: r.rowCount || 0, lastInsertRowid: r.rows[0]?.id || 0 };
      } catch {
        const r = await pool.query(q, params || []);
        return { changes: r.rowCount || 0, lastInsertRowid: 0 };
      }
    }
    const r = await pool.query(q, params || []);
    return { changes: r.rowCount || 0, lastInsertRowid: 0 };
  },
  async raw(sql: string, params?: any[]) {
    return pool.query(sql, params || []);
  },
  async tx<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
    const client = await pool.connect();
    try { await client.query('BEGIN'); const r = await fn(client); await client.query('COMMIT'); return r; }
    catch (e) { await client.query('ROLLBACK'); throw e; }
    finally { client.release(); }
  },
};

export { pool };
