# CamelCase Conversion: Lessons Learned (PG Migration)

These are hard-won patterns from the MMO Arena PG migration. Silent data corruption is the #1 failure mode.

## The Core Problem

PG lowercases ALL unquoted identifiers. `totalPvpMoneyWon` → `totalpvpmoneywon`.
A generic suffix regex only capitalizes the LAST word: `totalpvpmoneyWon`.
But the code reads `user.totalPvpMoneyWon` — mismatch → `undefined`.

## Suffix Regex (current)

```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start)$/i
```

## DO NOT add single-letter suffixes

`s`, `a`, `d`, `m` match too broadly (`statpoints` → `statpointS`, `wins` → `winS`).
Use explicit `^bases$`→`baseS`, `^basea$`→`baseA` instead.

## Explicit Compound Mappings (MUST HAVE)

```
.replace(/^bases$/i, 'baseS').replace(/^basea$/i, 'baseA')
.replace(/^based$/i, 'baseD').replace(/^basem$/i, 'baseM')
.replace(/^statpoints$/i, 'statPoints')
.replace(/^totalbattles$/i, 'totalBattles')
.replace(/^pvetotalbattles$/i, 'pveTotalBattles')
.replace(/^pvewins$/i, 'pveWins')
.replace(/^totalpvpmoneywon$/i, 'totalPvpMoneyWon')
.replace(/^totalpvpmoneylost$/i, 'totalPvpMoneyLost')
.replace(/^totalpvemoneywon$/i, 'totalPveMoneyWon')
.replace(/^totalpvemoneylost$/i, 'totalPveMoneyLost')
.replace(/^totaljobmoney$/i, 'totalJobMoney')
.replace(/^totaljobseconds$/i, 'totalJobSeconds')
.replace(/^craftcreated$/i, 'craftCreated')
.replace(/^craftupgraded$/i, 'craftUpgraded')
.replace(/^craftbroken$/i, 'craftBroken')
.replace(/^tournamentcount$/i, 'tournamentCount')
.replace(/^tournamentwins$/i, 'tournamentWins')
.replace(/^emailverified$/i, 'emailVerified')
.replace(/^isguest$/i, 'isGuest')
.replace(/^oauthprovider$/i, 'oauthProvider')
.replace(/^oauthid$/i, 'oauthId')
.replace(/^rewardxp$/i, 'rewardXp')
```

## BigInt-to-number: ONLY for actual bigints

PG returns `COUNT(*)` as string `"5"`. Converting ALL numeric strings to numbers breaks chat content like `"2"`.

```ts
for (const key of Object.keys(row)) {
  if (typeof row[key] === 'string' && /^\d+$/.test(row[key])) {
    const n = parseInt(row[key], 10);
    // Only convert bigints (>2^31) or known numeric columns
    if (n > 2147483647 || /^(id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round|year|month|day|hour|min|sec|limit|offset|page|rank)$/i.test(key)) {
      row[key] = n;
    }
  }
}
```

## Silent Bug Checklist

When a feature is broken after PG migration, check in order:
1. API response — any `undefined` or `0` values? → missing camelCase suffix
2. EXP reset to 0? → `rewardXp` not converting → `exp + undefined` → NULL
3. Tournament stuck? → `registrationEnd` not converting
4. Stats all zero? → compound column names like `totalPvpMoneyWon` not mapped
5. Chat `.split()` crash? → BigInt converter turned `"2"` into `2`

## Prod Deploy

Client MUST be rebuilt: `cd /opt/game/client && npx vite build`
(Not `npm run build` — that calls tsc which has pre-existing errors)
