// Comprehensive endpoint test script for PG migration verification
// Usage: node test-all-endpoints.js
// Run against PG server on port 3002 (not production 3001)

const http = require("http");

function req(method, path, token, data) {
  return new Promise((resolve) => {
    const opts = { hostname: "127.0.0.1", port: 3002, path, method, headers: { "Content-Type": "application/json" } };
    if (token) opts.headers["Authorization"] = "Bearer " + token;
    const r = http.request(opts, (res) => {
      let body = "";
      res.on("data", (c) => body += c);
      res.on("end", () => {
        try { resolve({ code: res.statusCode, data: JSON.parse(body) }); }
        catch { resolve({ code: res.statusCode, error: body.substring(0, 40) }); }
      });
    });
    r.on("error", (e) => resolve({ code: 0, error: e.message }));
    if (data) r.write(JSON.stringify(data));
    r.end();
  });
}

async function test(desc, method, path, token, data, checkFn) {
  const r = await req(method, path, token, data);
  const ok = checkFn ? checkFn(r) : r.code < 500 && !r.error;
  console.log((ok ? "PASS" : "FAIL"), desc, `[${r.code}]`, r.error || (r.data && JSON.stringify(r.data).substring(0, 50)) || "");
  return ok;
}

async function main() {
  // Login
  const login = await req("POST", "/api/login", null, { username: "_test_", password: "test123" });
  const token = login.data?.token;
  console.log("Login:", token ? "OK" : "FAIL");
  if (!token) { console.log("Cannot continue without token"); return; }

  let pass = 0, fail = 0;
  const t = async (d, m, p, ck) => { if (await test(d, m, p, token, null, ck)) pass++; else fail++; };

  await t("time", "GET", "/api/time");
  await t("floors", "GET", "/api/floors");
  await t("actions", "GET", "/api/actions");
  await t("character/me", "GET", "/api/character/me", null, r => r.data?.username === "_test_");
  await t("rating", "GET", "/api/rating?page=1&limit=5");
  await t("battles", "GET", "/api/battles?limit=1");
  await t("tournament", "GET", "/api/tournament");
  await t("guild/list", "GET", "/api/guild/list");
  await t("chat/recent", "GET", "/api/chat/recent?limit=5");
  await t("tavern/quests", "GET", "/api/tavern/quests");
  await t("jobs", "GET", "/api/jobs");
  await t("collections", "GET", "/api/collections");
  await t("craft", "GET", "/api/craft/recipes");
  await t("bank", "GET", "/api/bank");

  console.log(`\n${pass} passed, ${fail} failed, ${pass + fail} total`);
}

main().catch(console.error);
