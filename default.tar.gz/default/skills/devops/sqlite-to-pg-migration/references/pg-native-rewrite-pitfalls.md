# PG Native Rewrite — Additional Pitfalls (2026-06-14)

These pitfalls were discovered during a full native PG rewrite of a 42-table MMO game project.
Unlike the wrapper approach, the native rewrite changes every file but is more robust long-term.

## camelCase Converter — Missing Suffixes

Problem: PG lowercases all unquoted identifiers. The suffix-based camelCase converter needs to know every possible suffix. Missing suffixes cause `undefined` field reads, breaking logic silently.

**Fixed suffixes added:**
- `max`, `min` → `rewardMax`, `rewardMin` (jobs rewards returned null)
- `job` → `activeJob` (jobs completed instantly because activeJob was undefined)
- `order`, `image`, `chance` → `sortOrder`, `bgImage`, `successChance`
- `hpupdate` → `lastHpUpdate` (HP regen never triggered)
- `bases/basea/based/basem` → `baseS/baseA/baseD/baseM` (stats showed 5-5-5-5)
- `statpoints` → `statPoints`

**Rule**: After schema migration, grep for ALL column names in the old codebase and verify each one appears in the suffix list or has a targeted replacement.

## BigInt Converter — Too Aggressive

PG returns bigint (COUNT/SUM) as strings. Adding a blanket `parseInt()` on all numeric-looking strings converts chat message content like `"2"` to number `2`, breaking `"2".split(...)`.

**Fix**: Only convert strings that represent bigints (> 2^31) OR belong to known numeric columns:
```ts
if (n > 2147483647 || /^(id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance)$/i.test(key)) {
  row[key] = n;
}
```

## TIMESTAMPTZ → TEXT

The codebase passes both epoch integers (`Math.floor(Date.now()/1000)`) and ISO strings (`new Date().toISOString()`) to date columns. PG TIMESTAMPTZ rejects epoch integers with `date/time field value out of range`.

**Fix**: Use TEXT for ALL date columns:
```sql
ALTER TABLE users ALTER COLUMN lastloginat TYPE TEXT;
ALTER TABLE tournaments ALTER COLUMN createdat TYPE TEXT;
-- etc.
```

## SQLite datetime() Function

Code uses `datetime(?)` wrapper. PG has no `datetime()`. Remove the wrapper — pass the value directly.

For `datetime('now', '-5 minutes')`, compute in JS:
```ts
const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
```

## `createdat NOT NULL` Without Default

Schema migration may leave `createdat TEXT NOT NULL` with no DEFAULT. Inserts omitting `createdat` fail.

**Fix**: `ALTER TABLE feedback_messages ALTER COLUMN createdat DROP NOT NULL;`

## `.map(async)` Without `Promise.all`

Bulk async conversion leaves `.map(async (x) => ({...}))` patterns. These return Promise arrays that serialize as `{}`.

**Detection**: `grep -rn "\.map(async" routes/` — for each:
- If callback has `await` → wrap in `await Promise.all(.map(async ...))`, close with `}));`
- If no `await` → remove `async`

## Missing `await` on Async Function Calls

After removing the `db` parameter from helper functions, call sites must be updated. Additionally, some async functions were called without `await` in the original code.

**Functions affected**:
- `loadPlayerForBattle` (2 call sites) → tournament crash
- `resolveCurrentRound` (2 call sites) → tournament hang
- `isGuildAtWar` (8 call sites) → guild null.name crash
- `addPveRating` (1 call site) → PvE 500 error

## Client Rebuild Required

After server-side fixes, the client JS bundle must be rebuilt. Old cached bundles cause errors that look server-side. Use `npx vite build` (skips TS checking).
