# Date Formatting — `+'Z'` cleanup and `safeDate`

## The bug
Client code everywhere had this pattern:
```js
new Date(someTimestamp + 'Z')
```
When the server returns epoch NUMBERS, `1780740117 + 'Z'` = `"1780740117Z"` → `Invalid Date`.

## Solution: `safeDate` + `fmtSafeDate` helpers
Created `client/src/utils/date.ts`:

```ts
export function safeDate(value: any): Date | null {
    if (value == null) return null;
    if (typeof value === 'number') return new Date(value * 1000);
    if (typeof value === 'string') {
        if (/^\d+$/.test(value)) return new Date(Number(value) * 1000);
        return new Date(value.replace(' ', 'T') + 'Z');
    }
    return null;
}

export function fmtSafeDate(value: any, options?: Intl.DateTimeFormatOptions): string {
    const d = safeDate(value);
    return d ? d.toLocaleString('ru-RU', options) : '—';
}
```

## Usage replaces `+'Z'` pattern
```jsx
// OLD (broken):
{new Date(m.createdAt + 'Z').toLocaleString(...)}

// NEW (safe):
{fmtSafeDate(m.createdAt, { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' })}
```

## Affected files (all fixed)
- `components/Header.tsx`
- `pages/GuildPage.tsx`
- `pages/GuildViewPage.tsx`
- `pages/GuildWarPage.tsx`
- `pages/ProfilePage.tsx`
- `pages/AdminPanel/AdminFeedback.tsx`
- `pages/BankPage.tsx`

## Server-side date fix pattern
When API returns dates, convert epoch strings to numbers:
```ts
createdAt: typeof t.createdAt === 'string' && /^\d+$/.test(t.createdAt) 
  ? Number(t.createdAt) 
  : Math.floor(new Date(t.createdAt).getTime() / 1000)
```
