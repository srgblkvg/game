# PG Migration Fix Scripts

These scripts convert a better-sqlite3 codebase to async pg-promise.
Run in the project root directory.

## apply-all-fixes.sh

```bash
#!/bin/bash
# Run from project root (e.g. /opt/game)

# 1. Add await to all db.prepare calls (slurp mode catches multi-line)
for f in $(grep -rl "db.prepare(" server/src/routes/ server/src/game/ server/src/db/ server/src/middleware/ server/src/websocket.ts server/src/setupRoutes.ts 2>/dev/null); do
  perl -0777 -i -pe "s/(?<!await )db\.prepare\(/await db.prepare(/g" "$f"
  perl -i -pe "s/await await /await /g" "$f"
done

# 2. Fix module-level awaits (statement objects don't need await)
sed -i '11s/await db.prepare/db.prepare/' server/src/routes/character.ts
sed -i '16s/await db.prepare/db.prepare/' server/src/routes/character.ts

# 3. Make all route handlers async
for f in server/src/routes/*.ts server/src/game/rating.ts server/src/middleware/auth.ts server/src/setupRoutes.ts server/src/websocket.ts; do
  perl -i -pe 's/\(\s*_?req[^,]*,\s*res[^)]*\)\s*=>\s*\{/async (req, res) => {/g' "$f" 2>/dev/null
  perl -i -pe 's/\(\s*_?req[^,]*,\s*res[^,]*,\s*next[^)]*\)\s*=>\s*\{/async (req, res, next) => {/g' "$f" 2>/dev/null
done

# 4. Make websocket callbacks async
sed -i "s/wss.on('connection', (ws:/wss.on('connection', async (ws:/" server/src/websocket.ts
sed -i "s/ws.on('message', (raw)/ws.on('message', async (raw)/" server/src/websocket.ts

# 5. Make all functions with await async
for f in $(grep -rl "await db\." server/src/ --include="*.ts" 2>/dev/null); do
  sed -i 's/^function /async function /g' "$f"
  sed -i 's/^export function /export async function /g' "$f"
done

# 6. Fix transaction callbacks
for f in server/src/routes/bank.ts server/src/routes/guild.ts; do
  sed -i 's/\.transaction(() =>/.transaction(async () =>/g' "$f"
  sed -i 's/db.transaction(() =>/db.transaction(async () =>/g' "$f"
done

# 7. Fix map callbacks - remove async (they don't need it unless they have await)
for f in $(grep -rl "\.map(async" server/src/ --include="*.ts" 2>/dev/null); do
  perl -i -pe 's/\.map\(\s*async\s*\(/.map((/g' "$f"
done

# 8. Re-add async for map callbacks that DO have await
perl -i -pe 's/completed\.map\(\(t: any\) => \{/completed.map(async (t: any) => {/' server/src/routes/tournament.ts
perl -i -pe 's/allTournaments\.map\(\(t: any\) => \{/allTournaments.map(async (t: any) => {/' server/src/routes/tournament.ts
perl -i -pe 's/matches\.map\(\(m: any\) => \(\{/matches.map(async (m: any) => ({/' server/src/routes/tournament.ts

# 9. Remove async from sync functions
sed -i 's/async function getBaseStats/function getBaseStats/' server/src/db/helpers.ts
sed -i 's/async function getMaxHp/function getMaxHp/' server/src/db/helpers.ts
sed -i 's/async function recalcHpOnEquip/function recalcHpOnEquip/' server/src/db/helpers.ts
sed -i 's/async function expForLevel/function expForLevel/' server/src/db/helpers.ts
sed -i 's/async function isGuestRestrictionsDisabled/function isGuestRestrictionsDisabled/' server/src/middleware/auth.ts
sed -i 's/async function setGuestRestrictionsDisabled/function setGuestRestrictionsDisabled/' server/src/middleware/auth.ts
sed -i 's/async function toggleGuestRestrictions/function toggleGuestRestrictions/' server/src/middleware/auth.ts

# 10. Fix double asyncs globally
find server/src -name "*.ts" -exec sed -i 's/async async /async /g' {} +
find server/src -name "*.ts" -exec sed -i 's/export async async /export async /g' {} +
```

## fix-all-maps.py

After running apply-all-fixes.sh, run this to restore `async` on `.map()` callbacks that genuinely need `await`:

```python
import re, glob

for fp in glob.glob('/opt/game/server/src/**/*.ts', recursive=True):
    with open(fp) as f: content = f.read()
    if '.map(' not in content: continue
    old = content
    
    lines = content.split('\n')
    
    for i, line in enumerate(lines):
        m = re.match(r'^(\s*)(.*?)\.map\(\s*\(([^)]+)\)\s*=>\s*[\{\(]', line)
        if not m: continue
        if 'async' in line: continue
        
        depth = 1 if '{' in line else 0
        has_await = False
        j = i + 1
        while j < len(lines) and depth > 0:
            if 'await db.' in lines[j] or 'await get' in lines[j]:
                has_await = True
                break
            depth += lines[j].count('{') - lines[j].count('}')
            if depth == 0 and '};' in lines[j]:
                break
            j += 1
        
        if has_await:
            lines[i] = m.group(1) + m.group(2) + '.map(async (' + m.group(3) + ') => ' + line[line.index('=>')+2:].lstrip()
    
    new_content = '\n'.join(lines)
    if new_content != old:
        with open(fp, 'w') as f: f.write(new_content)
        print(fp.split('/')[-1])
print('Done')
```

## Manual fixes after scripts

After running both scripts, apply these manual fixes:

```bash
# character.ts - async helper calls need await at call sites
perl -i -pe "s/const user = getUserById/const user = await getUserById/" server/src/routes/character.ts
perl -i -pe "s/enrichEquipment(db, equipment)/await enrichEquipment(db, equipment)/" server/src/routes/character.ts
perl -i -pe "s/getBaseStats(user)/await getBaseStats(user)/" server/src/routes/character.ts

# auction.ts - JSON.parse fallback
perl -i -pe "s/JSON.parse\(l\.itemData\)/JSON.parse(l.itemData || '{}')/" server/src/routes/auction.ts

# auth.ts - login_logs try/catch (line numbers may vary)
sed -i '138s/await db.prepare.*INSERT INTO login_logs.*run/try { &/ } catch {} /' server/src/routes/auth.ts
```
