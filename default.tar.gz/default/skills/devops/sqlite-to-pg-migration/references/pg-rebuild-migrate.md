# PG Rebuild & Migrate Sequence

Clean PG setup from scratch. Run with server STOPPED.

## Drop & recreate

```bash
pm2 stop game-server

# Drop all tables
node -e "
const{Pool}=require('pg');
const p=new Pool({database:'game',user:'game',password:'game123'});
async function f(){
  const tables=['battles','chat_messages','guilds',...]; // all tables!
  for(const t of tables){await p.query('DROP TABLE IF EXISTS '+t+' CASCADE')}
  await p.end()
}f()"
```

## Rebuild schema

```bash
cd /opt/game/server
PGHOST=localhost npx tsx src/database/rebuild-pg.ts
```

## Add missing columns

Compare SQLite `PRAGMA table_info` against PG `information_schema.columns`:

```bash
node fix-all-cols.js   # Adds columns present in SQLite but missing from PG
node add-more-cols.js  # Adds columns missed by fix-all-cols (mob drops, etc.)
```

See `references/add-missing-cols.js` for the column discovery script.

## Migrate data

```bash
npx tsx src/database/migrate-pg.ts
node insert-admin.js    # Admin with correct password hash from SQLite
node fix-all-passwords.js  # Copy all user password hashes
```

## Verify counts

```bash
node -e "
const{Pool}=require('pg');
const p=new Pool({database:'game',user:'game',password:'game123'});
async function f(){
  const tables=['users','admins','battles','chat_messages','guilds','tournaments','daily_quests'];
  for(const t of tables){
    const r=await p.query('SELECT count(*) as c FROM '+t);
    console.log(t+':',r.rows[0].c)
  }
  await p.end()
}f()"
```

## Critical column types

After migration, convert TEXT timestamp columns to INTEGER:

```bash
node -e "
const{Pool}=require('pg');
const p=new Pool({database:'game',user:'game',password:'game123'});
async function f(){
  const cols=await p.query(\"
    SELECT table_name,column_name FROM information_schema.columns 
    WHERE table_schema='public' AND data_type='text'
    AND (column_name LIKE '%at' OR column_name LIKE '%until' OR column_name LIKE '%time'
      OR column_name LIKE '%end' OR column_name LIKE '%start' OR column_name LIKE '%expires'
      OR column_name LIKE '%count' OR column_name LIKE '%seconds' OR column_name LIKE '%wins'
      OR column_name LIKE '%losses' OR column_name LIKE '%money' OR column_name LIKE '%battles'
      OR column_name LIKE '%level' OR column_name LIKE '%id' OR column_name LIKE '%amount'
      OR column_name LIKE '%price' OR column_name LIKE '%cost' OR column_name LIKE '%fee'
      OR column_name LIKE '%reward' OR column_name LIKE '%xp' OR column_name LIKE '%gained'
      OR column_name LIKE '%required' OR column_name LIKE '%limit')
  \");
  for(const c of cols.rows){
    try{
      await p.query('ALTER TABLE '+c.table_name+' ALTER COLUMN '+c.column_name+' TYPE INTEGER USING '+c.column_name+'::INTEGER');
      console.log('OK:',c.table_name+'.'+c.column_name);
    }catch(e){}
  }
  await p.end()
}f()"
```

## Start server

```bash
pm2 start game-server
sleep 4 && curl -sL https://mmoarena.ru/api/time
```

## Common mistakes

- **Don't convert all TEXT to INTEGER** — the script above targets only timestamp/count columns. Converting `username`, `guildname`, `emailcode`, `activedrink` to INTEGER destroys data.
- **Run migration with server stopped** — PM2 auto-restart during DROP/CREATE creates empty tables.
- **PGHOST=localhost** — the rebuild script hardcodes the external IP; override with env var.
