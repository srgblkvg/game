# PG-npm native migration: real-world pitfalls (June 2026 session)

This reference captures every non-obvious bug that manifested during a full SQLite→PG migration
of a game server (React+Express, 42 tables, 39 route files). Many of these took hours to diagnose.

## CamelCase Converter — THE #1 bug source

**Pattern**: PG lowercases all identifiers. Our converter rebuilds camelCase by matching suffixes.
Every `undefined` value in route code is a camelCase bug until proven otherwise.

### Missing suffixes that caused real bugs:
| Suffix | Column | Bug |
|--------|--------|-----|
| `s`, `a`, `d`, `m` | `bases`, `basea`, `based`, `basem` | Stats showed 5-5-5-5 instead of real values |
| `xp` | `rewardxp` | `exp = exp + undefined` → exp wiped to NULL |
| `end`, `start` | `registrationend` | Tournament never auto-advances |
| `elo` | `tournamentelo` | Tournament seeding broken |
| `job` | `activejob` | Jobs immediate kick to main page |
| `battles` | `totalbattles` | Profile stats missing |
| `number` | `accountnumber` | Bank account number not showing |
| `money` | `totaljobmoney` | Job earnings not showing |
| `created/upgraded/broken/seconds` | craft/job stats | Profile stats empty |

### Compound name bug
The suffix converter only capitalizes the LAST suffix. So `totalpvpmoneywon` becomes
`totalpvpmoneyWon` not `totalPvpMoneyWon`. Solution: explicit `.replace()` mappings for
ALL compound column names.

### Debugging approach
1. Check DB directly: `SELECT column_name FROM information_schema.columns WHERE table_name='...'`
2. Compare PG lowercase name vs what code expects
3. If suffix missing → add to regex AND add explicit mapping

## Date Handling — The `+'Z'` pattern is ALWAYS wrong

### Rule
- **Server**: convert ALL timestamps to epoch NUMBER before sending to client
- **Client**: use `new Date(epochSeconds * 1000)`. NEVER `new Date(str + 'Z')`.

### Cases that fail
- `"1781344545" + "Z"` → `"1781344545Z"` → Invalid Date (epoch string + Z)
- `"2026-06-13T09:25:45Z" + "Z"` → `"2026-06-13T09:25:45ZZ"` → Invalid Date
- Server sends epoch string, client does `* 1000` implicitly → `"1781344545" * 1000` → works (JS coercion), but fragile

### Server-side conversion pattern
```ts
createdAt: typeof row.createdAt === 'string' && /^\d+$/.test(row.createdAt)
  ? Number(row.createdAt)
  : (row.createdAt ? Math.floor(new Date(row.createdAt).getTime() / 1000) : row.createdAt)
```

## Missing `await` — Silent failures (no error, just wrong data)

### Specific bugs
- `isGuildAtWar()` called 8× without await → war info was Promise, not data → `null.name` crash
- `getOrCreateTournament()` without await → returns Promise → empty tournament list
- `generateBracket()` without await → 0 matches → tournament stuck in `in_progress`
- `loadPlayerForBattle()` without await → tournament battles corrupted

### Audit command
```bash
grep -rn 'async function' server/src/ | while read line; do
  name=$(echo "$line" | sed 's/.*function //;s/(.*//')
  grep -rn "$name(" server/src/routes/ | grep -v "await $name" | grep -v "async function"
done
```

## PG-Specific SQL Incompatibilities
- `MAX(a, b)` → `GREATEST(a, b)` (scalar max, not aggregate)
- `last_insert_rowid()` → does not exist → use `db.run` result `.lastInsertRowid` which uses `RETURNING id`
- `INSERT OR REPLACE` → `INSERT ... ON CONFLICT (id) DO UPDATE SET ...`
- `datetime('now')` → `NOW()` in PG or `new Date().toISOString()` in JS
- `CAST(createdAt AS BIGINT)` fails if column has ISO strings → check with regex first

## BigInt conversion — Too aggressive
Converting ALL numeric strings to numbers breaks text content.
- Chat message `"2"` became number `2` → `2.split()` → TypeError
- Fix: only convert if column name suggests numeric type OR value > 2^31

## Production migration checklist
1. Backup SQLite: `cp game.db game_backup_$(date +%Y%m%d_%H%M).db`
2. Git tag: `git tag backup-sqlite-$(date +%Y%m%d-%H%M)`
3. Push code branch, pull on VPS
4. Drop PG schema, recreate from schema.sql
5. Fix TEXT vs TIMESTAMPTZ: `ALTER TABLE ... ALTER COLUMN ... TYPE TEXT`
6. Run migration script (auto-maps camelCase→lowercase columns)
7. Reset sequences: `SELECT setval('...', COALESCE((SELECT MAX(id) FROM "..."), 1))`
8. Switch PM2 to new code
9. Verify: `SELECT count(*) FROM each_table` match SQLite counts
