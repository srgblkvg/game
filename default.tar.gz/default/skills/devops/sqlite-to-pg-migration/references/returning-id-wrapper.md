# Patching the PG wrapper's `run()` for RETURNING id

## Final approach: auto-detect INSERT and add RETURNING id

Instead of modifying 12+ route files individually, patch the wrapper's `run()` method:

```ts
// database/index.ts — in both the main prepare() and transaction prepare()
run: (...params: any[]) => {
    const isInsert = /^\s*INSERT\s+/i.test(q);  // q = converted SQL ($1,$2...)
    if (isInsert) {
        const returningQ = q.replace(/;?\s*$/, '') + ' RETURNING id';
        return (rawDb as any).one(returningQ, params)
            .then((r: any) => ({ changes: 1, lastInsertRowid: r.id }));
    }
    return rawDb.result(q, params)
        .then((r: any) => ({ changes: r.rowCount, lastInsertRowid: 0 }));
},
```

**Transaction variant** — identical pattern with `t.one()` instead of `rawDb.one()`:

```ts
// inside transaction's prepare() return object
run: (...params: any[]) => {
    const isInsert = /^\s*INSERT\s+/i.test(q);
    if (isInsert) {
        const returningQ = q.replace(/;?\s*$/, '') + ' RETURNING id';
        return t.one(returningQ, params)
            .then((r: any) => ({ changes: 1, lastInsertRowid: r.id }));
    }
    return t.result(q, params)
        .then((r: any) => ({ changes: r.rowCount, lastInsertRowid: 0 }));
},
```

**Important**: This approach requires that ALL tables have an `id` column with a sequence (SERIAL or `nextval()` default). Without it, `RETURNING id` will return the DEFAULT value (0 or next sequence value). Run Pitfall 55's sequence fix before enabling this.

**Files affected** (no longer need individual fixes):
- `websocket.ts` — 4 INSERT + lastInsertRowid
- `guild.ts` — 5 INSERT + lastInsertRowid
- `oauth.ts` — 1 INSERT + lastInsertRowid
- `adminChat.ts` — 1 INSERT + lastInsertRowid
- `adminCollections.ts` — 1 INSERT + lastInsertRowid
- `adminCraft.ts` — 1 INSERT + lastInsertRowid
- `tournament.ts` — 2 INSERT + lastInsertRowid
- `orders.ts` — 2 INSERT + lastInsertRowid
