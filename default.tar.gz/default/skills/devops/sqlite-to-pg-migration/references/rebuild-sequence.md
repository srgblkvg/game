# PG Rebuild Sequence (what actually works)

This is the proven sequence from the production migration of mmoarena.ru.

## Prerequisites
- PG installed and running on VPS
- Database `game` with user `game`/`game123` created
- `pg-promise` installed in server/node_modules

## Step 1: Stop the server
```bash
pm2 stop game-server
```

## Step 2: Drop ALL existing PG tables
```bash
node -e "
const{Pool}=require('pg');const p=new Pool({database:'game',user:'game',password:'game123'});
async function f(){
const tables=['battles','chat_messages','guilds','guild_members','guild_invites','guild_wars','guild_treasury_log','tournaments','tournament_participants','tournament_matches','daily_quests','quest_history','job_history','login_logs','feedback_messages','seasons','hall_of_fame','collections','collection_sets','collection_set_items','craft_recipes','craft_recipe_ingredients','shop_items','mobs','mob_drops','floors','jobs','drinks','items','craft_items','rarities','users','admins'];
for(const t of tables){await p.query('DROP TABLE IF EXISTS '+t+' CASCADE')}await p.end()}f()
"
```

## Step 3: Rebuild schema
```bash
PGHOST=localhost npx tsx src/database/rebuild-pg.ts
```

## Step 4: Add missing columns (compare with SQLite)
```bash
node scripts/fix-all-cols.js
```

## Step 5: Migrate data
```bash
npx tsx src/database/migrate-pg.ts
```

## Step 6: Fix passwords and OAuth fields
```bash
node scripts/fix-passwords.js
```

## Step 7: Convert timestamps from TEXT to INTEGER
```bash
node -e "
const{Pool}=require('pg');const p=new Pool({database:'game',user:'game',password:'game123'});
async function f(){
const cols=await p.query(\"SELECT table_name,column_name FROM information_schema.columns WHERE table_schema='public' AND data_type='text' AND (column_name LIKE '%at' OR column_name LIKE '%until' OR column_name LIKE '%time' OR column_name LIKE '%end' OR column_name LIKE '%start')\");
for(const c of cols.rows){
try{await p.query('ALTER TABLE '+c.table_name+' ALTER COLUMN '+c.column_name+' TYPE INTEGER USING '+c.column_name+'::INTEGER');console.log('CONVERTED:',c.table_name+'.'+c.column_name)}catch(e){}
}await p.end()}f()
"
```

## Step 8: Bulk async conversion of route files
```bash
cd server/src
# Add await before db.prepare
for f in $(grep -rl "db.prepare" routes/ game/ middleware/ db/ websocket.ts setupRoutes.ts); do
  perl -i -pe "s/(?<!await )db\.prepare\(/await db.prepare(/g" "$f"
  perl -i -pe "s/await await /await /g" "$f"
done
# Make handlers async
for f in routes/*.ts game/*.ts middleware/*.ts db/*.ts websocket.ts setupRoutes.ts; do
  [ ! -f "$f" ] && continue
  perl -i -pe "s/\(\s*(req|_req)(:\s*\w+)?\s*,\s*res(:\s*\w+)?\s*\)\s*=>\s*\{/async (req, res) => {/g" "$f"
  perl -i -pe "s/async async /async /g" "$f"
done
# Map, transaction, WS callbacks
for f in routes/*.ts websocket.ts game/*.ts; do
  [ ! -f "$f" ] && continue
  perl -i -pe "s/\.map\(\s*\((\w+)(:\s*\w+)?\)\s*=>\s*\{/.map(async (\1) => {/g" "$f"
  perl -i -pe "s/\.map\(\s*\((\w+)(:\s*\w+)?\)\s*=>\s*\(/.map(async (\1) => (/g" "$f"
  perl -i -pe "s/\.transaction\(\s*\(\)\s*=>\s*\{/.transaction(async () => {/g" "$f"
  perl -i -pe "s/async async /async /g" "$f"
done
# Functions with await
for f in $(grep -rl "await db\." routes/ game/ middleware/ db/ websocket.ts setupRoutes.ts); do
  perl -i -pe "s/^(export )?function (\w+)/\1async function \2/g" "$f"
  perl -i -pe "s/async async /async /g" "$f"
done
# WebSocket manual fix
sed -i 's/wss.on(.connection., (ws: WebSocket, req) =>/wss.on("connection", async (ws: WebSocket, req) =>/' websocket.ts
sed -i 's/ws.on(.message., (raw) =>/ws.on("message", async (raw) =>/' websocket.ts
```

## Step 9: Fix async contamination
```bash
# Remove async from sync helpers
sed -i "s/async function getBaseStats/function getBaseStats/" db/helpers.ts
sed -i "s/async function getMaxHp/function getMaxHp/" db/helpers.ts
sed -i "s/async function recalcHpOnEquip/function recalcHpOnEquip/" db/helpers.ts
sed -i "s/async function calcElo/function calcElo/" game/rating.ts
sed -i "s/async function generateCode/function generateCode/" routes/auth.ts

# Add await at applyHpRegen call site
sed -i "s/let currentHp = applyHpRegen/let currentHp = await applyHpRegen/" routes/character.ts
```

## Step 10: Fix OAuth function calls
```bash
sed -i "s/const user = findOrCreateUser/const user = await findOrCreateUser/g" routes/oauth.ts
sed -i "s/const jwtToken = makeToken/const jwtToken = await makeToken/g" routes/oauth.ts
```

## Step 11: Compile check & test
```bash
PORT=3002 npx tsx server/src/index.ts  # should compile clean, start on 3002
# Test endpoints manually on port 3002
```

## Step 12: Switch production
```bash
pm2 start game-server  # on the PG branch
# Verify: curl -sL https://mmoarena.ru/api/time
```
