# PG Native Rewrite — Key Learnings

Summarized from the full native-PG rewrite session (pg-native branch, June 2026).

## CamelCase Suffix List (CRITICAL)

PG lowercases all unquoted identifiers. The suffix-based converter MUST cover ALL compound column names.

**Complete suffix regex:**
```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance)$/i
```

**Compound corrections (applied after suffixes):**
```
attacktime → AttackTime
pveattacktime → PveAttackTime
attacksec → AttackSec / pveattacksec → PveAttackSec
taxrate → TaxRate
verified → Verified
hpupdate → HpUpdate
```

**How to find missing suffixes:** If a field is `undefined` in API but exists in DB:
1. `SELECT column_name FROM information_schema.columns WHERE table_name='X'`
2. Find the last word in the column name
3. If not in regex → add it
4. If compound (e.g. `hpupdate`) → add explicit correction

**Bugs caused by missing suffixes:**
- `max|min` missing → `rewardMax` undefined → jobs broken
- `job` missing → `activeJob` undefined → jobs didn't save
- `order` missing → `sortOrder` undefined
- `image` missing → `bgImage` undefined
- `chance` missing → `successChance` undefined
- `hpupdate` treated as one word → `lastHpUpdate` undefined → HP regen broken

## BigInt → Number Conversion

PG `COUNT(*)` returns bigint → node-postgres returns STRING. `"0" === 0` is false.

**Fix:** Convert all numeric strings to numbers in camelRows BEFORE suffix matching:
```ts
for (const key of Object.keys(row)) {
  if (typeof row[key] === 'string' && /^\d+$/.test(row[key])) {
    const n = parseInt(row[key], 10);
    if (n <= Number.MAX_SAFE_INTEGER) row[key] = n;
  }
}
```

## Column Types: All Dates = TEXT

SQLite is dynamically typed. Code passes BOTH epoch ints AND ISO strings to date columns. PG needs explicit types.

**Rule: ALL date columns → TEXT.** This matches SQLite's TEXT affinity.
- `createdAt`, `joinedAt`, `startedAt`, `finishedAt`, `completedAt`, `declaredAt`, `acceptedAt`, `expiresAt`, `endedAt`
- `users.lastLoginAt`, `users.createdAt`
- `feedback_messages.createdAt`, `seasons.startDate/endDate`, `daily_quests.date`

**Error signals:**
- `date/time field value out of range: "1781416223"` → column is TIMESTAMPTZ, code sends epoch int
- `invalid input syntax for type integer: "2026-06-13T..."` → column is INTEGER, code sends ISO string

## SQLite Functions to Replace

| SQLite | PG |
|--------|-----|
| `datetime(?)` | Just pass the ISO string: `?` |
| `datetime('now', '-5 minutes')` | `new Date(Date.now() - 5*60*1000).toISOString()` |
| `INSERT OR REPLACE` | `INSERT ... ON CONFLICT (pk) DO UPDATE SET ...` |
| `last_insert_rowid()` | `RETURNING id` in INSERT |

## Missing `await` on Async Functions

The pg-promise→native rewrite made ALL route handlers async. But MANY internal function calls were NOT updated with `await`. Always grep for these:

```bash
grep -rn "loadPlayerForBattle\|resolveCurrentRound\|isGuildAtWar\|addPveRating\|applyDecay\|checkSeasonReset\|enrichEquipment\|getUserById" routes/ | grep -v "async function\|await "
```

## .map(async) Without Promise.all

Bulk async conversion makes `.map()` callbacks async. If the result is used in `res.json()`, Promises serialize as `{}`. Two cases:

**Case A: Callback HAS `await`** → wrap in `await Promise.all(.map(async ...))`
**Case B: Callback has NO `await`** → remove `async` from callback

Detection: `grep -rn "\.map(async" routes/` — for each, check if body has `await`.

## Production Deploy Checklist

1. Backup: `cp game.db /opt/game_backup_pre_pg_DATE.db` + `git tag backup-sqlite-DATE`
2. Push branch + pull on VPS: `git fetch && git stash && git checkout pg-native`
3. Recreate PG: `DROP SCHEMA public CASCADE; CREATE SCHEMA public;`
4. Apply schema.sql + fix date cols to TEXT + grant permissions
5. Migrate: `node migrate_prod.js` (reads SQLite via better-sqlite3, writes PG)
6. Reset sequences: `SELECT setval(...)` for all
7. Start: `pm2 delete game-server; cd /opt/game && pm2 start 'PORT=3001 npx tsx server/src/index.ts' --name game-server`
8. Verify: `curl https://mmoarena.ru/api/time`
