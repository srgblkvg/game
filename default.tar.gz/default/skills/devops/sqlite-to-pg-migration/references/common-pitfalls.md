# Common PG Migration Pitfalls

## 1. Missing `await` on Async Functions

**Symptom:** Function returns a Promise instead of the expected value. Comparisons fail silently (`if (war)` is always true for a Promise).

**Pattern:** When converting from synchronous SQLite to async PG, every function that calls the DB becomes async. Any caller that doesn't `await` it will get a Promise, not the data.

**Checklist after migration:**
- `grep -n "isGuildAtWar(" *.ts` → all should have `await`
- `grep -n "autoAdvance(" *.ts` → all should have `await`
- `grep -n "generateBracket(" *.ts` → all should have `await`
- `grep -n "getOrCreateTournament(" *.ts` → should have `await`

## 2. `.map(async ...)` without `Promise.all`

**Symptom:** Array of empty objects, unresolved promises.

**Broken:**
```ts
const result = items.map(async (item) => {
  return { ...item, extra: await getExtra(item.id) };
});
// result is [Promise, Promise, ...] — empty objects when read
```

**Fixed:**
```ts
const result = await Promise.all(items.map(async (item) => {
  return { ...item, extra: await getExtra(item.id) };
}));
```

## 3. NOT NULL Constraints in PG Schema

**Symptom:** `error: null value in column "X" violates not-null constraint`

SQLite doesn't enforce NOT NULL by default. PG does. Check every INSERT/UPDATE for:
- `declaredAt` in `guild_wars`
- `createdAt`/`completedAt` in `tournaments`
- Any `TEXT NOT NULL` column without a DEFAULT

## 4. SQL Function Differences

| SQLite | PostgreSQL |
|--------|-----------|
| `MAX(a, b)` | `GREATEST(a, b)` |
| `datetime('now')` | `NOW()` or `new Date().toISOString()` in code |
| `last_insert_rowid()` | `RETURNING id` in INSERT, or capture from `db.run()` return |
| `INSERT OR REPLACE` | `INSERT ... ON CONFLICT (id) DO UPDATE SET ...` |

## 5. Date Handling

**Symptom:** `Invalid Date` everywhere in the client.

**Root cause:** PG returns dates in multiple formats depending on the column type:
- `TIMESTAMPTZ` → ISO string: `"2026-06-14T10:17:56.086Z"`
- `TEXT` (epoch) → string number: `"1781344545"`
- `TEXT` (space-separated) → `"2026-06-14 11:43:48"`

**Client fix:** Use a universal `safeDate()` helper:
```ts
export function safeDate(value: any): Date | null {
    if (value == null) return null;
    if (typeof value === 'number') return new Date(value * 1000);
    if (typeof value === 'string') {
        if (/^\d+$/.test(value)) return new Date(Number(value) * 1000);
        return new Date(value.replace(' ', 'T') + 'Z');
    }
    return null;
}
```

**Anti-pattern to find and fix:** `new Date(x.createdAt + 'Z')` — this worked for SQLite ISO strings but breaks with epoch numbers (`"1781344545Z"` is Invalid Date).

**Server-side fix:** Return epoch numbers for consistency:
```ts
createdAt: typeof t.createdAt === 'string' && /^\d+$/.test(t.createdAt) 
  ? Number(t.createdAt) 
  : (t.createdAt ? Math.floor(new Date(t.createdAt).getTime() / 1000) : 0)
```
