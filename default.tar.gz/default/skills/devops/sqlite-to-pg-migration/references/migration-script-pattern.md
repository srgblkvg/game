# Data Migration Script Pattern (ON CONFLICT DO UPDATE)

The reliable pattern for SQLite→PG data migration. Handles column name mapping (camelCase→lowercase), NULL→0 for specific columns, composite keys, and sequence reset.

```js
const Database = require('better-sqlite3');
const { Pool } = require('pg');
const s = new Database('source.db');
const p = new Pool({ host, port, database, user, password });

async function migrateTable(tn) {
  const sc = s.prepare(`PRAGMA table_info('${tn}')`).all();
  const pgCols = (await p.query(
    `SELECT column_name FROM information_schema.columns WHERE table_name=$1`, [tn]
  )).rows.map(r => r.column_name);
  
  // Map SQLite camelCase → PG lowercase
  const cols = [];
  for (const c of sc) {
    const lower = c.name.toLowerCase();
    if (pgCols.includes(lower)) cols.push({ sqlite: c.name, pg: lower });
  }
  
  const rows = s.prepare(`SELECT * FROM ${tn}`).all();
  const insertCols = cols.map(c => c.pg).join(',');
  const ph = cols.map((_,i) => '$'+(i+1)).join(',');
  
  // ON CONFLICT for tables with 'id' PK, plain INSERT for composite keys
  const isComposite = ['craft_recipe_ingredients','upgrade_chances','guild_members'].includes(tn);
  const updateSet = cols.map(c => `${c.pg}=EXCLUDED.${c.pg}`).join(',');
  const sql = isComposite
    ? `INSERT INTO ${tn} (${insertCols}) VALUES (${ph})`
    : `INSERT INTO ${tn} (${insertCols}) VALUES (${ph}) ON CONFLICT (id) DO UPDATE SET ${updateSet}`;

  // NULL→0 for epoch timestamp columns that should never be NULL
  const nullToZero = ['currentHp','bank','lastHpUpdate','lastAttackTime','lastPveAttackTime',
    'protectionUntil','chatBannedUntil','lockedUntil','roomUntil','drinkUntil',
    'lastEloDecay','bannedUntil','lastPvpTime','lastPveRatingTime','premiumUntil','lastBankVisit'];
  
  for (const row of rows) {
    const vals = cols.map(c => {
      let v = row[c.sqlite];
      if (v === null && nullToZero.includes(c.sqlite)) v = 0;
      return v;
    });
    await p.query(sql, vals);
  }
}

// After all tables migrated, reset sequences:
const seqs = await p.query(
  `SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema='public'`
);
for (const seq of seqs.rows) {
  const tn = seq.sequence_name.replace('_id_seq','');
  await p.query(
    `SELECT setval($1, COALESCE((SELECT MAX(id) FROM "${tn}"), 1))`,
    [seq.sequence_name]
  );
}
```

## Pre-Migration Schema Fixes

Some columns need type changes BEFORE migration because the code sends ISO strings to INTEGER columns:

```sql
ALTER TABLE tournaments ALTER COLUMN createdat TYPE TEXT;
ALTER TABLE tournaments ALTER COLUMN completedat TYPE TEXT;
ALTER TABLE users ALTER COLUMN lastloginat TYPE TEXT;
ALTER TABLE users ALTER COLUMN createdat TYPE TEXT;
```

## Verification
```js
for (const t of tables) {
  const pc = await p.query(`SELECT count(*) FROM "${t.name}"`);
  const sc = s.prepare(`SELECT count(*) FROM "${t.name}"`).get();
  console.log(`${t.name}: PG=${pc.rows[0].cnt} SQLite=${sc.cnt} ${pc.rows[0].cnt == sc.cnt ? '✓' : '✗'}`);
}
```
