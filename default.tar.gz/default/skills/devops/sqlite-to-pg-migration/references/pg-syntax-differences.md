# SQLite → PG Syntax Differences

## Scalar MAX → GREATEST
```sql
-- SQLite (works)
UPDATE users SET elo = MAX(100, elo + ?) WHERE id = ?

-- PG (correct)
UPDATE users SET elo = GREATEST(100, elo + ?) WHERE id = ?
```
`GREATEST(a, b, ...)` returns the largest value. `LEAST()` for minimum.

## last_insert_rowid → RETURNING id
```sql
-- SQLite
INSERT INTO t (col) VALUES (?); SELECT last_insert_rowid() as id

-- PG
INSERT INTO t (col) VALUES (?) RETURNING id
```
The wrapper should capture `RETURNING id` in `db.run()` and expose as `lastInsertRowid`.

## INSERT OR REPLACE → ON CONFLICT
```sql
-- SQLite
INSERT OR REPLACE INTO t (id, col) VALUES (?, ?)

-- PG
INSERT INTO t (id, col) VALUES (?, ?) ON CONFLICT (id) DO UPDATE SET col = EXCLUDED.col
```

## datetime() → manual
SQLite `datetime('now')` → PG `NOW()` or compute in JS: `new Date().toISOString()`

## Composite PRIMARY KEY
PG's `ON CONFLICT` requires all PK columns. For composite keys like `craft_recipe_ingredients(recipe_id, craft_item_id)`, use plain INSERT without ON CONFLICT.

## TIMESTAMPTZ vs TEXT
If the app sends ISO strings (not epoch), use TEXT columns for dates. If the app uses epoch integers, use INTEGER. Mismatch causes:
- `date/time field value out of range` — inserting epoch into TIMESTAMPTZ
- `invalid input syntax for type integer` — inserting ISO into INTEGER
