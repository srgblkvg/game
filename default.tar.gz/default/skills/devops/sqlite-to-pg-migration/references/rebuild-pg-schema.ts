// rebuild-pg.ts — пересоздаёт таблицы в PG с правильными типами
// Запуск: PGHOST=localhost npx tsx src/database/rebuild-pg.ts
// Перед запуском УБЕДИТЬСЯ что сервер остановлен (pm2 stop game-server)

import { Pool } from 'pg';

const pg = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: parseInt(process.env.PGPORT || '5432'),
  database: 'game',
  user: 'game',
  password: 'game123',
});

// Все timestamp колонки → TEXT, числовые → INTEGER, id → SERIAL PRIMARY KEY
// Порядок таблиц важен для FK зависимостей

const SCHEMA = [
  // Базовые справочники
  `CREATE TABLE IF NOT EXISTS rarities (
    id SERIAL PRIMARY KEY, name TEXT, display_name TEXT, color TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS items (
    id SERIAL PRIMARY KEY, name TEXT, slot TEXT, rarity_id INTEGER,
    image TEXT, s INTEGER DEFAULT 0, a INTEGER DEFAULT 0, d INTEGER DEFAULT 0, m INTEGER DEFAULT 0,
    hp INTEGER DEFAULT 0, crit INTEGER DEFAULT 0, dodge INTEGER DEFAULT 0,
    counter INTEGER DEFAULT 0, fullblock INTEGER DEFAULT 0, price INTEGER DEFAULT 0,
    bonuses TEXT, extra TEXT, upgradelevel INTEGER DEFAULT 0, created_at TEXT, cost INTEGER DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS craft_items (
    id SERIAL PRIMARY KEY, name TEXT, type TEXT, rarity_id INTEGER,
    image TEXT, s INTEGER DEFAULT 0, a INTEGER DEFAULT 0, d INTEGER DEFAULT 0,
    m INTEGER DEFAULT 0, hp INTEGER DEFAULT 0, crit INTEGER DEFAULT 0,
    dodge INTEGER DEFAULT 0, counter INTEGER DEFAULT 0, fullblock INTEGER DEFAULT 0,
    price INTEGER DEFAULT 0, description TEXT
  )`,

  // Пользователи и админы
  `CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY, username TEXT NOT NULL UNIQUE, passwordhash TEXT DEFAULT '',
    email TEXT, emailverified INTEGER DEFAULT 0, emailcode TEXT, emailcodeexpires INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1, exp INTEGER DEFAULT 0, money INTEGER DEFAULT 0, bank INTEGER DEFAULT 0,
    totalbattles INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
    bases INTEGER DEFAULT 5, basea INTEGER DEFAULT 5, based INTEGER DEFAULT 5, basem INTEGER DEFAULT 5,
    statpoints INTEGER DEFAULT 0, currenthp INTEGER DEFAULT 50, maxhp INTEGER DEFAULT 50,
    inventoryslots INTEGER DEFAULT 10, inventory TEXT DEFAULT '[]', equipment TEXT DEFAULT '{}',
    activejob TEXT, activedrink TEXT,
    drinkuntil INTEGER DEFAULT 0, roomtype TEXT, roomuntil INTEGER DEFAULT 0,
    premiumuntil INTEGER DEFAULT 0, elo INTEGER DEFAULT 1000,
    seasonwins INTEGER DEFAULT 0, seasonlosses INTEGER DEFAULT 0,
    gender TEXT DEFAULT 'male', isguest INTEGER DEFAULT 0, avatar TEXT,
    guildid INTEGER DEFAULT 0, guildname TEXT,
    -- Важно: INTEGER для epoch секунд, TEXT для ISO дат
    lastloginat INTEGER DEFAULT 0, failedlogins INTEGER DEFAULT 0,
    lockeduntil INTEGER DEFAULT 0, banneduntil INTEGER DEFAULT 0,
    chatbanneduntil INTEGER DEFAULT 0, lastattacktime INTEGER DEFAULT 0,
    lastpveattacktime INTEGER DEFAULT 0, protectionuntil INTEGER DEFAULT 0,
    lastpvptime INTEGER DEFAULT 0, lasthpupdate INTEGER DEFAULT 0,
    lastbankvisit INTEGER DEFAULT 0,
    openprivatetabs TEXT DEFAULT '[]',
    createdat TEXT DEFAULT (now()::TEXT),
    oauthprovider TEXT, oauthid TEXT
  )`,

  `CREATE TABLE IF NOT EXISTS admins (
    id SERIAL PRIMARY KEY, username TEXT NOT NULL UNIQUE,
    passwordhash TEXT NOT NULL, createdat TEXT DEFAULT (now()::TEXT)
  )`,

  // Игровые таблицы
  `CREATE TABLE IF NOT EXISTS battles (
    id SERIAL PRIMARY KEY, attackerid INTEGER, defenderid INTEGER, winnerid INTEGER,
    log TEXT, steps INTEGER DEFAULT 0, attackerhpafter INTEGER, defenderhpafter INTEGER,
    expgained INTEGER DEFAULT 0, moneygained INTEGER DEFAULT 0, moneystolen INTEGER DEFAULT 0,
    type TEXT DEFAULT 'pvp', mobid INTEGER, createdat TEXT DEFAULT (now()::TEXT)
  )`,

  // Чат
  `CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY, senderid INTEGER, targetid INTEGER,
    content TEXT, item_data TEXT, createdat TEXT DEFAULT (now()::TEXT)
  )`,

  // Гильдии
  `CREATE TABLE IF NOT EXISTS guilds (
    id SERIAL PRIMARY KEY, name TEXT, tag TEXT, leaderid INTEGER,
    treasury INTEGER DEFAULT 0, taxrate INTEGER DEFAULT 5, description TEXT,
    level INTEGER DEFAULT 1, jointype TEXT DEFAULT 'open',
    exp INTEGER DEFAULT 0, levelrequired INTEGER DEFAULT 0,
    createdat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS guild_members (
    id SERIAL PRIMARY KEY, guildid INTEGER, userid INTEGER,
    role TEXT DEFAULT 'member', rank TEXT, joinedat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS guild_invites (
    id SERIAL PRIMARY KEY, guildid INTEGER, userid INTEGER, fromuserid INTEGER,
    invitedby INTEGER DEFAULT 0, status TEXT DEFAULT 'pending',
    createdat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS guild_wars (
    id SERIAL PRIMARY KEY, attackerguildid INTEGER, defenderguildid INTEGER,
    status TEXT DEFAULT 'active', attackerscore INTEGER DEFAULT 0, defenderscore INTEGER DEFAULT 0,
    log TEXT, winnerguildid INTEGER DEFAULT 0,
    declaredat TEXT DEFAULT (now()::TEXT), acceptedat TEXT, endedat TEXT,
    expiresat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS guild_treasury_log (
    id SERIAL PRIMARY KEY, guildid INTEGER, userid INTEGER,
    amount INTEGER, type TEXT, createdat TEXT DEFAULT (now()::TEXT)
  )`,

  // Турниры
  `CREATE TABLE IF NOT EXISTS tournaments (
    id SERIAL PRIMARY KEY, division TEXT, status TEXT DEFAULT 'registration',
    prizepool INTEGER DEFAULT 0, type TEXT DEFAULT 'official',
    creatorid INTEGER, entryfee INTEGER DEFAULT 0, name TEXT,
    minlevel INTEGER DEFAULT 1, maxlevel INTEGER DEFAULT 999, basepool INTEGER DEFAULT 0,
    registrationstart TEXT, registrationend TEXT, completedat TEXT,
    createdat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS tournament_participants (
    id SERIAL PRIMARY KEY, tournamentid INTEGER, userid INTEGER,
    goldenticket INTEGER DEFAULT 0, snapshotstats TEXT, seed INTEGER DEFAULT 0,
    joinedat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS tournament_matches (
    id SERIAL PRIMARY KEY, tournamentid INTEGER, player1id INTEGER, player2id INTEGER,
    winnerid INTEGER, round INTEGER DEFAULT 1, log TEXT, completedat TEXT
  )`,

  // Квесты
  `CREATE TABLE IF NOT EXISTS daily_quests (
    id SERIAL PRIMARY KEY, userid INTEGER, questtype TEXT, difficulty TEXT DEFAULT 'normal',
    requirement INTEGER DEFAULT 0, progress INTEGER DEFAULT 0,
    rewardxp INTEGER DEFAULT 0, rewardmoney INTEGER DEFAULT 0,
    status TEXT DEFAULT 'available', snapshot TEXT, date TEXT,
    createdat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS quest_history (
    id SERIAL PRIMARY KEY, userid INTEGER, questtype TEXT, difficulty TEXT,
    typename TEXT, rewardxp INTEGER DEFAULT 0, rewardmoney INTEGER DEFAULT 0,
    createdat TEXT DEFAULT (now()::TEXT), completedat TEXT
  )`,

  // Работы
  `CREATE TABLE IF NOT EXISTS jobs (
    id SERIAL PRIMARY KEY, name TEXT, duration INTEGER DEFAULT 300,
    reward INTEGER DEFAULT 10, xpreward INTEGER DEFAULT 5,
    levelrequired INTEGER DEFAULT 1, description TEXT,
    rewardmin INTEGER DEFAULT 0, rewardmax INTEGER DEFAULT 0, background TEXT, image TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS job_history (
    id SERIAL PRIMARY KEY, userid INTEGER, jobid INTEGER, jobname TEXT,
    duration INTEGER, reward INTEGER, premiumbonus INTEGER DEFAULT 0, xpgained INTEGER DEFAULT 0,
    startedat TEXT, finishedat TEXT
  )`,

  // Логи и обратная связь
  `CREATE TABLE IF NOT EXISTS login_logs (
    id SERIAL PRIMARY KEY, userid INTEGER, username TEXT, ip TEXT,
    createdat TEXT DEFAULT (now()::TEXT)
  )`,
  `CREATE TABLE IF NOT EXISTS feedback_messages (
    id SERIAL PRIMARY KEY, userid INTEGER, username TEXT, subject TEXT, message TEXT,
    read INTEGER DEFAULT 0, createdat TEXT DEFAULT (now()::TEXT)
  )`,

  // Сезоны
  `CREATE TABLE IF NOT EXISTS seasons (
    id SERIAL PRIMARY KEY, name TEXT, startdate TEXT, enddate TEXT, status TEXT DEFAULT 'active'
  )`,
  `CREATE TABLE IF NOT EXISTS hall_of_fame (
    id SERIAL PRIMARY KEY, seasonid INTEGER, userid INTEGER, username TEXT,
    elo INTEGER, rank INTEGER, title TEXT, reward TEXT
  )`,

  // Коллекции
  `CREATE TABLE IF NOT EXISTS collections (
    id SERIAL PRIMARY KEY, userid INTEGER, itemname TEXT, slot TEXT,
    rarity_id INTEGER DEFAULT 0, addedat INTEGER DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS collection_sets (
    id SERIAL PRIMARY KEY, name TEXT, description TEXT,
    bonus_percent INTEGER DEFAULT 0, sort_order INTEGER DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS collection_set_items (
    id SERIAL PRIMARY KEY, set_id INTEGER, item_name TEXT, slot TEXT
  )`,

  // Крафт
  `CREATE TABLE IF NOT EXISTS craft_recipes (
    id SERIAL PRIMARY KEY, name TEXT, description TEXT,
    result_item_id INTEGER, result_rarity_id INTEGER, result_type TEXT, result_id INTEGER DEFAULT 0,
    money_cost INTEGER DEFAULT 0, success_chance INTEGER DEFAULT 0, category_id INTEGER DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS craft_recipe_ingredients (
    id SERIAL PRIMARY KEY, recipe_id INTEGER, craft_item_id INTEGER, quantity INTEGER DEFAULT 1
  )`,

  // Магазин, мобы, этажи, напитки
  `CREATE TABLE IF NOT EXISTS shop_items (
    id SERIAL PRIMARY KEY, item_name TEXT, slot TEXT, price INTEGER,
    quantity INTEGER DEFAULT -1, rarity_id INTEGER
  )`,
  `CREATE TABLE IF NOT EXISTS mobs (
    id SERIAL PRIMARY KEY, name TEXT, floor INTEGER DEFAULT 1,
    hp INTEGER DEFAULT 100, s INTEGER DEFAULT 5, a INTEGER DEFAULT 5,
    d INTEGER DEFAULT 5, m INTEGER DEFAULT 5, xp INTEGER DEFAULT 10, gold INTEGER DEFAULT 5,
    image TEXT, rarity_id INTEGER, level INTEGER DEFAULT 0,
    atk INTEGER DEFAULT 0, agi INTEGER DEFAULT 0, def INTEGER DEFAULT 0, mst INTEGER DEFAULT 0,
    gold_min INTEGER DEFAULT 0, gold_max INTEGER DEFAULT 0,
    loot_junk TEXT, loot_common TEXT, loot_uncommon TEXT, loot_rare TEXT,
    loot_epic TEXT, loot_legendary TEXT, loot_mythic TEXT,
    location TEXT, sort_order INTEGER DEFAULT 0, background TEXT, description TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS mob_drops (
    id SERIAL PRIMARY KEY, mobid INTEGER, itemname TEXT, itemtype TEXT,
    chance REAL DEFAULT 0.1, quantitymin INTEGER DEFAULT 1, quantitymax INTEGER DEFAULT 1
  )`,
  `CREATE TABLE IF NOT EXISTS floors (
    id SERIAL PRIMARY KEY, name TEXT, levelmin INTEGER DEFAULT 0, levelmax INTEGER DEFAULT 999,
    sort_order INTEGER DEFAULT 0, background TEXT, image TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS drinks (
    id SERIAL PRIMARY KEY, name TEXT, type TEXT, key TEXT UNIQUE,
    sbonus INTEGER DEFAULT 0, abonus INTEGER DEFAULT 0, dbonus INTEGER DEFAULT 0, mbonus INTEGER DEFAULT 0,
    hpbonus INTEGER DEFAULT 0, critbonus INTEGER DEFAULT 0, dodgebonus INTEGER DEFAULT 0,
    counterbonus INTEGER DEFAULT 0, fullblockbonus INTEGER DEFAULT 0,
    duration INTEGER DEFAULT 3600, price INTEGER DEFAULT 50, image TEXT
  )`,
];

async function main() {
  for (const sql of SCHEMA) {
    try {
      await pg.query(sql);
      const name = sql.match(/CREATE TABLE IF NOT EXISTS (\w+)/)?.[1] || '?';
      console.log('OK:', name);
    } catch (e: any) {
      console.log('ERR:', e.message.split('\n')[0].substring(0, 80));
    }
  }
  await pg.end();
  console.log('Done');
}

main();
