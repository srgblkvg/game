# PG-Native Rewrite Reference

Branch: `pg-native` (deployed to production `mmoarena.ru` as of 2026-06-14)

## Architecture

- **DB module**: `server/src/db/index.ts` — native `pg` Pool with helper functions
- **Schema**: `server/src/db/schema.sql` — 42 tables from SQLite ground truth
- **Seed**: `server/src/database/seed.ts` — rewritten for native PG

## Running locally

```bash
# Server
cd server && PORT=3002 npx tsx src/index.ts

# Client (proxy → :3002)
cd client && npx vite --host
# Open http://localhost:5173
```

## Key differences from main (SQLite/pg-promise)

| Aspect | main (prod) | pg-native |
|--------|------------|-----------|
| DB driver | pg-promise wrapper | native `pg.Pool` |
| Query API | `db.prepare(sql).get/all/run()` | `db.one/query/run(sql, params)` |
| Placeholders | `?` → `$1` auto | `?` → `$1` auto |
| camelCase | pg-promise receive event | custom camelRows() |
| Schema | SQLite file | PostgreSQL |
| Import | `import db from '../database'` | `import { db } from '../db/index'` |

## DB helper API

```ts
db.one(sql, [params])    // single row or null
db.query(sql, [params])  // array of rows
db.run(sql, [params])    // { changes, lastInsertRowid }
db.tx(async (client) => {...})  // transaction
db.raw(sql, [params])    // raw pg query, no conversion
```

## Test user
- Login: `testhero` / `Test123!@`
- Also: `arena_bot` (for arena testing)

## Critical camelCase issues (pg-native only)

The `camelRows()` function in `db/index.ts` converts PG lowercase column names to camelCase.
**Missing suffixes cause `undefined` → 500s, NaN, corrupted data.**

### Suffix regex (add new ones HERE when issues arise):
```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|
  fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|
  chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|score|number|
  players|ticket|stats|place|tag|text|chat|from|guild|role|last|first|ip|url|path|
  size|width|height|color|tier|slot|icon|attacked|made)$/i
```

### Compound replacements (for multi-word camelCase where suffix regex fails):
See `server/src/db/index.ts` lines 41-75 under `camelRows()`.

**Known victims (added over time):**
| Column | Issue | Fix |
|--------|-------|-----|
| `activeJob` | `job` not in suffix → `undefined` → jobs broken | Added `job` suffix |
| `rewardXp` | `xp` not in suffix → `undefined` → quest exp=NaN | Added `xp` suffix |
| `registrationEnd` | `end` not in suffix → tournaments never advance | Added `end` suffix |
| `baseS/A/D/M` | Single-letter suffixes → `bases` stays `bases` | Explicit `^bases$`→`baseS` |
| `statPoints` | `statpoints` no match → `undefined` → 0 | Explicit `^statpoints$` |
| `totalBattles` | `battles` not in suffix → 0 stats | Added `battles` suffix |
| `totalPvpMoneyWon` | Compound: becomes `totalpvpmoneyWon` not `totalPvpMoneyWon` | Explicit full match |
| `accountNumber` | `number` not in suffix → bank shows no ID | Added `number` suffix |
| `tournamentElo` | `elo` not in suffix → bracket seeding broken | Added `elo` suffix |
| `createdAt` | `at` IS in suffix ✓ but value is epoch string | Manual `Number()` conversion |
| `maxPlayers` | `players` not in suffix → `undefined` → "0/undefined уч." | Added `players` suffix |
| `goldenTicket` | `ticket` not in suffix → gold ticket payment broken | Added `ticket` suffix |
| `snapshotStats` | `stats` not in suffix → tournament results broken | Added `stats` suffix |
| `activeDrink`/`drinkUntil` | `drink` not in suffix → tavern drinks broken | Added `drink`? No — WARNING: `drink` is NOT in suffix list! These fields are accessed as `u.activeDrink` from camelRows result; if `activedrink` is the PG key, camelRows does NOT create `activeDrink`. **Check actual code paths.** |
| `timesAttacked` | `attacked` not in suffix → guild war " /3" display | Added `attacked` suffix |
| `attacksMade` | `made` not in suffix → guild war " /3" broken | Added `made` suffix |

## BigInt converter pitfall

The BigInt converter in `camelRows()` converts ALL numeric strings to numbers.
Chat message content like `"2"` was converted to number `2`, breaking `"2".split()`.

**Fix**: Only convert if value > 2^31 (actual bigint) OR if column name looks numeric:
```
if (n > 2147483647 || /^(id|count|level|cnt|total|sum|...|rank)$/i.test(key))
```

## SQLite → PG SQL differences

| SQLite | PostgreSQL |
|--------|-----------|
| `MAX(a, b)` | `GREATEST(a, b)` |
| `last_insert_rowid()` | `RETURNING id` (handled by `db.run`) |
| `INSERT OR REPLACE` | `INSERT ... ON CONFLICT DO UPDATE` |
| `datetime('now')` | `new Date().toISOString()` |

## Automatic SQL Identifier Lowercasing (pgLowerIdentifiers)

**Critical fix added 2026-06-15.** SQLite is case-insensitive for SQL identifiers — `tp.userId` works even though the column is `userid`. PostgreSQL is NOT — it folds unquoted identifiers to lowercase. After migration, ALL camelCase column references in SQL queries fail silently.

### The fix: `pgLowerIdentifiers(sql)` in `db/index.ts`

Function that transforms camelCase SQL identifiers to lowercase BEFORE sending to PG:
- Strips single-quoted string literals (preserves data)
- Regex: `/\b([a-z]+[A-Z][a-zA-Z0-9]*)\b/g` → `.toLowerCase()`
- Restores string literals
- Applied in `db.query()`, `db.one()`, `db.run()` before `pgParams()`

**This means route code can keep camelCase in SQL queries** — `tp.userId`, `tp.tournamentId`, `war.attackerGuildId`, etc. all work correctly.

### What it does NOT handle
- SQL functions/keywords in UPPERCASE (`SELECT`, `FROM`) — untouched (no lowercase+uppercase pattern)
- String values in single quotes — protected
- `::timestamptz` casts — `declaredAt::timestamptz` → `declaredat::timestamptz` — works correctly

## NOT NULL createdat audit

After PG migration, some tables have `createdat NOT NULL` but INSERT statements omit it.
**Proactively check ALL tables before deploying.**

### How to find affected tables:
```sql
SELECT table_name, column_name, is_nullable 
FROM information_schema.columns 
WHERE column_name = 'createdat' AND is_nullable = 'NO';
```

### Search for missing INSERTs:
```bash
grep -rn "INSERT INTO" server/src/ --include="*.ts" | grep -v "createdat\|createdAt"
```

### Common pattern — three types of INSERT:
1. **`db.run()` with `?` placeholders**: Add `createdat` column + `new Date().toISOString()` param
2. **`client.query()` in tx blocks**: Add `createdat` column + `NOW()` or `$N` param with ISO string
3. **Warning**: `db.run` auto-adds `RETURNING id` in a try/catch; the catch fallback runs the raw query. If `RETURNING id` fails (e.g., table has no `id` column), the catch block's INSERT must ALSO include `createdat`.

### Affected tables fixed 2026-06-15:
- `feedback_messages` — INSERT missing `createdat`
- `guild_treasury_log` — 4 INSERT locations missing `createdat` (deposit tx, war_win, war_loss, tax in helpers.ts)

## client.query return type pitfall

PG's `client.query()` returns `{ rows: [...], rowCount: N }`, NOT an array.
```ts
// WRONG — r is {rows: [...]}, not an array
const r = await client.query('SELECT ...');
return r[0];  // undefined!

// RIGHT
return r.rows[0];
```

This caused 500 errors in treasury/deposit after the tx succeeded — the DB operations completed but `result.treasury` was undefined.

## Client date formatting (safeDate evolution)

Three formats arrive from PG after migration:
1. **Old code**: `"2026-06-13 08:05:41"` — space-separated, no timezone (legacy SQLite format)
2. **ISO from JS**: `"2026-06-15T09:16:28.243Z"` — `new Date().toISOString()` in code
3. **PG NOW()**: `"2026-06-15 09:39:56.772895+00"` — space-separated, `+00` timezone (NOT `+00:00`!)

### safeDate must handle ALL three:

```typescript
function safeDate(value: any): Date | null {
    if (value == null) return null;
    if (typeof value === 'number') return new Date(value * 1000);
    if (typeof value === 'string') {
        if (/^\d+$/.test(value)) return new Date(Number(value) * 1000);
        let s = value.replace(' ', 'T');
        s = s.replace(/([+-]\d{2})$/, '$1:00');  // +00 → +00:00 (стандартный ISO)
        const hasTZ = s.endsWith('Z') || /[+-]\d{2}:\d{2}$/.test(s);
        return new Date(s + (hasTZ ? '' : 'Z'));
    }
    return null;
}
```

### Evolution (why 3 iterations):
1. **v1**: `new Date(value.replace(' ', 'T') + 'Z')` — broke on ISO strings (double Z: `...Z` + `Z` = `...ZZ`)
2. **v2**: `endsWith('Z') ? noZ : addZ` — broke on `+00` (added Z → `+00Z`)
3. **v3**: Normalize `+00` → `+00:00`, check for ANY timezone before adding Z. Critical because `new Date("...+00")` is NOT standard ISO — `+00` without minutes (`+00:00`) fails on some browsers (especially mobile).

### Client files needing `new Date(*1000)` → `fmtSafeDate()` conversion:
Run this to find all: `grep -rn "new Date.*\* 1000" client/src/ --include="*.tsx" | grep -v utils/date.ts`
Then replace with `fmtSafeDate(field, options)` + add import.

### Server-side date anti-pattern: `replace('T',' ').slice(0,19)`

**Problem**: Legacy code uses `new Date().toISOString().replace('T', ' ').slice(0, 19)` 
to produce `"2026-06-15 09:14:00"` (matching SQLite datetime format). In PG:
1. Stored as text, not timestamptz — can't use PG date functions
2. String comparison `joinedAt (timestamptz) > declaredAt (text "2026-06-15 09:14:00")` is unreliable
3. Client must handle yet another format variant

**Fix**: Use `new Date().toISOString()` everywhere. ISO string `"2026-06-15T09:14:00.000Z"`:
- Works with PG timestamptz columns
- Compares correctly lexicographically
- Parses correctly in all browsers

**Search for offenders**: `grep -rn "replace.*T.*slice.*19" server/src/`

**Server-side `+ 'Z'` anti-pattern (protectedUntil bug):** In `guild.ts`, the `protectedUntil` calculation does `new Date(m.lastAttackedAt + 'Z')`. If `lastAttackedAt` is already ISO with Z (from PG), this produces `...ZZ` → Invalid Date → `protectionEnd = NaN` → protection never active. Same pattern as client safeDate v1. Fix: check `endsWith('Z')` before appending.
```typescript
const attackedTime = new Date(
    m.lastAttackedAt.endsWith('Z') ? m.lastAttackedAt : m.lastAttackedAt + 'Z'
).getTime();
```

## Missing `await` bugs

Common pattern that causes silent failures in tournament, guild, and rating code:
```ts
// WRONG — returns Promise, not value
const war = isGuildAtWar(guildId);

// RIGHT
const war = await isGuildAtWar(guildId);
```

Also: `.map(async ...)` returns array of Promises — must wrap with `Promise.all()`.

## Tournament auto-advance design

Tournaments advance ONLY on page visit (`GET /tournament` → `autoAdvance()`).
No server-side timer. Design:
1. Registration ends → page visit triggers `generateBracket()`
2. `resolveCurrentRound()` runs battles
3. `advanceWinners()` creates next round
4. `finishTournament()` marks complete and pays rewards
5. New tournament after 1-hour cooldown (uses `completedAt` comparison)

**Bracket regeneration fix:** If tournament is `in_progress` but has 0 matches (generateBracket failed silently), autoAdvance now regenerates the bracket:
```typescript
if (t.status === 'in_progress') {
    const matchCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_matches WHERE tournamentid = ?', [tournamentId]) as any).cnt;
    if (matchCount === 0) {
        await generateBracket(tournamentId);
        await autoAdvance(tournamentId);
        return;
    }
    // ... normal resolveCurrentRound flow
}
```
Without this, tournaments stuck in `in_progress` with 0 matches never recover.

## Guild war timer pattern

Guild war attack button needs live countdowns for:
1. **Attack cooldown** (5 min after any attack — affects ALL enemies)
2. **Defender protection** (1 hour after being attacked — per enemy)

Implementation:
```tsx
// Tick state for re-renders
const [tick, setTick] = useState(0);
useEffect(() => {
    const iv = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(iv);
}, []);

// Countdown from ISO string
function countdown(until: string | null): string {
    if (!until) return '';
    const sec = Math.max(0, Math.ceil((new Date(until).getTime() - Date.now()) / 1000));
    if (sec <= 0) return '';
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m > 0 ? `${m}:${String(s).padStart(2, '0')}` : `0:${String(s).padStart(2, '0')}`;
}

// On attack button:
const attackCd = countdown(data.attackCooldownUntil);     // 5 min, all enemies
const protCd = countdown(m.protectedUntil);                // 1 hour, this enemy
const hasCooldown = !!attackCd;
const cantAttack = !!protCd || limitReached || hasCooldown;
// Button shows: hasCooldown ? `⏳${attackCd}` : protCd ? `🛡️${protCd}` : '⚔️'
```
