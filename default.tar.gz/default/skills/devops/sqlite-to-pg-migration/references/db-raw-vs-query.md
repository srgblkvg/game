# db.query vs db.raw — Когда ломается pgLowerIdentifiers

## Проблема

`db.query()` прогоняет SQL через `pgLowerIdentifiers`, который:
1. Временно убирает single-quoted строки
2. Находит camelCase-идентификаторы и приводит к lowercase
3. Возвращает строки на место

На практике этот конвертер **ломает некоторые запросы** непредсказуемым образом.

## Симптомы

Запрос возвращает 0 строк, хотя прямой SQL в psql возвращает корректные данные.

Пример из резни:
```ts
// НЕ РАБОТАЕТ — возвращает 0 строк
const participants = await db.query(
    `SELECT mp.*, u.username FROM massacre_participants mp 
     JOIN users u ON mp.user_id = u.id 
     WHERE mp.event_id = ? AND mp.alive = TRUE`,
    [eventId]
);
```

В psql тот же запрос возвращает 119 строк.

## Решение: db.raw

```ts
// РАБОТАЕТ — обходит pgLowerIdentifiers
const rawResult = await db.raw(
    `SELECT mp.*, u.username FROM massacre_participants mp 
     JOIN users u ON mp.user_id = u.id 
     WHERE mp.event_id = $1 AND mp.alive = TRUE`,
    [eventId]
);
const participants = rawResult.rows;
```

**Важно:** `db.raw` использует `$1, $2, ...` вместо `?`.

## Когда использовать db.raw

- JOIN-запросы
- Запросы с булевыми условиями (`= TRUE`, `= FALSE`)
- Любой запрос, который возвращает 0 строк хотя в psql данные есть
- Запросы, где pgLowerIdentifiers может неправильно обработать идентификаторы

**db.raw НЕ применяет `camelRows`** — ключи остаются как есть из PG (lowercase snake_case).
