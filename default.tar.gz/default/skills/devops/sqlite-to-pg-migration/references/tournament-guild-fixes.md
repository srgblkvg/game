# Tournament & Guild War PG Migration Fixes (June 2026)

## Tournament: generateBracket → raw pool.query

The bracket generation INSERTs via `db.run()` were silently failing. Root cause: `async function nextPowerOfTwo` returned `Promise<number>`, causing `half = NaN` and the for-loop to never execute. Fix: remove `async`.

Additionally, `generateBracket` was rewritten to use `pool.query()` directly instead of `db.run()`. This bypasses the `RETURNING id` → fallback flow and the `lastInsertRowid` gymnastics.

```typescript
// New: direct pool access in generateBracket
import { db, pool } from '../db/index';

async function generateBracket(tournamentId: number) {
    const partRows = await pool.query(
        `SELECT tp.userid, u.tournamentelo FROM tournament_participants tp
         JOIN users u ON tp.userid = u.id WHERE tp.tournamentid = $1
         ORDER BY u.tournamentelo ASC`,
        [tournamentId]
    );
    const participants = partRows.rows;
    const getUserId = (p: any) => p ? p.userid : null;
    // ... rest uses pool.query directly for INSERTs
}
```

### Bracket regeneration for stuck tournaments

Added to `autoAdvance`: if status is `in_progress` but 0 matches exist, regenerate the bracket:

```typescript
if (t.status === 'in_progress') {
    const matchCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_matches WHERE tournamentid = ?', [tournamentId]) as any).cnt;
    if (matchCount === 0) {
        await generateBracket(tournamentId);
        await autoAdvance(tournamentId);
        return;
    }
    // normal flow...
}
```

### Missing await on finishTournament

```typescript
// BROKEN:
finishTournament(tournamentId);
// FIXED:
await finishTournament(tournamentId);
```

## Tournament: SELECT last_insert_rowid()

SQLite-specific function. Replaced with `info.lastInsertRowid` from `db.run()` response:

```typescript
// OLD:
const matchRow = await db.one('SELECT last_insert_rowid() as id', []) as any;
// NEW:
const matchRow = { id: info.lastInsertRowid };
```

## Tournament: maxPlayers column

Column didn't exist in PG schema. Added via:
```sql
ALTER TABLE tournaments ADD COLUMN maxplayers integer DEFAULT 8;
```

Server code updated to include `maxPlayers` in INSERT and API response. Client already used `t.maxPlayers || 8`.

## Guild Wars: lastAttackedAt camelCase

`lastattackedat` was not converted to `lastAttackedAt` because only the `at` suffix matched. Added to camelRows:

```typescript
.replace(/lastattackedat$/i, 'lastAttackedAt')
```

Without this, `protectedUntil` was always null because `m.lastAttackedAt` was undefined.

## Guild Wars: date format in server code

Server code was doing `m.lastAttackedAt + 'Z'` on a value that already ends with `Z` (PG timestamptz). Fixed:

```typescript
// BROKEN:
const attackedTime = new Date(m.lastAttackedAt + 'Z').getTime();
// FIXED:
const attackedTime = new Date(
    m.lastAttackedAt.endsWith('Z') ? m.lastAttackedAt : m.lastAttackedAt + 'Z'
).getTime();
```

## SafeDate: timezone handling

`PG NOW()` returns `"2026-06-15 09:39:56.772895+00"` — the `+00` is not standard JS ISO (needs `+00:00`). Also must not append `Z` to strings that already have timezone:

```typescript
let s = value.replace(' ', 'T');
s = s.replace(/([+-]\d{2})$/, '$1:00');  // +00 → +00:00
const hasTZ = s.endsWith('Z') || /[+-]\d{2}:\d{2}$/.test(s);
return new Date(s + (hasTZ ? '' : 'Z'));
```

## Client-side date fixes

Replaced ALL `new Date(X * 1000).toLocaleString(...)` with `fmtSafeDate(X, ...)` across:
- BankPage, TournamentPage, AdminUsers, AdminTournaments, AdminChat
- ChatContext, ChatInput, GuildViewPage, GuildWarPage

Added missing `import { fmtSafeDate }` in AdminTournaments, AdminChat, AdminUsers.

## Fair bye system: all byes in round 1 for top-ELO players

Old `generateBracket` used simple pairwise matching with NULL padding. With 38 players and 64 slots, this created 19 matches in R1 → 19 winners (odd!) → 9 matches + 1 bye in R2 → and so on. Byes persisted into later rounds, sometimes the same player got multiple byes — unfair.

**New approach:** Give byes ONLY in round 1, to the highest-ELO players. After round 1, the bracket is a clean power-of-2.

```
n=38, slots=64, byes=64-38=26, playInRound1=12 (6 matches)
26 top-ELO players → bye → round 2 directly
12 remaining players → 6 matches → 6 winners → round 2
Round 2: 26 + 6 = 32 players = 2^5 ← CLEAN!
```

```typescript
// Sort by ELO descending (highest first)
SELECT ... ORDER BY u.tournamentelo DESC

// Top byes get free pass
for (let i = 0; i < byes; i++) {
    INSERT INTO tournament_matches (...) VALUES (tid, 1, p.userid, NULL, p.userid)
}

// Remaining play pairwise
for (let i = 0; i < playInRound1 / 2; i++) {
    const p1 = participants[byes + i*2];
    const p2 = participants[byes + i*2 + 1];
    INSERT INTO tournament_matches (...) VALUES (tid, 1, p1.userid, p2.userid)
}
```

Result: R1 has exactly `slots/2` entries (byes + real matches), R2 always has `slots/2` players — a perfect power-of-2. No byes in later rounds.

## 3rd place: `round` suffix missing from camelRows

`finishTournament` queries `SELECT MAX(round) as maxRound`. camelRows converts column names via suffix regex. Suffix `round` was NOT in the list, so `maxround` stayed as `maxround` (no camelCase key). `lastRound.maxRound` was `undefined` → `finalRound = 1` → `finalRound >= 2` was always false → **3rd place never awarded**.

**Fix:** Add `round` to the suffix regex: `...|icon|attacked|made|round)$/i`

## Guild war log: `log` suffix missing from camelRows

`guild_war_attacks` has column `battleLog`. After PG: `battlelog`. camelRows suffix regex didn't include `log`, so `battlelog` stayed lowercase. Client accessed `attack.battleLog` → `undefined` → logs didn't open.

**Fix:** Add `log` to the suffix regex: `...|attacked|made|round|log)$/i`

## Salary messages: `pveWins` camelCase

Salary cron job: `SELECT pvewins FROM users`. camelRows: `pvewins` → `pveWins` (suffix `wins` → `Wins`). Code used `u.pvewins` (lowercase) → `undefined` → messages showed empty/undefined amount.

**Fix:** Use `u.pveWins || u.pvewins` as safety fallback.

## Battle log: HP tracking

Added `hp1, hp2, maxHp1, maxHp2` fields to `BattleStep` interface. Modified `runBattle` to include these in every damage step. Also added initial character stats (`stats1`, `stats2`) with level, S/A/D/M, HP, drinks, collection bonus.
