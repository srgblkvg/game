# PG Native — `await` Audit Pattern

## The bug class
Async functions called without `await` return a Promise, not the value. Common places:
- `getOrCreateTournament()` — used in `GET /api/tournament` handler
- `autoAdvance(tournamentId)` — recursive calls within autoAdvance
- `generateBracket(tournamentId)` — called when registration → in_progress
- `isGuildAtWar(guildId)` — called in 8 places across guild.ts
- `loadPlayerForBattle(userId)` / `resolveCurrentRound(tournamentId)` — in tournament.ts
- `addPveRating(...)` — extra `db` parameter removed

## Audit approach
```bash
# Find async function definitions
grep -rPn 'async function' server/src/routes/

# Find calls to those functions (check for await)
grep -rPn 'autoAdvance|generateBracket|isGuildAtWar|resolveCurrentRound' server/src/routes/
```

## `.map(async)` without `Promise.all`
When mapping with async, the result is an array of Promises, not values.
- **Fix**: Wrap in `Promise.all(...)` or use `for...of` loop
- **Hit in**: tournament, guild, rating, adminCollections routes

## Recursive fire-and-forget
`autoAdvance()` calls itself recursively. If called without `await`, the outer call returns before inner completes, breaking the chain.
- **Fix**: `await autoAdvance(tournamentId)` in all recursive calls
