# Post-Migration Bugs from 2026-06-13 Session

## Quest Daily Limit Bug
The check `completedToday >= 5` allowed 6+ quests per day:
- Player has 3 active + 2 completed = 5 → can take another (only checks completedToday < 5)
- Then completes one: 2 active + 3 completed = 5 → can take another
- Result: 6 total quests in one day

**Fix**: `activeCount + completedToday >= 5` replaces `completedToday >= 5`.
Files: `server/src/routes/quests.ts` lines 129 and 172.

## defLevel Variable Bug (Rollback)  
After git checkout of old SQLite code, battle.ts had `defLevel` and `defLevelsGained` — variables that didn't exist in that commit. The `applyExp` function returns `{ newExp, newLevel, levelsGained, newStatPoints }`. Must use `defExp.newLevel` and `defExp.levelsGained`.
File: `server/src/routes/battle.ts` line 118.

## Hardcoded localhost:3001
Admin panel had hardcoded localhost URLs:
- `AdminPanel/AdminUsers.tsx:57` — reset-timers
- `AdminRegisterPage.tsx:14,22` — admin/check, admin/register
**Fix**: Replace with relative paths (`/api/...`).

## Uploads Lost
`git reset --hard` wipes server/uploads/. Restore from backup:
```bash
cp -r /opt/game_backup_DATE/server/uploads/* /opt/game/server/uploads/
```

## Collection Progress Bar
BuffsBlock fetched `/api/collections` separately for percentage. Better: use `collectionCount` and `totalCollectionItems` from character/me response.
- Server: added `totalCollectionItems` (SELECT COUNT(*) FROM collection_set_items)
- Client: `Math.round((collectionCount / totalCollectionItems) * 100)`

## Admin Password Overwritten by Seed
PG seed script inserted admin with `admin123` hash before data migration ran. Data migration had `ON CONFLICT DO NOTHING` so original admin hash was lost.
**Fix**: Restore admin passwordhash from SQLite after migration.

## Missing CSS Variable --color-accent-gold
Client code referenced `var(--color-accent-gold)` but theme.css only defined `--color-accent-warning` (same gold `#f1c40f`). Progress bars were invisible.
**Fix**: Add `--color-accent-gold: #f1c40f` (dark) and `--color-accent-gold: #b8860b` (light) to theme.css.

## BuffsBlock useState Removal
When patching BuffsBlock, removing `const [collectionPercent, setCollectionPercent] = useState(0)` accidentally also removed `const [now, setNow]`, `const [collapsed, setCollapsed]`, `const [hasCollectionItems, setHasCollectionItems]`. Caused `ReferenceError: collapsed is not defined`.
**Fix**: Always verify ALL useState declarations are preserved after any patch.

## Hardcoded 189 in Collections Page
`collectionCount / 189` was hardcoded. If new collection sets are added, the percentage breaks.
**Fix**: `totalCollectionItems` from `SELECT COUNT(*) FROM collection_set_items`, passed via character/me response.

## Missing PG Columns (2026-06-13 v2 session)
After full rebuild + migration, several columns were missing from the PG schema:
- `users.pvewins`, `users.craftcount`, `users.auctiontrades` — stats page
- `users.oauthprovider`, `users.oauthid` — OAuth login
- `guilds.level`, `guilds.jointype`, `guilds.exp`, `guilds.levelrequired` — guild features
**Fix**: `ALTER TABLE users ADD COLUMN pvewins INTEGER DEFAULT 0`, etc.

## Passwords Lost After Each Migration
The migration script uses SQLite column names (camelCase) for INSERT. PG columns are lowercase. `passwordHash` (SQLite) → INSERT tries `"passwordHash"` (quoted) → PG column is `passwordhash` (lowercase) → mismatch → NULL inserted.
**Fix**: After every migration, run a separate password fix script that reads SQLite `passwordHash` and updates PG `passwordhash` directly:
```js
const s = new D('game.db'); const p = new Pool({...});
const rows = s.prepare("SELECT id, passwordHash FROM users WHERE passwordHash != ''").all();
for (const u of rows) await p.query("UPDATE users SET passwordhash=$1 WHERE id=$2", [u.passwordHash, u.id]);
```

## PM2 Restart During Table Drops
When running `DROP TABLE IF EXISTS` while PM2 is running, PM2 auto-restarts the server which connects to empty tables and crashes. Sequence must be: `pm2 stop → DROP → CREATE → MIGRATE → pm2 start`.
