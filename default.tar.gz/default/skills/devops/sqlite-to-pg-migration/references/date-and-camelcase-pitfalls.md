# Date Parsing & camelCase Converter Pitfalls

## `+ 'Z'` appending breaks on PG timestamptz

**Bug:** Guild war cooldown never worked. Guild invites cooldown always expired.

**Root cause:** 
```typescript
// BROKEN — PG timestamptz already has +00:00, adding 'Z' creates invalid string
const lastTime = new Date(lastAttack.lastAt + 'Z').getTime();
// "2026-06-15T09:39:56.000+00:00Z" → Invalid Date → NaN
```

**Fix:** `new Date(lastAttack.lastAt).getTime()` — no `+ 'Z'`.

**Audit:** Grep for `\+ 'Z'` — every instance is a bug on PG.

## camelCase Suffix List (keep synced with db/index.ts)

```
hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|score|number|players|ticket|stats|place|tag|text|chat|from|guild|role|last|first|ip|url|path|size|width|height|color|tier|slot|icon|attacked|made|round|log|code|expires|verified|drink|date|bid|by
```

## Explicit camelCase rules (keep synced)

```typescript
// FULL-KEY rules (before generic suffix regex):
.replace(/^accountnumber$/i, 'accountNumber')
.replace(/^fromaccount$/i, 'fromAccount')
.replace(/^toaccount$/i, 'toAccount')
.replace(/^currentbiddername$/i, 'currentBidderName')
.replace(/^attackerguildid$/i, 'attackerGuildId')
.replace(/^defenderguildid$/i, 'defenderGuildId')
.replace(/taxrate$/i, 'taxRate')  // was 'TaxRate' (PascalCase) — broke guild tax display
```

## Known Suffix Collisions

| PG column | Regex match | Wrong result | Explicit rule |
|-----------|-------------|-------------|---------------|
| `fromaccount` | `count` | `fromacCount` | `fromAccount` |
| `toaccount` | `count` | `toacCount` | `toAccount` |
| `currentbiddername` | `name` | `currentbidderName` | `currentBidderName` |
| `attackerguildid` | `id` | `attackerguildId` | `attackerGuildId` |
| `defenderguildid` | `id` | `defenderguildId` | `defenderGuildId` |

## Missing Suffixes (added later)

- `bid` — `currentbid` → `currentBid`. Was missing, caused auction bid display to silently fail.
- `by` — `invitedby` → `invitedBy`. Was missing, caused guild invite data to lack camelCase key.

## `INSERT INTO table VALUES (...)` without explicit columns

PG fills ALL columns in ordinal position. Omitting auto-increment `id` shifts values.
**Fix:** Always list columns explicitly.
