# Post-Migration Bugs — 2026-06-14 Session

## Bug 1: Base stats show 5-5-5-5 (defaults)
**Symptom**: Client shows 5/5/5/5 base stats instead of actual values (8/7/7/8).
**Root cause**: PG columns `bases/basea/based/basem` — camelCase converter didn't have explicit mappings. `bases` → suffix `s` not in list → stays `bases` → `user.baseS` = undefined → fallback to `?? 5`.
**Fix**: Add explicit `.replace(/^bases$/i, 'baseS')` etc.

## Bug 2: Stat points = 0 (were 20)
**Symptom**: `statPoints` shows 0.
**Root cause**: `statpoints` → no matching suffix → stays `statpoints` → `user.statPoints` = undefined → `|| 0`.
**Fix**: Add explicit `.replace(/^statpoints$/i, 'statPoints')`.

## Bug 3: Chat LS crash — `content.split is not a function`
**Symptom**: Private messages crash client with `e.content.split is not a function`.
**Root cause**: BigInt auto-converter converts ALL numeric strings to numbers. Chat message "2" became number 2 → `.split()` fails. Also `content` from API could be undefined for some messages.
**Fix**: 
- Server: `const msg = { ...m, content: m.content || '' }` in chat.ts
- Client: `(msg.content || '').split(...)` in ChatPanel.tsx
- BigInt: restrict to numeric column names OR value > 2³¹

## Bug 4: Jobs broken — activeJob not appearing
**Symptom**: Job starts but character/me shows no activeJob, job page kicks to main.
**Root cause**: `activejob` → suffix `job` not in list → stays `activejob` → code reads `user.activeJob` = undefined.
**Fix**: Add `job` to suffix list.

## Bug 5: Quest completion resets EXP to 0
**Symptom**: Completing quest sets EXP to 0/null instead of adding.
**Root cause**: `rewardxp` → suffix `xp` not in list → `quest.rewardXp` = undefined → `UPDATE SET exp = exp + NULL` → exp = NULL → treated as 0.
**Fix**: Add `xp` to suffix list + explicit `.replace(/^rewardxp$/i, 'rewardXp')`.

## Bug 6: Tournament registration never ends
**Symptom**: "до старта: 0 мин" — registration stuck.
**Root cause**: Two issues:
1. `registrationend` → suffix `end` not in list → `t.registrationEnd` = undefined → `now >= undefined` = false → never advances
2. `getOrCreateTournament()` called without `await` → returned Promise, not array
3. `createdAt` filter used ISO string comparison against epoch TEXT column → CAST::BIGINT on ISO string crashes
**Fix**: Add `end`/`start` to suffix list, add `await`, simplify filter.

## Bug 7: Guild war crash
**Symptom**: Guild view crashes — `Cannot read properties of null`.
**Root cause**: `isGuildAtWar(guildId)` called 8 times without `await` — returns Promise (truthy) instead of null.
**Fix**: Add `await` to all 8 call sites.

## Bug 8: Tournament shows "Invalid Date"
**Symptom**: Completed tournaments list shows "Invalid Date".
**Root cause**: `createdAt`/`completedAt` stored as epoch TEXT like "1781344545". `new Date("1781344545")` → Invalid Date.
**Fix**: `Number(t.createdAt) || t.createdAt` in API response.

## Bug 9: Statistics missing in profile
**Symptom**: PvP money, PvE battles, job money/time all show 0.
**Root cause**: Compound camelCase: `totalpvpmoneywon` → camelCase converter only capitalizes LAST suffix → `totalpvpmoneyWon` instead of `totalPvpMoneyWon`. Code reads `user.totalPvpMoneyWon` → undefined.
**Fix**: Add explicit compound mappings for ALL user stats columns.

## Bug 10: Drink/collection bonuses missing in some modes
**Symptom**: Bonuses not applied in users.ts and battle.ts defender HP calc.
**Root cause**: `getDrinkBonuses(user)` passed as `undefined` instead of actual value.
**Fix**: Add `getDrinkBonuses(user)` to all `currentStats()` calls. Added `coll` to users.ts profile.

## Bug 11: Arena "Некорректный ответ сервера"
**Symptom**: When no opponents found, client shows generic error.
**Root cause**: Arena returned 200 with `{ error, opponent: null }` → client saw `res.ok=true` but `data.id` was missing → "Некорректный ответ".
**Fix**: Reverted to `404` status — client handles `!res.ok` correctly with `data.error`.

## Bug 12: Tournament auto-advance not working
**Symptom**: Tournament stuck in registration, only advances when user visits page.
**Root cause**: `autoAdvance()` only called on GET /tournament. No server-side timer.
**Fix**: Added `setInterval` every 10s in tournament.ts to auto-progress all active tournaments.

## Bug 13: Feedback 500 error
**Symptom**: POST /api/feedback → 500.
**Root cause**: `feedback_messages.createdat` — NOT NULL without DEFAULT. Code doesn't set createdAt → PG rejects INSERT.
**Fix**: `ALTER TABLE ALTER COLUMN DROP NOT NULL, SET DEFAULT ''`.

## Bug 14: CollectionsPage mobile tap unreliable
**Symptom**: Tap on collection items sometimes doesn't register.
**Root cause**: Duplicate onClick: longPress hook fires via onTouchEnd, React fires separate onClick 300ms later. On mobile, two handlers conflict.
**Fix**: Added mouse event support to longPress hook, removed duplicate onClick.

## Root Cause Pattern
**95% of bugs**: camelCase converter missing suffix → field value is undefined → silent corruption (0, NaN, NULL, default).
**Detection**: When any feature is broken after PG migration, CHECK CAMELCASE FIRST. Print the raw DB column names vs what the code expects.
