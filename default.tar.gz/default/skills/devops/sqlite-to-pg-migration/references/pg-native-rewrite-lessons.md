# PG Migration Lessons — June 14 Session

## camelCase Suffix List (CRITICAL)
The suffix-based converter is the #1 source of bugs. Every missing suffix causes a field to silently become `undefined`.

Current minimum suffix regex:
```
hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds
```

Compound corrections (applied AFTER generic suffix):
```ts
cc = cc.replace(/attacktime$/i, 'AttackTime')
       .replace(/pveattacktime$/i, 'PveAttackTime')
       .replace(/attacksec$/i, 'AttackSec')
       .replace(/pveattacksec$/i, 'PveAttackSec')
       .replace(/taxrate$/i, 'TaxRate')
       .replace(/verified$/i, 'Verified')
       .replace(/hpupdate$/i, 'HpUpdate')
       .replace(/^bases$/i, 'baseS').replace(/^basea$/i, 'baseA')
       .replace(/^based$/i, 'baseD').replace(/^basem$/i, 'baseM')
       .replace(/^statpoints$/i, 'statPoints');
```

## BigInt Converter
PG returns COUNT(*) as string. Auto-converting ALL numeric strings to numbers breaks text fields (chat "2" → number 2 → `.split()` crash).

**Safe converter**: only convert if value > 2³¹ OR column name is in numeric list:
```ts
const numericCols = /^(id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round|limit|offset|page|rank)$/i;
if (n > 2147483647 || numericCols.test(key)) row[key] = n;
```

## db.run() RETURNING id on Composite Keys
Tables with composite PKs (craft_recipe_ingredients, upgrade_chances, guild_members) have no `id` column. Wrap RETURNING id in try/catch.

## SQLite → PG Function Replacements
- `datetime(?)` → `?` (pass ISO string directly)
- `datetime('now', '-5 minutes')` → compute in JS
- `INSERT OR REPLACE` → `INSERT ... ON CONFLICT (pk) DO UPDATE SET ...`

## TIMESTAMPTZ → TEXT
SQLite dynamic typing allows mixing epoch integers and ISO strings. Make ALL date columns TEXT.
