# CamelCase Converter: Suffixes, Pitfalls, and SQL Patterns

## Current Suffix List

After extensive debugging, the MINIMUM suffix regex for PG lowercased columns:

```
hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|code|expires|verified
```

## Explicit Compound Mappings

Always add these `.replace()` chains for multi-word column names that the generic suffix regex can't handle:

```ts
.replace(/^bases$/i, 'baseS').replace(/^basea$/i, 'baseA')
.replace(/^based$/i, 'baseD').replace(/^basem$/i, 'baseM')
.replace(/^statpoints$/i, 'statPoints')
.replace(/^totalbattles$/i, 'totalBattles')
.replace(/^pvetotalbattles$/i, 'pveTotalBattles')
.replace(/^pvewins$/i, 'pveWins')
.replace(/^totalpvpmoneywon$/i, 'totalPvpMoneyWon')
.replace(/^totalpvpmoneylost$/i, 'totalPvpMoneyLost')
.replace(/^totalpvemoneywon$/i, 'totalPveMoneyWon')
.replace(/^totalpvemoneylost$/i, 'totalPveMoneyLost')
.replace(/^totaljobmoney$/i, 'totalJobMoney')
.replace(/^totaljobseconds$/i, 'totalJobSeconds')
.replace(/^craftcreated$/i, 'craftCreated')
.replace(/^craftupgraded$/i, 'craftUpgraded')
.replace(/^craftbroken$/i, 'craftBroken')
.replace(/^tournamentcount$/i, 'tournamentCount')
.replace(/^tournamentwins$/i, 'tournamentWins')
.replace(/^rewardxp$/i, 'rewardXp')
.replace(/^arenatopponentid$/i, 'arenaOpponentId')
.replace(/^emailcode$/i, 'emailCode')
.replace(/^emailcodeexpires$/i, 'emailCodeExpires')
```

### Multi-Suffix Pitfall: JS `.replace()` Without `/g`

**`String.replace()` with a non-global regex only matches ONCE.** When a column name has two camelCase suffixes (e.g., `emailcodeexpires` — suffixes `code` + `expires`), the generic suffix regex only capitalses the FIRST one it matches, producing `emailcodeExpires` instead of `emailCodeExpires`.

**Symptom:** `user.emailCodeExpires` returns `undefined` while `user.emailcodeExpires` exists — the first suffix (`code`) was never capitalised.

**Fix:** Always add an explicit `.replace(/^emailcodeexpires$/i, 'emailCodeExpires')` for double-suffix columns. Do NOT use `/g` on the generic regex — it would break compound replacements that rely on prefix-anchored (`^`) matches happening AFTER the generic pass.

### Symptom Pattern: Silent "Invalid Code"

When an email/code verification field isn't converted, the comparison `user.emailCode !== code` evaluates `undefined !== "123456"` → always `true`. The user sees "Неверный код" but the real problem is a **missing camelCase suffix**, not a wrong code. Before debugging the verification logic, check: does `db.one(...)` return the field as the expected camelCase key?

## BigInt Converter Pitfall

The auto-converter that turns PG bigint strings to numbers silently breaks TEXT columns containing all-numeric content. A chat message "123" becomes number 123 → `.split()` crashes with `TypeError: x.split is not a function`.

**Safe version** — only convert when the column name is known numeric, or the value exceeds 2³¹:

```ts
if (n > 2147483647 || /^(id|count|level|cnt|total|sum|amount|price|cost|fee|rate|score|elo|rating|hp|exp|gold|money|slots|points|duration|chance|round|year|month|day|hour|min|sec|limit|offset|page|rank)$/i.test(key)) {
  row[key] = n;
}
```

## SQLite→PG SQL Pattern Replacements

| SQLite | PostgreSQL |
|--------|-----------|
| `MAX(a, b)` | `GREATEST(a, b)` |
| `MIN(a, b)` | `LEAST(a, b)` |
| `last_insert_rowid()` | `RETURNING id` (auto via `db.run()`) |
| `INSERT OR REPLACE` | `INSERT ... ON CONFLICT (id) DO UPDATE` |
| `datetime('now')` | `new Date().toISOString()` in JS |

## Date/Time Handling

### The `completedAt + 'Z'` bug

`new Date(val + 'Z')` breaks when `val` already has a timezone suffix like `"2026-06-14T10:17:56.086Z"`. The concatenation produces `"2026-06-14T10:17:56.086ZZ"` → Invalid Date → time-based delay checks silently skip.

**Fix:** Parse dates defensively:
```ts
const ts = typeof val === 'number' ? val * 1000
  : Number(val) || new Date(val).getTime();
```

### TIMESTAMPTZ → TEXT migration

Server code often sends epoch integers mixed with ISO strings. Change affected columns to TEXT:
```sql
ALTER TABLE users ALTER COLUMN lastloginat TYPE TEXT USING lastloginat::TEXT;
ALTER TABLE tournaments ALTER COLUMN createdat TYPE TEXT USING createdat::TEXT;
```

## Async/Await Pitfalls

After PG migration, **ALL** `async` function calls need `await`. Common misses:
- `generateBracket(tournamentId)` → `await generateBracket(tournamentId)`
- `autoAdvance(tournamentId)` → `await autoAdvance(tournamentId)`
- `isGuildAtWar(guildId)` → `await isGuildAtWar(guildId)`
- `.map(async ...)` returns Promise array → wrap with `Promise.all()`

Without `await`, the function returns a Promise that never resolves, and dependent code runs with stale/undefined data.
