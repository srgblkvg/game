# Post-Rewrite Fix Checklist (Native PG, No Wrapper)

After a full native-PG rewrite, systematically verify these 10 items before opening the app.

## 1. camelCase Suffix Coverage (CRITICAL — #1 bug source)

PG lowercases ALL unquoted identifiers. Suffix-based converter must cover every column name suffix.

**Complete suffix regex:**
```
/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance)$/i
```

**Compound corrections:**
```ts
cc.replace(/attacktime$/i, 'AttackTime')
  .replace(/pveattacktime$/i, 'PveAttackTime')
  .replace(/hpupdate$/i, 'HpUpdate');  // ← most commonly missed
```

**Symptoms by missing suffix:** `job`→activeJob undefined, `max/min`→reward null, `hpupdate`→HP regen broken, `order`→sort broken, `image`→images missing, `chance`→craft broken.

## 2. BigInt → Number (COUNT(*) returns string)

PG returns COUNT(*) as string. `"0" !== 0` breaks ALL null checks. Fix: parse numeric strings to int in camelRows.

## 3. Async Helper Call Sites (db param removal)

After removing `db` from helpers, ALL call sites must drop `db,`:
```bash
grep -rn "addPveRating(db,\|applyDecay(db,\|checkSeasonReset(db,\|getUserById(db,\|enrichEquipment(db," server/src/
```

## 4. Missing `await` on Async Functions

```bash
grep -rn "loadPlayerForBattle\|resolveCurrentRound\|isGuildAtWar" routes/ | grep -v "await "
```
Symptom: PM2 crash loop, `Object.values(undefined)` at currentStats.

## 5. `.map(async` → `Promise.all`

```bash
grep -rn "\.map(async" routes/ | grep -v "Promise.all"
```
Has await inside → wrap in Promise.all. No await → remove async.

## 6. SQLite Functions → PG

- `datetime(?)` → just `?`
- `datetime('now', '-5m')` → compute in JS
- `INSERT OR REPLACE` → `ON CONFLICT DO UPDATE`

## 7. Schema Types

- All date columns → TEXT (code mixes epoch ints and ISO strings)
- `steps` in battles → TEXT (stores JSON)

## 8. RETURNING id on Composite Keys

Use try/catch fallback in db.run() — tables without `id` column fail silently.

## 9. client.query().rows[0] not [0]

Inside db.tx(), client.query() returns QueryResult, not array.

## 10. Misc

- `recipeId || recipe_id` — client/server mismatch
- Arena "no opponents" → 200 not 404
- Seed: actions_config, floors
- Vite proxy → point to PG port (3002 for testing)
