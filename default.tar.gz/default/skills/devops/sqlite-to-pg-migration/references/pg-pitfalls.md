# PG Migration: Critical pitfalls (session-compiled)

## 1. `.map(async` → empty objects `{}`
`.map(async (x) => ({...}))` returns array of Promises. `JSON.stringify` on Promise = `{}`.
`res.json(users.map(async ...))` sends `[{},{},{}]`.

**Fix A** (no await in callback): Remove `async` — callback doesn't need it.
**Fix B** (has await): `const result = await Promise.all(items.map(async (x) => ...))`

## 2. Nested `.map(async` in tournament/guild
tournament.ts has `.map(async` inside `.map(async`:
```
allTournaments.map(async (t) => {
    ...
    matches: matches.map(async (m) => ({ ...await db... }))
})
```
Both levels need `await Promise.all()`. Inner closing needs extra `)`:
- Outer: `await Promise.all(allTournaments.map(async (t) => { ... }));`
- Inner: `await Promise.all(matches.map(async (m) => ({ ... }))),`

## 3. Async contamination chain → React #31
```
getUserById (async, not awaited) → Promise, not user
getBaseStats(user) → Promise, not {s,a,d,m}
currentStats(Promise, ...) → {s:null, a:null, ...}
applyHpRegen (async, not awaited) → Promise → JSON = {}
→ client gets `currentHp: {}`, React error #31
```
Fix: After bulk async conversion, run SECOND pass adding `await` at call sites for:
`getUserById`, `enrichEquipment`, `getBaseStats`, `applyHpRegen`, `findOrCreateUser`

## 4. Module-level `await db.prepare()`
tsx rejects: "Top-level await is currently not supported with cjs"
Remove `await` from `const getItemData = await db.prepare(...)` — `db.prepare()` is sync.

## 5. Multi-line db.prepare not caught by line-based regex
`const x = db.prepare(\n` with SQL on next line. Use perl slurp mode:
```
perl -0777 -i -pe "s/(?<!await )db\.prepare\(/await db.prepare(/g" file.ts
```

## 6. Sync helpers falsely made async
Functions WITHOUT `await db.` that were made async by bulk converter:
- `getBaseStats`, `getMaxHp`, `recalcHpOnEquip`, `calcElo`, `generateCode`
- `isGuestRestrictionsDisabled`, `setGuestRestrictionsDisabled`, `toggleGuestRestrictions`
Remove `async` from these.

## 7. Migration INSERT column quoting
DOUBLE-QUOTED column names: `"passwordHash"` → PG treats as case-sensitive, no match.
UNQUOTED lowercase: `passwordhash` → PG lowercases → matches column.
Fix migration script: `columns.map(c => c.toLowerCase()).join(', ')` — no quotes.

## 8. NULL vs empty string in PG
PG returns NULL; SQLite returns ''. Fix in `camelRows`:
```js
if (r[k] === null) {
    if (k === 'inventory') { r[k] = '[]'; continue; }
    if (k === 'equipment') { r[k] = '{}'; continue; }
    r[k] = '';
}
```

## 9. Missing tables from late migrations
SQLite tables not in initial DDL: `actions_config`, `auction_lots`, `bank_operations`,
`craft_recipe_categories`, `guild_war_attacks`, `order_members`, `orders`, `pve_battles`,
`stat_names`, `tournaments_new`, `transfers`, `upgrade_chances`.
Create them BEFORE migration using `PRAGMA table_info` to derive column types.

## 10. Transaction callbacks need async
`db.transaction(() => {` → `db.transaction(async () => {` if callback uses `await db.`.

## 11. WebSocket callbacks need async
`wss.on('connection', (ws) => {` → `wss.on('connection', async (ws) => {`
`ws.on('message', (raw) => {` → `ws.on('message', async (raw) => {`

## 12. Date parsing: `+ 'Z'` suffix breaks on PG timestamptz

**Symptom:** Cooldowns/protection timers never activate, `new Date()` returns `NaN`.

**Root cause:** PG returns timestamptz with timezone info already (e.g. `2026-01-15T10:30:00.000+00:00`). Adding `'Z'` creates `"...+00:00Z"` → invalid date → `NaN` → all comparisons fail silently.

**Wrong:**
```typescript
const lastTime = new Date(lastAttack.lastAt + 'Z').getTime();
```

**Right:**
```typescript
const lastTime = new Date(lastAttack.lastAt).getTime();
```

**Also:** Prefer unixtime (seconds) over ISO strings for cooldown/protection values in API responses. Client can compare directly: `remaining = cooldownUntil - serverTime`.

**Grep audit:** Search for `\+ 'Z'` in codebase — every instance is a bug on PG.

## 13. INSERT VALUES without columns — column shift

**Symptom:** `invalid input syntax for type integer` — a JSON array (battle log) is inserted where an integer column expects.

**Root cause:** `INSERT INTO battles VALUES (?, ?, ...)` omits the `id` column. In SQLite, `id` auto-increments and VALUES start from column 2. In PG, VALUES fill columns from position 1 — all values shift by one. The 4th value (JSON log) goes into the 4th column (winnerId, integer).

**Fix:** Always list columns explicitly:
```sql
INSERT INTO battles (attackerId, defenderId, winnerId, log, steps, ...) VALUES (?, ?, ?, ?, ?, ...)
```

**Grep audit:** Search for `INSERT INTO \w+ VALUES` without column list — must fix every instance.

## 14. Raw PG client queries return lowercase keys

**Symptom:** `sender.accountNumber` is `undefined` inside `db.tx()` callback.

**Root cause:** `db.tx(fn)` passes a raw `PoolClient`. `client.query()` returns PG-native lowercase column names. `db.query()`/`db.one()` apply `camelRows` converter, but `client.query()` does NOT.

**Fix:** Use lowercase property access in `db.tx()` callbacks:
```typescript
// Inside db.tx(async (client) => { ... }):
const row = (await client.query('SELECT bank, accountnumber FROM users WHERE id = $1', [id])).rows[0];
row.accountnumber // correct (lowercase)
row.accountNumber // undefined
```

Also use lowercase in SQL SELECT inside `db.tx()` for consistency.

## 15. camelCase suffix collisions

**Symptom:** `fromAccount`/`toAccount` show as `undefined` in transfer history.

**Root cause:** The `camelRows` suffix regex matches substrings — e.g. `count` at end of `fromaccount` → becomes `fromacCount` instead of `fromAccount`.

**Fix:** Add explicit full-key `.replace()` rules BEFORE the generic suffix regex:
```typescript
.replace(/^fromaccount$/i, 'fromAccount')
.replace(/^toaccount$/i, 'toAccount')
.replace(/^accountnumber$/i, 'accountNumber')
```

**Checklist for any missing camelCase field:**
1. Check raw PG column name (lowercase)
2. See if any suffix in the regex overlaps: `count`, `from`, `to`, `name`, `type`, `date`, `time`, `at`, `id`, `hp`, `log`, `data`, `wins`, `end`, `start`, `created`, `slot`, `icon`, `text`, `chat`, `guild`, `role`, `last`, `first`, `color`, `tier`, `code`, `xp`, `cost`, `fee`, `rate`, `url`, `path`, `size`, `width`, `height`, `tag`, `ip`, `made`, `round`, `expires`, `verified`, `drink`
3. Add explicit rule if collision found

## 16. Account number generation missing

**Symptom:** Transfer history shows "от undefined" because `fromAccount` is NULL.

**Root cause:** `accountNumber` TEXT column exists but no code generates values. Old users have them from a migration; new users get NULL.

**Fix — auto-generate on first access (idempotent):**
```typescript
if (!user.accountNumber) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let acc = '';
    for (let i = 0; i < 6; i++) acc += chars[Math.floor(Math.random() * chars.length)];
    await db.run('UPDATE users SET accountNumber = ? WHERE id = ?', [acc, userId]);
    user.accountNumber = acc;
}
```
Add to `GET /bank` and `POST /bank/transfer` (sender check).
