# pg-promise setup with better-sqlite3-compatible API

## Monkey-patch approach (quickest)

Replace database/index.ts entirely:

```ts
import pgPromise from 'pg-promise';

// CamelCase converter
function camelKeys(row: any): any {
  const out: any = { ...row };
  for (const key of Object.keys(row)) {
    const cc = key
      .replace(/(hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid)$/i, 
        m => m.charAt(0).toUpperCase() + m.slice(1))
      .replace(/taxrate$/i, 'TaxRate')
      .replace(/verified$/i, 'Verified');
    if (cc !== key) out[cc] = row[key];
  }
  return out;
}

const pgp = pgPromise();

const rawDb = pgp({
  host: process.env.PGHOST || 'localhost',
  port: parseInt(process.env.PGPORT || '5432'),
  database: process.env.PGDATABASE || 'game',
  user: process.env.PGUSER || 'game',
  password: process.env.PGPASSWORD || 'game123',
  max: 20,
});

// ? → $N converter
function pgParams(sql: string): string {
  let i = 0;
  return sql.replace(/\?/g, () => `$${++i}`);
}

// better-sqlite3-compatible statement
class Statement {
  private sql: string;
  constructor(sql: string) { this.sql = pgParams(sql); }
  async get(...params: any[]) {
    const rows = await rawDb.any(this.sql, params);
    return camelKeys(rows[0] || {});
  }
  async all(...params: any[]) {
    const rows = await rawDb.any(this.sql, params);
    return rows.map(camelKeys);
  }
  async run(...params: any[]) {
    const result = await rawDb.result(this.sql, params);
    return { changes: result.rowCount, lastInsertRowid: 0 };
  }
}

// Database object with prepare() method
const db = {
  prepare(sql: string) { return new Statement(sql); },
  exec(sql: string) { return rawDb.none(sql); },
  transaction<T>(fn: (() => Promise<T>)): Promise<T> {
    return rawDb.tx(async (t: any) => {
      const origAny = rawDb.any;
      rawDb.any = t.any.bind(t);
      try { return await fn(); }
      finally { rawDb.any = origAny; }
    });
  }
};

export default db;
export async function initDB() {}
```

## Route conversion required

ALL route handlers need `await` before `db.prepare(sql).get/all/run()`:

```
// BEFORE (SQLite sync):
db.prepare('SELECT * FROM users WHERE id = ?').get(userId)

// AFTER (PG async):
await db.prepare('SELECT * FROM users WHERE id = ?').get(userId)
```

ALL route handler callbacks need `async`:
```
// BEFORE:
router.get('/path', (req, res) => { ... await db.prepare(...).get(...) ... })

// AFTER:
router.get('/path', async (req, res) => { ... await db.prepare(...).get(...) ... })
```

Same for:
- `db.transaction(async () => { ... })` 
- `.map(async (item) => { ... await ... })` — wrap in `await Promise.all(...)` if result used as value
- `wss.on('connection', async (ws, req) => { ... })` and `ws.on('message', async (raw) => { ... })`

## Pitfall: module-level prepared statements

Statements like `const getItem = db.prepare(`SELECT...`)` at module level become async — call sites need `await getItem.get(params)`. If this is too invasive, redefine as arrow functions:

```
const getItem = (id: number) => db.prepare('SELECT * FROM items WHERE id = ?').get(id);
```

## Pros vs custom wrapper

pg-promise wrapper is ~60 lines vs ~200 for custom wrapper. No lowercaseSQL needed, no pgParams needed, no manual pool management, no transaction boilerplate. The ONLY conversion work is adding `await` and `async` to route files — which is unavoidable regardless of approach.
