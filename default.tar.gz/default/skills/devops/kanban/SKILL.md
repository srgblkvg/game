---
name: kanban
description: "Multi-agent Kanban workflow: orchestrator decomposition playbook + worker lifecycle, handoff patterns, retry diagnostics, and pitfalls."
version: 1.0.0
author: Hermes Agent (consolidated from kanban-orchestrator + kanban-worker)
license: MIT
platforms: [linux, macos, windows]
environments: [kanban]
metadata:
  hermes:
    tags: [kanban, multi-agent, orchestration, routing, collaboration, workflow, pitfalls]
---

# Kanban Multi-Agent Workflow

Hermes Kanban is a durable SQLite-backed multi-agent work queue. This skill covers both roles: the **orchestrator** (decomposes and routes work) and the **worker** (executes tasks with proper handoffs).

> The core worker lifecycle and kanban_create fan-out pattern are auto-injected into every kanban worker's system prompt as KANBAN_GUIDANCE. This skill is the deeper playbook.

---

## Section 1: Orchestrator — Decomposition & Routing

### When to Use the Board (vs. Just Doing the Work)

Create Kanban tasks when any of these are true:
1. **Multiple specialists are needed.**
2. **The work should survive a crash or restart.**
3. **The user might want to interject.** Human-in-the-loop at any step.
4. **Multiple subtasks can run in parallel.** Fan-out for speed.
5. **Review / iteration is expected.**
6. **The audit trail matters.**

If *none* apply — it's a one-shot task — use `delegate_task` instead or answer directly.

### Step 0: Discover Available Profiles

The dispatcher silently fails to spawn unknown assignee names. Before fanning out, discover what profiles exist:
- `hermes profile list` — prints configured profiles
- `kanban_list(assignee="<name>")` — sanity-check a single name
- Just ask the user: "What profiles do you have set up?"

### The Anti-Temptation Rules

- **Do not execute the work yourself.**
- **For any concrete task, create a Kanban task and assign it.**
- **Split multi-lane requests before creating cards.** Extract lanes first.
- **Run independent lanes in parallel.** No parent links needed.
- **Never create dependent work as independent ready cards.** Use `parents=[...]`.
- **Do not invent profile names.** Dispatcher drops unknown assignees silently.
- **Decompose, route, and summarize — that's the whole job.**

### Decomposition Playbook

1. **Understand the goal** — ask clarifying questions if ambiguous.
2. **Sketch the task graph** — draft the lanes, map to profiles, identify dependencies.
3. **Create tasks with links** — parent cards first, capture IDs, use in child `parents`:

```python
t1 = kanban_create(title="research: ...", assignee="<profile-A>", body="...")["task_id"]
t2 = kanban_create(title="research: ...", assignee="<profile-A>", body="...")["task_id"]
t3 = kanban_create(title="synthesize", assignee="<profile-B>", body="...", parents=[t1, t2])["task_id"]
```

4. **Complete your own task** with a summary of what you created.
5. **Report back to user** — plain prose naming actual profiles.

### Common Patterns

- **Fan-out + fan-in:** N research-style cards with no parents → one synthesis card with all as parents.
- **Parallel implementation + validation:** implementer card + explorer/researcher card → reviewer gates on both.
- **Pipeline:** `planner → implementer → reviewer` — each stage's `parents=[previous]`.
- **Same-profile queue:** N tasks, same assignee, no deps → dispatcher serializes.
- **Goal-mode cards:** `goal_mode=True` for open-ended cards — judge re-evaluates after each turn.

### Recovering Stuck Workers

Dashboard ⚠ badge flags stuck tasks:
1. **Reclaim** — `hermes kanban reclaim <task_id>` — abort + reset to `ready`
2. **Reassign** — `hermes kanban reassign <task_id> <new-profile> --reclaim`
3. **Change model** — edit profile config, then Reclaim to retry

---

## Section 2: Worker — Lifecycle & Handoffs

### Workspace Handling

| Kind | What it is | How to work |
|---|---|---|
| `scratch` | Fresh tmp dir | Read/write freely; GC'd on archive |
| `dir:<path>` | Shared persistent dir | Other runs will read what you write |
| `worktree` | Git worktree | `git worktree add` if .git missing, then work normally |

### Tenant Isolation

If `$HERMES_TENANT` is set, prefix memory entries with the tenant to prevent cross-tenant context leaks.

### Good Handoff Shapes

**Coding task:**
```python
kanban_complete(
    summary="shipped rate limiter — token bucket, 14 tests pass",
    metadata={"changed_files": ["rate_limiter.py", "tests/test_rate_limiter.py"], "tests_run": 14, "tests_passed": 14},
)
```

**Review-required (block instead of complete):**
```python
kanban_comment(body="review-required handoff:\n" + json.dumps({"changed_files": [...], "tests_run": 14, ...}))
kanban_block(reason="review-required: rate limiter shipped — needs review before merge")
```

**Research task:**
```python
kanban_complete(
    summary="3 libraries reviewed; vLLM wins on throughput",
    metadata={"sources_read": 12, "recommendation": "vLLM"},
)
```

### Claiming Created Cards

Pass `created_cards=[c1["task_id"], c2["task_id"]]` with IDs captured from `kanban_create` return values. Never invent IDs from prose or claim cards another worker created.

### Block Reasons That Get Answered

Bad: `"stuck"` — no context.
Good: one sentence naming the specific decision. Leave context as a comment.

```python
kanban_comment(body="Full context: IP-based keying causes false positives on NATs...")
kanban_block(reason="Rate limit key: IP (NAT-unsafe) or user_id (requires auth)?")
```

### Heartbeats

Good: `"epoch 12/50, loss 0.31"`, `"scanned 1.2M/2.4M rows"`.
Bad: `"still working"`, empty notes, sub-second intervals.

### Retry Diagnostics

Check prior runs via `kanban_show`:
- `timed_out` → chunk the work
- `crashed` → reduce memory
- `spawn_failed` → profile config issue, `kanban_block` to ask human
- `reclaimed` → task was archived out from under the worker
- `blocked` → unblock comment should be in thread

### Do NOT

- Call `delegate_task` as substitute for `kanban_create`
- Call `clarify` — use `kanban_comment` + `kanban_block` instead
- Modify files outside `$HERMES_KANBAN_WORKSPACE`
- Create follow-up tasks assigned to yourself
- Complete a task you didn't finish — block it instead

### Pitfalls

- **Task state can change between dispatch and startup.** Always `kanban_show` first.
- **Workspace may have stale artifacts.** Read the comment thread for context.
- **Don't rely on CLI when tools are available.** `kanban_*` tools work across all backends; `hermes kanban <verb>` doesn't in containerized backends.
