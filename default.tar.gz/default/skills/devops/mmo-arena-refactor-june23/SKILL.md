---
name: mmo-arena-refactor-june23
description: Рефакторинг MMO Arena, баланс, бестиарий, постройки, логин, правила — 23-24 июня 2026
---

# Рефакторинг MMO Arena — 23 июня 2026

## 1. Статы → PRIMARY_STATS + F + sv()
- Конфиг `F` — единственное место правки имён статов в формулах
- Добавить стат: `PRIMARY_STATS` + `F` + `StatRecord`. Формулы не трогаем

## 2. buildPlayerStats(userRow, context)
- Все бонусы в одном вызове (base + equip + drinks + collection + guild)
- Заменён ручной `currentStats` в: character, battle, arena, mobs, tavern, users, tournament
- Клиент НЕ считает статы — всегда `character.stats`

## 3. toCharCardData(character, overrides)
- Единая фабрика для LeftSidebar, Arena, Bestiary
- CharacterCard показывает гильд-здания раздельно

## 4. USER_FIELDS константы
- `USER_BATTLE_FIELDS`, `USER_BATTLE_FIELDS_GUILD`, `USER_ARENA_FIELDS_GUILD`
- Новое поле в users → править только константу

## 5. Гильдия — сплит (1163→19 строк)
- `routes/guild/`: Core, Members, Chat, Treasury, War, Quests
- **Техника сплита**: Node.js `lines.slice()` на VPS (не `sed` — ненадёжен)
- Импорты в поддиректориях: `../../db/index`
- Экспорты: `export async function isGuildAtWar`, `export async function updateGuildQuestProgress`

## 6. GuildPage — переписан (869→256 строк, -70%)
- 4 вкладки: Обзор, Постройки, Казна, Участники
- Герб + загрузка, описание + редактирование, смена типа для лидера
- Участники: 👑/🛡️/⚔️, Повысить/Разжаловать/Исключить, приглашения во вкладке
- **⚠️ Patch-хрупкость JSX**: файлы >500 строк НЕ патчить. Писать с нуля через `write_file`. Patch на минифицированном JSX ломает структуру — 8+ откатов за сессию.
- **⚠️ heredoc**: на VPS через `cat >> ... << 'EOF'` надёжнее patch, но только для append. Не `ssh root bash -s << 'SPLIT'` — ломает JSON.stringify и шаблонные строки.
- **⚠️ `node -e`**: нестабилен на VPS (экранирование `$`, `Bearer `). Для сложных скриптов — `write_file` локально → `scp` → `ssh node file.js`.
- **Счётчики на клиенте**: ВСЕГДА из API (`myLotCount`), НЕ считать из `array.filter()` на пагинированном массиве.

## 7. Постройки — полная система
- `getGuildBuildings()`: ВСЕ 4 типа (построенные + нет) с cost, reqLevel, canBuild
- `buildBuilding(userId, type)`: проверка казны + уровня, INSERT или UPDATE
- Эндпоинт: `POST /guild/buildings/build`
- Buildings внутри `data.guild.buildings` (не на верхнем уровне)

## 8. Казна — периоды + ники
- `GET /guild/treasury/history?period=today|week|month|all`
- JOIN users для username, фильтр `userid > 0` (system id0)
- **⚠️ PG pitfall**: `createdat` — TEXT. Сравнение: `createdat >= '2026-06-23T00:00:00.000Z'`. НЕ `datetime()` (SQLite) или `to_timestamp()` (требует TIMESTAMP).
- Клиент: автозагрузка при `tab === 2` через `useEffect`

## 9. parseEquipment()
- `parseEquipment(eq?: string|null)` — с try/catch, замена `JSON.parse(x.equipment||'{}')`

## 10. Турниры + гильд-квесты — live WS
- Турниры: `broadcast('tournamentCreated')` → ChatContext dispatch → TournamentBanner
- Квесты: авто-левелап `exp >= 100*2^(level-1)`, события `guildExp`/`guildLevelUp`

## 12. Баланс — HP и капы
- HP = S+A+M (D исключена — защита даёт блок)
- Extra-статы: soft cap `x/(x+300)` вместо `x/300`
- Блок: кап 75% вместо 100%
- Extra-статы получают множитель улучшения (был баг — только primary)

## 13. Логин — редизайн
- Главная: никнейм → игра (без пароля)
- `/login-classic` — email+пароль (гостевой вход убран)
- OAuth → +3 дня премиума
- Красная точка на шестерёнке для гостей/без премиума

## 14. Правила и документы
- `/rules` — правила игры (честная игра, баги, один аккаунт, последствия)
- `/privacy` — обработка данных (6 пунктов)
- `/wiki` — гайд встроен в приложение
- **Баг 1**: `COUNT(*)` без фильтра — считал ВСЕ лоты (включая проданные/истекшие)
- **Баг 2**: `status = 'active'` — колонки `status` нет в таблице
- **Баг 3**: `endsat > NOW()` — PG: `integer > timestamp` несовместимы
- **Баг 4**: Клиент считал `lots.filter(l => l.sellerId === id).length` — только на текущей странице (6 из 12)
- **Фикс**: `sellerId = ? AND endsat > ?` с Unix-таймстемпом + `myLotCount` в ответе сервера
- **Правило**: Счётчики на клиенте — ТОЛЬКО из API (не фильтровать пагинированный массив)

## Баги (17)
- guildChat `require('../websocket')` → битый путь при отправке
- markDirty из websocket → events (mobs)
- guild TS: `any|null` → `Promise<any>`, undefined index
- tournament: `Promise<number>`, экспорты
- battleSim: `collCnt?.cnt` на number
- arena/tavern/users: мёртвые импорты
- treasury: `datetime()` → `createdat >= 'ISO'` (PG TEXT)
- buildings: `data.buildings` → `data.guild.buildings`

## 8. Боевой баланс (24 июня)
- **HP = S+A+M** (защита исключена — даёт блок, не HP). Сервер + клиент синхронизированы.
- **Блок**: кап 75% (был 100%)
- **Extra-статы**: мягкий кап `x/(x+300)` вместо `x/300` — защита от бесконечного скейлинга
- Затронуты: dodge, crit, block, counter, fullBlock — все используют мягкий кап
- `blockChance: Math.min(0.75, ...)` + `fullBlockChance: fb/(fb+300)`
- `counterChance: extraBonus/(extraBonus+300)`
- **Extra-статы получают множитель улучшения** — был баг: `item.extra[k]` не умножалось на `multiplier`. Вынес `multiplier` на уровень выше в цикле.

## 11. Клиент — sumStats удалён
- Клиентский `sumStats(s: StatRecord)` считал HP как S+A+D+M
- Убран из CharacterCard: `char.maxHp ?? stats.hp ?? 0` (было `?? sumStats(stats)`)
- `calculateStats()` в stats.ts помечен deprecated — клиент всегда берёт `stats.hp` с сервера
- **Правило**: клиент НЕ вычисляет HP/статы. Единственный источник — `character.stats.hp`

## 12. BattleSim — убран дубликат
- buildPlayerStats(u1, 'arena') вместо ручных getDrinkBonuses/getGuildBonus/COUNT
- runBattle принимает stats?: CharStats — без пересчёта currentStats

## 13. Bestiary — группы сложности (серверный подход)
- **Сервер**: `/api/floors` возвращает `{ floors: [{...difficulty:0-3}], groups: [{label,icon,difficulty}] }`
- **Клиент**: читает `groups` из API, группирует по `difficulty`, рендерит `FloorGroup` с раскрытием ▶/▼
- **Принцип**: НИКОГДА не хардкодить данные на клиенте, если сервер может их отдать
- **Техника замены JSX**: Python `lines[:start] + new_lines + lines[end+1:]` + `write_file` — надёжнее patch
- **LocalStorage persistence**: `useState(() => { const s = localStorage.getItem(k); return s !== null ? s === '1' : false })` + toggle сохраняет. По умолчанию свёрнуто.
- **Защита от undefined**: `{(arr || []).map(...)}` — все .map() с fallback, иначе краш при асинхронной загрузке
- **Регистронезависимый поиск**: API-имена могут отличаться регистром → `floors.some(f => f.toLowerCase() === name.toLowerCase())`

## 14. calculateStats — полностью удалён с клиента
- BestiaryPage использовал `calculateStats(character, ...)` без гильд-бонуса → maxHP был ниже серверного
- Заменён на `character.stats` — серверные значения со ВСЕМИ бонусами
- `sumStats` на клиенте удалён из CharacterCard: `char.maxHp ?? stats.hp ?? 0`
- Импорт `calculateStats` удалён из BestiaryPage
- **Правило усилено**: клиент НИКОГДА не вычисляет статы. Единственный источник — `character.stats`

## 15. Логин / онбординг — переработка
- **Новая страница входа**: приветствие → никнейм (без пароля) → игра
- Сервер: `POST /guest` принимает `{ nickname }`, проверка уникальности `SELECT COUNT(*) WHERE username = ?`
- Классический вход: `/login-classic` (старый email+пароль)
- Мобильный отступ: `pt-16 sm:pt-0` — не примыкает к верхнему краю
- **OAuth премиум**: при создании нового OAuth-юзера — `premiumUntil = now + 3*86400`
- **Нотификации**: красная точка на шестерёнке если `user.isGuest || !character?.premium`
- **Баннер в меню**: «Привяжите аккаунт — 3 дня премиума» + кнопки Яндекс/VK
- **Баннер на странице Аккаунта**: для гостей — призыв к привязке
- **Регистрация**: убрано поле «Логин» — только email + пароль. Логин = email.
- Кнопки OAuth: без лишних символов, чистые Яндекс ID / VK ID

## 16. Правила и приватность
- `/rules` — 4 пункта: честная игра, баги, один аккаунт, последствия
- `/privacy` — 6 пунктов: данные, использование, НЕ делаем, хранение, согласие, контакты
- LoginPage: ссылки на обе страницы, текст крупнее (0.7rem), форматирование с переносами
- Текст: «Нажимая «⚔️ В бой!», вы принимаете **правила игры** и соглашаетесь на **обработку данных**»
- Куки: НЕ используются для пользовательских данных. Только CSRF-токен (техническая кука). Всё на localStorage.

## 18. Гостевой вход — возврат по нику
- Существующий гость может войти повторно: `SELECT id, isGuest WHERE username = ?`
- Если `isGuest=1` → выдаём токен для существующего аккаунта
- Если `isGuest=0` → «никнейм уже занят зарегистрированным пользователем»
- Регистрация через `/account/register-guest` НЕ меняет username (сохраняет ник с логина)\n- Поле «Логин» убрано из формы регистрации — только email + пароль\n- Классический вход `/login-classic`: убран гостевой вход\n- Гильд-квесты: `GET /guild/quest` для юзера без гильдии → `{ activeQuest: null }` (не 400)\n- **Баннер привязки**: условие ТОЛЬКО `user.isGuest`. НЕ `user.isGuest || !character?.premium` — после регистрации `isGuest=false` обновляется мгновенно из auth context, а `character` может не успеть загрузиться.\n- **Email-регистрация тоже даёт премиум**: `UPDATE users SET premiumUntil = now + 3*86400` в register-guest

## 14. PG datetime pitfall (TEXT колонки)
- `createdat` в `guild_treasury_log` — TEXT, не TIMESTAMP
- Правильное сравнение: `createdat >= '2026-06-23T00:00:00.000Z'` (ISO строка)
- НЕ использовать: `datetime()` (SQLite), `to_timestamp()` (требует TIMESTAMP колонку), `NOW()` (PG timestamp vs integer)
- См. `references/pg-datetime-pitfalls.md` и `references/auction-pitfalls.md`

## 15. Премиум — страница и баги (финализировано)
- `/premium` — публичная страница (без авторизации). Оферта, реквизиты, выбор тарифа.
- Тарифы: 7 дней 99₽, 30 дней 299₽. Кнопки видны всегда (можно продлить).
- Продавец: Беляков Сергей Русланович, ИНН 253715362700, email srgblkvvl@ya.ru
- Системный юзер yukassa УДАЛЁН — страница публичная, не нужен.
- Баги: `applyHpRegen` без premiumUntil, `lastHpUpdate` не в API, equip без stats, email-рег без премиума
- См. `references/hp-regen-premium.md` и `references/premium-page.md`

## 17. Гильдия — война
- При активной войне: кнопка «⚔️ На поле боя» → `/guild/war`
- GuildWarPage: враги (атака), союзники (статистика), ход войны (лог)
- Лимиты: 3 атаки на игрока, 3 атаки всего, кулдаун между атаками

## ПРАВИЛА (НЕ НАРУШАТЬ)
- **buildPlayerStats(userRow, context) — ЕДИНСТВЕННАЯ функция получения статов**
- НЕ вызывать currentStats в роутах
- НЕ импортировать getDrinkBonuses/getGuildBonus/getBaseStats/enrichEquipment в роутах
- runBattle принимает stats?: CharStats — всегда передавать pre-computed из buildPlayerStats
- Клиент НЕ вычисляет статы — character.stats
- Новый стат → PRIMARY_STATS + StatRecord + F
- Новое поле users → USER_BATTLE_FIELDS
- CharacterCard → toCharCardData()
- Гильдия → новый файл в routes/guild/
- JSX >500 строк → `write_file` с нуля, не `patch`
- `JSON.parse(eq||'{}')` → `parseEquipment(eq)`
- PG даты → ISO-строки для TEXT колонок
- `treasury_history` → `userid > 0`
- Спред данных → без костылей (внутри объекта, не на верхнем уровне)
- Счётчики на клиенте → только из API (не filter на пагинированном массиве)
- QuestsBlock → всегда показывает блок, даже без активных заданий
- equipItem → ВСЕГДА возвращать `stats` в ответе. Клиент применяет `data.stats` сразу.
- HP snapshot: `_hpSnapshot = { hp: character.currentHp, time: character.lastHpUpdate || serverTime }`. НЕ `serverTime` для time — иначе реген считается от загрузки, а не от последнего сохранения HP.
- `applyHpRegen` → всегда передавать `premiumUntil` (иначе премиум-реген не работает)
- `character/me` → всегда возвращать `lastHpUpdate` в ответе API
- `registerGuest` → НЕ менять username. Сохранять ник с логина. `premiumUntil = now + 3*86400`

## BackButton / Header / UI-компоненты
- **BackButton**: убран Icon, только текст `← Назад`. Импорт: `import BackButton from '../components/BackButton'`. Заменять кастомные кнопки-назад на единый компонент.
- **PlayerBadge**: `components/PlayerBadge.tsx` — аватар+ник+HP-бар. Принимает `avatar, username, level, gender, currentHp, maxHp, hpPct`. Кликабельный (cursor-pointer, navigate('/')).
- **Хедер — XP/HP бары**: XP-bar: `absolute top-0 h-1 bg-[var(--color-accent-purple)]` (формула: `10*Math.pow(2,level-1)`). HP-bar: `h-1 bg-[var(--color-accent-danger)]` с `getRegenHp()`.
- **Хедер — аватар/ник/время**: `PlayerBadge` слева, время по центру через `absolute left-1/2 -translate-x-1/2`.
- **VK header offset**: `--vk-top-offset: env(safe-area-inset-top, 0px)` (без принудительных 54px). Хедер `fixed top-0`, не `padding-top`.

## camelRows — lastLoginAt
- `camelRows` в `server/src/db/index.ts` конвертирует `lastloginat` → `lastLoginAt` через `.replace(/lastloginat$/i, 'lastLoginAt')`
- PG возвращает имена колонок в lowercase → нужны явные правила для CamelCase-имён с несколькими словами

## Админка — пагинация и картинки
- **Пагинация 10 элементов**: `const [page, setPage] = useState(1); const LIMIT=10; const total=Math.ceil(items.length/LIMIT); const paged=items.slice((page-1)*LIMIT, page*LIMIT);`
- **Картинки в таблицах**: колонка `<th className="w-10">` + `<td>{item.image && <img src={item.image} className="w-8 h-8 object-cover rounded"/>}</td>`
- **Поля с картинками**: `item.image` (предметы), `item.bg_image` (действия), `item.background` (работы/мобы/этажи), `item.avatar` (игроки)
- **Клик → заполнить ID**: `onClick={() => { setInput1(String(row.senderId)); setInput2(String(row.id)); }}` с `cursor-pointer hover:bg-...`
- **Компактные действия**: `grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4` для 4 блоков в ряд
- **Подписи над инпутами**: `<label className="text-[0.6rem] text-[var(--color-text-muted)]">ID игрока</label>`
- **Сортировка**: `[...items].sort((a,b) => (a.field||'').localeCompare(b.field||''))` перед slice

## WS баланс — мгновенное обновление
- Клиент: в ChatContext добавить `case 'balance': window.dispatchEvent(new CustomEvent('balance', { detail: { money: data.money, bank: data.bank||0 } }));`
- Сервер: `import { sendToUser } from '../events';` + после транзакции `sendToUser(userId, { type: 'balance', money: updated.money, bank: updated.bank });`
- Применять в: bank deposit/withdraw, guild treasury deposit, любых операциях меняющих money

## VK клавиатура — числовые инпуты
- **Блокировка нативной клавиатуры**: `const isVK = document.documentElement.classList.contains('vk-iframe'); const inputType = isVK ? 'text' : 'number';` — в VK использовать `type="text"`
- **Фильтр только цифр**: `onChange={e=>{const v=e.target.value.replace(/\D/g,''); setValue(v)}}` — вырезать всё кроме цифр
- **Авто-цифровая раскладка**: `data-vk-num` атрибут на input — VkKeyboard переключится на цифры
- **Enter на VK-клавиатуре**: диспатчит KeyboardEvent с `bubbles: true, cancelable: true` + `setTimeout(() => setActive(null), 50)` — задержка чтобы input успел обработать
- Не вешать `data-vk-num` на поля где нужны буквы (никнейм, название гильдии и т.д.)

## Рейтинг гильдий
- Сортировка: `ORDER BY g.level DESC, g.exp DESC` (не по казне)
- Отображение: герб гильдии `g.image` справа от названия `w-8 h-8 object-contain rounded`, без медалек (просто #rank)
