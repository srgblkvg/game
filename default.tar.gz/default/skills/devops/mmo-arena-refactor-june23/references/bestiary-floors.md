# Bestiary Difficulty Groups — Server-Side Approach

## Principle
NEVER hardcode data on the client. Server returns structured data, client renders.

## Implementation
### Server: `/api/floors` (setupRoutes.ts)
Returns `{ floors: [{...difficulty:0-3}], groups: [{label,icon,difficulty}] }`

Difficulty map on server:
```typescript
const DIFF_MAP: Record<string,number> = {
    'Склеп':0,'Подземелье':0,'Катакомбы':0,'Деревня Пепла':0,
    'Лес Черепов':1,'Старый Тракт':1,'Ядовитые луга':1,'Первый ярус':1,
    'Гнилая Топь':2,'Чёрный Монастырь':2,'Башня Плакальщиц':2,'Некрополь Королей':2,
    'Бездонный Овраг':3,'Врата Бездны':3,
};
```

### Client: BestiaryPage.tsx
- Fetches `/api/floors` → `data.groups` and `data.floors`
- Groups floors by `difficulty` field
- Renders `FloorGroup` component per group
- Expand/collapse with localStorage persistence: `floor_Легко`, `floor_Нормально`, etc.
- Default: collapsed (`false`)
- Arrow indicators: ▶ collapsed, ▼ expanded
- Case-insensitive matching for safety

## Pitfalls
- `.map()` on undefined → `(arr || []).map(...)` for async data
- Case mismatch between API floor names and UI labels
- localStorage key collision — prefix with `floor_`
