# Аукцион — pitfalls

## Счётчик активных лотов
- `endsat` — INTEGER (Unix timestamp), не TIMESTAMP
- Сравнение: `endsat > ?` с `Math.floor(Date.now()/1000)`, НЕ `endsat > NOW()`
- Колонки `status` НЕТ — active = `endsat > now`
- `COUNT(*)` без фильтра `endsat` считает ВСЕ лоты (включая проданные/истекшие)

## Клиентский счётчик
- НЕ `lots.filter(l => l.sellerId === id).length` — только на текущей странице
- Сервер должен возвращать `myLotCount` в ответе GET /auction
