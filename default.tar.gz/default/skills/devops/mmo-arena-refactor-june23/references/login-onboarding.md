# Login / Onboarding Reference

## Architecture
- `/login` — Welcome + nickname → POST /api/guest { nickname } → game
- `/login-classic` — Email + password → POST /api/login → game
- `/register` — Available but hidden from main flow
- `/account` → Email registration for guests: email + password only

## Guest flow
1. User enters nickname on /login
2. POST /api/guest { nickname: "Игрок" }
3. Server checks: `SELECT id, isGuest FROM users WHERE username = ?`
   - If isGuest=1 → return token for existing account
   - If isGuest=0 → "никнейм уже занят"
   - If not found → INSERT new guest user
4. Token stored in localStorage, user redirected to /

## Registration flow (guest → registered)
1. Guest visits /account → sees premium banner
2. Enters email + password → sends verification code
3. Enters code → POST /api/account/register-guest { email, password, code }
4. Server: `UPDATE users SET passwordHash, email, emailVerified=1, isGuest=0, premiumUntil=now+3*86400`
5. Username NOT changed — keeps the nickname from login page

## Premium rules
- OAuth registration → +3 days premium (in `findOrCreateUser`)
- Email registration → +3 days premium (in `/account/register-guest`)
- Banner shows only for `user.isGuest` (not `!character?.premium`)

## Key pages
- `/rules` — 4 rules: fair play, bugs, one account, consequences
- `/privacy` — 6 sections: data collected, usage, what we DON'T do, storage, consent, contacts
- `/wiki` — guide embedded in app
