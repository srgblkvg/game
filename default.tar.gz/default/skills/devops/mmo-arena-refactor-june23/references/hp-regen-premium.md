# HP-реген и премиум — баги и фиксы

## applyHpRegen не получал premiumUntil
- **Баг**: в `character.ts` и `battle.ts` вызов `applyHpRegen({...})` не передавал `premiumUntil`
- **Симптом**: премиум-реген (×3, как чулан) не работал несмотря на активный премиум
- **Фикс**: добавить `premiumUntil: user.premiumUntil` в вызов

## lastHpUpdate не возвращался в character response
- **Баг**: `/character/me` не включал `lastHpUpdate` в JSON
- **Симптом**: клиентский `getRegenHp` использовал `serverTime` вместо реального времени последнего сохранения HP → неточный реген
- **Фикс**: добавить `lastHpUpdate: user.lastHpUpdate || 0` в `res.json({...})`

## Клиентский снапшот HP использовал serverTime
- **Баг**: `_hpSnapshot.time = serverTime` (текущее время) вместо `character.lastHpUpdate`
- **Фикс**: `_hpSnapshot = { hp: character.currentHp, time: character.lastHpUpdate || serverTime }`
- Зависимость useEffect: только `[character]` (не `[character, serverTime]`)

## equipItem не возвращал stats
- **Баг**: `POST /character/equip` возвращал `{inventory, equipment, currentHp, maxHp}` без `stats`
- **Симптом**: при надевании/снятии предмета карточка персонажа не обновляла статы до перезагрузки
- **Фикс**: добавить `stats: newStats` в оба ответа (equip и unequip)
- Клиент: `setCharacter({..., stats: data.stats ?? character.stats})`

## Email-регистрация не давала премиум
- **Баг**: `registerGuestSchema` требовал поле `username`, `UPDATE` запрос не включал `premiumUntil`
- **Фикс**: убрать `username` из схемы, добавить `premiumUntil = now + 3*86400` в UPDATE
- Логин теперь всегда из ника (заданного на странице входа), email только для восстановления
