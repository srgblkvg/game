# PG datetime pitfalls for TEXT columns

## Problem
Some legacy columns use TEXT type for dates instead of TIMESTAMP.
This causes type mismatch errors with PG date functions.

## Common mistakes

### `createdat >= NOW()` — FAILS
```
error: operator does not exist: text >= timestamp with time zone
```
**Fix**: `createdat >= '2026-06-23T00:00:00.000Z'` (ISO string)

### `createdat >= to_timestamp(1750000000)` — FAILS
```
error: function to_timestamp(integer) does not exist
```
Only works if column IS timestamp. With TEXT: use ISO string.

### `endsat > NOW()` — FAILS (integer column)
```
error: integer > timestamp with time zone
```
`endsat` is Unix timestamp (integer). Compare with integer: `endsat > ?` + `Math.floor(Date.now()/1000)`

## Correct patterns

| Column type | Query | JS value |
|-------------|-------|----------|
| TEXT (ISO dates) | `col >= '2026-06-23T00:00:00.000Z'` | `new Date().toISOString()` |
| INTEGER (Unix ts) | `col > $1` | `Math.floor(Date.now()/1000)` |
| TIMESTAMP | `col >= NOW()` | — |

## Files affected
- `guild_treasury_log.createdat` — TEXT
- `auction_lots.endsat` — INTEGER
- `auction_lots.createdat` — TEXT
