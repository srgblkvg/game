# Client-Side Request Reduction

## HistoryPage: `fetchAllPrivateMessagesNew()` → batch
The original HistoryPage made N+1 API calls on mount (one per conversation peer). Replace with a single endpoint:

```tsx
// BEFORE: N+1 calls
import { fetchAllPrivateMessagesNew } from '../api/chat';
// ...
fetchAllPrivateMessagesNew().then(msgs => msgs.filter(m => m.targetId === user.id))

// AFTER: 1 call
fetch(`${BASE_URL}/chat/recent?limit=50`, { headers: getHeaders() })
  .then(r => r.json())
  .then(msgs => msgs.filter((m: any) => m.targetId === user.id))
```

Also reduce limits on parallel fetches:
```tsx
// BEFORE
fetchBattles(100)
fetch(`${BASE_URL}/log/pve-battles?limit=100`, ...)
fetch(`${BASE_URL}/log/tournament-history?limit=50`, ...)
fetch(`${BASE_URL}/log/quest-history?limit=50`, ...)

// AFTER
fetchBattles(30)
fetch(`${BASE_URL}/log/pve-battles?limit=30`, ...)
fetch(`${BASE_URL}/log/tournament-history?limit=20`, ...)
fetch(`${BASE_URL}/log/quest-history?limit=20`, ...)
```

Result: 25+ API calls → 5 parallel calls, page loads in <1s instead of 10+s.

## AuctionPage: defensive array check
```tsx
// BEFORE: crashes if API returns error object
setLots(data.lots);

// AFTER
setLots(Array.isArray(data.lots) ? data.lots : []);
```

## General principle
When a page makes parallel `Promise.all([...])` on mount, check each call:
- Is `fetchAllXNew()` making a loop of sub-requests? Replace with batch endpoint.
- Are limits unnecessarily large (100, 50)? Reduce to 20-30 unless pagination is explicit.
