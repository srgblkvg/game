# Tournament Query Batching Pattern

## Problem
`GET /api/tournament` was making 200+ DB queries: for each tournament (20), query participants + matches, then for each match (3-8), query 3 player names individually. Result: 10+ seconds, server OOM under load.

## Before (N+1 per match per player)
```ts
const result = await Promise.all(tournaments.map(async (t) => {
  const participants = await db.query(/* per tournament */);
  const matches = await db.query(/* per tournament */);
  return {
    ...t,
    matches: await Promise.all(matches.map(async (m) => ({
      ...m,
      player1Name: m.player1Id ? (await db.one('SELECT username FROM users WHERE id = ?', [m.player1Id]))?.username : null,
      player2Name: m.player2Id ? (await db.one('SELECT username FROM users WHERE id = ?', [m.player2Id]))?.username : null,
      winnerName: m.winnerId ? (await db.one('SELECT username FROM users WHERE id = ?', [m.winnerId]))?.username : null,
    }))),
  };
}));
```

## After (batch all matches + batch all names)
```ts
// 1. One query for ALL matches across ALL tournaments
const allMatches = await db.query(
  `SELECT * FROM tournament_matches WHERE tournamentId IN (${tournaments.map(() => '?').join(',')})`,
  tournaments.map(t => t.id)
);

// 2. Collect all player IDs
const playerIds = new Set<number>();
for (const m of allMatches) {
  if (m.player1Id) playerIds.add(m.player1Id);
  if (m.player2Id) playerIds.add(m.player2Id);
  if (m.winnerId) playerIds.add(m.winnerId);
}

// 3. One query for ALL names
const playerNames = new Map<number, string>();
if (playerIds.size > 0) {
  const ids = [...playerIds];
  const users = await db.query(
    `SELECT id, username FROM users WHERE id IN (${ids.map(() => '?').join(',')})`,
    ids
  );
  for (const u of users) playerNames.set(u.id, u.username);
}

// 4. Use Map for O(1) lookups — no more per-row queries
const result = tournaments.map(t => ({
  ...t,
  matches: allMatches.filter(m => m.tournamentId === t.id).map(m => ({
    ...m,
    player1Name: m.player1Id ? playerNames.get(m.player1Id) : null,
    player2Name: m.player2Id ? playerNames.get(m.player2Id) : null,
    winnerName: m.winnerId ? playerNames.get(m.winnerId) : null,
  })),
}));
```

## Result
- Queries: 200+ → 13 (2 batch + 1 per tournament for participants, max 10 tournaments)
- Response time: 10+ seconds → 0.8ms
- Also removed `getOrCreateTournament()` (tournament creation on every GET) and `autoAdvance()` from the read path.

## Tournament auto-creation timer
Since creation/advancement is removed from the GET handler, add a 5-minute interval in `index.ts`:
```ts
// ── Создание турниров и авто-продвижение (раз в 5 минут) ──
setInterval(async () => {
  try {
    const mod = await import('./routes/tournament');
    await mod.getOrCreateTournament();
    const all = await db.query(
      "SELECT * FROM tournaments WHERE status IN ('registration', 'in_progress') ORDER BY id DESC",
      []
    ) as any[];
    for (const t of all) await mod.autoAdvance(t.id);
  } catch {}
}, 5 * 60 * 1000);
```
This MUST be added whenever `getOrCreateTournament()` is removed from the GET handler — otherwise no new tournaments will ever be created.

## Completed tab: reduce limit
Same batching pattern applies. Also reduce `LIMIT` from 20 to 5 — the completed handler makes the same N+1 per-match name lookups:
```ts
const limit = 5; // was 20
```
The total handler is shared (active + completed use same per-tournament response builder). The `LIMIT 10` on active tab prevents runaway queries even if there are many active tournaments.
