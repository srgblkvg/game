# WebSocket serverTick Batching

The original serverTick does per-user DB queries every second. For N connected users,
that's N queries/sec (e.g., 50 users = 50 DB queries/second). Batch into one query.

## Before (per-user, N queries)
```typescript
const tickInterval = setInterval(() => {
  clients.forEach((_, userId) => {
    sendServerTick(userId, time).catch(...);
  });
}, 1000);

async function sendServerTick(userId, time) {
  const stats = await db.one('SELECT money, bank FROM users WHERE id = ?', [userId]);
  // ... send
}
```

## After (one batch query for all users)
```typescript
const tickInterval = setInterval(async () => {
  const userIds = Array.from(clients.keys());
  if (userIds.length === 0) return;

  const placeholders = userIds.map(() => '?').join(',');
  const rows = await db.query(
    `SELECT id, money, bank, COALESCE(auction_sales, 0) as auctionSales
     FROM users WHERE id IN (${placeholders})`,
    userIds
  );

  const batch = new Map<number, any>();
  for (const r of rows) batch.set(r.id, r);

  for (const userId of userIds) {
    const ws = clients.get(userId);
    if (!ws || ws.readyState !== WebSocket.OPEN) continue;
    const stats = batch.get(userId);
    // ... send payload
  }
}, 1000);
```

## Impact
- **Before**: N queries/sec (linear with connected users)
- **After**: 1 query/sec (constant, regardless of user count)
- With 50 users: 50→1 queries/sec = 50× reduction in DB load

## Caveat
Quests and rating are still per-user (lazy, only on `markDirty`). They fire infrequently
and are not worth batching.
