# Nginx WebSocket Proxy Configuration

## Minimum required config
```nginx
location /ws {
    proxy_pass http://127.0.0.1:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}
```

## Why each directive
- `proxy_http_version 1.1` — required for HTTP upgrade mechanism (WebSocket handshake)
- `Upgrade $http_upgrade` — forwards the browser's Upgrade header to backend
- `Connection "upgrade"` — tells backend to upgrade the connection
- `proxy_read_timeout 3600s` — keeps WS connection alive for 1 hour (default is 60s, killing idle WS)
- `X-Forwarded-Proto $scheme` — tells backend this was HTTPS (needed for wss://)

## Testing
Test WS independently of nginx first:
```bash
# Direct to backend (bypass nginx)
curl -s -o /dev/null -w "%{http_code}\n" --max-time 3 \
  -H "Connection: Upgrade" -H "Upgrade: websocket" \
  -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" \
  -H "Sec-WebSocket-Version: 13" \
  http://localhost:3001/ws
# 101 = WebSocket upgrade successful

# Through nginx (HTTPS)
curl -sk -o /dev/null -w "%{http_code}\n" --max-time 5 \
  -H "Connection: Upgrade" -H "Upgrade: websocket" \
  -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" \
  -H "Sec-WebSocket-Version: 13" \
  https://mmoarena.ru/ws
```

## Reload after editing
```bash
nginx -t && nginx -s reload
```
