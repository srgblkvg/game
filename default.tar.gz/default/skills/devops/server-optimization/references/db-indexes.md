# Database Indexes for Performance

PostgreSQL uses only primary key indexes by default. Add secondary indexes
for frequently queried columns to reduce full table scans.

## Critical indexes to add

```sql
-- Users table (most frequently queried)
CREATE INDEX idx_users_level ON users(level);
CREATE INDEX idx_users_elo ON users(elo);
CREATE INDEX idx_users_guildid ON users(guildid);
CREATE INDEX idx_users_lastaction ON users(lastaction);

-- Tournament performance
CREATE INDEX idx_tournament_participants_tid ON tournament_participants(tournamentid);
CREATE INDEX idx_tournament_matches_tid ON tournament_matches(tournamentid);

-- Chat and messaging
CREATE INDEX idx_chat_messages_createdat ON chat_messages(createdat);
CREATE INDEX idx_chat_messages_senderid ON chat_messages(senderid);

-- Battle logging
CREATE INDEX idx_battles_attackerid ON battles(attackerid);

-- Auction lookups
CREATE INDEX idx_auction_lots_sellerid ON auction_lots(sellerid);

-- Collections
CREATE INDEX idx_collections_userid ON collections(userid);

-- Daily quests (commonly queried per user per date)
CREATE INDEX idx_daily_quests_userid_date ON daily_quests(userid, date);

-- PvE and job history
CREATE INDEX idx_pve_battles_userid ON pve_battles(userid);
CREATE INDEX idx_job_history_userid ON job_history(userid);
```

## Verification
```bash
# Check existing indexes
sudo -u postgres psql -d game -c "
  SELECT tablename, indexname FROM pg_indexes WHERE schemaname='public' ORDER BY tablename;
"
# Vacuum after adding indexes
sudo -u postgres psql -d game -c "VACUUM ANALYZE;"
```
