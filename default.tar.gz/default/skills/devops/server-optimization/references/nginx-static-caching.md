# nginx Static Asset Caching

Assets (JS/CSS chunks with content hashes in filenames) can be cached indefinitely
by the browser. Add an explicit `location /assets/` block BEFORE the `location /` fallback:

```nginx
location /assets/ {
    alias /opt/game/client/dist/assets/;
    expires 30d;
    add_header Cache-Control "public, immutable";
}
```

This means:
- Browser never re-requests the same asset version (30-day cache + immutable)
- nginx serves them directly from disk without proxying to Node
- No server load for static files even with hundreds of concurrent players

**Placement matters**: the `/assets/` location must be INSIDE the HTTPS `server {}` block
and BEFORE the `location /` catch-all. nginx evaluates locations in order of specificity,
so `/assets/` (exact prefix) takes priority over `/` (catch-all).

Full nginx config: all location blocks in order:
1. `/wiki/` — static wiki
2. `/uploads/` — static avatars (7d cache)
3. `/assets/` — static JS/CSS (30d cache, immutable)
4. `/api/` — proxy to Node (no cache)
5. `/ws` — WebSocket proxy (long timeout)
6. `/` — SPA fallback (try_files)
