# DB Auto-Cleanup (7-day retention)

Created `server/src/cleanup.ts` — deletes tournament/battle/chat/auction/quest/job data older than 7 days.

```typescript
// cleanup.ts
import { db } from './db/index';

export async function cleanupOldData() {
  const weekAgo = Math.floor(Date.now() / 1000) - 7 * 24 * 3600;
  const weekAgoISO = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();

  await db.run(`DELETE FROM tournament_matches WHERE tournamentId IN (SELECT id FROM tournaments WHERE status = 'completed' AND completedAt < ?)`, [weekAgo]);
  await db.run(`DELETE FROM tournaments WHERE status = 'completed' AND completedAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM chat_messages WHERE createdAt < ?`, [weekAgoISO]);
  await db.run(`DELETE FROM battles WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM pve_battles WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM auction_history WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM quest_history WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM job_history WHERE endTime < ?`, [weekAgo]);
}
```

Wired in `index.ts`:
```typescript
import { cleanupOldData } from './cleanup';
setTimeout(() => { cleanupOldData().catch(() => {}); }, 60000);  // 1 min after start
setInterval(() => { cleanupOldData().catch(() => {}); }, 24 * 3600 * 1000);  // daily
```

## Emergency cleanup (bot aftermath)

50 bots overnight generate ~334MB of tournament_matches (427K rows) + 7.5K chat messages. 
Quick fix:
```sql
DELETE FROM tournament_matches;
DELETE FROM tournament_participants;
DELETE FROM tournaments;
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);
VACUUM FULL tournament_matches;
```
DB drops from 379MB → 46MB.
