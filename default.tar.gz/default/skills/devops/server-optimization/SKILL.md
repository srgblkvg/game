---
name: server-optimization
description: Optimize a Node.js/TypeScript backend server for low-memory VPS — find memory leaks, reduce baseline RSS, switch runtimes, batch N+1 queries, and remove unnecessary middleware.
---

# Server Memory Optimization

## Trigger
Server OOM-killed, high restart count in PM2, slow responses (~20s page loads), 502/504 errors, high swap usage.

## Diagnostic workflow (ordered by impact)

### 0. BEFORE ANYTHING: verify the server is actually down
User reports 502/504 → `curl -sk --max-time 5 https://mmoarena.ru/api/time`. If 200, server IS running and the issue is elsewhere (client code, nginx config, DNS). Don't claim "server is up" from PM2 alone — PM2 can show `online` for a process that can't bind the port.

### 1. Check the obvious
```bash
pm2 status           # restart count > 0 = crashes
free -h              # swap > 0 = memory pressure
pm2 logs --err --lines 20  # OOM stack traces
pm2 show game-server | grep 'interpreter args'  # check heap limit
```
Look for `FATAL ERROR: ... heap out of memory` or Bun's `emitError` + `Bun vX.X.X`.

**If heap OOM found:** check current `--max-old-space-size`. On 2GB VPS, 1024MB (1GB) is too high — Node's 1GB heap + OS + nginx + postgres exceeds total RAM. Reduce to 512MB:
```bash
pm2 restart game-server --node-args="--max-old-space-size=512" && pm2 save
```
`pm2 save` persists the setting to `/root/.pm2/dump.pm2` for resurrection across reboots.

### 2. Find what's allocating
- High CPU + growing RSS = hot allocation loop
- High `mu` (marked/used ratio) in GC traces near 1.0 = objects NOT being freed (retention leak)
- Low `mu` near 0.1 = objects ARE freed but allocation rate outruns GC (throughput problem)

### 3. Binary-search the leak source
Disable subsystems one at a time and measure RSS over 60-120s:
1. Pure Express (no routes, no WS) -> baseline
2. + Routes (no WS) -> check
3. + WebSocket (no serverTick) -> check
4. + serverTick enabled -> check

## Common culprits (by impact)

### #1: Polling intervals with DB queries (serverTick)
Every-second `setInterval` calling `db.one()` per connected user = 3600 queries/hour/user. Fix: disable the interval, replace with event-driven or SSE.

### #2: TypeScript runtime overhead

**Option A: Node.js with tsc pre-compile** (best for production — stable + no runtime overhead):

Replace tsx with pre-compiled JavaScript. tsx holds source maps and ASTs in memory (~50-100MB). Pre-compiling with tsc eliminates this entirely.

```bash
cd /opt/game/server
npx tsc                    # compiles to dist/
ls dist/index.js           # verify output
pm2 start "PORT=3001 node --max-old-space-size=512 dist/index.js" \\
  --name game-server --max-memory-restart 900M
```

| VPS RAM | `--max-old-space-size` | `--max-memory-restart` | Runtime | Memory (RSS) |
|---------|------------------------|------------------------|---------|-------------|
| 2GB | 512 | 900M | tsx | 146MB |
| 2GB | 512 | 900M | **tsc pre-compile** | **94MB (-52MB)** |

**Important:** When using compiled JS, apply code changes to TypeScript SOURCE files, then recompile: `npx tsc && pm2 restart`. Do NOT sed/patch compiled .js files — it breaks exports and router definitions.

**Option B: Bun** (native TS, ~40% less memory) — but TEST FIRST. Bun 1.3.14 was UNSTABLE on this MMO codebase (repeated `emitError` crashes within seconds, no OOM stack trace). If it works, use it. If it crashes immediately, fall back to Node.

### #3: DB connection pool tuning
PostgreSQL connections consume ~25MB each. Default `max: 20` = 500MB potential overhead. On 2GB VPS, reduce:
```typescript
// db/index.ts
const pool = new Pool({
  max: 5,                    // was 20 — enough for ~250 req/s
  idleTimeoutMillis: 30000,  // close idle after 30s
  connectionTimeoutMillis: 5000,
});
```
5 connections × 25MB = 125MB. Only increase if you see `too many clients` in logs. 5 conns handle 100+ concurrent players easily.

### #4: express-rate-limit
Stores per-IP request counters in memory. Disable via env var:
```bash
DISABLE_RATE_LIMIT=true pm2 start ...
```

### #4: N+1 DB queries
Every tournament/matches handler making per-row subqueries. Batch with `WHERE id IN (...)` + Map lookup. Full pattern in `references/tournament-batching.md`.

### #5: PM2 systemd resurrect creates duplicates
When systemd launches PM2 via `pm2-root.service` with `ExecStart=pm2 resurrect`, it reads `/root/.pm2/dump.pm2`. If you `pm2 delete` and `pm2 start` but don't save, the OLD dump still has the previous process — systemd resurrects BOTH on next boot, causing port-conflict crashes (new process can't bind port 3001, old one holds it).

Fix: after setting up the single desired process, persist it:
```bash
pm2 save   # overwrites dump.pm2 with current state
```

### #6: WebSocket → HTTP polling migration
When WS must be disabled (memory, stability), replace with polling intervals:

### #7: nginx static asset caching
Add `location /assets/` with `expires 30d` and `add_header Cache-Control "public, immutable"` to serve JS/CSS chunks without proxying to Node. Zero server load for static files. Full config: `references/nginx-static-caching.md`.

### #8: WebSocket serverTick batching
Replace per-user DB queries with one batched query per tick cycle. Instead of N `db.one()` calls for N connected users, use one `db.query()` with `WHERE id IN (...)` + Map lookup. Full pattern: `references/ws-tick-batching.md`.

### #9: Database performance indexes
Add secondary indexes for frequently-queried columns (users.level, users.elo, users.guildid, tournament_matches.tournamentid, chat_messages.createdat, daily_quests(userid, date), etc.). Full list: `references/db-indexes.md`.

### #6: WebSocket → HTTP polling migration
When WS must be disabled (memory, stability), replace with polling intervals:
- **Chat**: `GET /api/chat/recent?limit=50` every 3s + `POST /api/chat/send` for sending
- **Online users**: `GET /api/users/online` every 10s (add `lastAction` column, update in auth middleware)
- **Balance**: `GET /api/character/me` every 5s
- **ServerTick events**: dispatch `window.CustomEvent('serverTick', {detail: time})` from balance poll

Client ChatContext rewrite: remove all `WebSocket` refs, add `setInterval` polls, dispatch mirror events (`serverTick`, `balance`, `notifications`).

### #7: Client-side request reduction
Pages making N+1 API calls on mount (e.g. HistoryPage calling `fetchAllPrivateMessagesNew()` which fetches peers list then loops per-peer) — replace with single batched endpoint. Reduce limits: battles 100→30, PvE 100→30, tournaments 50→20.
Full patterns: `references/client-request-reduction.md`.

## PM2 production config
```bash
pm2 start "PORT=3001 bun run server/src/index.ts" \
  --name game-server \
  --max-memory-restart 800M   # adjust to ~80% of available RAM
pm2 save   # overwrite dump.pm2 so systemd resurrect doesn't create duplicates
```
Full deploy script: `scripts/deploy-bun.sh` — one-command setup including Bun install, env config, cleanup, and warmup.

Auto-cleanup pattern: `references/db-cleanup.md` — daily deletion of tournament data, chat, battles older than 7 days.
## Pitfalls

- **`--max-old-space-size=1024` on 2GB VPS = guaranteed heap OOM**: 1GB heap + OS (~200MB) + nginx + postgres > 1.9GB total RAM. Node crashes with `FATAL ERROR: Reached heap limit Allocation failed - JavaScript heap out of memory`. Always verify: `pm2 show game-server | grep 'interpreter args'`. For 2GB VPS, max safe value is 512MB. Persist with `pm2 save`.
- **`pm2 save` required after changing `--node-args`**: `pm2 restart --node-args="..."` applies only to the current process. On systemd resurrect (reboot) it loads the old value from `/root/.pm2/dump.pm2`. Always follow with `pm2 save`.

- **tsc-compiled JS can use MORE memory than tsx** — CommonJS `require()` loads differently than ESM imports. Test before assuming.
- **PM2 `mem` column shows RSS of the bash wrapper, not the child process** — use `ps -o rss,comm` for accurate per-process RSS.
- **`write_file` and terminal tools truncate `process.env.JWT_SECRET!` to `proces...CRET`** — the `!` followed by space triggers truncation. Use `patch` tool or write the file locally and `scp` it.
- **Don't wait 3 minutes for stability tests** when the user is actively testing — deploy fixes, warm up routes, tell user to test immediately.
- **Bun not always stable**: Bun 1.3.14 crashed instantly (emitError, no OOM trace) on this MMO codebase with ~50 TypeScript files. Always do a 10-second direct test (`timeout 10 bun run ...`) before deploying via PM2. If it crashes, fall back to Node.js immediately — don't debug Bun.
- **Inline env vars don't survive PM2 restarts**: `DISABLE_RATE_LIMIT=true pm2 start "..."` creates the process with the var set, but PM2 resurrect/systemd restart loses it. Always persist env vars in `server/.env` file: `echo "DISABLE_RATE_LIMIT=true" >> server/.env`.
- **[MMO-specific] rsync overwrites local fixes**: If you `rsync` the local `server/` to prod, it brings the ORIGINAL code with serverTick enabled. Either rsync BEFORE making local fixes, or re-apply fixes after rsync. Better: maintain a production patch stack. **CRITICAL**: `git stash` before rsync, rsync clean code, then `git stash pop` to restore working changes. If you `git checkout` files to fix breakage and then `git stash pop`, the pop may merge old patch versions on top of clean files — verify key lines after pop.

- **[MMO-specific] Tournament empty-table guard**: When tournament_matches table is empty (`DELETE FROM` cleared it), the batch query `WHERE tournamentId IN (${ids.map(() => '?').join(',')})` generates `IN ()` — a SQL syntax error. Always wrap batch queries with `if (array.length > 0)`. The error surfaces as HTTP 500 with `error: syntax error at or near ")"`.

- **[MMO-specific] ServerTick is required by this user**: The user wants real-time WebSocket push for money, quests, rating, notifications — NOT polling. The lightweight balance tick (every 1 second, only money+bank) is the minimum viable. Full tick adds 2 parallel DB queries per user (quests + rating). On 2GB VPS with clean DB and no bots, this is stable. Do NOT propose removing serverTick in favor of HTTP polling on this project.
- **[MMO-specific] Bot system location**: `server/src/bots/botManager.ts` — in-process bots that do PvE/PvP/jobs/auction/craft/tournaments via HTTP calls to localhost. Admin endpoint `/api/admin/bots/status`. They don't auto-start — must be started manually from admin panel. If server is crashing, check if bots are running (`GET /api/admin/bots`) — 50 bots × API calls = memory pressure.

- **[MMO-specific] Bot database bloat**: 50 bots overnight generate MASSIVE data. Check the real culprit:
```bash
sudo -u postgres psql -d game -c "
SELECT relname, n_live_tup as rows, pg_size_pretty(pg_total_relation_size(relid)) as size
FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 10;
"
```
Typical bloat from 50 bots overnight: 427K tournament_matches (334MB), 7.5K chat messages, 16K pve_battles. Server OOMs not from code but from loading 427K rows into memory on every tournament page load. Fix: `DELETE FROM tournament_matches; DELETE FROM tournaments; DELETE FROM tournament_participants; VACUUM FULL;` — DB dropped from 379MB to 46MB. Also clean chat: keep last 500 messages. Bots also create self-vs-self tournament matches (player1Id == player2Id) causing display bugs ("Игрок1 vs Игрок1").

- **[MMO-specific] Auto-cleanup script**: Create `server/src/cleanup.ts` with daily deletion of data older than 7 days (tournaments, chat, battles, pve_battles, auction_history, quest_history, job_history). Wire in index.ts: `setInterval(() => cleanupOldData(), 24*3600*1000)`. Pattern in `references/db-cleanup.md`.
- **`pkill -f "bun run"` kills the SSH session**: the pattern matches the shell that launched the SSH command. Use `pkill -9 -f "bun run server"` (more specific) or kill by PID instead. If SSH dies after a pkill, wait 15-20s and reconnect — PM2 will auto-restart. Better: `pm2 delete game-server` first, then `pkill`.
- **`sed` on compiled JS is dangerous**: `sed "s/pattern/\/\/ commented/"` inserts `//` comment markers which can break `export default router`, function definitions, or other structural code. The compiled JS may compile successfully but crash at runtime with `TypeError: argument handler must be a function` because the export is now a comment. Always apply fixes to TypeScript source (.ts files), not compiled JS (.js files).
- **Never claim stability without verifying**: PM2 showing 0 restarts and low memory does NOT guarantee stability. A server can show `online` while refusing connections (port already in use, compilation error). Always verify with `curl http://localhost:3001/api/time` BEFORE telling the user "it's working". If the server is crashing loop, the user sees 502/504 — don't claim success until those errors stop.

- **PM2 `restart` reuses old compiled code**: After fixing a .ts file and recompiling with `npx tsc`, `pm2 restart` may keep the old `dist/*.js` in Node's module cache. For compiled JS changes to take effect, you MUST do `pm2 delete game-server && pm2 start "..."`. The `restart` command only sends SIGHUP — Node may not reload modules. Symptom: error logs show old line numbers or fixed variables still undefined.

- **New PG tables need GRANT for app user**: Tables created via `sudo -u postgres psql` are owned by `postgres`. The app connects as `game` user. Always run `GRANT ALL ON <table> TO game; GRANT ALL ON <table>_id_seq TO game;` after creating tables, or the app gets `permission denied`. For existing tables: `GRANT ALL ON ALL TABLES IN SCHEMA public TO game;`.

- **Inventory slot counting — materials don't take slots**: Equipment items (those with `.slot` field: helmet/gloves/boots/amulet/weapon/shield) each take 1 inventory slot. Craft items (`type: 'craft_item'`), materials (`type: 'material'`), and upgrade stones (`type: 'upgrade'`) take 0 slots — they stack freely. When checking if inventory is full, count only `inventory.filter(i => !!i.slot).length`, not `inventory.length`. The `inventorySlots` column controls max equipment items, not total items.

- **`write_file` truncates `process.env.JWT_SECRET!`**: The tool inserts `...` in the middle of this line when writing server source files. The `!` followed by a space triggers truncation. Fix: write the file locally and `scp` it, or use `patch` with the string split across old_string/new_string boundaries. Always verify with `xxd <file> | grep JWT` after writing.
- **Tournament timer + tsc interaction**: If you comment out `getOrCreateTournament()` and `autoAdvance()` in `tournament.ts` but leave the tournament timer in `index.ts` that calls them, tsc compile will succeed but the server crashes at runtime. Always remove paired calls together — either keep functions AND timer, or comment out BOTH.
- **`git checkout` before `git stash pop` corrupts user state**: If you `git checkout -- file.ts` to fix broken code, then `git stash pop`, the pop merges the stash's OLD patches onto the freshly-checked-out file. The result may include your previous session's stale patches (old tournament timer, old websocket code). Better approach: `git stash pop` FIRST (restore user's original working state with all their latest features), then apply ONLY the critical fixes on top. If the pop conflicts, resolve manually — don't checkout as a shortcut.
- **WebSocket test independent of nginx**: When user reports "ws doesn't work", test WebSocket directly on localhost to bypass nginx: `curl -s -o /dev/null -w "%{http_code}" -H "Connection: Upgrade" -H "Upgrade: websocket" -H "Sec-WebSocket-Key: test==" -H "Sec-WebSocket-Version: 13" http://localhost:3001/ws`. If 101, WS server is fine — the issue is nginx proxy or client. Full nginx WS proxy config: `references/nginx-ws-proxy.md`.
- **WebSocket not working through nginx**: even with `proxy_set_header Upgrade $http_upgrade` and `Connection "upgrade"`, the WS connection may fail silently. Missing `proxy_read_timeout 3600s` causes nginx to close idle WS after 60s. Missing `X-Forwarded-Proto $scheme` may cause auth issues. Full config and test procedure: `references/nginx-ws-proxy.md`.

- **[PG-native] PostgreSQL lowercases column names**: `CREATE TABLE users (guildId INT)` creates column `guildid`. The code `user.guildId` returns `undefined`. Always use the pattern `user.guildid || user.guildId` when accessing columns that may be camelCase in SQL. This affects: guildId, itemName→itemname, createdAt→createdat, inventorySlots→inventoryslots, lastAction→lastaction. The DB helper may have a camelCase converter — verify per-column pattern.
- **[write_file] JWT_SECRET truncation**: `write_file` truncates `process.env.JWT_SECRET!` to `proces...CRET` in source files. The `!` character followed by text triggers truncation. Fix: write the file with a placeholder like `JWT_SECRET_PLACEHOLDER`, then `scp` the local file. Or use `patch` tool with `process.env.JWT_SECRET` split across two lines. NEVER write files containing `process.env.JWT_SECRET!` via `write_file`.
