#!/bin/bash
# One-shot Bun+PM2 deploy for low-memory VPS
# Usage: ssh root@host 'bash -s' < deploy-bun.sh
set -e

echo "=== Installing Bun ==="
command -v bun &>/dev/null || (apt-get install -y unzip && curl -fsSL https://bun.sh/install | bash)
export PATH="/root/.bun/bin:$PATH"

echo "=== Configuring .env ==="
cd /opt/game
grep -q DISABLE_RATE_LIMIT server/.env 2>/dev/null || echo "DISABLE_RATE_LIMIT=true" >> server/.env

echo "=== Killing old processes ==="
pkill -9 -f "bun run" 2>/dev/null || true
sleep 2
pm2 delete all 2>/dev/null || true
systemctl stop pm2-root 2>/dev/null || true

echo "=== Starting server ==="
pm2 start "PORT=3001 bun run server/src/index.ts" \
  --name game-server \
  --max-memory-restart 800M

echo "=== Saving PM2 state (prevents systemd resurrect duplicates) ==="
sleep 5
pm2 save --force

echo "=== Warming up routes ==="
sleep 3
for ep in /api/time /api/auction /api/shop /api/mobs /api/tournament /api/chat/recent; do
  curl -s -o /dev/null --max-time 5 http://localhost:3001$ep || true
done

echo "=== Status ==="
pm2 status
free -h | head -2
curl -s --max-time 3 http://localhost:3001/api/time
echo ""
echo "✓ Deploy complete"
