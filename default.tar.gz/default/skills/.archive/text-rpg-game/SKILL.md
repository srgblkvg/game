---
name: text-rpg-game
description: "Work on the text-based online RPG at /mnt/c/project/game — server + client + game mechanics."
version: 1.0.0
metadata:
  hermes:
    tags: [game, rpg, react, express, sqlite]
---

# Text RPG Game — Project Skill

## Overview

Browser-based text RPG with React 19 + TypeScript client and Express 5 + SQLite server. Dark theme, turn-based PvP battles, arena, crafting, jobs, chat.

## Project Layout

```
/mnt/c/project/game/
  server/          Express 5 + TypeScript + SQLite (better-sqlite3)
    src/
      index.ts          entry point
      env.ts            JWT_SECRET, PORT
      setupMiddleware.ts helmet, cors, rate-limiters, trust proxy
      setupRoutes.ts    route mounting
      validation.ts     Zod schemas
      email.ts          nodemailer + sendmail (Postfix)
      logger.ts         pino logger
      audit.ts          audit logging
      websocket.ts      real-time chat + online status
      database/
        index.ts        DB init (runSchema → runMigrations → runSeed)
        schema.ts       CREATE TABLE statements
        migrations.ts   ALTER TABLE migrations (try/catch)
      game/
        stats.ts        stat calculation (CharStats, currentStats)
        battle.ts       battle simulation (runBattle)
      routes/
        auth.ts         player register (email+code), verify-email, login
        ...             character, inventory, battle, arena, shop, jobs, craft, chat, account, admin*
  client/          React 19 + Vite 8 + Tailwind CSS v4
    ...
```

### Server Architecture (Post-Refactor)
- `database/` dir: schema, seed, migrations, index — split from single `database.ts`
- Routes split: character/inventory/users/rating/characterStats + index
- `index.ts` → `setupMiddleware.ts` + `setupRoutes.ts`
- Security: helmet, 5-tier rate-limiters, body limit 1MB, password complexity, account lockout, XSS sanitization, CSRF middleware (disabled for Bearer API), JWT revocation blacklist
- Audit logging: all auth events (register, login success/failure, account lockout, WS connect/disconnect)
      styles/theme.css  Tailwind + CSS variables + animations
      components/
        ui/             shared UI: Button, Card, Modal, Badge, BackButton,
                         PageHeader, ItemIcon, FilterBar, EmptyState
        CharacterCard   player card with slots + stats
        StatAllocation  collapsible stat point distributer
        Inventory       item grid
        Actions         action cards (shop/arena/jobs/craft)
        chat/           ChatPanel, ChatInput, MessageList, etc.
      pages/            all game pages
      contexts/         AuthContext, GameContext, ChatContext
      hooks/            useBattleLogic
      api/              HTTP clients
      utils/            stats, money, itemUtils
```

## New Features (post bags/ideas session 2026-06-03)

After processing `.hermes/bags/` and `.hermes/ideas/`, the following features were added. See `references/bags-ideas-workflow.md` for the full dependency order and implementation plan.

### PvE Bestiary (`/bestiary`)
- 30 mobs across 14 location tiers (Склеп → Врата Бездны), sorted by min level
- Arena-style battle: player card + mob card side-by-side with HP bars, step-by-step animation, speed control
- Separate cooldown: 5 min (`lastPveAttackTime`), independent from PvP — timer on both floor cards and main page Hunt button
- Mob stats: static (no equipment), HP/ATK/AGI/DEF/MST displayed on card
- XP: +0 (weaker), +1 (equal), +2 (stronger than player)
- Gold: random between gold_min–gold_max; defeat: lose 10% of pocket gold
- Material drop: ~35% chance, rarity from loot table
- After battle: «На главную» + «К этажам» buttons
- Route: `server/src/routes/mobs.ts`, Page: `BestiaryPage.tsx`

### Equipment & Items (189 items)

### Bank (`/bank`)
- `bank` column: silver stored in vault, protected from PvP theft
- `accountNumber` column: unique 6-char alphanumeric (chars: 2-9, A-Z excluding 0/O/1/I/l)
- No cooldown — bank always accessible
- Guests blocked via `requireFullAccess` middleware
- Deposit: 2% commission
- Withdrawal: no fee
- Transfer: bank-to-bank by account number, 2% commission
- All money ops use `db.transaction()` for atomicity — verify target exists BEFORE deducting
- History tables: `transfers` (from/to accounts), `bank_operations` (deposit/withdraw)
- API: `GET/POST /bank`, `POST /bank/deposit`, `POST /bank/withdraw`, `POST /bank/transfer`, `GET /bank/transfers?filter=all|in|out`, `GET /bank/operations?filter=all|deposit|withdraw`
- Frontend: BankPage with 3 tabs (Информация, Пополнение, Переводы), filter sub-tabs, live commission preview
- Route: `server/src/routes/bank.ts`, Page: `BankPage.tsx`
- Ref: `references/bank-transactions.md`

### Tournaments (`/tournament`)
- Continuous rolling tournaments (no weekly schedule): 30-min registration window, 8-player max
- Auto-start when 8th player joins or 30-min timer expires
- Completed tournament → new one immediately created
- 4 divisions: copper (1-15), steel (16-35), mithril (36-60), adamant (61+)
- Single-elimination bracket: adjacent pairing (players with similar skill fight each other)
- Hidden `tournamentElo` per player (DEFAULT 1000), used for seeding only — NOT public PvP Elo
- Battles use full max HP (s+a+d+m) — no HP disadvantage from prior fights
- Bracket generation: pad to power-of-2 with byes, generate round-robin matches
- Match simulation: auto-resolve via `runBattle`, log stored in `tournament_matches.log`
- Prizes: 1st: 50%, 2nd: 30%, 3rd: 20% of prize pool
- Stats tracked: `tournamentCount`, `tournamentWins` (top-3 placements)

### Custom Tournaments
- Players create with: prize pool (min 0), entry fee, name, 5-120 min timer, 2-16 players, min/max level
- `basePool` column: creator's original contribution — used for refund calculation
- Entry fees added to prize pool on join
- Cancel if < 2 players: refund basePool to creator, entryFee to each participant
- No golden ticket in custom tournaments
- Separate tab on TournamentPage: Все / Официальные / Самоорганизованные / Завершённые
- API: `POST /tournament/create-custom`, type='custom' filter on existing endpoints
- `tournaments.type` column: 'official' or 'custom', `creatorId`, `entryFee`, `name`, `minLevel`, `maxLevel`
- Ref: `references/tournaments.md`

### Daily Quests (`/tavern`, tab: Задания)
- 5 quest types: hunt (mobs), arena (PvP wins), job (work time), craft (create/upgrade), auction (trades)
- 3 difficulties (random): ⭐ Easy, ⭐⭐ Medium (×3-5 req), ⭐⭐⭐ Hard (×6-25 req)
- Job requirements time-based: easy=10min, medium=1h, hard=4h (tracked via `totalJobSeconds`)
- Craft: 1/3/6 items; Auction: 1/3/6 deals
- 3 active simultaneously, 5 per day limit, reset at midnight
- Progress tracking: snapshot of player counters (`pveTotalBattles`, `wins`, `craftCount`, `auctionTrades`, `totalJobSeconds`) at quest start, delta compared on check
- `craftCount` incremented on craftItem + upgradeItem success
- `auctionTrades` incremented on buyout + buy-partial for both buyer and seller
- API: `GET /tavern/quests` (gen+list), `POST /tavern/quests/take`, `POST /tavern/quests/claim`
- Route: `server/src/routes/quests.ts`, Page: `TavernPage.tsx` quests tab

### Tavern (`/tavern`)
- Healing: instant (2🥇 per HP, full or 50%), room rental (closet ×3, bed ×10, chamber ×50 regen rate)
- Room regen multiplies base 1 HP/10s rate in `character.ts`
- Drinks: 15 types, +10/+25/+50 to S/A/D/M or all stats, 1-hour duration
- Columns: `roomType`, `roomUntil`, `activeDrink`, `drinkUntil`
- Route: `server/src/routes/tavern.ts`, Page: `TavernPage.tsx`

### ELO Rating System
- Replaced win-count ranking with full ELO system (start 1000, min 100)
- K-factor: 40 (levels 1–10) → 15 (51+)
- 10 ranks: Пепел → Смерть (with icons and colors)
- PvP: both players updated, `lastPvpTime` tracked
- PvE: +1/+2 for mobs (1h cooldown), +10 for bosses (1d), capped at 15% of total
- Decay: −5/−10/−20 per day after 7/14/30 days without PvP (checked on login)
- Seasons: monthly soft reset `1000 + (old−1000)×0.5`, top-10 → hall_of_fame
- Upgrades: +7 → +5 ELO, +10 → +50 ELO
- `elo`, `seasonWins`, `seasonLosses`, `lastEloDecay`, `lastPvpTime`, `pveRating` columns
- ELO change returned in battle response (`eloChange`)
- Route: `server/src/routes/rating.ts` updated
- Core module: `server/src/game/rating.ts` — calcElo(), applyDecay(), addPveRating(), checkSeasonReset()

### Auction House (`/auction`)
- Player-to-player item trading with price floors per rarity
- 5% listing fee, 10% sales commission
- Bidding with 5% minimum increment, optional buyout
- Durations: 6/12/24/48 hours
- Expired lots auto-resolve on GET (payout to seller, item to winner)
- Route: `server/src/routes/auction.ts`, Page: `AuctionPage.tsx`

### Actions Layout Redesign
- Split into two zones: 🌍 За стенами (Охота, Работы) and 🏰 В замке (Арена, Магазин, Сундук, Крафт, Аукцион, Трактир)
- 2-column grid for outside, 3-column for castle
- `client/src/components/Actions.tsx` completely rewritten

### Account Management
- Delete account with password confirmation (POST `/account/delete`)
- Password show/hide toggle on LoginPage and RegisterPage
- Enter key submits forms when all fields filled

## Game Mechanics (Current State)

### Stats
- S (Сила) — attack damage
- A (Ловкость) — dodge chance, turn order
- D (Защита) — block chance + reduction
- M (Мастерство) — crit chance/multiplier, counter-attack, stun
- V REMOVED — was always 100, never grew

HP = S + A + D + M (no more +100 from V)

### Leveling
- XP per level: `10 * 2^(level-1)` — 10, 20, 40, 80, 160, 320...
- No level cap
- Each level-up gives +5 stat points (`levelsGained * 5`)
- Players distribute stat points via StatAllocation component
- Stored in DB columns: `baseS, baseA, baseD, baseM, statPoints`

**CRITICAL: XP level-up check must be applied consistently in ALL XP-awarding code paths.** The pattern is:
```ts
let newExp = user.exp + expGain;
let newLevel = user.level;
let levelsGained = 0;
while (true) {
    const required = 10 * Math.pow(2, newLevel - 1);
    if (newExp >= required) { newExp -= required; newLevel++; levelsGained++; }
    else break;
}
```
This exists in `server/src/routes/battle.ts` but was MISSING from `server/src/routes/character.ts` (job completion handler — line 80–86). If you add XP anywhere else (quests, PvE, events), copy this block. Without it, players accumulate raw exp but never level up.

### Combat
- Turn-based, first striker = higher Agility
- NO stamina system (removed — every turn is an attack)
- Mechanics: dodge, crit, block, full block, counter, stun
- Loop: `while (hpA > 0 && hpD > 0)` — fight to death
- Winner steals 10-50% of loser's money
- Winner gains EXP, money, stat points on level-up

### Equipment
- 10 slots: helmet, chest, gloves, boots, amulet, ring1, ring2, belt, weapon1, weapon2
- Rarities: junk(0) → mythic(6), each with color
- Items have bonuses (S/A/D/M) and extra stats (crit%, dodge%, etc.)
- Upgrade levels: +5% bonus per level

### Currency
- Single currency: серебро. `formatMoney(n)` → `1 838 серебра`
- **No coin emojis** (🥇 💰) or coin icons — text only. Where «серебро» is missing from context, add it: «Стоимость (серебро)», «5000 серебра»
- **Header balance**: plain text `Серебро: N` with `text-white`. `MoneyDisplay` component is deprecated — do not use
- Full currency conventions → `text-rpg-project` skill, Currency section

### Jobs
- EXP reward: `max(1, floor(duration / 3600))` — 1 EXP per hour, minimum 1
- Money reward: random between rewardMin–rewardMax

### Deployment

### VPS (Production)
- **IP:** 194.226.142.237 (Ubuntu 26.04, 955MB RAM, 8.6G disk)
- **Domain:** mmoarena.ru (DNS: ns5/ns6.hosting.reg.ru, A → 194.226.142.237)
- **SSH:** `ssh root@194.226.142.237` (key: ~/.ssh/id_ed25519)
- **Project path:** `/opt/game/`

### Stack
- **nginx** 1.28.3 — serves static files from `/opt/game/client/dist/`, proxies `/api/` and `/ws` to :3001
- **pm2** — process manager, auto-restart on reboot (`pm2 startup systemd`)
- **Postfix** + **nodemailer** (sendmail transport) — verification email delivery
- **Node.js** 22 + npm 9

### Deploy Script (`/opt/game/deploy.sh`)

```bash
#!/bin/bash
set -e
cd /opt/game

echo "=== Pulling changes ==="
cp server/game.db /tmp/game.db.backup        # ⚠️ PRESERVE live player data
git fetch
git reset --hard origin/main
cp /tmp/game.db.backup server/game.db        # ⚠️ Restore after pull

echo "=== Building client ==="
cd /opt/game/client
npm install --silent
npx vite build

echo "=== Restarting server ==="
pm2 delete game-server 2>/dev/null
pm2 start "npx tsx src/index.ts" --name game-server --cwd /opt/game/server  # ⚠️ --cwd is CRITICAL

echo "=== Reloading nginx ==="
systemctl reload nginx

echo "=== Done ==="
pm2 status
```

Run: `ssh root@194.226.142.237 /opt/game/deploy.sh`

**⛔ NEVER use `git stash` + `git pull` + `git stash drop`** — this DELETES the live database. `git stash` saves game.db, but `git stash drop` discards it permanently. The backup-then-reset-then-restore pattern above is the ONLY safe way.

**⛔ PM2 MUST use `--cwd /opt/game/server`**. Without `--cwd`, pm2 runs `npx tsx src/index.ts` from `/opt/game` (repo root), which resolves to `client/src/index.ts` → ERR_MODULE_NOT_FOUND → 502 Bad Gateway. The `pm2 restart` command does NOT preserve cwd from a previous `pm2 start` — always use `pm2 delete` + `pm2 start --cwd`.

**game.db removed from git tracking** (`git rm --cached server/game.db`). It's in `.gitignore` (`*.db`) but was previously committed. Now untracked — `git reset --hard` won't touch it on the VPS (but we still backup-then-restore as a safety net).

**Client build**: `npx vite build` in client dir. Server uses `npx tsx` (no tsc build — tsx runs TypeScript directly).

### Nginx Config (`/etc/nginx/sites-available/mmoarena`)
```nginx
server {
    listen 80;
    server_name mmoarena.ru www.mmoarena.ru;
    root /opt/game/client/dist;
    index index.html;

    location /api/ { proxy_pass http://127.0.0.1:3001; }  # no trailing slash — preserves /api prefix
    location /ws   { proxy_pass http://127.0.0.1:3001; }  # no trailing slash — matches /ws?token=...
    location /     { try_files $uri $uri/ /index.html; }
}
```

### Email Setup
- **Transport:** `nodemailer.createTransport({ sendmail: true, path: '/usr/sbin/sendmail' })`
- **From:** `noreply@mmoarena.ru`
- **Note:** PTR pending (reg.ru tech support). SPF configured: `v=spf1 ip4:194.226.142.237 a mx ~all`. Emails may still land in spam until PTR is set — client shows ⚠ warning on email confirmation pages (RegisterPage, LoginPage).
- WebSocket-based real-time chat
- `/w nick message` — private message (ЛС)
- Self-message blocked both client-side and server-side with error

## Design System

### Tailwind CSS v4
- Plugin: `@tailwindcss/vite` in `vite.config.ts`
- Theme tokens in `client/src/styles/theme.css` via `@theme {}` block
- CSS variables for colors: `var(--color-bg-primary)`, `var(--color-text-primary)`, etc.
- Dark theme: backgrounds `#1a1a2e` / `#1e1e30` / `#2a2a3e`

### Shared UI Components (`client/src/components/ui/`)
- **Button**: variants (primary/secondary/danger/ghost/success), sizes (xs/sm/md)
- **Card**: rounded container with optional borderColor
- **Modal**: overlay with close-on-backdrop
- **BackButton**: `← Назад` using navigate(-1)
- **ItemIcon**: colored square with rarity border + image

### Styling Rules
- Use CSS variables for colors: `text-[var(--color-text-primary)]`
- Use Tailwind utilities for layout: `flex`, `grid`, `p-4`, `gap-2`
- Responsive via Tailwind prefixes: `sm:`, `md:`
- Body has `padding-bottom: 42px` for collapsed chat bar
- HomePage flex container: `items-start` (prevent cross-column stretching)
- **Note:** PTR pending (reg.ru tech support). SPF configured: `v=spf1 ip4:194.226.142.237 a mx ~all`. Emails may still land in spam until PTR is set — client shows ⚠ warning on email confirmation pages (RegisterPage, LoginPage).

## Chat

- WebSocket-based real-time chat
- `/w nick message` — private message (ЛС)
- Self-message blocked both client-side and server-side with error
- **Messenger-style layout**: nicknames above bubbles, own messages right-aligned (blue), others left-aligned (dark), grouped by sender within 2-min windows, timestamps. See `game-frontend` skill → Chat Messenger-Style Layout.

## SEO & Analytics

### Meta Tags (`client/index.html`)
- `<title>`: «MMO Arena — Браузерная текстовая MMO в мире grimdark horror fantasy»
- `<meta name="description">`: полное описание с ключевыми словами (PvP, крафт, аукцион, гильдии)
- `<meta name="keywords">`: 15 релевантных слов
- **Open Graph**: `og:title`, `og:description`, `og:locale=ru_RU` — для соцсетей (VK, Telegram)
- **Twitter Card**: `summary`
- **robots**: `index, follow`
- **canonical**: `https://mmoarena.ru`
- **lang**: `ru`

### Top.Mail.Ru Counter
- Скрипт загружается в `index.html` (инициализация `_tmr = []`)
- `pageView` с реальным `user.id` отправляется из `App.tsx` через `useEffect` при наличии пользователя:
```ts
useEffect(() => {
    if (user && user.id) {
        const w = window as any;
        w._tmr = w._tmr || [];
        w._tmr.push({ id: "3771382", type: "pageView", start: (new Date()).getTime(), pid: String(user.id) });
    }
}, [user]);
```
- **Никогда не использовать шаблонный `USER_ID` в статическом HTML** — pid должен быть реальным ID из AuthContext

### Email Verification (Registration)
- **POST /api/register** — accepts `{username, email, password}`, creates user with `emailCode` + 10-min expiry, sends code via email, returns `{message}`. On SMTP failure: does NOT auto-verify. Returns 500 + clears code. User must retry via `/resend-code`.
- **POST /api/verify-email** — accepts `{email, code}`, verifies code, marks `emailVerified=1`, sets `lastLoginAt`, returns `{token, user}`.
- **POST /api/resend-code** — accepts `{email}`, generates new code (10-min expiry), sends via email. Only usable when `emailVerified=0`.
- Code: 6-digit, stored in `emailCode` column, expires in 10 minutes.
- Uniqueness: username and email checked at application level (NOT DB constraints — SQLite can't ALTER TABLE ADD UNIQUE).
- **Login emailVerified check**: only enforced when user HAS an email (`email IS NOT NULL AND email != ''`). OAuth users and legacy accounts without email skip this check. Migration: `UPDATE users SET emailVerified = 1 WHERE email IS NULL OR email = ''`.
- **Login 403 flow**: when login returns `{error: "Почта не подтверждена...", email: "user@..."}`, LoginPage switches to verification mode.
- **Spam warning**: both RegisterPage and LoginPage show ⚠ amber alert: «Письмо может попасть в спам.»
- **Pitfall — auto-verify on SMTP failure**: previously when sendmail failed, server auto-verified email and issued token. FIXED — now returns 500 error, user stays unverified, must retry via resend-code. Without this fix, every new player in production got auto-verified because sendmail is unreliable.
- **Pitfall — verify-email doesn't set lastLoginAt**: users who verify email get token without calling /login, so lastLoginAt stayed NULL. FIXED — verify-email now sets lastLoginAt to current unix timestamp.
- **Pitfall — sendmail queue delay**: sendmail may return success but delay delivery. First registration email may arrive late; resend often works because queue is already warm. This is infrastructure, not a code bug. PTR record setup with reg.ru tech support fixes deliverability.
- **Pitfall — auto-verify on SMTP failure**: previously when sendmail failed, server auto-verified email and issued token. FIXED — now returns 500 error, user stays unverified, must retry via resend-code. Without this fix, every new player in production got auto-verified because sendmail is unreliable.
- **Pitfall — verify-email doesn't set lastLoginAt**: users who verify email get token without calling /login, so lastLoginAt stayed NULL. FIXED — verify-email now sets lastLoginAt to current unix timestamp.

## Common Pitfalls

### Vite Cache
- **Client changes not visible**: restart Vite with `--force` flag AND clear `.vite` cache first. Use `execute_code` with `shutil.rmtree('.../node_modules/.vite')` — the `terminal` tool may reject `rm -rf` as a server process. After restart, tell user to `Ctrl+Shift+R`.
- **DB migrations not applied**: migrations only run on `server/src/index.ts` startup. After schema/migration changes, restart the server.

### Filesystem Cleanup
- **`terminal` rejects `rm -rf`**: the tool may classify it as a "long-running server process". Use `execute_code` with `import shutil; shutil.rmtree(path)` instead.

### UI Changes Not Taking Effect
- Check: Vite cache cleared, server restarted, `--force` flag used, user did hard refresh.
- Verify endpoints: `curl localhost:3001/api/endpoint` with auth token to confirm server returns new data.
- Verify client compile: `npx tsc --noEmit` in client directory.

See `references/bags-ideas-workflow.md` for the bugs+ideas→plan→execute workflow and dependency order of feature phases.

### Nginx & WebSocket
- **`location /ws/` vs `location /ws`**: client connects to `ws://host/ws?token=...`. Nginx `location /ws/` (with trailing slash) does NOT match `/ws?token=...` — the request falls through to SPA fallback and returns HTML instead of upgrading. Use `location /ws` (no trailing slash) to match both `/ws` and `/ws/...`.
- **`proxy_pass` trailing slash**: `proxy_pass http://backend/` strips the matched location prefix. `proxy_pass http://backend` passes the full URI. When backend routes are mounted with prefix (e.g., `app.use('/api', routes)`), use NO trailing slash to preserve the prefix.
- **`trust proxy`**: when using `express-rate-limit` behind nginx, Express must trust the reverse proxy: `app.set('trust proxy', 1)`. Otherwise rate-limiting breaks with `ERR_ERL_UNEXPECTED_X_FORWARDED_FOR`.

### SQLite Migrations
- **ALTER TABLE ADD COLUMN cannot add UNIQUE**: SQLite doesn't support uniqueness constraints via ALTER TABLE. Add column without UNIQUE, enforce uniqueness at application level with SELECT-before-INSERT.
- When adding DB columns, add ALTER TABLE migrations with try/catch for existing databases

### Auth
- **Login MUST check emailVerified**: after verifying password in `POST /api/login`, query `SELECT email, emailVerified FROM users WHERE id = ?`. If user has email AND `emailVerified === 0`, return 403 `"Почта не подтверждена"`. Skip this check for users without email (legacy/OAuth accounts) — otherwise they're locked out.
- **Registration error messages**: use generic `"Имя или email уже зарегистрированы"` instead of separate messages for username vs email — prevents username enumeration.
- **SMTP failure fallback (dev mode)**: when `sendVerificationCode` returns false, auto-verify: set `emailVerified=1`, clear code, return token immediately. This keeps local dev functional without sendmail/Postfix.

## Key Files to Check When Debugging

| Issue | Files |
|-------|-------|
| Battle bugs | `server/src/game/battle.ts`, `client/src/hooks/useBattleLogic.ts` |
| Stats/HP wrong | `server/src/game/stats.ts`, `client/src/utils/stats.ts` |
| Item/equip issues | `server/src/routes/character.ts` (equip endpoint) |
| Chat issues | `server/src/websocket.ts`, `client/src/components/chat/` |
| Level/XP issues | `server/src/routes/battle.ts` (level-up logic), `server/src/routes/character.ts` |
| Money display | `client/src/utils/money.ts`, `client/src/components/MoneyDisplay.tsx` |
