# Bank Transaction Safety Pattern

## Transaction Wrapper

All bank write operations (deposit, withdraw, transfer) use `db.transaction(fn)`:

```ts
const txn = db.transaction(() => {
    const target = db.prepare('SELECT id, bank FROM users WHERE accountNumber = ?').get(accountNumber);
    if (!target) throw new Error('Счёт не найден');
    if (target.id === userId) throw new Error('Нельзя перевести самому себе');

    const sender = db.prepare('SELECT bank FROM users WHERE id = ?').get(userId);
    if (sender.bank < transferAmount) throw new Error('Недостаточно серебра в банке');

    db.prepare('UPDATE users SET bank = bank - ? WHERE id = ?').run(transferAmount, userId);
    db.prepare('UPDATE users SET bank = bank + ? WHERE id = ?').run(receivedAmount, target.id);
    return db.prepare('SELECT bank FROM users WHERE id = ?').get(userId);
});

try { const result = txn(); res.json({ success: true, bank: result.bank }); }
catch (e) { res.status(400).json({ error: e.message }); }
```

## Rules
1. Check target exists BEFORE deduction
2. All reads+writes in one transaction
3. Throw on validation errors → auto rollback
4. Return updated state from transaction
