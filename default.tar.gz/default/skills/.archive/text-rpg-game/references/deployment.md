# VPS Deployment Reference

## Server Specs
- IP: 194.226.142.237
- OS: Ubuntu 26.04 LTS (Resolute Raccoon)
- CPU/RAM: 1 vCPU / 955 MB
- Disk: 8.6 GB (used ~2 GB)
- Hostname: mmoarena.ru
- Virtualization: KVM (OpenStack)
- SSH: root@194.226.142.237, key at ~/.ssh/id_ed25519 (ed25519)

## Domain
- Domain: mmoarena.ru
- Registrar: reg.ru
- NS: ns5.hosting.reg.ru, ns6.hosting.reg.ru
- A record: 194.226.142.237 (TTL 3600)

## Installed Packages
- nginx 1.28.3
- Node.js 22.22.1 + npm 9.2.0
- pm2 (global)
- Postfix + mailutils
- build-essential, python3 (for better-sqlite3 native build)

## Postfix Config
- myhostname = mmoarena.ru
- mydestination = localhost.localdomain, localhost
- inet_interfaces = loopback-only (send-only, no open relay)

## SPF Record
```
TXT @ "v=spf1 ip4:194.226.142.237 a mx ~all"
```
- `~all` = soft-fail (mark as spam but don't reject) — safer than `-all` while PTR/DKIM are being set up
- `a mx` = also allow servers listed in A and MX records

## PTR (Reverse DNS)
- **Not configurable in reg.ru panel for cloud VPS** — requires tech support ticket
- Request: "Прошу установить PTR-запись для IP 194.226.142.237 → mmoarena.ru. Номер VPS: cv7428291"
- Verify after setup: `dig -x 194.226.142.237 +short` should return `mmoarena.ru.`
- PTR is set in the VPS management interface (reverse zone), NOT in the domain DNS editor

## DNS Records (mmoarena.ru)
```
mmoarena.ru.      3600  A       194.226.142.237
www.mmoarena.ru.  3600  A       194.226.142.237
ftp.mmoarena.ru.  3600  A       194.226.142.237
mail.mmoarena.ru. 3600  A       194.226.142.237
smtp.mmoarena.ru. 3600  A       194.226.142.237
pop.mmoarena.ru.  3600  A       194.226.142.237
mmoarena.ru.      3600  MX 10   mail.mmoarena.ru.
mmoarena.ru.      3600  MX 20   mail.mmoarena.ru.
mmoarena.ru.      3600  TXT     "v=spf1 ip4:194.226.142.237 a mx ~all"
```
NS: ns5.hosting.reg.ru, ns6.hosting.reg.ru

## Hostname
```bash
hostnamectl set-hostname mmoarena.ru
```
Current: `mmoarena.ru` (was `cv7428291.novalocal`)

## Useful Commands
```bash
# Check server status
ssh root@194.226.142.237 'pm2 status && systemctl status nginx --no-pager'

# View logs
ssh root@194.226.142.237 'pm2 logs game-server --lines 20 --nostream'

# Deploy
ssh root@194.226.142.237 /opt/game/deploy.sh

# Check email queue
ssh root@194.226.142.237 mailq

# Manual DB query
ssh root@194.226.142.237 'cd /opt/game/server && node -e "
const Database = require(\"better-sqlite3\");
const db = new Database(\"game.db\");
console.log(JSON.stringify(db.prepare(\"SELECT ...\").all()));
"'
```
