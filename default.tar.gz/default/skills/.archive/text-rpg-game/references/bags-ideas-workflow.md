# Bags & Ideas Workflow

## Structure
- `.hermes/bags/` — bugs and improvements to fix (plain text, numbered items)
- `.hermes/ideas/` — feature specifications (markdown files, one per feature)

## How to process
1. Read all files in both folders
2. Parse bugs into priority-ordered list (P0=critical, P1=important, P2=nice-to-have)
3. Parse ideas into implementation phases (each idea becomes a phase)
4. Create a git tag `before-bags-and-ideas-YYYYMMDD` for rollback
5. Write plan to `.hermes/plans/bags-and-ideas-implementation.md`
6. Execute bugs first (Фаза 1, Фаза 2), then features in dependency order
7. Commit each phase separately with Russian commit messages
8. Some ideas are interdependent: equipment → shop/craft/auction, rating → tournament/orders, treasury → auction

## Dependency order for ideas

Ideal order (from 2026-06-03 session):
1. equipment.md (items, crafting, jobs, upgrade system) — foundational. Use `delegate_task` for the seed.
2. bestiary.md (PvE mobs) — needs equipment for balance context
3. treasury.md (bank) — standalone, small
4. tavern.md (healing, quests, potions) — standalone, medium
5. rating.md (ELO system) — standalone, medium
6. dark-market.md (auction) — depends on equipment values
7. tournament.md — depends on rating (registration + bracket, auto-battle pending)
8. orders.md (guilds) — depends on rating, auction, treasury (core done, wars/rituals pending)
9. navigation.md — layout change, last (depends on all features existing)

## Completed phases (2026-06-03)

| Phase | Commit | Description |
|-------|--------|-------------|
| 1a | 5961012 | Auth: emailVerified, OAuth above register/login, XP level-up on job completion, variable damage, account deletion |
| 1b | 29ab97f | Admin: removed regenHP, added item cost to DB + shop |
| 2 | 5ee014d | UX: password show/hide + Enter, crit icon (flame), battle log taller, grammar fix, actions grid |
| 3 | e3da489 | Bestiary: 30 mobs, PvE combat, material drops, 5-min cooldown |
| 4 | 6b40b4e | Equipment: 189 items + 20 jobs seeded from equipment.md (via delegate_task) |
| 5 | 1fe90d4 | Bank: treasury with 2% deposit fee, 30-min cooldown, PvP protection |
| 6 | e4b8822 | Tavern: healing, room rental (×3–×50 regen), 15 drink types |
| 7 | 348fc5f | ELO: 10-rank system, K-factor, eloChange in battle response |
| 8 | c5ba3c1 | Auction: listing 5%, commission 10%, price floors, bidding, buyout |
| 9 | 894397a | Tournament: 4 divisions, registration, Golden Ticket, prize pool |
| 10 | 49533ae | Orders: creation (5000🥇), ranks, treasury, join/leave/kick/promote |
| 11 | a181b64 | Navigation: За стенами / В замке zone split in Actions |

## Post-implementation fixes (2026-06-03)

**Email auto-verify for dev**: after implementing email verification, local dev broke because sendmail (Postfix) isn't available on WSL. Fix: in `POST /api/register`, when `sendVerificationCode` fails, auto-verify the user:
- Set `emailVerified = 1`, clear `emailCode`/`emailCodeExpires`
- Generate JWT and return token immediately (skip verify-email step)
- Login: only check `emailVerified` if user has an email (`email IS NOT NULL AND email != ''`)
- Migration: `UPDATE users SET emailVerified = 1 WHERE email IS NULL OR email = ''`
- OAuth users already get `emailVerified = 1` on creation — no change needed

**nodemailer missing**: server wouldn't start because `nodemailer` wasn't installed locally. Run `npm install nodemailer @types/nodemailer` in server/ if missing.

## Remaining future work
- Tournament auto-battle (bracket generation + runBattle for each match)
- Orders: wars, rituals, arsenal, order quests, order chat, level-up system
- Tavern quests: 38 daily quest types from tavern.md
- Chat improvements: @mentions, PM tabs, unread counters

## Adding new DB columns

Pattern: add to schema.ts CREATE TABLE, add migration in migrations.ts with `try { db.exec('ALTER TABLE ... ADD COLUMN ...') } catch {}`. Then add to any SELECT queries that need the column. Columns added this session on users: `lastPveAttackTime`, `bank`, `lastBankVisit`, `roomType`, `roomUntil`, `activeDrink`, `drinkUntil`, `elo`, `seasonWins`, `seasonLosses`, `lastEloDecay`. On items: `cost`.

## Adding new features (checklist)

1. Migration: add columns/tables in `migrations.ts` (try/catch)
2. Schema: add table/column to `schema.ts` for new databases
3. Seed: populate data in `seed.ts` (idempotent: check `COUNT(*) = 0` first)
4. Route: create `server/src/routes/<name>.ts` with Express Router
5. Register: import + `app.use('/api', authMiddleware, requirePlayer, router)` in `setupRoutes.ts`
6. Client API: `client/src/api/<name>.ts` (if needed)
7. Client Page: `client/src/pages/<Name>Page.tsx` with BackButton
8. App.tsx: import + Route
9. Actions.tsx: add card to home page grid
10. Verify: `npx tsc --noEmit` in both server/ and client/
