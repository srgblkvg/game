# Tournament System Reference

## Official Tournaments
- Continuous rolling: 30-min registration, 8 players max
- Auto-start: 8th player OR 30-min timeout
- Completed → new tournament immediately
- 4 divisions: copper(1-15), steel(16-35), mithril(36-60), adamant(61+)
- Division filtering: check `divisions` array level ranges, NOT `minLevel`/`maxLevel`

## Bracket
- Adjacent pairing: sort by `tournamentElo` ASC, pair (1-2, 3-4, ...)
- Pad to next power-of-2 with byes
- Subsequent rounds: adjacent winners
- Golden ticket does NOT affect seeding

## Custom Tournaments
- `type='custom'`, `division='custom'`
- No golden ticket, no auto-creation of new tournaments
- Entry fees added to prize pool on join
- `basePool` column: creator's contribution (for refund calc)
- Cancel if < 2: refund `basePool` to creator, `entryFee` to each participant
- Creator pays prize pool + entry fee, auto-registered

## Auto-Advance
- `autoAdvance()` runs on GET /tournament for all tournaments
- Only creates new tournaments for `type='official'`
- Completed → immediate new official tournament for same division
- Registration expired with < 2 → cancelled, new official created

## Pitfalls
- `generateBracket` cancels if participants < 2 → must handle refund in custom tournaments
- `registrationEnd` comparison uses unix timestamps
- `getOrCreateTournament` must find active-by-division for ALL statuses not just `registrationEnd > now`
