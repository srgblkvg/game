---
name: text-rpg-mechanics
description: Game mechanics and architecture for the text-based online RPG at /mnt/c/project/game. Covers battle system, stats, XP/leveling, currency, and UI patterns.
version: 1.0.0
metadata:
  hermes:
    tags: [game, rpg, mechanics, battle, stats]
---

# Text RPG Game Mechanics

## Project Overview

Browser-based text RPG with Express + SQLite backend and React + Vite + Tailwind frontend. Russian-language UI. Located at `/mnt/c/project/game`.

## Battle System

- Turn-based, determined by Agility (A): higher A goes first
- No stamina — each turn attacks immediately
- Loop: `while (hpA > 0 && hpD > 0)` — fight to the death (HP can reach 0)
- Mechanics: dodge, crit, block, fullBlock, counter, stun
- Stun: blocked character skips their next turn (no regen needed since no stamina)
- Winner steals 10-50% of loser's money
- **Formula tuning** (reduced from original — effects were triggering too often):
  - Extra stats from equipment contribute at `/200` instead of `/100`
  - Dodge max: 0.5, Crit max: 0.8, Counter max: 0.5
  - Counter base ×0.5, Stun base ×0.3

## Stats

- **4 base stats**: S (Strength/damage), A (Agility/dodge+initiative), D (Defense/block), M (Mastery/crit+counter+stun)
- **HP = S + A + D + M** (no V / Vitality — removed)
- **No stamina** — removed from entire game
- Base stats stored per-user in DB: `baseS, baseA, baseD, baseM` (default 5)
- Stats from equipment: bonuses multiplied by `1 + upgradeLevel * 0.05`

## Leveling & XP

- **XP formula**: `10 * 2^(level - 1)` — 10, 20, 40, 80, 160, 320...
- **No level cap** — can grow indefinitely
- Each level-up grants **+5 free stat points** (`statPoints` column)
- Stat allocation endpoint: `POST /api/character/allocate-stats { s, a, d, m }`
- XP from battles: +1 for equal level, +2 for higher-level opponent
- XP from jobs: `Math.max(1, Math.floor(duration / 3600))` — 1 EXP per hour

## Currency

- **Single currency**: "серебро" (silver), stored as integer
- Display: `formatMoney(n)` → `"1 838 серебра"` — текст, без эмодзи
- В шапке: `Серебро: {money.toLocaleString()}` — белый текст, без SVG-иконки
- No gold/silver/bronze split

## UI Design System

- **Tailwind CSS v4** with `@tailwindcss/vite` plugin
- Theme: `client/src/styles/theme.css` with CSS custom properties
- Shared components in `client/src/components/ui/`: Button, Card, Modal, Badge, BackButton, PageHeader, ItemIcon, FilterBar, EmptyState
- Character cards: weapon slots at bottom, body slots on sides, gray border (`#555`)
- Chat panel: `position: fixed; bottom: 0; height: 300px open / 40px closed`
- Body padding: `42px` (room for collapsed chat bar)
- HomePage layout: `items-start` so sidebars don't stretch each other
- Action cards: `w-[200px]` mobile, `min-w-[200px] max-w-[280px]` desktop
- Actions alignment: full-bleed with `w-screen ml-[calc(-50vw+50%)]` on mobile
- Rating block: `min-w-[180px]`

## Item Display

- **ItemStats component** (`client/src/components/ItemStats.tsx`) — shared between ItemTooltip and ShopPage
  - Item name: colored text, NO border frame (user preference)
  - Rarity line: "Редкость: Хлам" in muted text
  - Stat table: name left, value right in white (NOT rarity color), alternating row backgrounds, borders between rows
- **getRarityColor(item)**: returns `rarity_color` or computes from `rarity_id` (0-6 → gray/white/green/blue/purple/yellow/red)
- **getItemImage(item)**: returns image path from `item.image`, or computes from slot+rarity_id (e.g. `sword/sword_white.webp`). Maps: weapon1→sword, weapon2→shield, ring1→ring, craft→fragment, upgrade→stoneUpgrade
- Image files live in `client/public/{slot}/{slot}_{color}.webp`
- All item-returning queries (getItemData) MUST include `i.image` in SELECT
- Enriched items MUST include `image: itemRow.image || item.image || null`

## Database

- `stat_names` table: (id, name, nameRu) — canonical stat name mappings
  - API: `GET /api/stat-names`
- `users` table key columns: baseS, baseA, baseD, baseM, statPoints

## CharacterCard Slots Layout

- Left column: amulet, ring1, ring2, belt (position: absolute, left: 4px, top: 10px)
- Right column: helmet, chest, gloves, boots (position: absolute, right: 4px, top: 10px)
- Bottom: weapon1, weapon2 (position: absolute, bottom: 2px, centered)
- Frame: overflow visible (not hidden) so weapon slots are clearly below body slots
- No colored border (red/blue) — always `#555`

## Tournament System

### Architecture
- Table: `tournaments` with columns for division, status, timing, prize pool, type (official/custom)
- Supporting tables: `tournament_participants`, `tournament_matches`
- 4 divisions: copper (1-15), steel (16-35), mithril (36-60), adamant (61+)
- **Continuous mode**: official tournaments run non-stop — max 8 players or 30-min window, then auto-start + auto-create new
- Custom tournaments: created by players with `entryFee`, `basePool`, `minLevel`, `maxLevel`

### Bracket Generation (`generateBracket`)
- Participants sorted by `tournamentElo` ASC (hidden Elo for tournament seeding only)
- Adjacent pairing (1-2, 3-4...) — same-skill players fight each other, NOT Olympic-style
- Padded to next power of 2 with nulls (bye)
- Golden ticket does NOT affect seeding
- Players get full HP before each tournament battle (`currentStats` calculated on-the-fly)

### Match Resolution
- `resolveCurrentRound`: processes all pending matches in current round
- Uses `runBattle` with full player stats + equipment
- `advanceWinners`: creates next-round matches with adjacent pairing (winners[i*2] vs winners[i*2+1])
- `finishTournament`: distributes 50%/30%/20% of prize pool to top 3

### Custom Tournaments
- Created via `POST /api/tournament/create-custom` — creator pays prizePool + entryFee
- Entry fees added to prizePool; `basePool` tracks creator's original contribution
- On cancel (< 2 players): refund basePool to creator, entryFee to all participants
- Division column = 'custom' (NOT null — NOT NULL constraint)

### Elo
- `tournamentElo` (hidden, DEFAULT 1000) for seeding only — not shown to players
- Updated after tournament: winner +25, 2nd +15, 3rd +10, R1 survivors +3, R1 losers -3, min 100

### Tournament History
- API: `GET /api/tournament?tab=active|completed&type=all|official|custom&page=N`
- Completed tab excludes tournaments with < 2 participants
- Tab filtering on TournamentPage: Все/Официальные/Самоорганизованные/Завершённые

## Bank System

### Account Numbers
- Each player gets a unique 6-char alphanumeric account number (chars: 2-9, A-Z excluding 0/O/1/I/l)
- Generated on server start for users without one (`migrations.ts`)
- UNIQUE index on `accountNumber`

### Operations
- **No cooldown** — bank accessible anytime (removed 30-min `lastBankVisit` restriction)
- **Guests blocked**: `requireFullAccess` middleware
- Deposit: commission 2%, money moves pocket→bank
- Withdraw: free, money moves bank→pocket
- **All write operations use `db.transaction()`** for atomicity — prevent race conditions

### Transfers
- Bank-to-bank only (deduct from sender's `bank`, credit to receiver's `bank`)
- Commission 2%, verified account existence BEFORE deduction
- Saved to `transfers` table with full details

### History
- `bank_operations` table: deposit/withdraw with commission
- `transfers` table: sender/receiver, accounts, amount, commission
- API: `GET /api/bank/transfers?filter=in|out|all`, `GET /api/bank/operations?filter=deposit|withdraw|all`
- Frontend: commission preview shown BEFORE submission (`depositCommission`, `transferCommission`)

### Bank Page Structure
- 3 tabs: Информация (balance + combined history), Пополнение (deposit/withdraw + history), Переводы (transfer + history)
- Filter sub-tabs in history sections (Все/Входящие/Исходящие, Все/Пополнение/Снятие)

## Quest System (Daily)

### Data Model
- `daily_quests` table: userId, questType, difficulty, requirement, progress, rewardXp, rewardMoney, status, snapshot, date
- `quest_history` table: completed quests record with rewards
- Counters on users: `craftCount`, `auctionTrades`, `totalJobSeconds` (for tracking)

### Quest Types & Requirements
- 5 types: hunt (mobs), arena (PvP wins), job (time-based), craft (create/improve), auction (trades)
- 3 difficulties (random): easy/medium/hard
- Multipliers: hunt/arena use ×1/×5/×25; craft/auction use ×1/×3/×6; job uses time: 10m/1hr/4hr
- Rewards scale: medium ×1.5, hard ×2 of base reward

### Progress Tracking (Snapshot-based)
- On quest activation: snapshot current counters (pveTotalBattles, wins, craftCount, auctionTrades, totalJobSeconds)
- Progress = current counter - snapshot value
- Updated on each GET /tavern/quests call

### Quest Lifecycle
- 5 quests generated daily (one per type), midnight reset
- Max 3 active simultaneously, daily limit 5 completed
- After claiming a quest → new quest of same type with random difficulty appears immediately
- Save to `quest_history` on claim

### UI
- Tavern tab: Задания — shows all 5 quests with status, description, progress, "Награда:" label
- QuestsBlock on main page (above tournaments): shows active quests compactly (icon + name + description + progress bar)
- **Click behavior**: active quest → highlight Actions card (blue ring, 3-sec auto-clear, scroll on mobile); completed quest → open tavern
- Completed quest notification via `showAcquire` context (popup)

## Key Pitfalls

- Character card frame `overflow: hidden` clips weapon slots — changed to `overflow: visible` with inner wrapper for background clipping
- Client-side stamina regen intervals conflict with server step values — removed entirely
- `battleResult.hpAfter` field is the ATTACKER's HP (matches server `attackerHpAfter`)
- Don't override damage-step HP with battleResult HP at battle end — let damage steps be authoritative
- JobsPage `activeJob` object needs the `activeJob: { ... }` wrapper in setCharacter
- Battle loop `while (hp > 1)` leaves HP at 1 — changed to `while (hp > 0)`
- `5 * Math.pow(2, level-1)` base stat formula replaced with DB-stored `baseS/baseA/baseD/baseM`
