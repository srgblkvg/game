# PvE Battle Animation (Bestiary / Mobs)

This pattern handles step-by-step battle animation for mob/PvE fights. It must match Arena PvP animations exactly.

## Key Functions (copy from useBattleLogic.ts)

```typescript
// Shows floating text on the effect overlay (УКЛОНЕНИЕ, БЛОК, КРИТ, etc.)
const showEffectText = (side: 'left' | 'right', text: string, color = '#f1c40f') => {
    const overlay = document.getElementById(`effect-${side}`);
    if (!overlay) return;
    overlay.textContent = text;
    overlay.style.color = color;
    overlay.classList.add('show');
    overlay.addEventListener('animationend', () => overlay.classList.remove('show'), { once: true });
};

// Shows floating damage numbers on the card
const showDamageNumber = (side: 'left' | 'right', dmg: number) => {
    const card = document.getElementById(`fighter-${side}`);
    if (!card) return;
    const float = document.createElement('div');
    float.className = 'damage-float';
    float.textContent = `-${dmg}`;
    card.appendChild(float);
    float.addEventListener('animationend', () => float.remove());
};

// Applies CSS animation classes to the fighter frame
const executeStep = (step: any, side: 'left' | 'right') => {
    const frame = document.getElementById(`fighter-${side}`);
    const card = document.querySelector(`.fighter-card.${side}`) as HTMLElement;
    
    if (step.type === 'attack' || step.type === 'crit' || step.type === 'counter') {
        if (card) card.style.zIndex = '20';
        frame?.classList.add('attacking');
        setTimeout(() => {
            frame?.classList.remove('attacking');
            if (card) card.style.zIndex = '';
        }, 600);
    } else if (step.type === 'dodge') {
        frame?.classList.add('dodging');
        setTimeout(() => frame?.classList.remove('dodging'), 500);
        showEffectText(side, 'УКЛОНЕНИЕ!', '#f1c40f');
    } else if (step.type === 'block' || step.type === 'fullBlock') {
        frame?.classList.add('blocking');
        setTimeout(() => frame?.classList.remove('blocking'), 600);
        showEffectText(side, step.type === 'fullBlock' ? 'ПОЛНЫЙ БЛОК!' : 'БЛОК!',
            step.type === 'fullBlock' ? '#9b59b6' : '#3498db');
    } else if (step.type === 'stun') {
        frame?.classList.add('stunned');
        setTimeout(() => frame?.classList.remove('stunned'), 1000);
        showEffectText(side, 'ОГЛУШЁН', '#f1c40f');
    }
    // crit: attacking + showEffectText('КРИТ!', '#e74c3c')
    // counter: attacking + showEffectText('КОНТРАТАКА!', '#f1c40f')
};
```

## Incremental HP Tracking (NOT computeHp replay)

**OLD (broken)**: `computeHp()` replays ALL steps from 0 to current — incompatible with animation because states must update incrementally for CSS transitions to fire.

**NEW (correct)**: Each `nextStep` applies damage directly via `setState(prev => prev - dmg)`:

```typescript
const nextStep = useCallback(async () => {
    if (stepLock.current) return;
    const steps = stepsRef.current;
    const next = currentStepRef.current + 1;
    if (next >= steps.length) { stopAuto(); return; }
    stepLock.current = true;
    const step = steps[next];
    currentStepRef.current = next;
    setCurrentStep(next);

    // Resolve actor: player when message starts with 'Вы' or step.actor === 'attacker'
    const playerActor = step.actor === 'attacker' || step.message?.startsWith('Вы');

    // Run animation on appropriate side
    if (step.type === 'attack' || step.type === 'crit' || step.type === 'counter') {
        executeStep(step, playerActor ? 'left' : 'right');
    } else if (step.type === 'dodge') {
        executeStep(step, playerActor ? 'left' : 'right');
    } else if (step.type === 'block' || step.type === 'fullBlock') {
        executeStep(step, playerActor ? 'right' : 'left'); // block animates defender
    } else if (step.type === 'stun') {
        executeStep(step, playerActor ? 'right' : 'left');
    }

    // Apply damage incrementally
    if (step.type === 'damage' && step.damage) {
        if (step.target === 'attacker') {
            setPlayerHp(prev => Math.max(0, prev - step.damage));
            showDamageNumber('left', step.damage);
        } else {
            setMobHp(prev => Math.max(0, prev - step.damage));
            showDamageNumber('right', step.damage);
        }
    }

    scrollLog();
    const isDamage = step?.type === 'damage';
    await new Promise(r => setTimeout(r, (isDamage ? 1000 : 700) / speedRef.current));
    stepLock.current = false;
}, [scrollLog, stopAuto]);
```

## Side resolution

- Player is ALWAYS left, mob is ALWAYS right
- `playerActor`: step.actor === 'attacker' OR step.message.startsWith('Вы')
- Attack/crit/counter/dodge: animate the ACTOR's side
- Block/fullBlock/stun: animate the DEFENDER's side (opposite of actor)

## Skip handler

When skipping, set final HP from battleResult (NOT from recomputing steps):

```typescript
const handleSkip = () => {
    stopAuto();
    const last = steps.length - 1;
    currentStepRef.current = last;
    setCurrentStep(last);
    if (battleResult) {
        setPlayerHp(Math.max(0, battleResult.hpAfter ?? 0));
        setMobHp(Math.max(0, battleResult.hpDefenderAfter ?? 0));
    }
};
```

## Prerequisites

- `effect-overlay` div must exist in CharacterCard `<div className="effect-overlay" id={`effect-${side}`}></div>`
- CSS classes `.attacking`, `.dodging`, `.blocking`, `.stunned`, `.damage-float`, `.effect-overlay.show` are in `theme.css`
- `fighter-left` and `fighter-right` IDs on the CharacterCard frame divs
