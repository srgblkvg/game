# Hermes Browser via CDP (Ubuntu 26.04 Workaround)

## Problem

Playwright browsers cannot install on Ubuntu 26.04 (too new, unsupported).
`npx playwright install chromium` → `ERROR: Playwright does not support chromium on ubuntu26.04-x64`
Same for Firefox and WebKit.

Hermes browser tools (`browser_navigate`, `browser_snapshot`, etc.) use `agent-browser` CLI,
not Playwright directly. But agent-browser downloads its own Chrome which also needs
system libraries (libnspr4.so, etc.) that require sudo to install.

## Solution: System Chromium + CDP

### 1. Install agent-browser globally
```bash
npm install -g agent-browser
# Binary at: ~/.hermes/node/bin/agent-browser
```

### 2. Start system Chromium with remote debugging
```bash
chromium-browser --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 &
```

### 3. Configure Hermes to use CDP
```bash
hermes config set browser.cdp_url "http://localhost:9222"
```

### 4. Auto-start Chromium CDP (add to ~/.bashrc)
```bash
if ! pgrep -f "chromium.*remote-debugging-port=9222" >/dev/null 2>&1; then
    nohup chromium-browser --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 >/dev/null 2>&1 &
fi
```

## Verification
```bash
curl -s http://localhost:9222/json/version | jq .Browser
# Should return: "Chrome/148.0.7778.167"
```

## Notes
- System Chromium on WSL/Ubuntu comes from snap: `/snap/bin/chromium`
- Hermes config path: `~/.hermes/config.yaml` → `browser.cdp_url`
- The config `browser.local.executable_path` is for Playwright, not used with CDP
- agent-browser version used: 0.27.0
