# Tailwind Migration — Text RPG Game

## Migration Steps (Ordered)

1. **Install**: `npm install tailwindcss @tailwindcss/vite`
2. **Vite config**: Add `import tailwindcss from '@tailwindcss/vite'` + add to plugins array
3. **Create theme.css**: `@import "tailwindcss"` then `@theme { ... }` block with all CSS variables
4. **Update main.tsx**: Replace old CSS import with `./styles/theme.css`
5. **Create shared UI components** (order):
   - `Button` (with variant/size/fullWidth/disabled)
   - `Card` (with borderColor/padding)
   - `Modal` (with open/onClose/title)
   - `Badge`, `BackButton`, `PageHeader`, `ItemIcon`, `FilterBar`, `EmptyState`
6. **Refactor pages** one by one, smallest first:
   - LoginPage → AdminRegisterPage → ProfilePage → RatingPage → HistoryPage
   - JobsPage → ArenaPage → ShopPage → CraftPage
   - HomePage → AdminPanel pages
7. **Delete old CSS**: Remove `index.css` and `arena.css` once all animations are moved to `theme.css`
8. **Verify**: `npx tsc --noEmit` + `npx vite build`

## Key Replacements

| Before (inline style) | After (Tailwind) |
|---|---|
| `style={{ color: '#eee', padding: '1rem' }}` | `className="text-[var(--color-text-primary)] p-4"` |
| `style={{ background: '#1e1e30' }}` | `className="bg-[var(--color-bg-secondary)]"` |
| `style={{ border: '1px solid #555', borderRadius: '4px' }}` | `className="border border-[var(--color-border-light)] rounded"` |
| `style={{ display: 'flex', gap: '1rem' }}` | `className="flex gap-4"` |
| `<button style={{...}}>` | `<Button variant="..." size="...">` |
| Inline modal div | `<Modal open={...} onClose={...}>` |

## Battle System Changes (Server)

- Stamina removed entirely: no regen, cost, or stamina steps in battle log
- Battle loop: `while (hpA > 0 && hpD > 0)` — fight to death
- HP = S + A + D + M (no V stat, V=100 removed)
- Levels: no cap, XP requirement = `10 * 2^(level-1)`
- Level up: +5 stat points (not auto-doubling stats)
- Jobs reward EXP: `1 EXP per 60 minutes` (minimum 1)

## Currency System

- Single currency: серебро (сер.)
- Removed gold/silver/bronze split
- `formatMoney(total)` → `"1 838 сер."`
- `MoneyDisplay` → number + silver circle SVG
