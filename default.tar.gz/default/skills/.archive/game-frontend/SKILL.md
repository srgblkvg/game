---
name: game-frontend
description: "Frontend conventions for the text RPG game — Tailwind v4 design system, UI components, responsive patterns, currency/stats display."
version: 1.0.0
metadata:
  hermes:
    tags: [game, react, tailwind, design-system, frontend]
    related_skills: [tailwind-setup]
---

# Game Frontend Design System

## Overview

The text RPG game (client at `/mnt/c/project/game/client`) uses React 19 + TypeScript + Vite 8 with Tailwind CSS v4. All styling is through Tailwind utility classes and CSS custom properties defined in `@theme`. No inline `style={{}}` objects — use Tailwind classes exclusively. When a dynamic value is unavoidable (e.g. per-item rarity color), use a `style` prop ONLY for that one dynamic property, not the whole element.

## Tailwind Setup

- **Plugin**: `@tailwindcss/vite` in `vite.config.ts`
- **Theme file**: `client/src/styles/theme.css` — contains `@import "tailwindcss"` and `@theme { ... }` block with all design tokens as CSS variables
- **No tailwind.config.js** — Tailwind v4 uses CSS-based config

## Design Tokens

All colors, shadows, and common values are CSS variables in `@theme`:

| Token | Value | Usage |
|-------|-------|-------|
| `--color-bg-primary` | `#1a1a2e` | Page background |
| `--color-bg-secondary` | `#1e1e30` | Section backgrounds |
| `--color-bg-card` | `#2a2a3e` | Card backgrounds |
| `--color-bg-input` | `#333` | Input/select backgrounds |
| `--color-text-primary` | `#eee` | Main text |
| `--color-text-secondary` | `#ccc` | Secondary text |
| `--color-text-muted` | `#888` | Muted/disabled text |
| `--color-text-accent` | `#f1c40f` | Accent/highlight text (gold) |
| `--color-accent-success` | `#2ecc71` | Success (green) |
| `--color-accent-danger` | `#e63946` | Danger/error (red) |
| `--color-accent-info` | `#3498db` | Info/primary (blue) |
| `--color-accent-purple` | `#9b59b6` | Purple accent (EXP, mastery) |
| `--color-border-default` | `#444` | Default borders |
| `--color-border-light` | `#555` | Lighter borders |
| `--color-rarity-{tier}` | varies | Rarity colors (junk through mythic) |
| `--shadow-card` | `0 4px 12px rgba(0,0,0,0.8)` | Card shadow |

**Rule**: Always reference colors via CSS variables, never hardcode hex values:
```
bg-[var(--color-bg-card)]  ✓
bg-[#2a2a3e]               ✗ (never)
```

## Shared UI Components

Location: `client/src/components/ui/`

| Component | Props | Usage |
|-----------|-------|-------|
| `Button` | `variant` (primary/secondary/danger/ghost/success), `size` (xs/sm/md), `fullWidth`, `disabled`, `icon`, `className` | All buttons — never render a raw `<button>` |
| `Card` | `borderColor?`, `padding?` (sm/md/lg), `className` | All card containers |
| `Modal` | `open`, `onClose`, `title?`, `children`, `maxWidth?`, `borderColor?` | All modal dialogs |
| `Badge` | `color?`, `text` | Small colored labels |
| `BackButton` | `to?` | "← Назад" button with `navigate(-1)` |
| `PageHeader` | `title`, `children?` | Page title with optional actions |
| `ItemIcon` | `item?`, `color?`, `image?`, `name?`, `size?` | Item icon square — auto-computes image from slot+rarity if `item` provided, falls back to `color`+`name` |
| `FilterBar` | `children`, `className?` | Flex container for filter controls |
| `EmptyState` | `message?` | Centered "nothing here" placeholder |

## Actions Layout (Two-Zone)

The home page Actions component (`client/src/components/Actions.tsx`) displays action cards split into two zones per ideas/navigation.md:

- **🌍 За стенами** (dangerous outside): Охота (Бестиарий), Работы (Экспедиции) — 2-column grid
- **🏰 В замке** (safe inside): Арена, Магазин, Сундук, Крафт, Аукцион, Трактир — 3-column grid on desktop, 2-col on mobile

Implementation: two separate `ActionCard[]` arrays (`outsideCards`, `castleCards`) rendered by a shared `CardGrid` component. Each zone has a header with `game-icons:castle-ruins` / `game-icons:castle` icons. Cards use `p-2` padding (tighter than old `p-4`), `text-[0.8rem]` titles.

**Card format** (add new features here):
```ts
{ icon: 'game-icons:xxx', title: 'Название', subtitle: 'Описание',
  cost: 0, path: '/route', buttonText: 'Перейти',
  bgClass: 'url(/action_xxx.webp)', variant: 'danger' as const }
```
Cards with `path: null` and `cost > 0` are treated as arena (cooldown-aware) buttons.

## Responsive Patterns

- **Mobile-first**: base classes = mobile, `sm:` prefix = ≥640px desktop
- **No `useState(isMobile)`**: use Tailwind responsive prefixes instead — `flex-col sm:flex-row`, `grid-cols-1 sm:grid-cols-2`, etc.
- **Horizontal scroll**: `overflow-x-auto hide-scrollbar` for horizontally scrollable sections on mobile
- **Flex stretching fix**: always add `items-start` to flex containers with sidebars to prevent cross-axis stretching

## Empty Slot Styling

Empty slots are rendered by `SlotBase.tsx`, which is shared across inventory (`LongPressItemSlot → ItemSlot → SlotBase`) and equipment (`LongPressSlot → Slot → ItemSlot → SlotBase`). The component distinguishes slot type by the presence of a `title` prop:

- **Equipment slots** pass `title={slotNames[slotId]}` (e.g. "Шлем", "Амулет") — background `rgba(0,0,0,0.35)` (dark, readable against card's `#2a2a3e`). Show an ICON (see equipment slot icon table above) at 24px with `opacity: 0.5`.
- **Inventory slots** pass no `title` — background `rgba(0,0,0,0.6)` (darker), show "Пусто" text
- All empty slots get `border: 2px solid #555` (SOLID, not dashed — user explicitly rejected dashed borders)
- Border is applied in `ItemSlot.tsx` via `customStyle.border`, NOT in SlotBase (ItemSlot's shorthand overwrites SlotBase's `borderStyle`)

The empty label in SlotBase:
```
{!item && (
  iconName ? (
    <Icon icon={iconName} width="24" height="24" style={{ opacity: 0.5 }} />
  ) : (
    <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.55rem', ... }}>
      Пусто
    </span>
  )
)}
```

Equipment slots show the mapped icon; inventory slots show "Пусто". Ring slots display as "Кольцо" (not "Кольцо 1"/"Кольцо 2" — user requested simplified naming). Weapon slots: "Оружие 1" (sword icon), "Оружие 2" (shield icon).

**CRITICAL**: SlotBase is a SHARED component. Any change to SlotBase affects ALL slot types (inventory, equipment, craft, resources). Test visually after every SlotBase change by checking inventory grid AND equipment paperdoll AND resource slots.

## Arena Slot Sizing

CharacterCard on arena uses `compact` prop with 3 modes. Slot sizes must fit proportionally within the frame:

| Mode | Frame H | Card W | Slot Size | Slot Gap | Font |
|------|---------|--------|-----------|----------|------|
| Desktop | 240px | 200px | 44px (default) | 4px | 0.65rem |
| Mobile (<600px) | 180px | 150px | 26px | 4px | 0.55rem |
| VerySmall (<420px) | 140px | 110px | 20px | 2px | 0.55rem |

Formula check for no overlap: vertical 4 slots must end before weapon row starts.
- verySmall: 4×20 + 3×2 = 86px, top:8px → ends 94px. Weapons start: 140-2-20=118px. ✓
- mobile: 4×26 + 3×4 = 116px, top:10px → ends 126px. Weapons: 180-2-26=152px. ✓

## Mobile Layout

- **Desktop**: `flex flex-wrap gap-6 justify-center items-start` — original 3-column flow
- **Mobile**: each sidebar has `w-full sm:w-auto` — full-width on mobile, auto on desktop
- **LeftSidebar**: `flex flex-col items-center sm:items-start` — centers character card on mobile
- **Character centering**: use `items-center` on the sidebar wrapper, not on the card itself

## Compact Header

Header (`Header.tsx`) is a single flex row with `flex-wrap`:
- Money display on the left
- Protection timer always visible next to money:
  - Active: blue shield icon + MM:SS timer on blue background
  - Inactive: gray `shield-disabled` icon + «нет защиты» on muted background
- Account/Notifications buttons on the right (`ml-auto`)
- No separate rows for money/protection — all inline

## Onboarding Hint

On `HomePage`, when player has `money === 0` AND empty inventory (`inventory.length === 0`), show a subtle hint:
```
<div className="mb-4 p-3 bg-[rgba(52,152,219,0.1)] border border-[rgba(52,152,219,0.3)] rounded-lg text-sm text-center">
  💡 Начните с <b>🛠️ Приключений</b> — заработайте серебро и купите снаряжение в <b>🛒 Магазине</b>
</div>
```
This appears above the three-column layout, disappears automatically once player earns money or gets items.

## Layout Rules

- **Page container**: `px-4 py-4`
- **Body**: `padding-bottom: max(env(safe-area-inset-bottom, 42px), 50px)` — room for collapsed chat bar (40px + 2px border), 50px minimum. This prevents the collapsed chat panel from covering the rating block on mobile.
- **Chat panel**: `position: fixed; bottom: 0; z-index: 1000` — ALWAYS overlays, never reserve space for it in page content
- **Desktop**: `flex flex-wrap gap-6 justify-center items-start` (3-column flow)
- **Mobile**: each column has `w-full sm:w-auto` for full-width stacking
- **LeftSidebar**: `flex flex-col items-center sm:items-start` — centers character card on mobile, left-aligns on desktop

## Currency

- Single currency: **серебро** (silver)
- `formatMoney(total)` returns localized number + word with Russian plural: 1→"серебро", 2-4→"серебра", 5+→"серебра"
- **No emoji** (🥇 💰 or coin icons like `game-icons:coins`) — text only. Where «серебро» word is missing from context (form labels, column headers), add it explicitly: «Стоимость (серебро)», «5000 серебра».
- **Header balance**: plain text `Серебро: N` with `text-white`, no `MoneyDisplay` component, no SVG/Iconify icons. `MoneyDisplay` is deprecated — do not use in new code.
- Never show raw numbers — always use `formatMoney()`

## Icons

Project uses `@iconify/react` + `@iconify-json/game-icons` (4000+ RPG icons from game-icons.net). Install: `npm install @iconify/react @iconify-json/game-icons`. Import: `import { Icon } from '@iconify/react'`. Usage: `<Icon icon="game-icons:sword" width="18" height="18" />`.

**Key icon mappings** (action cards, header, pages):
- `game-icons:coins` — ~~money (header and money display)~~ **DEPRECATED in header — use text «Серебро: N» instead. Keep for arena battle results only.**
- `game-icons:person` — account/profile button
- `game-icons:bell-ring` — notifications/history button (NOT `game-icons:scroll` — user rejected it)
- `game-icons:bell` — new alert indicator
- `game-icons:shield` — protection/defense timer (active)
- `game-icons:shield-disabled` — protection timer (inactive, «нет защиты»)
- `game-icons:buy-card` — shop card
- `game-icons:crossed-swords` — arena/battle card
- `game-icons:swap-bag` — adventures/jobs card (NOT `game-icons:anvil` — anvil is for craft)
- `game-icons:anvil` — craft card (NOT `game-icons:hammer-drop`)
- `game-icons:trophy` — rating/leaderboard, victory
- `game-icons:backpack` — inventory title
- `game-icons:speech-bubble` — chat panel title
- `game-icons:private` — private message in history/notifications (NOT `game-icons:speech-bubble` for history)
- `game-icons:hourglass` — cooldown/timer
- `game-icons:skull` — defeat/death

**Collapse/expand arrows**: Text arrows `▶` (collapsed) / `▼` (expanded) — used for Stats block, BuffsBlock, and Chat panel. User explicitly rejected icon-based arrows — text arrows are more readable and consistent. NEVER use `game-icons:caret-right` or any icon-based chevron for collapse toggles.

**Sort icons**: `game-icons:sort-amount-up` (default/unsorted ⇅), `game-icons:arrow-up` (asc ↑), `game-icons:arrow-down` (desc ↓). NOT `game-icons:swap`.

**Arena icons**: `game-icons:lightning-bolt` (fight button ⚡), `game-icons:cycle` (reroll opponent 🔄), `game-icons:coins` (money stolen 🪙), `game-icons:cash` (money lost 💸), `game-icons:level-up` (level gain ⬆).

**Equipment slot icons** (empty slots show these instead of text):
| Slot | Icon |
|------|------|
| Шлем | `game-icons:helmet` |
| Нагрудник | `game-icons:chest-armor` |
| Перчатки | `game-icons:gloves` |
| Ботинки | `game-icons:boots` |
| Амулет | `game-icons:gem-necklace` |
| Кольцо | `game-icons:ring` |
| Пояс | `game-icons:belt` |
| Оружие | `game-icons:broadsword` |
| Щит | `game-icons:shield` |

Defined in SlotBase.tsx `EQUIPMENT_ICONS` mapping. Icons render at 24px with `opacity: 0.5`. Inventory empty slots still show "Пусто" text (no icon).

**Pitfall**: When replacing emoji in JSX ternary expressions, NEVER embed Icon as a string: `{cond ? '<Icon .../>Text' : '<Icon .../>Text'}` will break JSX parsing. Use React fragments: `{cond ? (<><Icon .../>Text</>) : (<><Icon .../>Text</>)}`.

**Pitfall**: NEVER use `sed` to batch-replace JSX — it produces broken `class='inline'` (should be `className="inline"`) and mismatched quotes (`icon='game-icons:...\"`). Use Python or individual `patch` calls for JSX edits.

Full catalog: https://icon-sets.iconify.design/game-icons/

## Stats Display

- Full stat names: Сила, Ловкость, Защита, Мастерство
- Never abbreviated: "Ловк" → "Ловкость", "Защ" → "Защита", "Маст" → "Мастерство"
- Stat values right-aligned, labels left-aligned (`justify-between`)
- HP = S + A + D + M (sum of all base stats, no V/stamina)
- **Stamina полностью удалена** — нет `stamReg`, `maxStamina`, `attackCost`, `staminaRegen` ни на клиенте, ни на сервере. Поле «Реген вын.» убрано из админки и seed-данных.
- **Stat values use white text, NOT rarity color** — user explicitly rejected colored stat values
- **Item name does NOT have a border frame** — name is colored text only, no box around it
- For item display in tooltips and shop cards, use the shared `ItemStats` component

## Item Display

- **`ItemStats`** component (`client/src/components/ItemStats.tsx`) — unified item card used by both `ItemTooltip` and `ShopPage`
  - Renders: icon + name, rarity line, stat table with alternating row backgrounds
  - Accepts: `item`, `showImage`, `imageSize`, `extra` (ReactNode for price/action buttons)
  - Stat values: white `font-bold`, NOT rarity-colored
  - Stat labels from `statNameRu` map (s→Сила, a→Ловкость, etc.)
  - Between rows: `border-bottom: 1px solid #333` (except last)
  - Alternating backgrounds: `rgba(255,255,255,0.03)` on odd rows
- **`getRarityColor(item)`** in `utils/itemUtils.ts`:
  - Returns `item.rarity_color` if present
  - Falls back to `rarityColors[item.rarity_id]` if `rarity_id` exists
  - Default: `#888`
- **`getItemImage(item)`** in `utils/itemUtils.ts`:
  - Returns `item.image` if present
  - Computes path from slot+rarity_id: `{folder}/{folder}_{color}.webp`
  - Slot→folder: weapon1→sword, shield→shield, ring→ring
  - Craft items: `fragment/fragment_{color}.webp`
- **ItemIcon** component accepts `item` prop and auto-computes image via `getItemImage`
- **StatAllocation** panel: **collapsed by default** (`useState(true)`), in LeftSidebar below CharacterCard

## Image Assets

- Equipment images: `client/public/{slot}/{slot}_{color}.webp`
- Rarity colors: gray(0), white(1), green(2), blue(3), purple(4), yellow(5), red(6)
- Craft materials: `fragment/fragment_{color}.webp`
- Upgrade stones: `stone/stoneUpgrade_{color}.webp`
- When adding new items via admin: server MUST include `i.image` in `getItemData` queries and enrich items with `image: itemRow.image || item.image || null`

## Static Files (SEO / Verification)

Static files for SEO or verification go in `client/public/` — Vite copies them to `dist/` during build, nginx serves them via `try_files $uri`:
- `robots.txt` — search engine crawling rules
- `sitemap.xml` — URL listing for search engines
- `yandex_*.html` — Yandex Webmaster verification files

These are plain files served directly by nginx without going through React. Content-Type is set automatically.

## TournamentBanner (RightSidebar)

`TournamentBanner` (`client/src/components/TournamentBanner.tsx`) — блок в правой колонке над рейтингом. Показывает турниры, в которых игрок может участвовать (по уровню/дивизиону), максимум 3. Сортировка: доступные → по времени старта.

- **Заголовок**: «Турниры» с иконкой трофея, клик → `/tournament`
- **Свой дивизион**: зелёным, с пометкой «← ваш»
- **Таймер**: до конца регистрации или «⚔️ идёт»
- **Счётчик**: N/8 участников
- **Завершённые**: только те, где игрок участвовал, с местом
- **Custom турниры**: помечены 🎪 и «игр.», показываются если игрок может участвовать
- Данные: `GET /api/tournament`

## QuestsBlock (RightSidebar)

`QuestsBlock` (`client/src/components/QuestsBlock.tsx`) — над TournamentBanner. Показывает активные задания (статус `active`).

- **Заголовок**: «Задания: N/3», клик → `/tavern?tab=quests`
- **Пусто**: «Нет активных заданий. Взять в таверне...» с ссылкой на таверну
- **Карточка задания**: иконка, название, описание, прогресс-бар, X/Y
- **Клик по заданию**: `window.location.hash = 'action-<type>'` → подсветка карточки в Actions
- **Подсветка**: синее кольцо на 3 секунды, авто-сброс. На мобильных (<640px) + скролл к карточке
- **Типы → карточки**: hunt→Охота, arena→Арена, job→Работы, craft→Крафт, auction→Аукцион

### `getItemImage()` — Image Path Resolution

All image paths go through `getItemImage()` in `utils/itemUtils.ts`. The function now **owns the leading `/`** — callers must NOT add their own `/`:

```ts
function ensureLeadingSlash(path: string): string {
    return path.startsWith('/') ? path : `/${path}`;
}

export function getItemImage(item: any): string | null {
    if (item?.image) return ensureLeadingSlash(item.image);  // DB paths already have /
    if (item?.rarity_id == null) return null;
    const color = rarityColorNames[item.rarity_id] || 'gray';
    if (item?.type === 'upgrade') return `/stone/stoneUpgrade_${color}.webp`;
    if (item?.type === 'craft_item' || item?.type === 'material') return `/fragment/fragment_${color}.webp`;
    if (item?.slot) {
        const folder = slotImageFolders[item.slot] || item.slot;
        return `/${folder}/${folder}_${color}.webp`;
    }
    return null;
}
```

**CRITICAL PITFALL**: Callers (`ItemIcon`, `ItemStats`, `ShopPage`) must NOT add their own `/` prefix:

```tsx
// ✓ Correct — getItemImage already returns /path/to/file.webp
background: img ? `url(${img}) center / contain no-repeat` : color

// ✗ WRONG — double slash becomes //path/to/file which browser treats as hostname
background: img ? `url(/${img}) center / contain no-repeat` : color
```

**`isCraftItem()`** now also recognizes `type === 'upgrade'` items. **`typeNameRu`** maps `upgrade → 'Камень'`.

### CharacterCard Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `char` | `CharacterCardData` | required | Character data |
| `showHealth` | `boolean` | `true` | Show HP bar |
| `showExp` | `boolean` | `true` | Show EXP bar |
| `showRegenHint` | `boolean` | `true` | Show "+1 HP / 10 сек" under HP bar. **Set `false` in battles** (BestiaryPage, ArenaPage). |
| `readOnly` | `boolean` | `false` | Disable slot clicks |
| `compact` | `boolean \| 'mobile' \| 'verySmall'` | `false` | Sizing mode |
| `isMob` | `boolean` | `false` | Hides fighter image + slots |

### PvE Battle Animation (Bestiary)

The BestiaryPage uses a step-by-step battle animation pattern similar to Arena, but without `actor`/`target` fields in the steps. Instead, the attacker is inferred from step messages (`"Вы атакуете!"` = player turn, anything else = mob turn). HP bars update reactively as each damage step is processed. Full pattern: `references/pve-battle-animation.md`.

## Related Files

- `references/tailwind-migration.md` — Step-by-step Tailwind migration process and server-side battle/currency changes.
- `references/hermes-browser-cdp.md` — Hermes browser CDP workaround for Ubuntu 26.04 (system Chromium + remote debugging).
- `references/pve-battle-animation.md` — PvE mob battle step-by-step animation pattern (attacker inference, timer refs, HP bars).

## AcquireModal — Toast-уведомления о получении предметов

При покупке, крафте, дропе или выкупе предметов показывается всплывающее уведомление в правом нижнем углу. Система построена на React Context (`client/src/contexts/AcquireContext.tsx`):

- **`AcquireProvider`** — оборачивает всё приложение в `main.tsx`. Хранит массив тостов, рендерит их в фиксированном контейнере (`position: fixed; bottom: 80px; right: 16px; z-index: 9999`).
- **`useAcquire()`** — хук, возвращает `{ showAcquire }`. Вызывается в компонентах-потребителях.
- **`showAcquire(item, quantity, action)`** — показывает тост с иконкой предмета, названием, количеством и действием. Авто-исчезает через 3 секунды. Анимация: `acquireToastIn` (slide-in справа).

**Где используется:**
- `ShopPage.tsx` — `showAcquire(boughtItem, 1, 'Куплено')`
- `AuctionPage.tsx` — `showAcquire(lot.itemData, count, 'Выкуплено' | 'Куплено')`
- `CraftPage.tsx` — `showAcquire(recipe.result, 1, 'Создано')` / `showAcquire(item, 1, 'Улучшено до +N')`
- `BestiaryPage.tsx` — `showAcquire(result.materialDropped, 1, 'Добыто')`

**Добавление в новую страницу:**
1. `import { useAcquire } from '../contexts/AcquireContext'`
2. `const { showAcquire } = useAcquire()`
3. После успешного получения предмета: `showAcquire(itemObject, quantity, 'Действие')`

**`main.tsx`** должен включать провайдер в цепочку:
```tsx
<AcquireProvider>
  <App />
</AcquireProvider>
```

## Chat Messenger-Style Layout

Chat messages use a modern messenger bubble pattern (implemented in `client/src/components/chat/MessageList.tsx`):

- **Nickname above bubble**: sender name on its own row, not inline beside text
- **Left/right alignment**: own messages → right (blue gradient `#3b5998 → #4a6fa5`), others → left (dark `#2a2a3e`), private → left with purple tint (`#2d1f3d`)
- **Bubbles**: rounded corners (`12px 12px 4px 12px`), padding, subtle box-shadow, `max-width: 85%`
- **Timestamps**: `HH:MM` format next to nickname, muted gray (`#555`)
- **Message grouping**: same sender within 2 minutes → shared nickname header, sequential bubbles with 2px gap. New sender or >2min → new group with 6px spacing
- **Item links**: rendered in styled bubbles with rarity-colored text

## Buffs Block (Tavern Effects)

`BuffsBlock` component (`client/src/components/BuffsBlock.tsx`) shows all possible buffs under the character card:

- **Props**: `room`, `drink`, `premium` — each `{ until: number } | null` (optional type info for room/drink)
- **Collapsed by default** (`useState(true)`) — user wants this compact, expand manually
- **Text arrow**: `▶` (collapsed) / `▼` (expanded) — matches StatAllocation pattern, NO Iconify icons
- **Active count**: shows number of active buffs as badge on header right side
- **Live timer**: 1-second interval updates remaining time for all buffs
- **Always visible**: ALL THREE rows (Комната, Напиток, Премиум) are always shown, even when inactive
  - Active buff: colored name (green/purple/gold) + timer
  - Inactive buff: muted text «Отсутствует»
  - NO «Нет активных усилений» empty state — list is always displayed
- **Clickable rows**: each row uses `useNavigate()` to link to the relevant page
  - Комната → `/tavern?tab=room` (TavernPage reads `?tab=` via `useSearchParams`)
  - Напиток → `/tavern?tab=drink`
  - Премиум → `/premium`
- **Room display**: green text, room name + regen multiplier + formatted remaining time
- **Drink display**: purple text, drink name + formatted remaining time
- **Premium display**: gold text (`#f1c40f`), no description in the name (just «Премиум»)
- **Header**: uses `<div>` with `cursor-pointer select-none`, NOT a `<button>` (consistent with StatAllocation)

### Premium Page

`/premium` route (`client/src/pages/PremiumPage.tsx`):
- Card with gold header «⭐ Премиум»
- Lists bonuses: +30% gold from hunt, +30% job rewards, cooldown ×0.5
- Bottom box: «Можно запросить у админа»
- Player-only route (added in App.tsx alongside other player routes)
- Import: `import PremiumPage from './pages/PremiumPage'`

Social login buttons use plain `<a href>` with brand-colored text-only buttons (NO icons — user rejected SVG icons as unclear):

```tsx
<div className="flex flex-col gap-2">
  <a href="/api/oauth/yandex" className="flex items-center justify-center w-full p-2 rounded text-sm font-medium bg-[#FC3F1D] text-white hover:bg-[#E5391A] transition-colors">
    Яндекс ID
  </a>
  <a href="/api/oauth/vk" className="flex items-center justify-center w-full p-2 rounded text-sm font-medium bg-[#0077FF] text-white hover:bg-[#0066DD] transition-colors">
    VK ID
  </a>
</div>

OAuth providers redirect back to `https://mmoarena.ru/?jwt={token}` after authentication. The `AuthProvider` detects `?jwt=` in the URL on mount, stores the token in localStorage, and clears the query parameter. New OAuth users are auto-created on the backend — no email verification needed.

### JWT from URL (AuthProvider)

**CRITICAL**: JWT must be extracted **synchronously** in `useState` initializer, NOT in `useEffect`. The route guard `<Route path="/" element={user ? HomePage : <Navigate to="/login">}>` fires on the first render. If `user` is `null` during render (because `useEffect` hasn't run yet), the guard immediately redirects to `/login` before `useEffect` processes the JWT.

```tsx
function getTokenFromURL(): string | null {
    const params = new URLSearchParams(window.location.search);
    const jwt = params.get('jwt');
    if (jwt) {
        const url = new URL(window.location.href);
        url.searchParams.delete('jwt');
        window.history.replaceState({}, '', url.toString());
    }
    return jwt;
}

function parseUserFromToken(token: string): User | null {
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return {
            id: payload.adminId || payload.userId,
            username: '',
            level: payload.role === 'admin' ? 0 : 1,
            role: payload.role,
            gender: payload.gender || 'male',
        };
    } catch { return null; }
}

// In AuthProvider:
const [token, setToken] = useState<string | null>(() => {
    const urlJwt = getTokenFromURL();
    if (urlJwt) {
        localStorage.setItem('token', urlJwt);
        return urlJwt;
    }
    return localStorage.getItem('token');
});

const [user, setUser] = useState<User | null>(() => {
    if (token) return parseUserFromToken(token);
    return null;
});
```

## Static assets

All files served at domain root (SEO, verification) go in `client/public/`:
- `robots.txt`, `sitemap.xml`, `yandex_*.html`
- Vite copies `public/` to `dist/` on build
- Nginx `try_files $uri $uri/ /index.html` serves them directly — no API involvement

## Related Features

- **Bank**: three tabs (Информация/Пополнение/Переводы), live commission preview, transfer history with filters, guest-blocked. See `text-rpg-project` references.
- **Quests/Tavern**: quests tab in tavern, snapshot-based progress tracking. See `text-rpg-project` references.
- **Tournaments**: continuous cycle, custom tournaments, bracket visualization. See `text-rpg-project` references.

## Common Pitfalls

1. **React `style` prop overrides computed styles**: When spreading `...style` at the end of a style object, a parent passing `style={{ border: undefined }}` REMOVES the border entirely. Never pass `border: undefined` as a style override — use a separate `highlighted` prop instead. This caused inventory items to lose their rarity-colored borders.

2. **Import/function name collision**: A local function with the same name as an imported function shadows the import. If you define `const renderBattleLog = () => ...` and also `import { renderBattleLog } from '...'`, the local function wins and calling `renderBattleLog()` inside it causes infinite recursion. **Always give local functions distinct names** from imports.

3. **Patch tool can corrupt JSX object literals**: The `patch` tool's fuzzy matching sometimes drops intermediate keys in nested objects. Example: `{ ...char, activeJob: { jobId, ... } }` became `{ ...char, jobId, ... }` — the `activeJob:` wrapper was lost. **After patching JSX/TSX, always verify object structure** — prefer `write_file` for complex rewrites.

4. **Double padding**: `body` has `padding-bottom: 50px`. Don't add another bottom padding in page components.

5. **Flex stretching**: When a flex child grows (e.g. uncollapsing stat panel), other flex children stretch to match if `align-items: stretch` (default). Always use `items-start`.

6. **CSS class selectors for animations**: Make sure selectors match the elements that JS targets. E.g. `#fighter-left.attacking` not `.fighter-card.attacking` when JS adds class to `#fighter-left`.

7. **Currency display**: Never show raw money numbers. Always use `formatMoney()` or `MoneyDisplay`.

8. **Stale LSP diagnostics**: Errors shown after patches are often from old line numbers and cached state. **Always run `npx tsc --noEmit`** to verify — if tsc passes, the code is correct regardless of LSP errors.

9. **Import paths across directory boundaries**: When importing from `components/ui/` into `pages/SubPage/`, use `../../components/ui/Component`. A relative `../ui/Component` resolves to `pages/ui/` which doesn't exist. If Vite shows "Cannot find module" after a restart, check cross-directory imports first.

10. **Vite HMR can silently fail and serve stale code**: After file changes, Vite may keep serving the old compiled version even through restarts with `--force`. The browser shows old UI while files on disk are correct.

**Escalation ladder** (try in order, stop when user confirms change is visible):

1. **Restart with force**: `pkill -f vite; sleep 1; npx vite --host --force`
2. **Clear .vite cache**: `shutil.rmtree('client/node_modules/.vite')` then restart
3. **Rename the file**: `mv BestiaryPage.tsx HuntPage.tsx` + update imports — forces new module name, bypasses all caches. Revert after confirming it works.
4. **Nuclear — reinstall node_modules**: `shutil.rmtree('node_modules'); npm install` — this is the only 100% reliable method. Takes ~20 seconds.

**Verify with curl**, not browser refresh: `curl -s http://localhost:5173/src/pages/Foo.tsx | grep -c "expectedString"`

11. **SlotBase changes affect ALL slots**: SlotBase is shared by inventory, equipment, and resource slots. Any background/border/text change impacts all three. Test visually by checking inventory grid, equipment paperdoll, and resource section after every SlotBase edit.

13. **sed corrupts JSX syntax**: Never use `sed` for batch JSX edits. Single quotes conflict with JSX attribute quoting, producing broken `class='inline'` (should be `className=\"inline\"`) and mismatched quotes like `icon='game-icons:name\\\"`. This happened 4+ times in one session across HistoryPage, ArenaPage, ContextMenu. **Always use `patch` tool or `write_file` for JSX edits**. If you must batch-edit, use a Python script with proper string escaping, never sed.

14. **`class` vs `className` in Iconify `<Icon>`**: React requires `className`, but raw HTML uses `class`. When writing `<Icon>` components, always use `className=`, never `class=`. A stray `class=` produces the DOM warning "Invalid DOM property `class`. Did you mean `className`?" and causes the icon to render without the intended CSS class. Common in Iconify because users think of `<Icon>` as an HTML element. **Fix**: search for ` class="` (with leading space) across all `.tsx` files — `grep -rn ' class=\"' client/src/pages/` finds all instances.

15. **Guest UI patterns**: Guest accounts have limited access — auction/craft/bank cards show «Заблокировано» with tooltip on hover. `isGuest` from `useAuth()` passed to CardGrid. AccountPage for guests shows only registration form (2-step: name+email+password → verification code), hides password change/gender/delete. LoginPage guest button at bottom, no emoji.

16. **CSS text truncation for names**: CharacterCard names use CSS `text-overflow: ellipsis` (`overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100%`) instead of JS string slicing. Removed the `maxNickLength`/`truncate()` pattern. Names now naturally truncate to container width with `…`.

15. **Guest UI patterns**: Guest accounts have limited access — auction/craft/bank cards show «Заблокировано» with tooltip on hover. `isGuest` from `useAuth()` passed to CardGrid. AccountPage for guests shows only registration form (2-step: name+email+password → verification code), hides password change/gender/delete. LoginPage guest button at bottom, no emoji.

15. **Guest UI patterns**: Guest accounts have limited access — auction/craft/bank cards show «Заблокировано» with tooltip on hover. `isGuest` from `useAuth()` passed to CardGrid. AccountPage for guests shows only registration form (2-step: name+email+password → verification code), hides password change/gender/delete. LoginPage guest button at bottom, no emoji.
