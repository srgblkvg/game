# Game Data Model

## Database tables (SQLite via better-sqlite3)

### users
```
id, username, passwordHash, level, exp, money,
totalBattles, wins, inventory(JSON), equipment(JSON),
currentHp, lastHpUpdate, lastAttackTime, protectionUntil,
inventorySlots, activeJob(JSON), chatBannedUntil,
openPrivateTabs(JSON), gender,
statPoints, baseS, baseA, baseD, baseM,
createdAt
```

Base stats stored per-user: `baseS`, `baseA`, `baseD`, `baseM` (default 5).
`statPoints` = unallocated level-up points.
`lastHpUpdate` = Unix timestamp of last HP tick (used for regen: `floor((now - lastHpUpdate) / 10)` = HP recovered).
`currentHp` = must never exceed calculated `maxHp = baseS+baseA+baseD+baseM + equipment bonuses`.

### battles
```
id, attackerId, defenderId, winnerId,
log(JSON), steps(JSON),
attackerHpAfter, defenderHpAfter,
expGained, moneyGained, moneyStolen,
createdAt
```

`steps` is the full battle log array — each step has `type`, `actor`, `target`, `message`, `damage`, `amount`.

### items (equipment)
```
id, name, slot, rarity_id, bonuses(JSON), extra(JSON),
upgradeLevel, image, created_at
```

Slots: helmet, chest, gloves, boots, amulet, ring1, ring2, belt, weapon1, weapon2.
Rarity: 0-6 (junk, common, uncommon, rare, epic, legendary, mythic).

### craft_items (materials)
```
id, name, rarity_id, description, type, image
```
Types: `craft` (material), `upgrade` (stone).

### rarities
```
id, name, display_name, color
```

### stat_names
```
id, name, nameRu
```
Currently: s(a), a(ya), d(ya), m(tvo), crit, dodge, counter, fullBlock, block.
Removed: hpRegen, stamReg.

### jobs, job_history, admins, chat_messages, craft_recipes, etc.

## Inventory item format (JSON)
```json
{
  "id": 1780208968640.3003,  // runtime-generated
  "name": "Белый меч",
  "slot": "weapon1",
  "rarity_id": 1,
  "rarity_display": "Обычный",
  "rarity_color": "#cccccc",
  "bonuses": {"s":10,"a":0,"d":0,"m":0},
  "extra": {"stamReg":0,"crit":2,"dodge":0,"counter":0,"fullBlock":0},
  "image": "sword/sword_white.webp"
}
```

Craft items have `type: "craft_item"` and `count` field.

## API endpoints (key ones)
- `GET /api/character/me` — full character data with enriched inventory/equipment
- `POST /api/character/allocate-stats` — `{s, a, d, m}` distribute stat points
- `POST /api/battle` — start battle, returns steps + result
- `GET /api/battles` — battle history with `steps` column
- `GET /api/stat-names` — list of stat name translations

## Currency
- Single integer in `money` column
- Displayed as "N сер." via `formatMoney()`
- Shop prices: `100 * 10^rarity_id`
