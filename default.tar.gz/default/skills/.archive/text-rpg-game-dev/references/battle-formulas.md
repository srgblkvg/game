# Battle Formulas

## Current formulas (server/src/game/battle.ts)

All extra stat contributions from equipment are divided by 200 (was 100).

### Dodge chance
```
dodgeChance(defA, atkM, defExtraDodge) =
  max(0, (defA/(defA+50)) * (1 - atkM/(atkM+100)) + min(0.5, defExtraDodge/200))
```
- Base from defender Agility vs attacker Magic
- Extra dodge from equipment halved, capped at 50%

### Crit chance
```
critChance(m, extraCrit) = min(0.8, m/(m+50) + extraCrit/200)
```
- Based on attacker Magic
- Extra crit from equipment halved, capped at 80%

### Crit multiplier
```
critMult(m) = 1.5 + 0.5 * (m/(m+50))
```
- Scales from 1.5x to 2.0x

### Block chance
```
blockChance(d, extraFullBlock) = min(1, d/(d+50) + extraFullBlock/200)
```
- Based on defender Defense
- Extra block from equipment halved

### Block reduction
```
blockRed(d, s) = min(0.75, 0.5 * d/max(1,s))
```
- Ratio-based: defender Defense vs attacker Strength
- At equal stats (d=s): blocks 50% of damage
- d > s: blocks up to 75%
- s > d: blocks less than 50%, down to near 0%

### Full block
- Separate check: `extraFullBlock/100` (NOT using the blockChance formula)
- Full block = 0 damage, separate from regular block

### Counter chance
```
counterChance(defStats, atkStats, defExtraCounter) =
  min(0.5, (defM+defA)/(defM+defA+atkM+atkD) * 0.5 + defExtraCounter/200)
```
- Based on defender M+A vs attacker M+D ratio
- Halved from original, capped at 50%

### Stun chance
```
stunChance(atkStats, defStats) =
  (atkS+atkM) / (atkS+atkM+defS+defD) * 0.3
```
- Based on attacker S+M vs defender S+D
- Multiplied by 0.3 (was 1.0)

## Base stats (no V)
- S (Strength): damage in attack
- A (Agility): dodge, initiative (turn order)
- D (Defense): block chance and reduction
- M (Magic): crit chance/multiplier, counter, stun

HP = S + A + D + M

## Level-up
- XP for level N: `10 * 2^(N-1)`
- No level cap
- Each level: +5 free stat points

## Battle flow
1. Determine initiative: higher Agility goes first
2. Each turn: attacker rolls attack; defender checks dodge → counter → block/crit → damage → stun
4. Fight to death: loop while `hpA > 0 && hpD > 0`
5. Max 200 turns
6. **Rewards for both sides**: the winner (attacker OR defender) gets XP, money, win count, and stat points. Previously only the attacker got rewards — now the defender also gets them when they win.

### XP rewards
- Winner vs higher level: 2 XP
- Winner vs same level: 1 XP
- Winner vs lower level: 0 XP
- Money: 10 silver (attacker win only — defender gets no money when they win defensively)

## HP Recovery
- **Rate**: +1 HP every 10 seconds, out of combat only
- **Implementation**: `server/src/routes/character.ts` in `/character/me` route
- Formula: `regenAmount = floor((now - lastHpUpdate) / 10)`
- `lastHpUpdate` stores timestamp of last HP tick (remainder seconds preserved)
- HP never exceeds `maxHp = S + A + D + M`
- Full heal time: `(maxHp - currentHp) × 10` seconds
- On equip/unequip: `newHp = max(1, floor(oldHp × newMaxHp / oldMaxHp))` — proportional scaling
- Client hint: `CharacterCard` shows "+1 HP / 10 сек — полное через X мин Y сек" when `currentHp < maxHp && showRegenHint`
