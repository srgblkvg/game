---
name: text-rpg-game-dev
description: "Development patterns for the text-based online RPG at /mnt/c/project/game — battle formulas, currency, stats, design system."
version: 1.0.0
---

# Text RPG Game Development

## Overview

Project: text-based online RPG at `/mnt/c/project/game`.
Stack: Node.js/Express + TypeScript server, React 19 + Vite + Tailwind CSS v4 client, SQLite (better-sqlite3), WebSocket chat.

## Communication Style

- Respond in Russian
- Be concise — no long explanations, just do the task
- Don't ask for confirmation on low-stakes changes, just make them
- Prefer direct tool calls over describing what you'll do

## Project Architecture

### Server (`server/`)
- Entry: `server/src/index.ts` — Express 5 on port from `PORT` env
- DB: `server/src/database.ts` — SQLite with auto-migration
- Game logic: `server/src/game/stats.ts`, `server/src/game/battle.ts`
- Routes: `server/src/routes/` — auth, character, battle, arena, shop, jobs, craft, admin*
- WebSocket: `server/src/websocket.ts` — chat + online status
- Validation: `server/src/validation.ts` — Zod v4 schemas

### Client (`client/`)
- Entry: `client/src/main.tsx`
- UI kit: `client/src/components/ui/` — Button, Card, Modal, Badge, BackButton, PageHeader, ItemIcon, FilterBar, EmptyState
- Shared: `client/src/components/ItemStats.tsx` — unified item display for tooltip/shop
- Shared: `client/src/utils/battleLog.tsx` — colored battle log renderer with turn separators
- Shared: `client/src/utils/itemUtils.ts` — `getRarityColor()`, `getItemImage()`
- Styles: `client/src/styles/theme.css` — Tailwind v4 with CSS custom properties for dark theme

## Battle System

See `references/battle-formulas.md` for current formulas.
See `references/game-data-model.md` for DB schema and stat system.

### Key mechanics
- No stamina — attacks are free, battle is purely turn-based
- HP = S + A + D + M (sum of base stats)
- No level cap — XP needed = 10 × 2^(level−1)
- Each level = +5 free stat points (allocated via UI)
- Items have `bonuses` (S/A/D/M) and `extra` (crit/dodge/counter/fullBlock). **`hpRegen` was removed from item extras** — items no longer provide HP regen bonuses.
- Upgrade level increases bonuses by 5% per level
- **Variable damage**: `dmg = level + random × (strength − level + 1)`. Minimum = attacker level, maximum = attacker strength. Applied to both attacker and defender turns in `server/src/game/battle.ts`. If `strength <= level`, damage defaults to strength (no random range).

### Formulas (overview)
- Dodge: `defA/(defA+50) × (1 − atkM/(atkM+100)) + defExtraDodge/200`, max bonus 0.5
- Crit: `min(0.8, m/(m+50) + extraCrit/200)`
- Block: `min(1, d/(d+50) + extraFullBlock/200)`
- Counter: `min(0.5, baseM+A/total × 0.5 + extraCounter/200)`
- Stun: `(atkS+atkM)/total × 0.3`

### Removed mechanics
- V (Vitality) — was always 100, now HP = S+A+D+M
- Stamina — removed entirely (was 100 max, regen, attack cost). All stamReg fields in GameItem.extra, CharStats, validation schemas, seed data, stat_names table, admin forms, and CharacterCard props cleaned. If encountering `Property showStamina does not exist` errors — grep and remove remaining usages from ArenaPage and any other character card consumers.
- Gold/Silver/Bronze split — single currency "серебро" with Russian plural forms
- Ring slot naming — items use `slot: 'ring'` (not ring1/ring2). Character equipment has two ring slots (ring1, ring2) — any 'ring' item fits in either, same name cannot be in both. Display as "Кольцо" (no numbers). Updated in: seed.ts, validation.ts, admin panel slot dropdowns (EditItemModal, AdminItems), ShopPage filter, itemUtils slotNames/folderMap.
- Weapon slot naming — `weapon2` FULLY renamed to `shield`. Equipment slot, DB items, seed data, validation, admin forms, ShopPage filter, itemUtils ALL use `shield` now. `weapon2` no longer exists anywhere. EquipmentSlots array: `['weapon1', 'shield']`. SlotBase icon: «Щит» → `game-icons:shield`. Server `isSlotCompatible`: `itemSlot === 'shield' → slotId === 'shield'`. Two-handed weapons go to `weapon1`, unequip `shield` beforehand. Migration: all users' equipment JSON `weapon2` → `shield`, items table `slot='weapon2'` → `'shield'`.

### Acquire Toast Notifications

**Global toast system** for item acquisition events (buy, craft, loot, auction). Context-based, auto-dismiss after 3s.

**Architecture**: `AcquireContext.tsx` — React context with `showAcquire(item, quantity, action)` function. Provider renders fixed-position toast stack (bottom-right, z-index 9999). Each toast shows: item image (40px), rarity-colored name, quantity badge if >1, action text below.

**Usage**: wrap app in `<AcquireProvider>` (in `main.tsx`), then use `const { showAcquire } = useAcquire()` in any component.

**Call sites** (where `showAcquire` is called):
| Page | Action text | Trigger |
|------|------------|---------|
| ShopPage | «Куплено» | after buyItem() succeeds |
| AuctionPage | «Выкуплено» / «Куплено» / «Выставлено на аукцион» | buyout, partial buy, sell |
| CraftPage | «Создано» / «Улучшено до +N» | craft execute, upgrade success |
| BestiaryPage | «Добыто» | material drop after mob kill |
| TavernPage | «Выпито» / «Аренда на Nч» / «Вылечено» | drink, room, heal |

**Pitfall — non-item toasts**: for services without inventory items (tavern heal/drink/room), pass a minimal object `{ name: '...', rarity_id: 2-3 }`. The image will be auto-generated via `getItemImage()`. The rarity_id controls the border color.

**Item names — dynamic sizing**: long item names use `text-xs break-words min-w-0` (NOT `truncate`). Small font + word wrap ensures names fit within cards without overflow. CSS: `className="font-bold text-xs leading-tight break-words min-w-0"`.

### Admin: Ban System

- **DB column**: `bannedUntil INTEGER DEFAULT 0` (Unix timestamp). `> now` = currently banned.
- **Login check**: in `auth.ts` — after user lookup, before password check: `if (bannedUntil > now) return 423 with formatted remaining time`.
- **Admin UI**: `AdminUsers.tsx` — each row has «Бан» button → inline form with duration + unit selector (minutes/hours/days). Banned rows highlighted in red. Button switches to «Разбан».
- **Cascade delete**: `DELETE /admin/users/:id` — removes battles, job_history, chat_messages, login_logs, auction_lots, tournament_participants, order_members, then user. Confirmation required in UI.
- **IP logging**: `login_logs` table (userId, ip, createdAt). IP recorded on each successful login. Admin UI shows IP list per user with last-seen and count.
- **Extended user data**: admin `/users` endpoint returns: email, emailVerified, oauthProvider, createdAt, bannedUntil, lastLoginAt. Sorted by lastLoginAt DESC NULLS LAST.

### Rate Limiting
Server uses `express-rate-limit` with 5 tiers configured in `setupMiddleware.ts`:
| Limiter | Path | Window | Max |
|---------|------|--------|-----|
| authLimiter | /api/login, /api/register, /api/guest | 15 min | 20 |
| battleLimiter | /api/battle, /api/arena | 1 min | 30 |
| chatLimiter | /api/chat | 1 min | 60 |
| craftLimiter | /api/craft | 1 min | 20 |
| playerLimiter | /api (all other) | 1 min | 200 |

When hitting 429 errors, check:
1. Polling intervals — set to 10s, not 5s
2. Duplicate polls — HomePage should NOT poll character (Header does it)
3. `fetchPrivateMessages` in HistoryPage for each battle participant (under chatLimiter 60/min)

### HP Regeneration
- Rate: +1 HP every 10 seconds when not in combat (multiplied by room buff when active)
- Calculated in `/character/me` route: `regenAmount = floor((now - lastHpUpdate) / 10) * regenRate`
- Room regen multipliers: closet=3, bed=10, chamber=50
- `lastHpUpdate` stores the timestamp of the last HP tick, so incomplete intervals are preserved
- `currentHp` is capped to `maxHp` (stats.hp = S+A+D+M) on every load
- Client displays regen hint below HP bar: "+{rate} HP / 10 сек — полное через X мин Y сек" (only when HP < max and `showRegenHint` prop is true)
- **regenRate prop chain**: LeftSidebar reads `character.room` → calculates rate → passes to CharacterCard → passes to HealthBar. ALL THREE must accept `regenRate` (default 1). Without this chain, client always shows +1 even with room buff active.
- `CharacterCard` has `showRegenHint` (default `true`) and `regenRate` (default `1`) props; pass `showRegenHint={false}` on arena/battle pages
- `formatRegenTime()` in `HealthBar.tsx`: `(missing / regenRate) * 10` — divides by regen multiplier
- HP text has `marginBottom: '3px'` for spacing before the bar

### Material / Inventory ID Type Safety

**Pitfall: String vs Number ID mismatch in craft & auction**. Инвентарь хранится как JSON — ID предметов могут быть строками или числами в зависимости от источника (крафт, моб, аукцион, магазин). При поиске материала в инвентаре по `craft_item_id` ВСЕГДА используй `String()` для обеих сторон:

```ts
// Number() comparison — ломается когда id приходит строкой из JSON:
const existing = inventory.find((i: any) => isCraftItem(i) && Number(i.id) === itemId);

// String() comparison — работает всегда:
const existing = inventory.find((i: any) => isCraftItem(i) && String(i.id) === String(itemId));
```

**Затрагиваемые файлы** (`routes/craft.ts`, `routes/auction.ts`):
- Проверка наличия ингредиентов перед крафтом
- `ingredientMap` — ключи: `new Map<string, number>()`, `.set(String(ing.id), ...)`
- Списание ресурсов: `.has(String(item.id))`, `.get(String(item.id))`, `.delete(String(item.id))`
- Результат крафта (resource): `String(i.id) === String(recipe.result_id)`
- Аукцион buyout + buy-partial: `String(i.id) === String(itemData.id)` при стакинге

**Симптом**: «недостаточно ресурса» при крафте, хотя материалов в инвентаре достаточно. Или материалы не стакаются при покупке с аукциона. Причина: ID из инвентаря (число) не совпадает с ID из рецепта/лота (строка) при строгом сравнении `===`.

## Currency

Single currency: серебро. `formatMoney(n)` returns the number + correct Russian plural form:
- 1, 21, 31, ... → "серебро"
- all others (2-20, 22-30, ...) → "серебра"

**No coin emojis**: НИКАКИХ эмодзи 🥇 💰 `game-icons:coins` `game-icons:cash` для отображения денег. Везде только текст через `formatMoney()`. Где нет слова «серебро» (например, в лейблах форм, заголовках колонок) — добавить текстом: «Стоимость (серебро)», «Серебро: 100», «5000 серебра». Удалены из: BankPage, OrdersPage, AuctionPage, TournamentPage, CraftPage/RecipeList, AdminBattles, EditItemModal, AdminItems, ArenaPage, Header. Единственное исключение — медали дивизионов турнира (🥇🥈🥉), это не деньги.

Implementation in `client/src/utils/money.ts`:
```ts
const lastTwo = total % 100;
const lastOne = total % 10;
const word = (lastOne === 1 && lastTwo !== 11) ? 'серебро' : 'серебра';
return `${total.toLocaleString()} ${word}`;
```

Never use the old abbreviation "сер." — it was replaced. Use `formatMoney()` for all money display. The function auto-handles pluralization.

## Item Images

Images auto-computed from slot + rarity_id via `getItemImage()`:
- Equipment: `{folder}/{folder}_{color}.webp` — folder = sword/shield/ring/helmet/chest/gloves/boots/amulet/belt
- Materials: `fragment/fragment_{color}.webp`
- Upgrade stones: `stone/stoneUpgrade_{color}.webp`
- Colors: gray(0), white(1), green(2), blue(3), purple(4), yellow(5), red(6)

When updating item data, always include `image` field. The `getItemData` DB queries in character.ts and arena.ts already SELECT `i.image`.

## Tailwind Design System

- Theme: `client/src/styles/theme.css` — CSS custom properties for colors, shadows, radii
- Use `var(--color-*)` for all colors, never hardcode hex values
- Responsive: `sm:` prefix (640px), avoid `useState(isMobile)` pattern
- Components in `client/src/components/ui/` — use Button/Card/Modal instead of raw HTML

## Icon Library

Project uses `@iconify/react` + `@iconify-json/game-icons` (4000+ RPG icons). Install: `npm install @iconify/react @iconify-json/game-icons`. Usage: `<Icon icon="game-icons:sword" width="16" height="16" />`.

### Current Icon Mapping

Collapse/expand arrows and sort arrows use **emoji** (▶ ▼ ▲ ⇅ ↑ ↓), not icons. User rejected icon-based arrows — they were less readable. Never use `game-icons:plain-arrow` with CSS rotate for these.

| Context | Emoji/Icon | Iconify name |
|---------|-----------|--------------|
| Money | text | `formatMoney()` — text only, no icon |
| Account | icon | `game-icons:person` |
| Notifications | icon | `game-icons:ringing-bell` |
| Protection | icon | `game-icons:shield` |
| Shop | icon | `game-icons:buy-card` |
| Arena/PvP | icon | `game-icons:crossed-swords` |
| Adventures/Jobs | icon | `game-icons:swap-bag` |
| Craft | icon | `game-icons:anvil` |
| Rating | icon | `game-icons:trophy` |
| Inventory | icon | `game-icons:backpack` |
| Chat | icon | `game-icons:chat-bubble` |
| Cooldown | icon | `game-icons:hourglass` |
| Defeat | icon | `game-icons:death-skull` |
| Victory | icon | `game-icons:trophy` |
| Arena battle button | icon | `game-icons:crossed-swords` |
| Arena refresh | icon | `game-icons:cycle` |
| Money stolen | text | \"Захвачено: N серебра\" (was coins icon) |
| Money lost | text | \"Потеряно: N серебра\" (was cash icon) |
| Level up | icon | `game-icons:level-end-flag` |
| Collapse/expand | emoji | ▶ ▼ (stats), ▲ ▼ (chat) |
| Sort none/asc/desc | emoji | ⇅ ↑ ↓ |

### Equipment Slot Icons

Empty equipment slots show icons (via `SlotBase.tsx` `EQUIPMENT_ICONS` map), 24px at opacity 0.5:

| Slot | Icon |
|------|------|
| Шлем | `game-icons:helmet` |
| Нагрудник | `game-icons:chest-armor` |
| Перчатки | `game-icons:gloves` |
| Ботинки | `game-icons:boots` |
| Амулет | `game-icons:gem-necklace` |
| Кольцо | `game-icons:ring` |
| Пояс | `game-icons:belt` |
| Оружие | `game-icons:broadsword` |
| Щит | `game-icons:shield` |

### Battle Log Icons

`battleLog.tsx` renders icons for each step type: attack→crossed-swords, damage→blood, crit→flame, dodge→sprint, block/fullBlock→shield, counter→backward-time, stun→dizzy, end→trophy, money→cash.

### Icon Pitfalls

- **VERIFY ICON NAMES EXIST**: before using any `game-icons:` name, check it exists in `node_modules/@iconify-json/game-icons/icons.json` → `icons` key. Many expected names (amulet, sword, skull, speech-bubble, bell-ring, caret-*, sort-amount-up, arrow-up/down) DO NOT EXIST. Use: `gem-necklace` (not amulet), `broadsword` (not sword), `death-skull` (not skull), `chat-bubble` (not speech-bubble), `ringing-bell` (not bell-ring), `plain-arrow` (for directional arrows).
- **Never use sed for JSX Icon tags** — it breaks single/double quote nesting. Use `patch` tool or Python `replace()`.
- **Icons in JSX ternaries**: use React fragments `(<><Icon .../>text</>)`, never embed `<Icon>` in string literals.
- **className vs class**: always `className=`, never `class=`. Sed produces broken `class=` by mistake.

## Slot Styling

Empty slots use solid borders (not dashed) — `#555` for empty, rarity color for filled. Background: `rgba(0,0,0,0.35)` for equipment (title present), `rgba(0,0,0,0.6)` for inventory (no title). 

**Equipment slots** (has `title` prop via Slot → slotNames[slotId]): render an Icon from `EQUIPMENT_ICONS` map at 24px with `opacity: 0.5`. No text label.

**Inventory slots** (no `title`): render "Пусто" text at 0.55rem, color `rgba(255,255,255,0.35)`.

SlotBase.tsx contains the logic: `iconName = title ? EQUIPMENT_ICONS[title] : null`. If iconName exists → `<Icon>` component; else → `<span>Пусто</span>`.

### Arena Flip Card & Modal Positioning

Arena card uses `.perspective-600` for 3D flip animation. **Pitfall**: CSS `perspective` (like `transform` and `filter`) creates a new containing block — `position: fixed` elements inside it position relative to the card, NOT the viewport. Fix: move modal/overlay elements OUTSIDE the `.perspective-600` div, wrapping return in a fragment `<>...</>`.

**JSX single-root rule**: `return (...)` must have ONE root element. Multiple siblings (card + modal) require a fragment wrapper.

**Error modal — centered overlay with auto-close**: ошибки проверки соперников показываются модальным окном по центру ЭКРАНА (не карточки), авто-закрываются через 2 секунды:

```tsx
const [modalMsg, setModalMsg] = useState('');

useEffect(() => {
    if (!modalMsg) return;
    const t = setTimeout(() => setModalMsg(''), 2000);
    return () => clearTimeout(t);
}, [modalMsg]);

// В JSX — ВНЕ .perspective-600, в фрагменте:
{modalMsg && (
    <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
        <div className="bg-red-900/90 text-red-200 border border-red-500 rounded-lg px-6 py-3 shadow-2xl text-sm font-medium animate-pulse">
            {modalMsg}
        </div>
    </div>
)}
```

Ключевые моменты:
- `fixed inset-0` — на весь viewport (если НЕТ perspective/transform/filter предков)
- `z-50` — поверх всего
- `pointer-events-none` — не блокирует клики сквозь оверлей
- `animate-pulse` — привлекает внимание
- `useEffect` с `setTimeout(2000)` — авто-закрытие
- Обязательно ВНЕ `.perspective-600` — иначе fixed привяжется к карточке

### Arena Slot Sizing

Slot sizes: desktop 44px/4px gap/240px frame, mobile 26px/4px gap/180px frame, verySmall 20px/2px gap/140px frame. Verified: 4×(size) + 3×(gap) + topOffset fits above weapon row (bottom:2px).

## Chat Overlap Fix

ChatPanel collapsed bar (40px fixed bottom) overlaps content. Fix: `padding-bottom: max(env(safe-area-inset-bottom,42px),50px)` in theme.css body.

## Header Conventions

Money: «Серебро: N» текстом (компонент `MoneyDisplay` с SVG-иконкой удалён). Protection: shield icon + MM:SS. Buttons: person+Аккаунт, scroll+Уведомления. Single-row flex layout. **Не использовать `MoneyDisplay` или `game-icons:coins` в хедере** — только текст.

## HomePage Onboarding

New players (money=0, inventory empty) see blue hint: "💡 Начните с Приключений...". Icons inline via `<Icon>`.

## Stat Allocation Panel

- Component: `client/src/components/StatAllocation.tsx`
- Placed below CharacterCard in LeftSidebar
- Collapsed by default (`useState(true)`)
- Shows current stats, +/− buttons when points available
- POST `/api/character/allocate-stats` with `{s, a, d, m}`

## Common Pitfalls

### Deployment & Infrastructure
- **Nginx WebSocket location trailing slash**: Client connects to `ws://host/ws?token=...`. `location /ws/` does NOT match `/ws?token=...`. Use `location /ws` (no trailing slash).
- **Nginx proxy_pass trailing slash**: `proxy_pass http://backend/` strips the matched prefix; `proxy_pass http://backend` preserves it.
- **express-rate-limit + nginx**: Set `app.set('trust proxy', 1)` in setupMiddleware.
- **SQLite ALTER TABLE ADD COLUMN cannot add UNIQUE**: Add column without UNIQUE, enforce at application level.
- **VPS setup**: apt-get install nginx certbot python3-certbot-nginx nodejs npm build-essential. pm2 for process management (`pm2 start`, `pm2 save`, `pm2 startup`).
- **HTTPS**: `certbot --nginx -d mmoarena.ru -d www.mmoarena.ru --non-interactive --agree-tos --email admin@mmoarena.ru --redirect`. Auto-renewal via systemd timer.
- **Deploy script**: `/opt/game/deploy.sh` — `git fetch && git reset --hard origin/main` → `npm install` → `vite build` → `pm2 restart` → `nginx reload`. **CRITICAL**: before running deploy, you MUST `git commit && git push`. The deploy script pulls from GitHub — local uncommitted changes are invisible to it. Symptom: «я всё исправил и перезапустил сервер, но на проде ничего не изменилось». Check: `git log --oneline -1` on VPS (`ssh root@IP "cd /opt/game && git log --oneline -1"`) to verify the commit hash matches your local fix.
- **Postfix/sendmail**: installed on VPS, nodemailer with sendmail transport. Port 25/465/587 may be blocked by hosting provider — emails won't deliver externally. Use API-based service (Resend, etc.) or request port unblock from VPS support.
- **Escape heredoc quotes** in SSH commands: use `cat > file << 'EOF'` (single-quoted delimiter) to avoid shell interpolation.

- **Remote API testing via SSH**: never try to inline Python/json parsing in SSH commands — bash quote escaping becomes combinatorially impossible. Pattern: write a Python test script locally → `scp` to VPS → `ssh root@IP "python3 /tmp/test.py"`. Bash heredocs over SSH also break with nested Python f-strings and JSON. Keep it simple: file on disk, run it. Reference script: `scripts/verify_battle_exp.py` — creates guest → arena battle → checks EXP persistence on VPS.

### Registration / Auth
- Registration requires email + verification code. Old users (created before email fields existed) can still log in — login now accepts email OR username (`WHERE username = ? OR email = ?`).
- `POST /api/register` does NOT return a token — only `POST /api/verify-email` does.
- The `emailCode` expires in 10 minutes (600 seconds).
- Login page placeholder: "Email или логин" (not "Логин").
- New registration form: login + email + password → verification code → auto-login.
- **Dev mode / SMTP failure**: when `sendVerificationCode` fails (no sendmail, port blocked), do NOT auto-verify. User is created with `emailVerified=0`. Return 500 error: «Не удалось отправить письмо с кодом. Попробуйте позже или запросите код повторно на странице входа.». Clear the code (`emailCode=NULL, emailCodeExpires=0`) so user can retry via `/resend-code`. Previously auto-verified — this was a security hole (players logged in without verification). Local dev without SMTP should either install sendmail or accept that registration requires a working mailer.
- **Login emailVerified check**: only enforced when user HAS an email (`email IS NOT NULL AND email != ''`). OAuth users and legacy accounts without email skip this check. Migration: `UPDATE users SET emailVerified = 1 WHERE email IS NULL OR email = ''`.
- **Guest registration email uniqueness**: `POST /api/account/register-guest` must check BOTH username AND email uniqueness with separate queries (`WHERE username = ? AND id != ?` + `WHERE email = ? AND id != ?`). SQLite INSERT doesn't enforce UNIQUE on columns added via ALTER TABLE — application-level check is mandatory. Without it, guests can occupy registered players' emails.

### Battle Response
- **`expGained` and `moneyGained` must be conditional on the winner.** `server/src/routes/battle.ts` returns these fields in the battle response JSON. `result.expGained` is non-zero when EITHER side gains XP (including when the defender wins). Always wrap: `expGained: result.winnerId === attacker.id ? result.expGained : 0`. Otherwise the loser sees "+1 XP" in the battle log and notification. Same for `moneyGained`.

- **SELECT queries MUST include `exp` column.** `battle.ts` has three SELECT queries (attacker line 20, defender with opponentId line 33, random defender line 36). If ANY of them omits `exp`, then `attacker.exp`/`defender.exp` is `undefined`. `undefined + expGained` = `NaN` → `NaN` written to DB as exp → when `/character/me` reads it back, `user.exp` is `NULL` or `0` → client shows `0/10` EXP bar after every arena fight. **Symptom**: опыт сбрасывается в 0/10 после победы на арене. **Fix**: `SELECT ..., exp, ... FROM users` во всех трёх запросах. PvE (`mobs.ts`) не затронут — использует `SELECT *`.

### Items & Admin
- **Item `cost` field**: items table has optional `cost INTEGER DEFAULT NULL` column. Shop uses `item.cost ?? Math.floor(100 * Math.pow(10, item.rarity_id))`. Admin forms (EditItemModal, AdminItems) include cost input. Cost is NOT displayed in tooltips — only shown in shop.
- **`hpRegen` removed from item extras**: `GameItem.extra` no longer includes `hpRegen`. Cleaned from: types (client GameContext, server stats.ts), validation (createItemSchema), seed data, admin forms (EditItemModal, AdminItems), stat_names table, client stats.ts. The base HP regen (1 HP/10s) is unaffected.
### PvE / Bestiary

- **Separate cooldown**: `lastPveAttackTime` is independent from PvP cooldown (`lastAttackTime`). Both are 5 min. Players can attack a mob and a player in the same 5-min window.
- **Mob stats are static**: no equipment, no level scaling. Use `currentStats(mobBase, {})` where mobBase = { s: atk, a: agi, d: def, m: mst }.
- **Material drop logic**: roll 35% → roll rarity from loot table → find craft_item by rarity_id → add to inventory. Craft items must exist in DB (seeded in craft_items table).
- **XP formula**: +0 if mob.level < player.level, +1 if |mob.level - player.level| ≤ 2, +2 if mob.level > player.level + 2.
- **Mob damage step MUST include `target` field**: server `routes/mobs.ts` constructs battle steps with `addStep({ type: 'damage', damage: dmg, ... })`. Without `target`, the client (`BestiaryPage.tsx`) can't distinguish player damage from mob damage. Add `target: 'player'` when mob hits player, `target: 'mob'` when player hits mob. Client condition: `step.target === 'player'` → `setPlayerHp(...)`, else → `setMobHp(...)`. Symptom without fix: mob damage visually subtracts from mob's own HP bar.
- **`xpGained` vs `expGained` field naming**: PvE battles (`pve_battles` table) use `xpGained` (with 'x'), PvP battles use `expGained` (with 'e'). Frontend must match the correct field per source: `b.expGained` for PvP, `b.xpGained` for PvE. Using wrong field silently renders nothing.

- **`lastLoginAt` consistency**: three places issue tokens — `POST /login`, `POST /verify-email`, and OAuth callbacks. ALL must update `lastLoginAt`. Use Unix timestamps (`Math.floor(Date.now() / 1000)`), NOT SQLite `CURRENT_TIMESTAMP` — avoids timezone parsing bugs between server (UTC) and client (local). Client `formatLastLogin` must handle both number (new) and string (old) formats. Symptom: «только что зашёл, а показывает 10ч».
- **Floor sorting**: sort by min monster level, not alphabetically: `floors.sort((a,b) => minLevel(a) - minLevel(b))`.
- **Page architecture**: 2 phases — `'floors'` and `'battle'`. Click floor → random mob → immediate battle (no intermediate mob card). Battle shows player card + mob card side by side (mob card has stats grid, no equipment slots), HP bars with CSS `transition-all`, step-by-step log like Arena, speed controls (x1/x2/Skip). After battle: «На главную» + «К этажам» buttons. Cooldown timer on floor cards and main page hunt action.
- **Main page hunt cooldown**: `pveCooldownSec` passed from HomePage → MainBar → Actions → CardGrid. Hunt button disabled during cooldown, shows `M:SS` like Arena.

### ELO Rating System (Full)

Rating lives in `server/src/game/rating.ts` — shared module with `calcElo()`, `applyDecay()`, `addPveRating()`, `checkSeasonReset()`.
- **elo column**: default 1000, minimum 100. Users table: `elo`, `seasonWins`, `seasonLosses`, `lastEloDecay`, `lastPvpTime`.
- **K-factor**: 40 (1–10), 30 (11–25), 20 (26–50), 15 (51+).
- **Formula**: `new = old + K × (result − expected)` where `expected = 1 / (1 + 10^((R_opp − R_self) / 400))`.
- **ELO returned in battle response**: `eloChange: newAttackerElo - attackerElo`. Both attacker and defender get ELO update.
- **`lastPvpTime`**: updated to `now` on every PvP fight (both attacker and defender). Required for decay calculation.
- **Rating route**: `GET /rating` — ORDER BY elo DESC, returns rank name/icon/color + `seasonWins`/`seasonLosses`.

#### PvE Rating (mobs.ts)
- Kill mob equal level: **+1** (once per hour, `lastPveRatingTime`)
- Kill mob stronger: **+2** (once per hour)
- Kill boss (level ≥ 100): **+10** (once per day, `lastBossKillDate`)
- **Cap**: PvE contribution ≤ **15%** of total ELO. Excess rating is silently dropped.
- Columns: `pveRating` (accumulated PvE contribution), `lastPveRatingTime`, `lastBossKillDate`.

**Pitfall — `elo` not updated on PvE kill.** The UPDATE query in `routes/mobs.ts` originally only did `pveRating = pveRating + ?`. This updated the tracker column but NOT the main `elo` column. Symptom: battle log shows «Рейтинг +2» but `elo` stays unchanged, `pveRating` grows alone. **Fix**: add `elo = elo + ?` to the same UPDATE with the same `result.eloAdded` value:
```ts
const updateFields = ['pveRating = pveRating + ?', 'elo = elo + ?'];
const updateValues: (number | string)[] = [result.eloAdded, result.eloAdded];
```
Both columns must increment by the same amount — `pveRating` tracks contribution for the 15% cap, `elo` is the displayed rating.

#### Decay (auth.ts — on login)
- 0–6 days no PvP: no penalty
- 7–13 days: **−5/day**
- 14–29 days: **−10/day**
- 30+ days: **−20/day**
- Min ELO: 100. `lastEloDecay` updated to prevent double-counting.
- `applyDecay(db, userId, lastPvpTime, elo)` in `rating.ts`.

#### Seasons (rating.ts — on login)
- **Monthly reset**: checked on first login after month ends via `checkSeasonReset(db)`.
- **Soft reset**: `1000 + (oldElo − 1000) × 0.5`.
- Top-10 archived to `hall_of_fame` table (seasonId, userId, rank, elo, title).
- `seasonWins`, `seasonLosses`, `pveRating` reset to 0.
- New season auto-created with name «Июнь 2026».

#### Upgrade Milestones (craft.ts)
- Item reaches +7: **+5 ELO**
- Item reaches +10: **+50 ELO**
- Added to `pveRating` column (counts toward PvE cap).

#### DB Tables Added
- `seasons` (id, name, startDate, endDate, status)
- `hall_of_fame` (id, seasonId, userId, rank, elo, title, reward)
- User columns: `lastPvpTime`, `lastPveRatingTime`, `lastBossKillDate`, `pveRating`

### Bank / Treasury

**Full banking system with accounts, transfers, and transaction history.**

#### Accounts
- **accountNumber**: 6-char alphanumeric (chars `23456789ABCDEFGHJKLMNPQRSTUVWXYZ`, no 0/O/1/I/l). UNIQUE index.
- **Auto-generated** for existing users in migration. New users get one on creation.
- **Display**: shown on BankPage (Информация tab) in monospace font with `select-all`.

#### No cooldown — instant access
- **30-min cooldown REMOVED**. `lastBankVisit` column no longer used. Bank accessible anytime.
- **Guest access**: fully blocked via `requireFullAccess` middleware + frontend guard.

#### Operations
- **Deposit**: 2% commission (`Math.ceil(amount * 0.02)`), deducts from `money`, adds to `bank`.
- **Withdraw**: 0% commission, deducts from `bank`, adds to `money`.
- **Live commission preview**: client calculates `Math.ceil(amount * 0.02)` before submit and shows «Комиссия: X серебра (зачислено: Y)».

#### Transfers (bank-to-bank)
- **From `bank` to `bank`**: sender must have money in the bank (not pocket). Receiver gets to their bank.
- **2% commission**: `Math.ceil(amount * 0.02)`. Receiver gets `amount - commission`.
- **Account existence check BEFORE deduction**: target account verified in the same transaction, not beforehand.
- **Live preview**: «Комиссия: X (получатель получит: Y)».
- **No self-transfer**, no transfer to non-existent accounts.

#### Transaction Safety (`db.transaction()`)
- **All write operations** (deposit, withdraw, transfer) wrapped in `db.transaction()`.
- **Atomicity**: any error throws → entire transaction rolls back. No partial money loss.
- **Transfer flow**: 1) check target exists 2) check sender balance 3) deduct sender 4) credit receiver 5) save history → all or nothing.

#### History Tables
- **`transfers`**: fromUserId, toUserId, fromAccount, toAccount, toUsername, amount, commission, received, createdAt. Joined to users on both sides.
- **`bank_operations`**: userId, type (deposit/withdraw), amount, commission, result, createdAt.
- **API**: `GET /bank/transfers?filter=all|in|out` and `GET /bank/operations?filter=all|deposit|withdraw`.

#### Frontend Tabs
- **Информация**: balances + account number + combined feed of all operations (transfers + deposits/withdrawals).
- **Пополнение**: deposit/withdraw form + deposit history (Все/Пополнение/Снятие tabs) + rules.
- **Переводы**: transfer form + transfer history (Все/Входящие/Исходящие tabs) + rules.

#### PvP Protection
- Battle route only reads/spends `money` column. `bank` is never touched by PvP or PvE defeat.

### Shop Page

Item cards use `ItemStats` directly — NO `ItemTooltip` on hover. The card itself shows all stats inline.

**Categories as collapsible blocks:** items grouped by slot. Each slot = a Card with ▶/▼ toggle. All collapsed by default. Inside: `grid-cols-[repeat(auto-fill,minmax(150px,1fr))]`.

**Smart search:** filters by name, slot label (рус), bonuses (s/a/d/m), extra stats. Uses `statNames` map. Shows «Найдено: N предметов».

### Rating Page / RatingBlock

**Three-column layout:** Ник (flex-1) | Титул (text-center, w-16) | Очки (text-right, w-12). Title NOT in brackets after nick. If no title → «—».

### Tavern / Healing
- **Room regen multiplier**: `character.ts` checks `roomType` and `roomUntil > now` before calculating HP regen. Multipliers: closet=3, bed=10, chamber=50.
- **Drinks**: `activeDrink TEXT`, `drinkUntil INTEGER`. Stat bonuses stored in drink definition (not DB) — apply on server when calculating stats.
- **Healing cost**: 2🥇 per HP. Full heal = missingHp * 2, 50% heal = ceil(missingHp * 0.5) * 2.
- **Pitfall — drink bonuses not factored into maxHp**: `currentStats()` in both GET /tavern and POST /tavern/heal must receive `drinkBonuses` (from active drink). Without it, players with +M drinks have lower maxHp than actual, and heal calculates `missingHp` from the wrong baseline. Fix: check `activeDrink && drinkUntil > now`, pass `drinks[activeDrink].bonuses` as third arg to `currentStats(base, enriched, drinkBonuses)`. Same pattern as `routes/character.ts` already applies for `/character/me`.

### Auction

#### Data model
- **Table**: `auction_lots` — sellerId, itemData (JSON), startPrice, buyoutPrice, currentBid, currentBidderId, duration, endsAt, createdAt.
- `itemData` is JSON containing the full item object. For stackable items (craft_item/material), it MUST include `count` (number of items in the lot).
- **Server route**: `server/src/routes/auction.ts` (222 lines, 6 endpoints).

#### Endpoints
| Method | Path | Purpose |
|--------|------|---------|
| GET | /auction | List active lots (auto-resolves expired) |
| GET | /auction/price-floor | Expose priceFloor map to client |
| POST | /auction/sell | Create lot (accepts `count` for stackable items) |
| POST | /auction/bid | Place bid (5% minimum increment) |
| POST | /auction/buyout | Full buyout at buyoutPrice |
| POST | /auction/buy-partial | Buy N items from a stack lot |

#### Price floors
- **Server**: `priceFloor: Record<number, number> = { 0: 5, 1: 15, 2: 50, 3: 150, 4: 400, 5: 1000, 6: 3000 }`
- **Client**: Mirrored as `PRICE_FLOOR` constant in `AuctionPage.tsx` — used for instant UI feedback (auto-fill startPrice, show min label). Client never fetches it from server; keep both maps in sync.
- Floor is multiplied by `count` for stack lots on both server and client: `floor * itemCount`.
- Server validates `startPrice >= floor * count` on sell; returns 400 with human-readable min price if violated.

#### Listing
- **Listing fee**: 5% of startPrice, non-refundable. Deducted from seller's money immediately.
- **5-lot limit**: per seller. Error message: «Максимум 5 лотов» (not «… одновременно»).
- **Stack selling**: client sends `count` for craft_item/material items. Server removes partial stack: if `count >= availableCount` → splice entire slot; else → reduce `item.count`. Validates `count <= availableCount`.

#### Bidding
- **Sale commission**: 10% of final price on completion. Calculated as `Math.floor(price * 0.1)`.
- **Min bid**: `currentBid ? Math.floor(currentBid * 1.05) : startPrice`. Previous bidder gets refunded on outbid.
- **Expired lots**: processed on GET /auction. Sold lots → payout seller, delete. Unsold → just delete. Previous bidder gets refunded.

#### Buyout stacking pitfall

**Symptom**: материалы, купленные через полный выкуп (buyout), не стакаются с уже имеющимися в инвентаре.

**Cause**: `POST /auction/buyout` handler does `inventory.push(itemData)` without checking for existing stacks of the same craft_item.

**Fix**: add stacking logic (same as `buy-partial` already has):
```ts
const isCraft = itemData.type === 'craft_item' || itemData.type === 'material';
if (isCraft) {
    const existingIdx = inventory.findIndex((i: any) =>
        (i.type === 'craft_item' || i.type === 'material') && String(i.id) === String(itemData.id)
    );
    if (existingIdx !== -1) {
        inventory[existingIdx].count = (inventory[existingIdx].count || 0) + (itemData.count || 1);
    } else {
        inventory.push(itemData);
    }
} else {
    inventory.push(itemData);
}
```

#### Stack partial buy (buy 1 from stack)
- **Endpoint**: `POST /auction/buy-partial` with `{ lotId, quantity }`.
- **Per-item price**: `Math.ceil(totalPrice / stackCount)`, where `totalPrice = currentBid ?? startPrice`.
- **Cost**: `pricePerItem * quantity`. 10% commission deducted from seller's portion.
- **Lot update**: if `remainingCount <= 0` → delete lot; else → scale startPrice/buyoutPrice/currentBid proportionally and update itemData count.
- **Buyer inventory**: craft_items auto-merge with existing stacks of same id (increment count). Non-craft items pushed as new slots.
- Client shows quantity input + button: «Купить N шт (цена) 🥇» on stack lots, separated by a border line from the bid section.

#### Buyout price validation

**Цена выкупа должна быть строго выше стартовой.** Запрет на `buyoutPrice <= startPrice` действует и на клиенте (мгновенная ошибка), и на сервере (400). Клиент `AuctionPage.tsx`:

```ts
if (buyoutNum > 0 && buyoutNum <= priceNum) { setError('Цена выкупа должна быть выше стартовой'); return; }
```

Сервер `auction.ts`: `if (buyoutPrice && buyoutPrice <= startPrice) return res.status(400)...`.

Без этой проверки можно выставить выкуп равным стартовой цене — и любой желающий выкупает лот по минимальной цене, обходя торги.

#### Per-item pricing convention

**Цены всегда за 1 штуку**, даже при продаже стека материалов:

- **Клиентская форма**: поля «Стартовая цена за 1 шт» и «Цена выкупа за 1 шт». Мин. цена (`priceFloor`) считается за 1 шт, не умножается на количество. При выборе >1 шт показывается итог: «Итого за N шт: X 🥇».
- **Сервер**: умножает per-item цену на `itemCount` при создании лота: `totalStartPrice = startPrice * itemCount`, `totalBuyoutPrice = buyoutPrice * itemCount`. В БД хранятся общие цены. Комиссия 5% от общей.
- **Отображение лотов**: для стеков показывается цена за штуку рядом с общей: «Старт: 500 (100 / шт)».

Код клиента (AuctionPage.tsx):
```tsx
// getAutoMinPrice — за 1 шт, без учёта количества
const floor = PRICE_FLOOR[rarity] || 5;

// Поля формы с пометкой «за 1 шт»
<label>Стартовая цена за 1 шт (мин: {formatMoney(autoMin)} 🥇)</label>
{isMaterial && sellCount > 1 && (
    <p>Итого за {sellCount} шт: {formatMoney(parseInt(startPrice) * sellCount)} 🥇</p>
)}
```

Код сервера (auction.ts):
```ts
const totalStartPrice = startPrice * itemCount;
const totalBuyoutPrice = buyoutPrice ? buyoutPrice * itemCount : null;
// INSERT использует totalStartPrice, totalBuyoutPrice
```

#### Client-side patterns
- **Auto min-price**: on item selection → `setStartPrice(String(floor))` (per item, NOT multiplied by count). On count change → no recalculation needed (price is per item).
- **Stack indicators**: dropdown shows `name x5 (rarity)` for stackable items. Lot card shows `xN` badge next to item name and per-item price below.
- **Empty state**: «Нет активных лотов» when buy tab has zero results.
- **Type mismatch fix**: `HTMLSelectElement.value` is always a string, but inventory item IDs may be numbers (`Date.now()` or auto-increment). Use `String(i.id) === id` for comparisons, never strict `===`. Both client (`findItemById` helper) and server (`auction.ts` sell route) need this fix.

### Tournament

**Continuous tournament system with official (admin) and custom (player-created) tournaments.**

#### Official Tournaments (type='official')
- **4 divisions**: copper (1–15, 500 base), steel (16–35, 2000), mithril (36–60, 8000), adamant (61+, 25000).
- **Continuous cycle**: new tournament starts immediately after previous one finishes.
- **Registration window**: 30 minutes. If 8 players register → instant auto-start.
- **Max players**: 8 per tournament.
- **If < 2 players** after 30 min → cancelled (refund not needed for official — no entry fee).
- **Prize distribution**: 1st=50%, 2nd=30%, 3rd=20% of prize pool.

#### Custom Tournaments (type='custom')
- **Created by players**: `POST /api/tournament/create-custom` — name, prizePool (from 0), entryFee, registrationMinutes (5-120), maxPlayers (2-16), minLevel, maxLevel.
- **Creator pays**: prizePool + entryFee (deducted from money). Auto-registered on creation.
- **division='custom'** in tournaments table (NOT NULL on division column — use 'custom' not NULL).
- **basePool column**: stores creator's original prizePool contribution. Entry fees added to prizePool on join. On cancel: refund basePool to creator + entryFee to each participant.
- **No golden tickets** in custom tournaments.
- **Columns**: type TEXT DEFAULT 'official', creatorId INTEGER, entryFee INTEGER DEFAULT 0, name TEXT, minLevel/maxLevel INTEGER, basePool INTEGER.

#### Seeding (tournamentElo)
- **Hidden `tournamentElo`** column (DEFAULT 1000) — NOT shown to players, only for seeding.
- **Sorting**: ORDER BY tournamentElo ASC, adjacent pairs (1 vs 2, 3 vs 4, ...). Players of similar skill fight each other, not spread across bracket.
- **Golden tickets do NOT affect seeding anymore**.
- **Elo update after tournament**: 1st +25, 2nd +15, 3rd +10, passed R1 +3, eliminated R1 −3. Min 100.

#### Bracket & Battle
- **Full HP before each tournament battle**: `currentStats()` recalculated, HP set to max = S+A+D+M. Players fight at full health regardless of their current HP.
- **All rounds simulated immediately** on auto-start (GET /tournament triggers autoAdvance → resolves all rounds).
- **Battle logs** saved as JSON in tournament_matches.log column. Viewable on TournamentPage.

#### Frontend
- **TournamentBanner** (sidebar): shows only player's eligible tournament (official or custom). Max 3 shown. Sorted by: joinable first → by start time. Custom marked with 🎪 and «игр.». Click title → /tournament.
- **TournamentPage**: tabs Все/Официальные/Самоорганизованные/Завершённые. Completed tab excludes cancelled tournaments (status='completed' only) and tournaments with < 2 participants.
- **Custom create form**: on Самоорганизованные tab. Prize pool from 0 (funded by entry fees). Button «+ Создать турнир».
- **Timer**: shows remaining time to registration start. Text size larger (text-sm), no medal emojis. Labels: «Призовой фонд», «Стоимость входа».

### Premium

### Daily Quests (Tavern)

- **5 daily quests, 3 active at once, random difficulty, snapshots for progress.**
- Full quest mechanics → `text-rpg-game` skill, Daily Quests section.

### History Page — Unified EntryRow Pattern

All notification entries use `EntryRow` component: `flex items-center gap-2` with content on left and timestamp on right (`ml-auto shrink-0`). Each entry type has its own renderer (`renderBattleRow`, `renderPveRow`, etc.) returning `<EntryRow time={...}>{...}</EntryRow>`. This replaces the old per-type div mess. XP displayed in purple (`text-[var(--color-accent-purple)]`), money in accent-green, defeats in red.
#### Quest Types
| Type | Name | Easy | Medium | Hard | Reward (easy) |
|------|------|------|--------|------|----------------|
| 🗡️ hunt | Крысиный мор | 3 mobs | 15 mobs | 75 mobs | +3 XP, 30 серебра |
| ⚔️ arena | Первая кровь | 1 PvP win | 5 PvP wins | 25 PvP wins | +3 XP, 40 серебра |
| 🌍 job | Медяки в карман | 10 min work | 1 hour work | 4 hours work | +3 XP, 20 серебра |
| ⚒️ craft | Проба пера | 1 craft/upgrade | 3 crafts | 6 crafts | +3 XP, 25 серебра |
| 💰 auction | Ставка сделана | 1 trade | 3 trades | 6 trades | +3 XP, 50 серебра |

#### Difficulty & Rewards
- **Random difficulty per quest** (easy/medium/hard).
- **Reward multipliers**: easy ×1, medium ×1.5, hard ×2.
- Requirements: hunt/arena use count multipliers (×1/×5/×25), job uses time (10m/1h/4h), craft/auction use (1/3/6).

#### Mechanics
- **5 quests generated daily**, all shown in tavern «Задания» tab.
- **3 simultaneous active**. After completing/cancelling one, can take another up to 5 per day.
- **Reset at midnight** server time.
- **Snapshot-based tracking**: player stats snapshotted on quest activation. Progress = current − snapshot.

#### Tracking Columns
- **craftCount**: incremented on craft success and upgrade success (both routes/craft.ts UPDATE queries).
- **auctionTrades**: incremented on buyout AND buy-partial for BOTH buyer and seller.
- **totalJobSeconds**: incremented on job completion with job duration (character.ts).

#### API Endpoints
- `GET /tavern/quests` — returns all 5 quests with status/progress, generates if none exist for today.
- `POST /tavern/quests/take` — snapshots stats, sets status='active'.
- `POST /tavern/quests/claim` — checks progress, awards XP+money, sets status='claimed'.

#### Frontend
- **TavernPage**: «Задания» tab with quest cards showing type icon, name, description, progress bar, «Награда:» label.
- **QuestsBlock** (sidebar): shows active quests (name + description + progress bar). Click quest → highlights Actions card. Click title → opens /tavern?tab=quests.
- **Actions highlighting**: `#action-{type}` URL hash → blue ring on matching card (`ring-2 ring-[var(--color-accent-info)]`). Mobile: scrollIntoView({block:'center'}).

### Premium

Премиум — усиление, выдаваемое через админку на N дней. Даёт +30% к доходу и уполовинивает кулдауны после боя.

#### DB
- Колонка `premiumUntil INTEGER DEFAULT 0` (Unix timestamp) в таблице `users`. `> now` = активен.
- Миграция: `ALTER TABLE users ADD COLUMN premiumUntil INTEGER DEFAULT 0`
- **`job_history.premiumBonus`**: колонка `premiumBonus INTEGER DEFAULT 0` в таблице `job_history` — сохраняет размер премиум-бонуса для каждой завершённой работы. Миграция: `ALTER TABLE job_history ADD COLUMN premiumBonus INTEGER DEFAULT 0`. Клиент (`HistoryPage.tsx`) отображает бонус жёлтым: `(+N премиум)`.

#### Сервер

**Выдача** (`routes/admin.ts`):
```ts
router.post('/premium', (req, res) => {
    const { userId, days } = req.body;
    const now = Math.floor(Date.now() / 1000);
    const currentUntil = Math.max(user.premiumUntil || 0, now); // продление от текущего
    const newUntil = currentUntil + days * 86400;
    db.prepare('UPDATE users SET premiumUntil = ? WHERE id = ?').run(newUntil, userId);
});
```

**Данные персонажа** (`routes/character.ts`):
```ts
premium: user.premiumUntil > now ? { until: user.premiumUntil } : null,
```

**Доход +30%** (НЕ на арене — убрано):
- PvE (`routes/mobs.ts`): `goldGained = Math.floor(goldGained * 1.3)`
- Работы (`routes/jobs.ts`): `reward = Math.floor(reward * 1.3)` при старте
- Арена (`routes/battle.ts`): без бонуса

**Кулдаун ×0.5** (PvP и PvE): `cooldown = hasPremium ? 150 : 300`.
Отображение: сервер возвращает `attackCooldownSec`/`pveCooldownSec` в `/character/me`, клиент берёт готовые значения, не считает сам.

#### Клиент

**BuffsBlock** (`components/BuffsBlock.tsx`):
- Принимает проп `premium?: { until: number } | null`
- Всегда показывает все три строки: Комната, Напиток, Премиум
- Если нет — «Отсутствует» серым. Если есть — таймер
- Премиум: жёлтый цвет `#f1c40f`, без описания в названии
- Строки кликабельны: Комната/Напиток → `/tavern`, Премиум → `/premium`
- Свёрнут по умолчанию (`collapsed = true`)

**LeftSidebar**: пробрасывает `premium` в BuffsBlock: `premium={(character as any).premium}`

**Админка** (`AdminUsers.tsx`):
- Форма «Выдать премиум»: ID игрока + дни (число)
- API-функция `grantPremium(userId, days)` в `api/admin.ts`
- Колонка «Премиум» в таблице игроков — жёлтый таймер если активен, «Нет» если нет
- Серверный `GET /admin/users` включает `premiumUntil` в SELECT

**Character endpoint**: `premium: user.premiumUntil > now ? { until: user.premiumUntil } : null`

**Страница премиума** (`client/src/pages/PremiumPage.tsx`, роут `/premium`):
- Карточка с описанием бонусов (+30% золота, кулдаун ×0.5)
- Блок «Можно запросить у админа» (временно, до появления покупки)

**Важно**: `hasPremium` определяется через `(user.premiumUntil || 0) > now` во всех боевых роутах. Проверка должна быть в начале хендлера, до боя, чтобы премиум влиял и на кулдаун, и на награду.

### Orders (Guilds)
- **Creation**: 5000🥇 + level 5+. `POST /orders/create` — creates order + adds creator as `master`.
- **Ranks**: master (👑), officer (🗡, up to 3), veteran (⚔, up to 5), fighter (💀), recruit (🕯, 3-day trial).
- **Treasury**: `POST /orders/donate` — any member can donate. `treasury` and `exp` columns updated. `exp` = floor(amount / 100).
- **Member limit**: `min(25, 10 + order.level)` — grows with order level.
- **Tables**: `orders` (name UNIQUE, masterId, level, exp, treasury, taxRate, createdAt), `order_members` (orderId, userId UNIQUE, rank, joinedAt).
- **Routes**: GET /orders (list all), GET /orders/my (player's order), POST /orders/create, /orders/join, /orders/leave, /orders/donate, /orders/promote, /orders/kick.
- **Leave restriction**: master cannot leave — must transfer or disband. Officers/veterans can kick recruits/fighters.

### OAuth (VK ID / Yandex ID)

**Pitfall — findOrCreateUser не обновляет lastLoginAt и не логирует IP.** В отличие от `/login` (auth.ts:150, 161-163), OAuth-колбэки VK/Яндекса исторически НЕ сохраняли `lastLoginAt` в `users` и НЕ писали IP в `login_logs`. Симптом: в админке нет данных о дате последнего входа и IP для пользователей VK/Яндекса.

**Что должно происходить при OAuth-входе** (реализовано в `routes/oauth.ts`):
1. `findOrCreateUser` обновляет `lastLoginAt` для существующих: `UPDATE users SET lastLoginAt = ? WHERE id = ?` (Unix timestamp)
2. `findOrCreateUser` проставляет `lastLoginAt` в INSERT для новых пользователей
3. Колбэки Яндекс и VK после `findOrCreateUser` логируют IP: `INSERT INTO login_logs (userId, ip) VALUES (?, req.ip)`
4. Колбэки вызывают `auditLoginSuccess(username, userId, req.ip)` для аудита

**Важно**: `findOrCreateUser` не имеет доступа к `req.ip` — IP-логирование и аудит должны быть СНАРУЖИ функции, в самих колбэках.

- **VK ID requires PKCE**: `code_challenge` + `code_challenge_method=S256` mandatory. Generate `code_verifier` (random 32 bytes base64url), `code_challenge` (SHA256 of verifier base64url), store verifier in memory keyed by `state` param, send in token exchange as `code_verifier`.
- **VK user info**: parse JWT from `id_token` field in token response (`.split('.')[1]`, base64 decode, JSON parse). Contains `sub`/`user_id`, `first_name`, `last_name`. Do NOT call a separate user_info API endpoint — it may fail or not exist in newer VK ID versions.
- **Yandex user info**: `GET https://login.yandex.ru/info?format=json` with `Authorization: OAuth {access_token}` header.
- **JWT from OAuth callback**: AuthProvider MUST process `?jwt=` in `useState` initializer (synchronously), NOT in `useEffect`. Route guards fire on first render — if `user` is `null`, `<Navigate to="/login">` fires before `useEffect` runs.
- **OAuth buttons**: plain `<a href>` links, NO icons (user rejected SVG icons). Brand colors only: Yandex `#FC3F1D`, VK `#0077FF`.
- OAuth providers redirect back to `https://mmoarena.ru/?jwt={token}`. AuthProvider extracts JWT, stores in localStorage, clears query param via `history.replaceState`.

## Notification / History Page — Unified EntryRow Pattern

All notification entries use `EntryRow` component: `flex items-center gap-2` with content on left and timestamp on right (`ml-auto shrink-0`). Each entry type has its own renderer (`renderBattleRow`, `renderPveRow`, etc.) returning `<EntryRow time={...}>{...}</EntryRow>`. XP displayed in purple (`text-[var(--color-accent-purple)]`), money in accent-green, defeats in red.

**Per-type renderers** (for tab-specific views): `renderBattleRow`, `renderPveRow`, `renderJobRow`, `renderTournamentRow`, `renderQuestRow`, `renderMessageRow`. For the «Все» tab, use `renderEntry` which dispatches by `entry.type`.

**Clarity**: use `expGained`/`expLost` for PvP and `expGained` for PvE. Field naming is now unified — PvE DB column renamed from `xpGained` to `expGained`.

## Workflow Rules

### ⚠️ Do NOT delegate everything to subagents

Subagent'ы часто не доставляют правильный результат для сложных задач. Пользователь получает один и тот же запрос по 5 раз. Правила:

1. **Составь план** (todo-список из 5-8 пунктов) и работай по нему последовательно
2. **Делай минимальные изменения** — точечные правки, а не переписывание целых файлов
3. **Проверяй результат** (`npx tsc --noEmit`) после каждого изменения
4. **Subagent'ы только для массового сидирования данных** (189 items в seed.ts, 20 jobs, etc.)

### When to delegate vs do it yourself

| Task | Approach |
|------|----------|
| 189 equipment items seed | delegate_task ✅ |
| 20 job types seed | delegate_task ✅ |
| New route/API | do it yourself |
| Client page rewrite | do it yourself |
| Bug fixes | NEVER delegate — do it yourself |

### ⚠️ ALWAYS restart servers after code changes

**Без исключений.** После ЛЮБОГО изменения в server/ или client/:

```bash
fuser -k 5173/tcp 3001/tcp; sleep 2
terminal(background=true, workdir=server/, cmd="npx tsx src/index.ts 2>&1", timeout=300)
terminal(background=true, workdir=client/, cmd="npx vite --host --force")
# Verify: curl localhost:3001/api/rating → 401 = OK, curl localhost:5173 → 200 = OK
```

**Client restart**: ALWAYS use `--force` flag (`npx vite --host --force`). Without it, Vite may serve cached builds even after files change on disk, causing «ничего не изменилось» feedback from user.

**Clear Vite cache before restart**: `execute_code` with `shutil.rmtree('/mnt/c/project/game/client/node_modules/.vite')`. The `terminal` tool may reject `rm -rf` as a "long-running server process" — use `execute_code` for filesystem cleanup operations.

**After restart, tell the user**: «Сделай Ctrl+Shift+R (жёсткий рефреш) в браузере». Cached JS bundles in the browser can also mask changes.

### Guest Login Architecture

Guest accounts allow playing without registration. They use `isGuest` flag in JWT and DB, with limited access to auction/craft/bank.

#### Server-side

**DB**: `users.isGuest INTEGER DEFAULT 0` (migration via `ALTER TABLE`).

**JWT**: guest token includes `isGuest: true` in payload. `authMiddleware` extracts it to `req.isGuest`.

**Guest creation** (`routes/auth.ts` — `POST /api/guest`):
- Random username: `Гость_{timestamp}_{random}`
- `passwordHash = ''` (empty — cannot login with password)
- `isGuest = 1`, `emailVerified = 1` (no email needed)
- Rate-limited via `authLimiter` (20/15min)

**Access control** (`middleware/auth.ts`):
- `requirePlayer`: blocks admins only (`req.role === 'admin'` → 403). Guests pass (role is `'player'`).
- `requireFullAccess`: blocks guests (`req.isGuest` → 403). Used on craft/bank/auction routes.

**Route-level protection** (`craft.ts`, `bank.ts`, `auction.ts`):
```ts
router.use('/craft', requireFullAccess);  // path-scoped — only blocks /craft/* paths
```
NOT `router.use(requireFullAccess)` — that blocks ALL requests reaching the router.

**Guest-to-player conversion** (`routes/account.ts` — `POST /api/account/register-guest`):
- Validated via `registerGuestSchema` (Zod): username 3-20, email, password 8-64 with digit+special, code exactly 6 digits
- Checks username + email uniqueness (separate queries with `id != userId`)
- Verifies `emailCode` from prior `resendCode()` call
- Updates: `username`, `passwordHash`, `email`, `emailVerified=1`, `isGuest=0`
- Returns new JWT with `isGuest: false`

**Registration flow**: client sends email → server stores `emailCode` via `resendCode()` → client sends code back → server verifies and converts.

#### Client-side

**LoginPage**: «Гостевой вход» button at bottom (no emoji). Calls `guestLogin()` from `api/auth.ts`.

**AuthContext**: `User` interface has `isGuest?: boolean`. `parseUserFromToken` extracts from JWT payload.

**Actions.tsx**: `isGuest` from `useAuth()` passed to `CardGrid`. Restricted paths (`/auction`, `/craft`, `/bank`) show «Заблокировано» button with tooltip on hover: «На гостевом аккаунте доступ к этой функции заблокирован».

**AccountPage**: guests see «Регистрация аккаунта» card (same style as RegisterPage — 2-step: name+email+password → code). Hidden: password change, gender, delete account. After conversion, all guest progress preserved (same user row, just `isGuest=0`).

**AdminUsers**: filter tabs «Все / Игроки / 🎭 Гости». Server `GET /admin/users?filter=guests`. Guest rows show 🎭 badge.

### JSX `class` vs `className`

**Никогда не использовать `class=` в JSX.** React требует `className=`. При поиске/замене через sed легко случайно написать `class=` — проверяй `grep -rn ' class="' client/src/` после правок. Симптом: консоль браузера показывает `Invalid DOM property 'class'. Did you mean 'className'?`.
- **Hermes browser via CDP on Ubuntu 26.04**: Playwright doesn't support Ubuntu 26.04. Workaround: install `agent-browser` globally via npm, run system Chromium in headless with `--remote-debugging-port=9222`, set `browser.cdp_url: http://localhost:9222` in Hermes config. Auto-start Chromium CDP in `.bashrc`.
- `style={{ border: undefined }}` overrides computed styles in React — don't pass `undefined` for border in `style` prop
- When patching CharacterCard, always update `statsMaxWidth`, `statsPadding`, etc. for all 3 modes (verySmall/mobile/desktop)
- WebSocket `/w` command is intercepted BOTH on client (ChatPanel.tsx) and server (websocket.ts) — check both when debugging
- `handleSkip` in useBattleLogic uses `battleResult.hpAfter` (attacker HP) and `battleResult.hpDefenderAfter` (defender HP)
- Inventory items have runtime-generated IDs (Date.now() + random) — don't match against DB item IDs
- **Express middleware ordering**: never mount the same router twice at `/api` with different middleware chains. If a router has both admin and player endpoints, split admin endpoints into a separate router, mount it at `/api/admin` BEFORE the `requirePlayer` middleware, and keep the player router at `/api` AFTER. Otherwise the first mount catches all routes and the stricter middleware (requireAdmin) rejects players with 403. Symptom: all API requests return 403 with no obvious cause. Root cause check: look for duplicate `app.use('/api', ...)` mounts of the same router in `server/src/index.ts`.
- **Express `router.use()` path scoping**: `router.use(middleware)` (without path) is a catch-all for the ENTIRE router — it fires for EVERY request that reaches that router in the Express chain, even if the request doesn't match any route inside. If craft.ts has `router.use(requireFullAccess)`, then ALL `/api/*` requests after craft in the `app.use` chain get blocked. Fix: use `router.use('/craft', requireFullAccess)` to scope the middleware to only `/craft/*` paths. Same for bank (`/bank`) and auction (`/auction`). NEVER use bare `router.use()` for restrictive middleware.
- **Route mount prefix must match client API paths**: when an admin router has internal paths like `/messages`, `/banned` and the client calls `/api/admin/chat/messages`, mount at `/api/admin/chat` (not `/api/admin`). Symptom: 403 on admin panel pages. Root cause: client sends `/admin/chat/...` but server expects `/admin/...`. Cross-check: search client `src/api/` for BASE_URL paths and verify they match the server mount prefix + router internal path.
- **Equip/unequip must recalculate `currentHp` on the server**: when gear changes, base stats (S/A/D/M) change, so max HP = S+A+D+M changes. The server must recalculate `currentHp` proportionally: `newHp = max(1, floor(oldHp × newMaxHp / oldMaxHp))`. Update BOTH `currentHp` and `lastHpUpdate` in the DB. Return `currentHp` and `maxHp` in the response. On the client, use `data.currentHp ?? max(1, character.currentHp)` instead of `Math.min(character.currentHp, calculateStats(...).hp)` — the client-side `Math.min` only caps HP down, never adjusts it up when max increases or down when max decreases. Affected client files: `useEquipment.ts`, `SlotSelectionModal.tsx`, `HomePage.tsx`.
- **ItemSlot.tsx `customStyle` overrides `SlotBase` inline styles**: border changes in `SlotBase` (dashed, color) are silently overridden by `ItemSlot`'s `customStyle={{ border: \`2px solid ...\` }}`. Always update both files when changing slot borders. The cascade is: SlotBase → baseStyle, then `style` prop, then `customStyle` (from ItemSlot). ItemSlot's `customStyle` wins on border.: the root-level `.env` pattern only matches the project root. Nested `.env` files (`server/.env`, `client/.env`) are NOT caught. Use `**/.env` to cover all levels. If `.env` was ever committed, even after removal, its contents are in git history — rotate any exposed secrets (JWT_SECRET, API keys).

## Responsive Layout

HomePage uses three-column flex layout: `flex flex-col sm:flex-row sm:flex-wrap gap-6 justify-center items-center sm:items-start`. Mobile: all blocks stack vertically at `w-full`. Desktop: flex-wrap with CharacterCard (fixed 200px), MainBar (flex-1 min-w-[280px]), RightSidebar (auto width).

Each sidebar column has `w-full sm:w-auto` wrapper. LeftSidebar uses `flex flex-col items-center sm:items-start` to center the card on mobile.

Actions card container uses the full-bleed hack: `w-screen ml-[calc(-50vw+50%)] sm:w-full sm:ml-0`. Do NOT replace with negative margin approaches — they break differently.

### ELO Rating System (Full)

### Responsive Modal Width

For modals that should be wide on desktop but fit the screen on mobile, use the `width` prop on the `Modal` component (not `maxWidth` alone — maxWidth only caps, doesn't stretch):

```tsx
<Modal
  width="min(900px, calc(100vw - 2rem))"
  ...
>
```

This sets BOTH `width` and `maxWidth` to the same value. On desktop (1920px): `min(900px, 1888px)` = 900px. On mobile (375px): `min(900px, 343px)` = 343px (fits screen minus margins).

The `Modal` component (`client/src/components/ui/Modal.tsx`):
- `width` prop → sets `style.width` and `style.maxWidth` to same value (forces width)
- `maxWidth` prop → sets only `style.maxWidth` (content determines actual width, up to max)
- If neither is passed → no width constraint, modal auto-sizes to content

### Item Type Localization

Craft items (materials, fragments, stones) have a `type` column in `craft_items` table. Display localized names:

- `itemUtils.ts`: `getItemTypeName(item)` — returns localized type name for any item
- `Inventory.tsx`: `typeLocalization` map for filter tab labels (plural form)
- `ItemStats.tsx`: uses `getItemTypeName()` for the "Тип: ..." line

Type map in `itemUtils.ts`:
```
craft → 'Материал'
material → 'Материал'
craft_item → 'Материал'
```

For equipment, `getItemTypeName` falls back to `slotNames[slot]` (Шлем, Оружие...).

### ItemStats Resource Properties Table

Craft item properties (Тип, Количество) must use the SAME styled table as equipment stats — alternating row backgrounds, white bold values.

**«Количество» показывается только если `item.count != null`** — для тултипов лута в карточках охоты count отсутствует. Используется spread-синтаксис для условного добавления строки:
```tsx
{[
  ['Тип', getItemTypeName(item)],
  ...(item.count != null ? [['Количество', String(item.count)]] : []),
].map(([name, val], i) => (...))}
```

Do NOT use plain text `div`s with color: '#aaa'. The table uses the pattern:

```tsx
{resource && (
  <div className="text-xs">
    {[
      ['Тип', getItemTypeName(item)],
      ['Количество', String(item.count)],
    ].map(([name, val], i) => (
      <div key={i} className="flex justify-between py-0.5 px-1"
        style={{ background: i % 2 === 0 ? 'rgba(255,255,255,0.03)' : 'transparent' }}>
        <span>{name}</span>
        <span className="font-bold text-white">{val}</span>
      </div>
    ))}
  </div>
)}
```

Always put Количество as the LAST row (new properties inserted before it).
