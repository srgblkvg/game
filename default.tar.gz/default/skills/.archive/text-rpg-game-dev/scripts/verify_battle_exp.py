#!/usr/bin/env python3
"""Remote battle EXP verification for text RPG.

Usage:
    scp this_file root@VPS:/tmp/test_battle.py
    ssh root@VPS "python3 /tmp/test_battle.py"

Creates a guest, runs one arena battle, reports EXP before/after.
Uses localhost:3001 by default; override with HOST env var.
"""

import subprocess, json, os, sys

HOST = os.environ.get("HOST", "http://localhost:3001")


def api(method, path, token=None, data=None):
    cmd = ["curl", "-s", f"{HOST}{path}", "-X", method,
           "-H", "Content-Type: application/json"]
    if token:
        cmd += ["-H", f"Authorization: Bearer ***    if data:
        cmd += ["-d", json.dumps(data)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return {"raw": r.stdout, "stderr": r.stderr}


def main():
    # Create guest
    guest = api("POST", "/api/guest")
    if "error" in guest:
        print(f"FAIL: Cannot create guest: {guest['error']}")
        sys.exit(1)
    token = guest["token"]
    uid = guest["user"]["id"]
    print(f"Guest: id={uid}")

    # Before battle
    char = api("GET", "/api/character/me", token)
    print(f"Before: level={char['level']}, exp={char['exp']}")

    # Find opponent
    opp = api("GET", "/api/arena/opponent", token)
    opp_id = opp.get("id")
    if not opp_id:
        print(f"No opponent: {opp.get('error', opp)}")
        # Try random battle
        battle = api("POST", "/api/battle", token, {})
    else:
        print(f"Opponent: id={opp_id}, name={opp.get('name')}")
        battle = api("POST", "/api/battle", token, {"opponentId": opp_id})

    if "error" in battle:
        print(f"BATTLE ERROR: {battle['error']}")
        sys.exit(1)

    wid = battle.get("winnerId")
    exp_gained = battle.get("expGained", 0)
    new_level = battle.get("newLevel")
    new_exp = battle.get("newExp")
    print(f"Battle: winnerId={wid}, expGained={exp_gained}, "
          f"newLevel={new_level}, newExp={new_exp}")

    # After battle
    char2 = api("GET", "/api/character/me", token)
    print(f"After: level={char2['level']}, exp={char2['exp']}")

    # Verdict
    if char2.get("exp", 0) > 0 and wid == uid:
        print("SUCCESS: EXP was awarded!")
    elif wid == uid:
        print("FAIL: Won but EXP is still 0!")
        sys.exit(1)
    else:
        print(f"Guest lost (winnerId={wid}, uid={uid}) — no EXP expected")
        if exp_gained > 0:
            print("  But expGained was returned — that's correct for the winner")


if __name__ == "__main__":
    main()