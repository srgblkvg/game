---
name: hermes-browser-setup
description: "Diagnose, configure, and fix Hermes browser tools (browser_navigate, browser_snapshot, browser_click, etc.) when they don't work — Playwright issues, agent-browser CLI setup, CDP fallback, system browser workarounds."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, wsl]
metadata:
  hermes:
    tags: [hermes, browser, troubleshooting, setup, cdp, playwright, agent-browser]
---

# Hermes Browser Setup & Troubleshooting

When `browser_navigate` times out or returns errors, this skill provides the diagnosis path and fixes. Hermes browser tools use **agent-browser CLI** under the hood (not Playwright directly), with optional cloud backends (Browserbase, Camofox, Browser Use) or local Chromium.

## Quick Diagnosis

Run these checks in order:

1. **Is agent-browser installed?** `which agent-browser || npx agent-browser --version`
2. **Is a browser binary available?** Check `~/.agent-browser/browsers/` or system Chromium
3. **Does the browser binary run?** `<binary> --headless --no-sandbox --disable-gpu --dump-dom https://example.com`
4. **Is CDP configured?** Check `hermes config` → `browser.cdp_url`

## Common Failure Modes

### 1. agent-browser not installed

**Symptom:** `browser_navigate` times out after 60s, no errors in console.

**Fix:**
```bash
npm install -g agent-browser
agent-browser install          # downloads Chrome to ~/.agent-browser/
```

Hermes auto-discovers `~/.hermes/node/bin/` in PATH — no manual PATH setup needed.

### 2. Playwright/agent-browser Chrome won't run (missing system libs)

**Symptom:** `agent-browser open <url>` hangs or Chrome binary fails with `libnspr4.so: cannot open shared object file`.

**Root cause:** agent-browser downloads its own Chrome, which needs system libraries not installed (and `agent-browser install --with-deps` requires `sudo`).

**Fix — CDP fallback with system Chromium:**

Use the system Chromium (snap/deb) which already has all dependencies:

```bash
# 1. Start system Chromium with remote debugging
chromium-browser --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 &

# 2. Configure Hermes to use it
hermes config set browser.cdp_url "http://localhost:9222"
```

**Auto-start** (add to `~/.bashrc`):
```bash
if ! pgrep -f "chromium.*remote-debugging-port=9222" >/dev/null 2>&1; then
    nohup chromium-browser --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 >/dev/null 2>&1 &
fi
```

After setting `browser.cdp_url`, browser tools work immediately — no restart needed.

### 3. Playwright unsupported OS version

**Symptom:** `npx playwright install chromium` fails with "Playwright does not support chromium on <os>".

**Fix:** Don't use Playwright. Hermes uses agent-browser, not Playwright. Install agent-browser instead (see #1). If agent-browser Chrome also fails, use CDP fallback (see #2).

### 4. Private URL blocked (localhost)

**Symptom:** `browser_navigate("http://localhost:5173")` fails with access error.

**Fix:** Hermes auto-allows localhost when `browser.auto_local_for_private_urls: true` (default). If still blocked, check `browser.allow_private_urls` in config.

## Config Reference

Key browser config in `~/.hermes/config.yaml`:

```yaml
browser:
  provider: local                  # local | browserbase | camofox
  cdp_url: "http://localhost:9222" # CDP endpoint for system browser
  local:
    executable_path: /snap/bin/chromium  # system browser path
  engine: auto
  auto_local_for_private_urls: true
  allow_private_urls: false
```

## Verification

After setup, test with:

```
browser_navigate("https://example.com")  → should return {"success": true, ...}
browser_snapshot()                        → should show page elements
```

## Architecture Note

Hermes browser stack (simplified):

```
browser_navigate / browser_snapshot / browser_click / ...
    ↓
browser_tool.py
    ↓
agent-browser CLI (npm package)  ←  what you install
    ↓
Chrome/Chromium                  ←  local or CDP-connected
```

Cloud backends (Browserbase, Browser Use, Camofox) bypass agent-browser entirely and use REST APIs.

## Pitfalls

- **Don't install Playwright for Hermes browser.** It's not used. agent-browser is the CLI Hermes invokes.
- **Don't set `browser.local.executable_path` alone.** It's only used by the Playwright fallback path (rarely reached). Use CDP instead.
- **CDP Chromium must stay running.** If the Chromium process dies, browser tools will hang. The auto-start in `.bashrc` prevents this.
- **Snap Chromium may print DBus warnings to stderr** — these are harmless. Ignore `org.freedesktop.UPower` and `xdg-settings` warnings.
