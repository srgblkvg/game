# Ubuntu 26.04 Browser Setup Recipe

Reproduction of the exact steps that worked on Ubuntu 26.04 (WSL) where Playwright
and agent-browser's bundled Chrome both failed.

## Environment

- OS: Ubuntu 26.04 (WSL2)
- Hermes version: installed via installer script
- Node: via Hermes bundled node at `~/.hermes/node/bin/`
- System Chromium: snap, v148.0.7778.167
- Playwright: v1.60.0 (npm), Python module NOT installed
- agent-browser: v0.27.0 (installed globally via npm)

## What Failed

### Attempt 1: Playwright Chromium
```
$ npx playwright install chromium
ERROR: Playwright does not support chromium on ubuntu26.04-x64
```

### Attempt 2: Playwright Firefox
```
$ npx playwright install firefox
ERROR: Playwright does not support firefox on ubuntu26.04-x64
```

### Attempt 3: agent-browser Chrome (missing libs)
```
$ agent-browser install       # downloads Chrome 149 to ~/.agent-browser/
$ agent-browser open https://example.com   # hangs 30s+
$ ~/.agent-browser/browsers/chrome-149.0.7827.54/chrome --headless ...
error while loading shared libraries: libnspr4.so: cannot open shared object file
```

`agent-browser install --with-deps` tried `sudo apt-get install` and failed
(no sudo available in this environment).

### Attempt 4: System Chromium (WORKS)
```
$ chromium-browser --headless --no-sandbox --disable-gpu --dump-dom https://example.com
# Returns full HTML immediately
```

### Attempt 5: CDP approach (WORKS)
```bash
# Start CDP server
$ chromium-browser --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 &
$ curl -s http://localhost:9222/json/version
# Returns WebSocket debugger URL

# Configure Hermes
$ hermes config set browser.cdp_url "http://localhost:9222"
```

## Final Working Config

```yaml
# ~/.hermes/config.yaml (relevant section)
browser:
  provider: local
  cdp_url: "http://localhost:9222"
  local:
    executable_path: /snap/bin/chromium
```

## Auto-start (added to ~/.bashrc)

```bash
# Hermes browser CDP — system Chromium with remote debugging (auto-start)
if ! pgrep -f "chromium.*remote-debugging-port=9222" >/dev/null 2>&1; then
    nohup chromium-browser --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 >/dev/null 2>&1 &
fi
```

## Key Lesson

The chain is: Hermes → agent-browser CLI → Chrome binary.
When agent-browser's own Chrome can't run (missing system deps), bypass agent-browser
by pointing Hermes directly at a working Chromium via CDP. The `browser.cdp_url` config
makes Hermes skip agent-browser's Chrome and connect to the CDP endpoint instead.
