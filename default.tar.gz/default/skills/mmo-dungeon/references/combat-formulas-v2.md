# Dungeon Combat Formulas v2 — battle.ts integration

Replaced the original simplified damage formulas with the main game's battle engine formulas from `server/src/game/battle.ts`.

## Imports

```typescript
import { dodgeChance, critChance, critMult, blockChance, blockReduction, counterChance, rollDamage } from '../game/battle';
```

## Player Attack

```typescript
function calcPlayerDamage(run: DungeonRun): { damage: number; isCrit: boolean; dodged: boolean; blocked: boolean; counterDmg: number } {
    const stats = { s: run.playerStr, a: run.playerAgi, d: run.playerDef, m: run.playerMag, hp: run.playerMaxHp, extra: {}, bonuses: {} };
    const target = run.enemies[run.targetIndex];
    const mobStats = { s: target.dmg, a: target.dmg, d: Math.floor(target.dmg * 0.5), m: Math.floor(target.dmg * 0.3), hp: target.maxHp, extra: {}, bonuses: {} };

    // Dodge check (enemy dodges)
    if (Math.random() < dodgeChance(mobStats, stats)) {
        run.log.push(`↗ ${target.name} уклоняется`);
        return { damage: 0, isCrit: false, dodged: true, blocked: false, counterDmg: 0 };
    }

    // Block check (enemy blocks)
    const blocked = Math.random() < blockChance(mobStats);
    const blockRed = blocked ? blockReduction(mobStats, stats) : 0;

    // Damage + crit
    const dmg = rollDamage(stats, run.playerLevel);
    const isCrit = Math.random() < critChance(stats);
    const finalDmg = Math.floor(isCrit ? dmg * critMult(stats) : dmg);
    const afterBlock = Math.max(1, Math.floor(finalDmg * (1 - blockRed)));
    const totalDmg = Math.floor(afterBlock * bcBonus);

    return { damage: totalDmg, isCrit, dodged: false, blocked, counterDmg: 0 };
}
```

## Enemy Attack

```typescript
function calcEnemyDamage(enemy: EnemyData, playerStats: any, floor: number): { damage: number; dodged: boolean; blocked: boolean } {
    const stats = { s: enemy.dmg, a: enemy.dmg, d: Math.floor(enemy.dmg * 0.5), m: Math.floor(enemy.dmg * 0.3), hp: enemy.maxHp, extra: {}, bonuses: {} };

    // Dodge check (player dodges)
    if (Math.random() < dodgeChance(playerStats, stats)) {
        return { damage: 0, dodged: true, blocked: false };
    }

    // Block check (player blocks)
    const blocked = Math.random() < blockChance(playerStats);
    const blockRed = blocked ? blockReduction(playerStats, stats) : 0;

    const base = enemy.dmg + Math.floor(floor * 0.3);
    const debuffPct = enemy.debuffs?.['demoralize']?.value || 0;
    const dmg = Math.floor((base + Math.random() * 2) * (1 - debuffPct / 100));
    const afterBlock = Math.max(1, Math.floor(dmg * (1 - blockRed)));

    return { damage: afterBlock, dodged: false, blocked };
}
```

## Mob Stats for Formulas

Mobs don't have full S/A/D/M stats — they have `atk` and `hp`. We derive stats:
- `s = atk` (strength)
- `a = atk` (agility)
- `d = floor(atk * 0.5)` (defense)
- `m = floor(atk * 0.3)` (mastery)
- `hp` from mob data
- `extra = {}` (no extra stats for mobs)

## Log Messages

| Event | Log |
|-------|-----|
| Player dodge | `↗ Вы уклоняетесь от {name}` |
| Enemy dodge | `↗ {name} уклоняется` |
| Player block | `🛡 Блок! {name} бьёт на {dmg}` |
| Enemy block | `⚔️ {dmg} по {name} (блок)` |
| Crit | `💥 Крит {dmg} по {name}` |
| Normal hit | `⚔️ {dmg} по {name}` |

## Floating Text Effects

| Effect | Color | Where |
|--------|-------|-------|
| Damage numbers | white / #ffaa00 (crit) | Over enemy card |
| Крит! | #ffaa00 | Over enemy card |
| Оглушение! | #fbbf24 | Over enemy card |
| Уклонение! | #60a5fa | Over dodger's card |
| Блок! | #818cf8 | Over blocker's card |
| +Rage | #f97316 | Over player card |

## Pitfalls

### critChance was 100% with old formula

Old: `critChance = playerAgi/3 * 0.5` where playerAgi from buildPlayerStats is scaled ×2-3. At playerAgi=600, critChance = 200 * 0.5 = 100%. Every hit was a crit.

Fix: use `critChance(stats)` from battle.ts which has proper soft cap `x/(x+300)`.

### No dodge/block before

Old code had no dodge or block mechanics at all — every attack always hit. Now enemies can dodge and block, and the player can too.
