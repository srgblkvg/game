# dungeon_logs — GRANT permissions

The `dungeon_logs` table is created by `CREATE TABLE IF NOT EXISTS` in `dungeon.ts`. After creation (or first deploy to a fresh DB), the `game` user needs explicit GRANT. Without it, all log INSERTs silently fail with `permission denied`.

## Fix

```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c 'GRANT ALL ON dungeon_logs TO game; GRANT ALL ON SEQUENCE dungeon_logs_id_seq TO game;'"
```

## Symptom

`pm2 logs game-server --err` shows repeated:
```
[dungeon_logs] permission denied for table dungeon_logs
```

The INSERT itself is wrapped in try/catch and will not crash the server, but no logs are written.

## When to run

- After first deploy with the dungeon feature
- After `DROP TABLE dungeon_logs` / recreation
- After DB migration/reset
