# Combat formulas v3 — full battle.ts integration (2026-08-09)

## What changed from v2

v2 had: dodge, block, crit, basic rollDamage.
v3 adds: fullBlock, blockPen, vampirism, execute.

## Player attack (calcPlayerDamage)

```typescript
function calcPlayerDamage(run): { damage, isCrit, dodged, blocked, counterDmg, vampHeal } {
    const stats = { s, a, d, m, hp, extra: run.playerExtra, vampirism: run.playerVamp };
    const mobStats = { s: target.dmg, a: target.dmg, d: target.dmg*0.5, m: target.dmg*0.3, hp, extra:{} };
    
    // 1. Dodge check (enemy dodges)
    if (Math.random() < dodgeChance(mobStats, stats)) → dodged
    
    // 2. Damage + crit
    const dmg = rollDamage(stats, level);
    const isCrit = Math.random() < critChance(stats);
    let finalDmg = isCrit ? dmg * critMult(stats) : dmg;
    
    // 3. Full block (enemy)
    const fb = mobStats.extra?.fullBlock || 0;
    if (Math.random() < fb / (fb + 300)) → fullBlock → 0 damage
    
    // 4. Regular block (enemy) with blockPen
    if (Math.random() < blockChance(mobStats)) {
        let red = blockReduction(mobStats, stats);
        if (stats.blockPen) red *= (1 - blockPen/100);
        finalDmg = Math.max(1, finalDmg * (1 - red));
    }
    
    // 5. Battle cry bonus
    finalDmg *= bcBonus;
    
    // 6. Vampirism
    const vampHeal = Math.round(finalDmg * (stats.vampirism || 0) / 100);
    
    // 7. Execute (instakill at <10% HP)
    if (stats.extra?.execute && target.hp < target.maxHp * 0.1) → instakill
    
    return { damage: finalDmg, isCrit, dodged, blocked, counterDmg: 0, vampHeal };
}
```

## Enemy attack (calcEnemyDamage)

```typescript
function calcEnemyDamage(enemy, playerStats, floor): { damage, dodged, blocked } {
    // 1. Dodge check (player dodges)
    if (Math.random() < dodgeChance(playerStats, enemyStats)) → dodged
    
    // 2. Calculate damage
    const base = enemy.dmg + floor * 0.3;
    let dmg = (base + random*2) * (1 - demoralizeDebuff/100);
    
    // 3. Full block (player)
    if (Math.random() < (playerStats.extra?.fullBlock||0) / (fb+300)) → 0 damage, blocked
    
    // 4. Regular block (player)
    if (Math.random() < blockChance(playerStats)) {
        dmg = Math.max(1, dmg * (1 - blockReduction(playerStats, enemyStats)));
        return { damage: dmg, blocked: true };
    }
    
    return { damage: dmg, dodged: false, blocked: false };
}
```

## DungeonRun fields

Added to interface:
- `playerExtra: any` — equip extra stats (fullBlock, execute, counter, etc.)
- `playerVamp: number` — vampirism % from equipment

Populated in start/continue:
```typescript
playerExtra: (stats as any).extra || {},
playerVamp: (stats as any).vampirism || 0,
```

## Vampirism application in tick

```typescript
const { damage: dmg, isCrit, dodged, blocked, vampHeal } = calcPlayerDamage(run);
target.hp -= dmg;
if (vampHeal > 0) {
    run.playerHp = Math.min(run.playerMaxHp, run.playerHp + vampHeal);
    run.log.push(`🩸 Вампиризм +${vampHeal} HP`);
}
```
