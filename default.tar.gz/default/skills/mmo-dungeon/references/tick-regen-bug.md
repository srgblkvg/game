# Dungeon: Tick, Regen, Combat Mechanics Reference

## COMBAT_SPEED — global slowdown
`const COMBAT_SPEED = 1/3` — applied to ALL per-second rates in tickCombat(). Change this one constant to adjust combat speed. Values < 1 = slower, 1 = normal.

## Death flow (correct as of 2026-08-09)
1. `tickCombat()` bottom check: `playerHp <= 0` → `clearInterval(tickTimer)`, do NOT delete from activeRuns
2. Client polls `/dungeon/state` → `{ active: true, dead: true }` → shows death card
3. User clicks «Вернуться» → `setDead(false)`, `stopPolling()`, `loadStatus()`
4. `/dungeon/status` finds zombie run → cleans up (clearInterval + activeRuns.delete) → returns inactive status
5. Status page shows cooldown

**NO auto-reload. NO setTimeout. NO location.reload().** Manual close only.

## Death — BOTH checks must call activeRuns.delete()
`tickCombat()` top check (line ~789) and bottom check (line ~868). Top check handles already-dead runs, bottom check handles fresh deaths. If bottom check misses `activeRuns.delete()`, the run stays in memory forever → infinite reload loop.

## Loot — accumulate on claim, award on exit
- `claim`: calculates rewards, pushes to `run.accumulatedLoot`, returns for display. NO DB writes.
- `flee` (exit): awards all `accumulatedLoot` (silver, items to inventory, pages to skill_pages), then cleans up.

## Target system
- `DungeonRun.targetIndex` — which enemy is targeted (0-based)
- `getTarget(run)` helper — returns `run.enemies[run.targetIndex]`
- Target endpoint: just changes index, validates enemy is alive
- ALL skill handlers use `getTarget()` — never `run.enemies[0]`
- State response includes `targetIndex` for client

## Dead enemies — stay in list
- `checkEnemyDeaths()` does NOT filter/remove dead enemies
- Just checks `allDead → cleared = true`
- Auto-switches `targetIndex` to first alive enemy when current target dies
- Client: `opacity-40 grayscale`, not clickable

## Enemy attack timer — MUST reset on stun
When applying stun: `target['_lastAttack'] = 0;` — resets attack progress so enemy doesn't hit immediately after stun ends. Required for shield_bash AND charge.

## HP regen formula
`const regenPerSec = run.playerMaxHp * 0.03 * run.regenRate * COMBAT_SPEED;`
`const regenThisTick = Math.floor(regenPerSec * (TICK_MS / 1000));`

## Defense formula
`Math.max(1, Math.floor(dmg * (1 - run.playerDef * 0.0008)))`

## Mob filtering
Filter: `mobs.filter(m => m.atk <= floor * 15)`

## Dungeon logs table — GRANT
After CREATE TABLE: `GRANT ALL ON dungeon_logs TO game; GRANT ALL ON SEQUENCE dungeon_logs_id_seq TO game;`
INSERT uses `?` placeholders, `::jsonb` cast for JSONB columns. Always `await`.

## Deploy checklist
1. `rm -rf dist && npx tsc`
2. `rsync dist/ root@VPS:/opt/game/server/dist/`
3. `ssh root@VPS "pm2 restart game-server"`
4. VERIFY with grep on VPS

## Attempt limits removed
Status returns `remainingRuns: 99, dailyRuns: 0` always.
