# Dungeon Balance Formulas (2026-08-08)

## Player damage
```
rs = run.playerStr / 3
ra = run.playerAgi / 3
rm = run.playerMag / 3
weaponBonus = 3 + run.equippedWeaponRarity * 3
baseDmg = rs + ra * 0.3 + rm * 0.2 + run.playerLevel + weaponBonus
random: Math.random() * (run.playerLevel + weaponBonus)
crit: (ra * 0.5)% chance, x2 damage
```

Stats are scaled (collection x2-3x guild x1.1), divisor /3 brings to raw values.

## Mob stats

### Filtering (CRITICAL)
`maxAtk = floor * 15` — mobs with ATK > maxAtk cannot spawn.
Mob table has ATK up to 4675. Without filter, floor 1 can get 5000+ damage boss.

### Scaling
`scale = 0.3 + floor * 0.8`
Floor 1: 1.1 (HP~8, dmg~3-4)
Floor 5: 4.3 (HP~34, dmg~13-15)
Floor 10: 8.3 (HP~66, dmg~25-29)
Floor 20: 16.3 (HP~130, dmg~49-52)
Boss: HP x5

### Enemy damage formula
```
base = enemy.dmg + Math.floor(floor * 0.3)
dmg = Math.floor((base + Math.random() * 2) * debuff)
reduced = Math.max(1, Math.floor(dmg * (1 - run.playerDef * 0.0008)))
```

## Enemy attack speed
Boss: 0.5-1.5s. Regular: 0.5-2.5s.

## HP regen in rest room
```
regenPerSec = run.playerMaxHp * 0.03 * run.regenRate
regenRate: 1 (base), x3 (premium), rooms x3/x10/x50/x250
```
~3% maxHP/s base, ~90%/s with bed+premium. 30x faster than game formula.

## Expected difficulty
Level 1 (HP 30): dies floor 1
Level 5 (HP ~100): reaches floor 5-6
Level 9 (HP ~270): reaches floor 15-16
