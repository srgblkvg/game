# Battle Simulation for Build Testing

## Running simulations without touching production

To test equipment builds without affecting live characters, run the battle simulator directly on the VPS using the `runBattle` engine:

```bash
cd /opt/game/server && npx tsx -e "
const { db } = require('./src/db/index');
const { runBattle } = require('./src/game/battle');
const { getCollectionBonus } = require('./src/db/helpers');

(async () => {
    const u1 = await db.one('SELECT * FROM users WHERE id = 1');
    const u2 = await db.one('SELECT * FROM users WHERE id = 131');
    
    // Use equipment_3 for testing (doesn't affect active equipment)
    const eq1 = JSON.parse(u1.equipment_3);
    const eq2 = JSON.parse(u2.equipment);
    
    const cb1 = await getCollectionBonus(1);
    const cb2 = await getCollectionBonus(131);
    
    const base1 = { s: +u1.bases, a: +u1.basea, d: +u1.based, m: +u1.basem };
    const base2 = { s: +u2.bases, a: +u2.basea, d: +u2.based, m: +u2.basem };
    
    let wins = 0;
    for (let i = 0; i < 100; i++) {
        const r = runBattle(
            { id:1, name:'P1', base:base1, equipment:eq1, level:u1.level, money:0, collectionBonus:cb1 },
            { id:2, name:'P2', base:base2, equipment:eq2, level:u2.level, money:0, collectionBonus:cb2 }
        );
        if (r.winnerId === 1) wins++;
    }
    console.log('Win rate:', wins + '%');
    process.exit(0);
})();
"
```

Key: this reads equipment_3 (or any slot) directly — it does NOT modify the active `equipment` column. The production character is unaffected.

## Understanding the gap

When a build underperforms despite optimal gearing, check:
1. **Collection bonus** (`getCollectionBonus(id)`) — scales ALL stats, massive impact
2. **Base stats** (bases/basea/based/basem) — from level + stat points
3. **Drink bonuses** (activedrink) — temporary buffs
4. **Equipment set bonuses** — multipliers on extra stats

Example: Некрохирург vs Sallarik:
- Sallarik collection: 508, Некро: 338 — 50% gap
- Even perfect gear can't close a 50% collection gap

Print full stats for comparison:
```bash
npx tsx -e "
const { currentStats } = require('./src/game/stats');
const s1 = currentStats(base1, eq1, null, cb1);
console.log(JSON.stringify(s1, null, 2));
"
```
