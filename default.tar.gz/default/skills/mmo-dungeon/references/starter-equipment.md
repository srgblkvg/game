# Starter Equipment — `equipment` column, NOT `equipment_1`

## Problem

Starter equipment was inserted into `equipment_1` column during registration, but the active `equipment` column was left NULL. When the player equipped a new item from inventory, the equipment system wrote to `equipment`, creating a fresh object with only the new item — overwriting the single-slot reference. On subsequent set switches, the original starter items (in `equipment_1`) would be lost.

**Root cause:** `INSERT INTO users (... equipment_1) VALUES (... eqObj)` — only `equipment_1`, not `equipment`.

**Symptom:** «после надевания других вещей экипировка обнуляется» — starter items disappear after equipping new gear.

## Fix

Change ALL registration INSERTs to use `equipment` (NOT `equipment_1`):

```typescript
// ❌ OLD — starter items only in equipment_1, equipment is NULL
INSERT INTO users (..., equipment_1) VALUES (..., $eqObj)

// ✅ NEW — starter items in equipment (active slot)
INSERT INTO users (..., equipment) VALUES (..., $eqObj)
```

**Files changed:**
- `server/src/routes/auth.ts` — email registration + guest registration (2 INSERTs)
- `server/src/routes/oauth.ts` — OAuth registration
- `server/src/routes/vkBridgeAuth.ts` — VK Bridge registration

## Why `equipment` not `equipment_1`?

`buildPlayerStats()` reads from the active slot first, then falls back to `equipment`:

```typescript
const equipKey = `equipment_${activeSlot}`;
let equip = parseEq(userRow[equipKey]);
if (Object.keys(equip).length === 0) equip = parseEq(userRow.equipment);
```

With `equipment` populated, the fallback works correctly. `equipment_1/2/3` are for saved sets (switch-equip), empty by default.

## Migration for existing players

Players who registered before the fix have `equipment_1` populated but `equipment` empty. Run:

```sql
UPDATE users SET equipment = equipment_1
WHERE (equipment IS NULL OR equipment::text = '{}' OR equipment::text = 'null')
  AND equipment_1 IS NOT NULL AND equipment_1::text != '{}';
```

This copies starter items from `equipment_1` to `equipment` for all affected users (180 users on production as of 2026-08-09).
