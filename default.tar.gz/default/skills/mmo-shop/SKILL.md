---
name: mmo-shop
description: MMO Arena daily shop — random offers, stones, money modal.
category: software-development
---

# MMO Arena — Shop System

## Overview
Daily randomized personal shop. Each player gets 10 offers per day. Server: `routes/shop.ts`, Client: `pages/ShopPage.tsx`, `components/NoMoneyModal.tsx`.

## Tables
- `shop_offers(user_id, item_id, item_type, quantity, date, rarity_id)` — unique on `(user_id, date, item_id, item_type)`
- `shop_purchases(user_id, offer_id, date)` — unique on `(user_id, offer_id, date)`
- **Always GRANT after CREATE:** `GRANT ALL ON shop_offers TO game; GRANT ALL ON SEQUENCE shop_offers_id_seq TO game;`

## Mechanics
- 1st slot: **Камень улучшения (Хлам)** ×1/×3/×5 (random), `craft_items.id=8`, price 2000/шт
- 9 slots: weighted random items. No sets (`extra NOT LIKE '%"set"%'`), no artifacts (`rarity_id != 7`)
- All items `sellable = true` — if not, UPDATE first (189 items, 27 per rarity)
- Weights: Хлам 40%, Обычный 25%, Необычный 15%, Редкий 10%, Эпик 5%, Лег 3%, Мифик 2%
- One purchase per offer per day per player

## Generation (`generateDailyOffers(userId)`)
1. Check existing for today + userId → skip if already have
2. Single DB query: `SELECT id, rarity_id FROM items WHERE sellable=true AND rarity_id!=7 AND extra NOT LIKE '%"set"%'`
3. Group by `byRarity` Map, pick weighted random from pools
4. Safety counter: `while (offers.length < 10 && safety < 1000)`
5. INSERT all with `user_id`

## Item Prices (from `items.cost` column)
| Rarity | Mult | Range |
|---|---|---|
| 0 Хлам | ×1 | 7-12 |
| 1 Обычный | ×1.5 | 45-68 |
| 2 Необычный | ×2 | 200-280 |
| 3 Редкий | ×3 | 840-1,080 |
| 4 Эпический | ×5 | 3,500-4,250 |
| 5 Легендарный | ×6 | 13,200-16,800 |
| 6 Мифический | ×7 | 49,000-57,400 |

To change prices: `UPDATE items SET cost = cost * N WHERE rarity_id = X;`

## Client
- `ShopPage.tsx` — fetches `GET /api/shop`, cards with `ItemStats` for items, custom render for stones
- Timer until next refresh: `getNextRefreshTime()` returns UTC midnight unix

## NoMoneyModal
- Global component in `App.tsx`
- `ToastContext.showToast` intercepts "недостаточно" + money keywords → `CustomEvent('noMoney')`
- Modal: earning tips + "💎 Купить" → `navigate('/bank?tab=exchange')`
- `BankPage` uses `useSearchParams` to read `?tab=exchange`

## Server Error Messages
All insufficient-money errors include amounts: `Недостаточно серебра. Нужно X, есть Y`
Files: shop, bank, casino, auction, inventory, craft, massacre, arena

## Auction Price Floor
Min listing prices per rarity in `routes/auction.ts` (`priceFloor`):
| Rarity | Floor |
|---|---|
| 0 Хлам | 5 |
| 1 Обычный | 20 |
| 2 Необычный | 100 |
| 3 Редкий | 400 |
| 4 Эпический | 1,500 |
| 5 Легендарный | 6,000 |
| 6 Мифический | 20,000 |

Update these when shop prices change — roughly half the minimum shop price.
