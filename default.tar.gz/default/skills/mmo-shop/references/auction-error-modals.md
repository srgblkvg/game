# Auction Error Modals

## Money errors → NoMoneyModal
Use existing showNoMoney() for "Недостаточно серебра" errors. Import from NoMoneyModal.tsx.
The modal shows earning tips + "Купить серебро" button → /bank?tab=exchange.

## "Максимум лотов" → custom modal with premium button
For max-lot errors, use a centered modal with:
- "Закрыть" button
- "⭐ Премиум (+10 слотов)" button (only if premium is not active) → /premium

Implementation: local centerModal state + inline JSX, not global event.

## Pattern in catch blocks
```ts
} catch (e: any) {
    const msg = e.message || '';
    if (msg.includes('Недостаточно')) showNoMoney(msg);
    else if (msg.includes('Максимум')) setCenterModal(msg);
    else setError(msg);
}
```

## Auction lot limits
Base: 10 slots. Premium: 20 slots. Server checks premiumUntil, client reads character.premium.
