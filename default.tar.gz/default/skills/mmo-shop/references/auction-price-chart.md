# Auction Price History Chart

## Overview
Price history line chart for each auction item using Chart.js. Server endpoint + client component with lazy loading.

## Server: GET /api/auction/price-history
Params: name, slot, rarity, upgradeLevel
Queries auction_history, groups by day (30 days), returns avg/min/max price per day.
Uses COALESCE for slot (NULL→'') and upgradeLevel (NULL→0) to handle materials/stones.

## Client: PriceChart component
- Chart.js + react-chartjs-2 (lightweight)
- Lazy loading: shows "📈 История цен" button, fetches on click
- Three lines: avg (yellow fill), min (green dashed), max (red dashed)
- Y-axis: compact labels (1.5k, 2.3M instead of formatMoney)
- X-axis: DD.MM format (slice(0,10).split('-') because PG DATE() returns ISO)
- Resets state on item change via itemKey in useEffect
- Height: 120px, dark theme colors

## Key pitfalls
- PG DATE() returns full ISO timestamp → slice(0,10) before splitting
- JSONB slot field is NULL for materials → COALESCE(..., '') in WHERE
- Component must reset cached points when item changes (useEffect on itemKey)
- Upgrade level must be included in all keys/queries for correct grouping
