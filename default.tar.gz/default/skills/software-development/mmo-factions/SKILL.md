---
name: mmo-factions
description: Faction mechanics — battle bonuses, karma, craft/job bonus.
---

# MMO Arena — Factions (Фракции)

## Overview
Три фракции: Бандиты (bandit), Ремесленники (crafter), Стражники (guard).
Выбор с 5 уровня. Первый выбор бесплатный, смена — 10 000 серебра.
**Очки фракции (карьера, репутация, опыт) при смене СОХРАНЯЮТСЯ.**
**КД смены — 7 дней** (колонка `faction_changed_at`).

## DB Schema
```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS faction TEXT DEFAULT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS karma INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS faction_craft_count INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS bandit_reputation INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS faction_changed_at INTEGER DEFAULT 0;
```

## API
- `GET /api/faction` — factions list, current faction, canChoose, changeCost, canChange, memberCounts, changeCooldownSec, factionChangedAt
- `POST /api/faction/choose` — first pick (free, requires no existing faction, sets faction_changed_at)
- `POST /api/faction/change` — change faction (10k, **НЕ сбрасывает очки**, КД 7 дней через faction_changed_at)

## Faction bonuses

### Бандиты (bandit)
- +10% к основным характеристикам против Ремесленников в PvP
- Диапазон атак ±4 уровня (вместо ±2)
- Репутация: +1 за каждую победу в PvP
- +1% дополнительного награбленного серебра за каждые 100 очков репутации
- Кулдаун между атаками в PvP уменьшен в два раза

### Ремесленники (crafter)
- +10% базовый бонус к шансу создания/улучшения
- +1% за каждые 100 успешных созданных и улучшенных предметов
- Опыт идёт только если ИТОГОВЫЙ шанс (базовый + бонус фракции + камень) < 80%
- Шанс ≥ 80% → опыт НЕ начисляется («без опыта»)
- ×2 награда за работы

### Стражники (guard)
- +10% к основным характеристикам против Бандитов в PvP
- +10% к основным характеристикам в PvE (против мобов)
- Карма: старт 0, диапазон -100…+100
- +1 карма за победу над Бандитом (PvP) или монстром (PvE), -1 за победу над мирным игроком
- Жалование: +1% за каждое очко кармы (karma=-100 → 0%, karma=0 → 100%, karma=+100 → 200%)

## Implementation points

### Battle bonus (server/src/routes/battle.ts)
Применяется к `attackerData.base` перед вызовом `runBattle`:
```typescript
if (attacker.faction === 'bandit' && defender.faction === 'crafter') { ... ×1.10 }
if (attacker.faction === 'guard' && defender.faction === 'bandit') { ... ×1.10 }
```

### Bandit reputation (server/src/routes/battle.ts)
После определения победителя (и в mercy, и в обычном бою):
```typescript
if (winnerFaction === 'bandit') {
    await db.run('UPDATE users SET bandit_reputation = bandit_reputation + 1 WHERE id = ?', [winnerId]);
}
```
Бонус к деньгам (применяется к moneyStolen сразу после runBattle/mercy):
```typescript
const rep = attacker.bandit_reputation || 0;
if (attacker.faction === 'bandit' && rep > 0) {
    moneyStolen = Math.floor(moneyStolen * (1 + Math.floor(rep / 100) / 100));
}
```

### Bandit cooldown (server/src/routes/battle.ts)
```typescript
let attackCooldown = hasPremium ? 300 : 600;
if (attacker.faction === 'bandit') attackCooldown = Math.floor(attackCooldown / 2);
```

### Karma update (server/src/routes/battle.ts)
```typescript
if (winnerFaction === 'guard') {
    const karmaChange = loserFaction === 'bandit' ? 1 : -1;
    await db.run('UPDATE users SET karma = GREATEST(-100, LEAST(100, karma + ?)) WHERE id = ?', [karmaChange, winnerId]);
}
```

### PvE karma (server/src/routes/mobs.ts)
После победы над мобом:
```typescript
if (playerWon && user.faction === 'guard') {
    await db.run('UPDATE users SET karma = GREATEST(-100, LEAST(100, karma + 1)) WHERE id = ?', [userId]);
}
```

### PvE guard bonus (server/src/routes/mobs.ts)
```typescript
if (user.faction === 'guard') {
    const mult = 1.10;
    userStats.s = Math.round(userStats.s * mult);
    userStats.a = Math.round(userStats.a * mult);
    userStats.d = Math.round(userStats.d * mult);
    userStats.m = Math.round(userStats.m * mult);
    userStats.hp = Math.round(userStats.hp * mult);
}
```

### Craft bonus (server/src/routes/craft.ts)
Создание и улучшение:
```typescript
const craftBonus = user.faction === 'crafter' ? 10 + Math.floor((user.faction_craft_count || 0) / 100) : 0;
const chance = (recipe.success_chance ?? 100) + craftBonus;
// ...
const finalChance = Math.min(100, chance + stoneBonus + factionBonus);
```

**Порог 80% для опыта фракции:** опыт начисляется только если `chance < 80` (крафт) или `finalChance < 80` (улучшение). Если шанс ≥ 80% — опыт НЕ идёт.
```typescript
// Для крафта (используем chance):
const factionInc = (user.faction === 'crafter' && chance < 80)
    ? ', faction_craft_count = faction_craft_count + 1' : '';
// Для улучшения (используем finalChance):
const upgradeFactionInc = (user.faction === 'crafter' && finalChance < 80)
    ? ', faction_craft_count = faction_craft_count + 1' : '';
await db.run(`UPDATE users SET ...${factionInc} WHERE id = ?`, [...]);
```
Затрагивает три UPDATE-запроса: крафт, улучшение+рейтинг, улучшение без рейтинга.

### Job bonus (server/src/routes/jobs.ts)
```typescript
if (user.faction === 'crafter') { reward = reward * 2; }
```

### Salary bonus (server/src/schedulers/salary.ts)
```typescript
if (u.faction === 'guard') {
    const mult = 1 + (u.karma || 0) / 100;
    baseAmount = Math.max(0, Math.round(baseAmount * mult));
}
```

## Client display

### Страница `/faction` (FactionPage.tsx)
- Диаграмма участников фракций (горизонтальный бар) над карточками выбора
- Выбор фракции или просмотр текущей + кнопки смены
- Бандиты: «Репутация: N» + «+1 за победу в PvP. Каждые 100 очков дают +1% к награбленному серебру.»
- Ремесленники: «Ремесленный опыт: N» + «+1% к шансу за каждые 100 успешных крафтов и улучшений»
- Стражники: прогресс-бар кармы + «+1 за победу над Бандитом или мобом, -1 за мирных. Карма влияет на жалование: от -100% до +100%.»
- Предупреждение при смене: «очки фракции сохранятся. КД смены — 7 дней»
- При активном КД: кнопки заблокированы, «⏳ Смена будет доступна через N дн.»
- **Модалка подтверждения** перед сменой: «ℹ️ Информация: очки сохраняются, повторная смена через 7 дней», кнопки «Отмена»/«Сменить фракцию» (danger). Стейт `changeTarget`.
- Топ-5 игроков фракции по репутации/опыту/карме (см. `references/faction-top5.md`)

### Замок (CastlePage.tsx)
- Диаграмма участников под заголовком «Фракция»
- Карточка текущей фракции с полным описанием или «Выберите фракцию»

### Хедер (Header.tsx)
- Фракция в правом верхнем углу первой строки
- Нет фракции: «Фракция: Отсутствует» (ссылка на /faction)
- Бандиты: «Репутация: N»
- Ремесленники: «Опыт: N»
- Стражники: «Карма: ±N» (всегда, включая 0)

### Рейтинг (RatingPage.tsx)
- Иконки фракций рядом с ником: капюшон/наковальня/щит (game-icons:hood/anvil/shield) с соответствующими цветами

### Иконка фракции у ника (везде)
Единый паттерн для показа иконки фракции рядом с ником игрока. Добавлять во ВСЕ места где показывается username:

```tsx
const FACTION_ICON: Record<string, string> = { bandit: 'game-icons:hood', crafter: 'game-icons:anvil', guard: 'game-icons:shield' };
const FACTION_COLOR: Record<string, string> = { bandit: 'text-red-300', crafter: 'text-blue-300', guard: 'text-yellow-300' };

// Рядом с ником:
{char.faction && FACTION_ICON[char.faction] && (
  <Icon icon={FACTION_ICON[char.faction]} width="12" height="12" className={`inline-block mr-0.5 ${FACTION_COLOR[char.faction]}`} />
)}
```

**Где применено:**
- `PlayerBadge.tsx` — проп `faction`, иконка перед username
- `CharacterCard.tsx` — поле `faction` в `CharacterCardData`, иконка перед username
- `Top3Podium.tsx` — поле `faction` в интерфейсе `Player`, иконка перед username
- `RatingPage.tsx` — иконки вместо текстовых бейджей Б/Р/С

**При добавлении новой иконки:**
1. Добавить поле `faction?: string | null` в интерфейс данных (Player, CharacterCardData)
2. Импортировать `Icon` из `@iconify/react`
3. Добавить константы FACTION_ICON/FACTION_COLOR или использовать существующие из PlayerBadge
4. Вставить иконку перед `{username}`

### Верстак (CraftPage.tsx)
- `(+N% фракция)` в шансе создания и улучшения (ремесленники)
- N = 10 + floor(factionCraftCount / 100)
- Подсказка: `+1 опыт` (зелёный) если итоговый шанс < 80%, `(без опыта)` (серый) если шанс ≥ 80%

## Full descriptions (везде одинаковые, без сокращений и сленга)
- **Бандиты**: +10% к основным характеристикам против Ремесленников. Атаки ±4 уровня. +1% дополнительного награбленного серебра за каждые 100 побед в PvP. Кулдаун между атаками в PvP уменьшен в два раза.
- **Ремесленники**: +10% шанс создания/улучшения +1% за 100 успешных созданных и улучшенных предметов. +100% награда за работы.
- **Стражники**: +10% к основным характеристикам против Бандитов и в PvE. Карма: +1 за победу над бандитом или монстром, -1 за победу над мирным игроком. +1% к жалованию за очко кармы.

## Fields in character/me
```typescript
faction: user.faction || null,
karma: user.karma || 0,
factionCraftCount: user.faction_craft_count || 0,
banditReputation: user.bandit_reputation || 0,
pvpCdSec: ((user.premiumUntil || 0) > now ? 300 : 600) / (user.faction === 'bandit' ? 2 : 1),
pveCdSec: (user.premiumUntil || 0) > now ? 150 : 300,
```

## Real-time updates via serverTick (WebSocket)

Очки фракций (bandit_reputation, faction_craft_count, karma) обновляются в БД на сервере при каждом действии (бой, крафт, PvE). Чтобы клиент видел изменения **без перезагрузки страницы**, они передаются через WebSocket serverTick.

### Сервер (websocket.ts)

В SELECT-запросе serverTick добавлены поля фракции:
```typescript
u.faction, u.karma, u.faction_craft_count, u.bandit_reputation
```

В payload для каждого пользователя:
```typescript
payload.faction = stats.faction || null;
payload.karma = stats.karma || 0;
payload.factionCraftCount = stats.faction_craft_count || 0;
payload.banditReputation = stats.bandit_reputation || 0;
```

### Клиент (ChatContext.tsx → GameContext.tsx)

ChatContext при получении serverTick с полями фракции диспатчит событие `factionStats`:
```typescript
window.dispatchEvent(new CustomEvent('factionStats', {
  detail: { faction, karma, factionCraftCount, banditReputation }
}));
```

GameContext слушает `factionStats` и обновляет character через setCharacter:
```typescript
window.addEventListener('factionStats', handler);
// handler:
setCharacter(prev => ({
  ...prev,
  faction: faction ?? prev.faction,
  karma: karma ?? prev.karma,
  factionCraftCount: factionCraftCount ?? prev.factionCraftCount,
  banditReputation: banditReputation ?? prev.banditReputation,
}));
```

**Результат:** после боя/крафта/убийства моба очки фракции в хедере, на странице фракций и в верстаке обновляются в течение ~1 секунды (следующий serverTick), без перезагрузки страницы.

## Pitfalls
- При добавлении бонуса всегда обновляй info-эндпоинт, чтобы клиент видел актуальную цифру
- **Очки фракции НЕ сбрасываются при смене** — только faction_changed_at обновляется для КД
- `USER_BATTLE_FIELDS` и `USER_ARENA_FIELDS_GUILD` должны включать `u.faction`, `u.bandit_reputation`
- `character/me` должен возвращать `faction`, `karma`, `factionCraftCount`, `banditReputation`
- При изменении диапазона — менять battle.ts + arena.ts + RatingPage
- `applyHpRegen` должен вызываться перед боем PvE (mobs.ts), иначе HP всегда полное
- `pveCdSec` обязательно слать из character/me, иначе клиент берёт 300 по умолчанию

## Related
- `references/faction-top5.md` — топ-5 фракции
- `references/battle-analysis.md` — методика анализа боя: расчёт шансов, проверка сет-бонусов, gotchas
