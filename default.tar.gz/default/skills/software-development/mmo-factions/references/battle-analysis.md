# Battle Analysis Methodology

## Step-by-step

1. **Get equipment** from production DB:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT id, username, equipment FROM users WHERE id IN (...);\""
```

2. **Get battle steps:**
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT id, steps FROM battles WHERE id IN (...);\""
```

3. **Sum extra stats** from all 10 equipment slots, then apply set multipliers:
   - Буревестник 4/4: `extra.dodge = Math.round(extra.dodge * 1.2)`
   - Страж 2/4: `extra.fullBlock = Math.round(extra.fullBlock * 1.1)`
   - etc. (see `game/stats.ts` ~line 160)

4. **Compute chances** using combat stats from steps[0]:
```
dodge  = A_def/(A_def+500) * (1 - M_atk/(M_atk+250)) / 1.5 + extraDodge/(extraDodge+300) + luckBoost/100
crit   = min(0.8, M/(M+500)/1.5 + extraCrit/(extraCrit+300)) + luckBoost/100
block  = min(0.75, D/(D+500)/1.5 + extraFullBlock/(extraFullBlock+300))
fullBlock = extraFullBlock / (extraFullBlock + 300)   // independent check
counter= min(0.5, defSum/totalSum * 0.5/1.5 + extraCounter/(extraCounter+300)) + luckBoost/100
```

5. **Compare** expected vs actual by counting event types in steps array.

## Set Slot Matrix

| Set | weapon1 | shield | helmet | chest | gloves | boots | amulet | ring | belt |
|---|---|---|---|---|---|---|---|---|---|
| Буревестник | | | ✓ | | ✓ | ✓ | ✓ | | |
| Гладиатор | ✓ | ✓ | ✓ | | | | ✓ | | |
| Берсерк | ✓ | | | | ✓ | ✓ | | | ✓ |
| Страж | | ✓ | ✓ | ✓ | | | | ✓ | |
| Крушитель | ✓ | ✓ | | | ✓ | | | | ✓ |
| Жнец | ✓ | | | ✓ | ✓ | | | | ✓ |
| Дуэлянт | ✓ | ✓ | | | | | ✓ | ✓ | |
| Отшельник | | | ✓ | ✓ | | ✓ | | ✓ | |

Impossible: Буревестник 4 + Гладиатор 4 (helmet+amulet conflict).

## Key gotchas

- **Буревестник 4/4**: `extra.dodge * 1.2`, NOT +20pp to chance. 62→74 raw: 19.8% from extra.
- **Luck (Подкова удачи)**: `luckBoost/100` = flat +pp to ALL chances.
- **fullBlock is independent**: checked BEFORE block in runTurn.
- **Counter triggers after dodge**: no dodge → no counter. CounterOnHit triggers on damage.
- **Curse adds stats**, never subtracts.
- **Страж 3pc**: all stats ×1.15 including HP.

## Dodge formula history

- **Before Aug 03, 2026**: `atkW/(atkW+500)` — M penalty too weak
- **After Aug 03, 2026**: `atkW/(atkW+250)` — M effectively counters dodge

At M=1351 vs A=623 + extraDodge=42: 22.3%→16.4% dodge.
