# Faction top-5 leaderboard

## Server endpoint
`GET /api/faction/top/:faction` — returns top 5 players of the faction ordered by their faction stat:

```typescript
router.get('/faction/top/:faction', async (req, res) => {
    const { faction } = req.params;
    if (!['bandit', 'crafter', 'guard'].includes(faction)) {
        return res.status(400).json({ error: 'Неверная фракция' });
    }
    const sortField = faction === 'bandit' ? 'bandit_reputation'
        : faction === 'crafter' ? 'faction_craft_count' : 'karma';
    const users = await db.query(
        `SELECT id, username, level, ${sortField} as value FROM users
         WHERE faction = ? ORDER BY ${sortField} DESC LIMIT 5`,
        [faction]
    );
    res.json({ users: users.map(u => ({ id: u.id, username: u.username, level: u.level, value: u.value || 0 })) });
});
```

## Client display (FactionPage.tsx)
Fetches when `data?.current` changes:
```tsx
const [topUsers, setTopUsers] = useState<any[]>([]);

useEffect(() => {
    if (data?.current) {
        fetch(`/api/faction/top/${data.current}`, { headers: getHeaders() })
            .then(r => r.json()).then(d => setTopUsers(d.users || []));
    }
}, [data?.current]);
```

Renders below the user's own faction stats:
```tsx
{topUsers.length > 0 && (
    <div className="mt-2 pt-2 border-t border-[var(--color-border-light)]">
        <p className="text-xs font-bold mb-1">
            {currentFaction === 'bandit' ? '🏆 Репутация' :
             currentFaction === 'crafter' ? '🏆 Ремесленный опыт' : '🏆 Карма'}
        </p>
        {topUsers.map((u, i) => (
            <div key={u.id} className="flex justify-between text-[0.6rem] py-0.5">
                <span>{i + 1}. {u.username} [{u.level}]</span>
                <span className="font-bold">{u.value?.toLocaleString()}</span>
            </div>
        ))}
    </div>
)}
```
