---
name: mmo-donat
description: Donat/payments system for MMO Arena — VK Payments + YooKassa integration, starter packs, silver exchange, delivery pipeline.
version: 1.0.0
---

# MMO Arena — Donat System

Payments system with two providers (VK Payments, YooKassa) converging on shared delivery functions. Trigger: any task involving donat items, starter packs, silver exchange, or payment callbacks.

## Architecture

```
vkPayments.ts ──→ donate.ts ──→ DB + WS notify
yukassa.ts    ──→ donate.ts ──→ DB + WS notify
```

## Files

| File | Role |
|------|------|
| `server/src/routes/donate.ts` | Delivery functions (`deliverStarterPack`, `deliverSilver`) + preview/status endpoints |
| `server/src/routes/vkPayments.ts` | VK Payments callback: `get_item` + `order_status_change` |
| `server/src/routes/yukassa.ts` | YooKassa: `create-payment` + webhook |
| `client/src/pages/StarterPackPage.tsx` | Starter pack product page |
| `client/src/pages/BankPage.tsx` | Exchange tab (silver for money) |
| `client/src/pages/ShopPage.tsx` | Banner for starter pack |

## Adding a new donat item

### 1. Add to both item registries

In `vkPayments.ts` ITEMS:
```typescript
new_item: { title: 'Название', price: 7, type: 'premium' | 'starter_pack' | 'silver', days?: N, amount?: N }
```

In `yukassa.ts` ITEMS:
```typescript
new_item: { title: 'Название', price: 49, type: 'premium' | 'starter_pack' | 'silver', days?: N, silverAmount?: N }
```

### 2. Add delivery logic

In `vkPayments.ts` order_status_change handler, add a branch for the new type. For simple items, route to `deliverSilver()` or add a new function in `donate.ts`.

In `yukassa.ts` `processDelivery()` function, add a branch.

### 3. Add VK app item

In the VK app admin panel, add the item with matching `item_id` and price in голосах.

### 4. Add client UI (if needed)

Purchase flow:
- **VK:** `window.vkBridge.send('VKWebAppShowOrderBox', { type: 'item', item: 'item_name' })`
- **Browser:** `POST /api/yukassa/create-payment { item: 'item_name' }` → redirect to `confirmation_url`

Listen for confirmation: `window.addEventListener('paymentStatus', handler)`.

## Starter Pack (one-time)

Composition: 9 common items (one per slot: weapon1, shield, helmet, chest, gloves, boots, amulet, ring, belt) + 4× Фрагмент ужаса + 1000 silver + 7 days premium. Price: 14 голосов / 99₽.

Delivery function `deliverStarterPack(userId)`:
1. Check `starter_pack_purchased` column (boolean, default false)
2. Query `items WHERE rarity_id=1` — one per slot
3. Query `craft_items WHERE name='Фрагмент ужаса'` — 4 copies
4. Add to inventory, add 1000 money, extend premiumUntil by 7 days
5. Set `starter_pack_purchased = true`
6. Send WS `paymentStatus`

Preview endpoint: `GET /api/donate/starter-pack/preview` returns equipment + fragment data with images.

## Silver Exchange

Items: `silver_1000` (7гол/49₽), `silver_5000` (14гол/99₽), `silver_10000` (28гол/199₽).

Delivery: `deliverSilver(userId, amount)` — `UPDATE users SET money = money + ?`.

## DB

- `users.starter_pack_purchased` BOOLEAN DEFAULT false
- `vk_payments` — order log
- `yukassa_payments` — order log (+ `item` column for new item types)

### Pitfall: ALTER TABLE in module top-level

`db.run('ALTER TABLE ADD COLUMN IF NOT EXISTS').catch(() => {})` at module scope silently fails during OOM restart cycles. Always verify:

```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT column_name FROM information_schema.columns WHERE table_name='users' AND column_name='starter_pack_purchased';\""
```

Run manually if missing.

## Client Tooltips on Product Pages

For item grids with hover tooltips, use `ItemStats` + `createPortal`:

```tsx
const [tooltip, setTooltip] = useState<{item:any; x:number; y:number}|null>(null);

const showTooltip = useCallback((item, e) => {
  const rect = e.target.getBoundingClientRect();
  setTooltip({ item, x: rect.left + rect.width/2, y: rect.top });
}, []);

// In JSX:
onMouseEnter={e => showTooltip(item, e)}
onMouseLeave={() => setTooltip(null)}

// Portal at end of component:
{tooltip && createPortal(
  <div ref={tooltipRef} className="fixed ... z-[99999] pointer-events-none ...">
    <ItemStats item={tooltip.item} imageSize={36} />
  </div>,
  document.body
)}
```

## Platform Detection

- VK: `localStorage.getItem('isVK') === '1'` or `document.documentElement.classList.contains('vk-iframe')`
- Browser: all others → YooKassa

## WS Confirmation

Server: `sendToUser(userId, { type: 'paymentStatus', status: 'success', platform, until? })`
Client: `ChatContext` dispatches `new CustomEvent('paymentStatus')`. Purchase pages listen for UI update.
