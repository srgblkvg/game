# Curse System — Full Reference

## Server: `server/src/routes/craft.ts`

### CURSE_RANKS (current weights)
```typescript
const CURSE_RANKS = [
    { rank: 1, name: 'I', color: '#22c55e', min: 10, max: 20, weight: 160 },  // 80%
    { rank: 2, name: 'II', color: '#3b82f6', min: 20, max: 30, weight: 24 },  // 12%
    { rank: 3, name: 'III', color: '#a855f7', min: 30, max: 40, weight: 12 }, // 6%
    { rank: 4, name: 'IV', color: '#f97316', min: 40, max: 50, weight: 3 },   // 1.5%
    { rank: 5, name: 'V', color: '#ef4444', min: 50, max: 60, weight: 1 },     // 0.5%
];
```

### Flow
1. `POST /craft/curse { itemId }` — rolls curse, returns `{ oldCurse, newCurse, needsConfirm }`, NO consumption
2. If `needsConfirm`: client dialog (Оставить/Заменить)
3. `POST /craft/curse/apply { itemId, crystalId, curse }` — consumes crystal + 100k, applies

### GameItem fields added
```
curseStat?: string;   // 's'|'a'|'d'|'m'
curseValue?: number;  // 10-60
curseRank?: number;   // 1-5
curseName?: string;   // 'I'-'V'
curseColor?: string;  // rank color hex
```

### Stats integration (`server/src/game/stats.ts`)
In `currentStats()`, after processing bonuses/extra:
```typescript
if (item.curseStat && item.curseValue && PRIMARY_STATS.includes(item.curseStat)) {
    sums[item.curseStat] += item.curseValue;  // NOT scaled by upgradeLevel
}
```

## Client

### CraftPage.tsx
- `curseInfo` state: set when slots have 1 equipment + 1 soul_crystal
- `handleCurse`: calls preview → if needsConfirm shows dialog → applyCurse on confirm
- `curseConfirm` state: `{ oldCurse, newCurse }` for dialog display
- Button disabled when `(character?.money || 0) < 100000`
- Info block shows: current curse, rank legend with colors, cost

### ItemStats.tsx
After upgrade level display:
```tsx
{item.curseStat && item.curseValue > 0 && (
  <div style={{ color: item.curseColor }}>
    ☠ Проклятие {item.curseName}: +{item.curseValue} к {statNameRu[item.curseStat]}
  </div>
)}
```

### Inventory.tsx
`typeLocalization['soul_crystal'] = 'Улучшение'`

### itemUtils.ts
`typeNameRu['soul_crystal'] = 'Улучшение'`

## DB\n- `craft_items`: id=23, name='Кристалл душ', type='soul_crystal', rarity_id=6\n- `items.bonuses` and `items.extra` are **TEXT** columns — must JSON.parse when reading\n- `overflow_storage.item` is jsonb — store as proper JSON objects

## Donate Packs — Сундуки за деньги

### Server-side
- `server/src/routes/yukassa.ts` — ITEMS map + `deliverCursePack` in processDelivery
- `server/src/routes/vkPayments.ts` — ITEMS map + `deliverCursePack` in processCallback
- `server/src/routes/donate.ts` — `deliverCursePack(userId, packType)` adds silver + crystals

| Pack key | Состав | YooKassa | VK голоса |
|----------|--------|----------|-----------|
| curse_small | 500k + 5 Кристаллов душ | 999₽ (type: 'curse_pack') | 144 |
| curse_large | 1M + 10 Кристаллов душ | 1799₽ (type: 'curse_pack') | 258 |

### Client display — Carousel
Packs render as horizontal carousel with absolute-positioned arrow buttons:
```tsx
<div className="relative">
  <button onClick={scroll('left')} className="absolute left-0 top-1/2 -translate-y-1/2 z-10 ...">◀</button>
  <div ref={scrollRef} className="flex gap-3 overflow-x-auto snap-x snap-mandatory scrollbar-none px-4">
    {PACKS.map(p => <div className="flex-shrink-0 w-[220px] snap-start" .../>)}
  </div>
  <button onClick={scroll('right')} className="absolute right-0 top-1/2 -translate-y-1/2 z-10 ...">▶</button>
</div>
```
Scroll: `el.scrollBy({ left: dir === 'left' ? -240 : 240, behavior: 'smooth' })`.

### Double-click guard
All three handlers (handleCreate, handleUpgrade, handleCurse) use `craftingRef` for instant blocking:
```typescript
const craftingRef = useRef(false);
// In handler:
if (craftingRef.current) return;
craftingRef.current = true;
setCrafting(true);
// ... in finally:
craftingRef.current = false;
setCrafting(false);
```
`setCrafting(true)` is async — between click and re-render, button is still active. ref guards instantly.
