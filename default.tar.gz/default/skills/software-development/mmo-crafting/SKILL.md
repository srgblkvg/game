---
name: mmo-crafting
description: Use for craft, upgrade, curse, soul crystals, or ad rewards.
---

# MMO Arena — Crafting, Upgrade & Curse

## Curse System (Проклятие)

### Quick ref — updated 2026-08-01
- **Item:** Кристалл душ (craft_items id=23, type='soul_crystal', rarity_id=6)
- **Drop:** Hell I-IV bosses via MYTHIC_RESOURCE_DROPS (mobs 49, 54-60)
- **Cost:** 100 000 серебра + Кристалл душ — **списывается при нажатии «Проклясть»**, не на «Оставить»/«Заменить»
- **Endpoint:** `POST /craft/curse` (списание + превью) + `POST /craft/curse/apply` (применение, без списаний; `keepOld: true` = оставить старое)
- **Ranks:** `CURSE_RANKS` in `server/src/routes/craft.ts`
- **Stats:** `cursorStat/curseValue` in GameItem, NOT scaled by upgradeLevel, added directly in `currentStats()`
- **Client UI:** CraftPage.tsx — info block + button + confirm dialog (does NOT close on outside click — resources already spent); ItemStats.tsx — tooltip display

### Pitfall: items.bonuses/extra are TEXT columns
When reading items from DB for inventory, MUST `JSON.parse(row.bonuses)` and `JSON.parse(row.extra)`. Double-stringifying breaks tooltips.

### Pitfall: curse confirm dialog must NOT close on outside click
After `POST /craft/curse` (which deducts resources), the dialog shows «Оставить» / «Заменить». Backdrop `onClick` handler that calls `setCurseConfirm(null)` would allow the user to lose the curse result (resources already spent). Remove the backdrop click handler entirely — only buttons close this dialog.
Old drops need migration: find `id=23, type=craft_item, itemType=material` → set `itemType='soul_crystal'`.

## Upgrade Break Condition
- Items break on FAILURE when `targetLevel >= 7` (trying to reach +7, not when already at +7)
- Breaking replaces item with craft material of same rarity, sends `💥` chat announcement
- At +0…+6: no break on fail, just loses stone + money

## Chat Announcements (Глашатай)
- **Upgrade to +7+:** `⚒️ USER улучшил ITEM до +N!` — broadcast `'message'` with `senderId=0, senderName='Глашатай'`
- **Break at +7+:** `💥 USER сломал ITEM (+N) при улучшении!` — same broadcast pattern
- **Pitfall: msg.id must match DB.** Client deduplicates by `id` (`p.some(m => m.id === msg.id)`). WS-сообщение и INSERT в БД должны использовать ОДИН id. Раньше WS генерировал `Date.now()+Math.random()`, а INSERT использовал SERIAL → id разные → клиент видит дубль (одно через WS, второе при загрузке истории из БД). **Правильно:** генерировать `msgId = Date.now()*1000 + Math.floor(Math.random()*1000)`, использовать в `INSERT INTO chat_messages (id, senderId, targetId, content) VALUES (?, 0, NULL, ?)` и в `broadcast('message', { message: { id: msgId, ... } })`.
- `POST /premium/ad` — +1h premium, cd 3600s (PremiumPage)
- `POST /shop/ad-silver` — +1000 silver, cd 300s (BankPage ExchangeTab)
- `POST /tavern/heal-ad` — full heal, cd 300s
- DB: `users.adpremiumat`, `users.adsilverat` (INTEGER)

## Race Condition Prevention
For reward endpoints, atomic UPDATE with WHERE status check BEFORE giving rewards:
```typescript
const result = await db.run(
  "UPDATE daily_quests SET status = 'claimed' WHERE id = ? AND status = 'active'", [id]);
if (result.changes === 0) return res.status(400).json({ error: 'Already claimed' });
```

## Auction — all returns to overflow
- Outbid refund → `overflowmoney`
- Unsold expired → `addToOverflow()`
- Cancel bidder refund → `overflowmoney`
- Cancel item → `addToOverflow()`

## Faction Crafter Bonus (Ремесленник)
- **Base:** +10% к шансу создания и улучшения
- **Прогрессивный:** +1% за каждые 1000 крафтов (`faction_craft_count / 1000`)
- **Счётчик:** `users.faction_craft_count` — инкрементится при КАЖДОМ создании и улучшении (успех и неудача)
- **Сброс:** в 0 при смене фракции (`/api/faction/change`)
- **Сервер:** бонус вычисляется как `10 + Math.floor(faction_craft_count / 1000)`, добавляется к `finalChance` в upgrade и к `chance` в craft creation
- **Info endpoint:** `GET /craft/upgrade-info/:level/:rarity` возвращает `factionBonus` (включая прогрессивный), клиент добавляет к отображаемому шансу
- **Клиент:** CraftPage показывает `(+N% фракция)` в шансе создания и улучшения
- **Pitfall:** когда добавляешь серверный бонус к шансу, всегда обновляй info-эндпоинт чтобы клиент показывал правильную цифру. Без этого игрок видит один шанс, а сервер использует другой.
