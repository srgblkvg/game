---
name: battle-engine
description: Battle engine. Use when changing combat — runBattle/runTurn.
version: 1.0.0
---

# Battle Engine — Shared Architecture

All combat modes use a single shared engine in `server/src/game/battle.ts`:

| Mode | Function | File |
|------|----------|------|
| PvP | `runBattle()` | `routes/battle.ts` |
| PvE | свой цикл через `runTurn()` | `routes/mobs.ts` |
| Guild Boss | свой цикл через `runTurn()` | `routes/guildBoss.ts` |
| Tournaments | `runBattle()` | `routes/tournament.ts` |
| Guild War | `runBattle()` | `routes/guild/guildWar.ts` |
| Massacre | `runTurn()` (per-turn) | `game/massacre.ts` |

**Rule:** ANY new battle effect MUST work through `runBattle`/`runTurn`. Never write separate battle loops.

## Exports

```typescript
export function runBattle(attacker, defender): BattleResult
export function runTurn(ctx: TurnContext, addStep): { hpActor, hpTarget, stunnedTarget, poisonApplied? }
export interface TurnContext {
  actorName, targetName, actorStats, targetStats, actorLevel,
  hpActor, hpTarget, maxHpActor, maxHpTarget, actor, target,
  antiDodge?, antiCrit?, antiBlock?, antiCounter?,
  antiVampiric?, targetAntiVampiric?
}
```

## Effects in runTurn

| Effect | Field | Behavior |
|--------|-------|----------|
| Vampirism | `vampirism` | Heal `dmg * pct/100` |
| Rage | `rageDmg`, `rageThreshold` | +dmg% when HP low |
| Execute | `execute` | Instakill <10% HP |
| BlockPen | `blockPen` | Reduce block |
| CounterOnHit | `counterOnHit` | Counter when receiving dmg |
| PoisonOnHit | `poisonOnHit` | DoT 3 turns |
| AlwaysFirst | `alwaysFirst` | First turn always |
| Luck | `luckBoost` | +% all chances |
| Resilience | `resiliencePct` | -% poison duration, -% stun chance |

## Combat Formulas (stats.ts + battle.ts)

See `references/combat-formulas.md` for full formula reference with caps, stat mappings, and top-player values.

### Dodge balance (2026-08-01)

Changed penalty divisor from `M/(M+100)` to `M/(M+500)`. Old formula made dodge near-zero at high stats (M=1194 → 92% penalty, dodge=3.75%). New: M=1194 → 70% penalty, dodge=14.3%.

Config in `battle.ts:39`:
```typescript
(1 - atkW / (atkW + 500))  // was (atkW + 100)
```

**Denominator tuning reference (2026-08-04):** for A=623, extraDodge=42, M_enemy=1351:

| X | Base dodge | +extra 12.3% | Total |
|---|---:|---:|---:|
| 500 (current) | 10.0% | 22.3% | 22.3% |
| 400 | 8.1% | 20.4% | 20.4% |
| **250** | **4.1%** | **16.4%** | **16.4%** |
| 200 | 2.2% | 14.5% | 14.5% |
| 100 | 0.4% | 12.7% | 12.7% |

X=250 даёт разумный баланс: при равных A=M=500 базовый шанс 11.1%, разрыв в M ощутим, extra dodge всё ещё важен.

### Dodge vs Block — balance asymmetry 🔴

Dodge сильнее block по двум причинам:
1. **Dodge + Counter:** уклонение даёт 0 урона + шанс контратаки полной силой (S). Block только снижает урон, контратаки нет.
2. **CounterOnHit** (Страж 4pc, 30%) срабатывает при получении урона — но только если не было блока/уклонения. То есть даже с блоком ты получаешь урон, но контратака слабее (S*0.5).

При равных extra-статах dodge-сборка почти всегда выигрывает у block-сборки. Рекомендация: стекнуть dodge 30-40+ как минимум.

### Anti-stats (контр-экстра статы) — гильдийские таланты (2026-08-05)

Гильдийские таланты дают контр-статы, снижающие вражеские extra-шансы: Accuracy (↓dodge), Fortitude (↓crit защитника), Penetration (↓block), Control (↓counter), AntiVampiric (↓вампиризм атакующего). 1 уровень = 1% снижения.

**TurnContext поля:**
```typescript
antiDodge?: number;        // снижает dodge цели (атакующий)
antiCrit?: number;         // снижает crit цели при контратаке (атакующий)
antiBlock?: number;        // снижает block цели (атакующий)
antiCounter?: number;      // снижает counter цели (атакующий)
antiVampiric?: number;     // не используется (исторически)
targetAntiVampiric?: number; // снижает вампиризм атакующего (цель)
```

**Где применяются в runTurn (battle.ts):**
- dodge: `Math.max(0, dodgeChance(...) - antiDodge/100)`
- counter-on-dodge: `Math.max(0, counterChance(...) - antiCounter/100)`
- crit цели при контратаке: `Math.max(0, critChance(targetStats) - antiCrit/100)`
- block: `Math.max(0, blockChance(targetStats) - antiBlock/100)`
- vampirism: `vamp = Math.max(0, vamp - targetAntiVampiric)`

**Источник:** `getAntiStats(playerTalents, guildTalents)` → `server/src/game/guildBoss.ts`.
- Личные таланты: `player_guild_talents` (userId + guildId)
- Гильдийские: `guild_talents` (guildId)
- Стоимость уровня: `10 * 2^currentLevel` очков (0→1=10, 1→2=20, 2→3=40, 3→4=80, ...)

**PvP:** оба игрока имеют свои anti-stats, передаваемые через TurnContext при их ходе.

Полная реализация: `references/anti-stats.md`.

## Poison DoT

1. `runTurn` sets `poisonApplied = { damage, turns }` on hit
2. `runBattle` tracks per-player poison state
3. At start of turn: apply damage, decrement turnsLeft
4. Resilience: `Math.max(1, Math.round(3 * (1 - pct/100)))`
5. Stun does NOT block poison ticks

## Resilience

- Stun: `stunChance * (1 - resiliencePct/100)`
- Poison turns: `Math.max(1, round(3 * (1 - pct/100)))`

## Pitfalls

### Express route ordering: `/:id` shadows specific routes (2026-08-05)

When adding a new router with specific paths (`/guild/boss`) alongside an existing router with parameterized paths (`/guild/:id`), the order of `app.use()` matters. If the `:id` router comes first, it catches `/guild/boss` as `:id = "boss"`.

**Fix:** mount specific-path routers BEFORE parameterized-path routers in `setupRoutes.ts`.

**Detection:** curl server directly returns 401/200, but browser shows 404 — the `:id` handler rejects the value or returns 404.

### PvE Mob Effects (2026-08-01)

Mobs can have battle effects (blockPen, vampirism, execute, counterOnHit, poisonOnHit, luckBoost) via a JSON `effects` column. See `references/pve-mob-effects.md`.

### hp1/hp2 swap must include maxHp1/maxHp2

In `runTurn()`, damage steps swap `hp1`/`hp2` based on `ctx.actor` to keep player=hp1, mob=hp2. **`maxHp1`/`maxHp2` must use the SAME swap** — otherwise when mob attacks, maxHp values swap between player and mob:

```typescript
// ✅ CORRECT — maxHp swaps with hp
hp1: ctx.actor === 'attacker' ? hpActor : hpTarget,
hp2: ctx.actor === 'attacker' ? hpTarget : hpActor,
maxHp1: ctx.actor === 'attacker' ? ctx.maxHpActor : ctx.maxHpTarget,
maxHp2: ctx.actor === 'attacker' ? ctx.maxHpTarget : ctx.maxHpActor

// ❌ WRONG — maxHp always actor/target, desynced from hp1/hp2
maxHp1: ctx.maxHpActor, maxHp2: ctx.maxHpTarget
```

Applies to all 4 damage step locations: normal hit, counter-on-dodge, counter-on-hit, poison DoT.

### PvE: mobs.ts addStep overwrites runBattle step fields

`routes/mobs.ts` wraps `runBattle` steps through its own `addStep()` which was unconditionally overwriting `hp1`/`hp2`/`maxHp` with stale closure variables. **Fix:** only set fields that `runBattle` didn't already populate:
```typescript
if (step.hp1 === undefined) step.hp1 = hpUser;
if (step.hp2 === undefined) step.hp2 = hpMob;
if (step.maxHp1 === undefined) step.maxHp1 = maxHpUser;
if (step.maxHp2 === undefined) step.maxHp2 = maxHpMob;
```

### PvE: mobStats.hp uses S+A+M, not actual mob HP from DB

`routes/mobs.ts` computes `mobStats = currentStats(mobBase, {})` which sets `hp = S+A+M` (sum of atk+agi+mst). But mobs have a separate `hp` DB column that overrides this. `runBattle()` uses `statsD.hp` as `maxHpD`, so mob's maxHp in steps is S+A+M instead of the real HP from DB (e.g. 266 vs 720).

**Fix:** override after `currentStats()`:
```typescript
const mobStats = currentStats(mobBase, {});
mobStats.hp = mob.hp; // мобы имеют ручной HP в БД, не S+A+M
```

### PvE client: step.target never equals 'player'

`BestiaryPage.tsx` applies damage with `step.target === 'player'`. But `runTurn()` sets `target` to `'attacker'`/`'defender'`, never `'player'`. In PvE, player = attacker, so condition is always false → all damage goes to mob.

**Fix:** `step.target === 'attacker'` (player is always the attacker in PvE context).

### PvE: mobs.ts ignores runTurn stunnedTarget — нет пропуска хода при оглушении (2026-07-30)

`routes/mobs.ts` имеет СВОЙ боевой цикл (не `runBattle()`), который вызывает `runTurn()` напрямую, но игнорирует `result.stunnedTarget`. Результат: и игрок, и монстр всегда ходят — оглушение не работает.

**Симптом:** после сообщения «оглушён!» цель всё равно атакует на следующем ходу.

**Root cause:** `runTurn()` возвращает `stunnedTarget: true`, но PvE-цикл просто отбрасывает это значение:
```typescript
const result1 = runTurn(ctx1, addStep);
userHp = result1.hpActor;
mobCurrentHp = result1.hpTarget;
// result1.stunnedTarget — IGNORED!
```

`runBattle()` (PvP) отслеживает `stunnedA`/`stunnedD` и перед каждым ходом проверяет — если true, пропускает ход с сообщением «оглушён и пропускает ход». PvE-цикл должен делать то же самое.

**Fix:** добавить `stunnedUser`/`stunnedMob` в PvE-цикл, зеркально `runBattle`:
```typescript
let stunnedUser = false;
let stunnedMob = false;

for (...) {
    // Ход игрока
    if (stunnedUser) {
        addStep({ type: 'stun', actor: 'attacker', message: `... оглушён и пропускает ход` });
        stunnedUser = false;
    } else {
        const result1 = runTurn(ctx1, addStep);
        userHp = result1.hpActor;
        mobCurrentHp = result1.hpTarget;
        stunnedMob = result1.stunnedTarget;
    }

    // Ход моба
    if (stunnedMob) {
        addStep({ type: 'stun', actor: 'defender', message: `... оглушён и пропускает ход` });
        stunnedMob = false;
    } else {
        const result2 = runTurn(ctx2, addStep);
        mobCurrentHp = result2.hpActor;
        userHp = result2.hpTarget;
        stunnedUser = result2.stunnedTarget;
    }
}
```

### Client: BestiaryPage stun animation side reversed (2026-07-26)

**Symptom:** в PvE анимация оглушения на противоположном бойце (моба оглушили → звёзды над игроком).

**Root cause:** `BestiaryPage.tsx` и `useBattleLogic.ts` используют разную логику для стороны `stun`:
```typescript
// useBattleLogic.ts — ПРАВИЛЬНО
const side = step.actor === 'attacker' ? 'left' : 'right';
// BestiaryPage.tsx — БЫЛО (зеркально)
const sSide = step.actor === 'attacker' ? 'right' : 'left';
```
`runTurn()` выставляет `actor` = тот кого оглушили. При зеркальной логике стороны меняются местами.

**Fix:** `BestiaryPage.tsx` → `'left' : 'right'` как в useBattleLogic.

## Testing API

Debug tooltips/API by testing directly on VPS:
```bash
scp test.js root@194.226.142.237:/tmp/
ssh root@194.226.142.237 'cd /opt/game/server && node /tmp/test.js'
```

### PvP: attacker currentHp не регенится перед боем (2026-08-01)

`routes/battle.ts` применял `applyHpRegen` только для защитника, но не для атакующего. Атакующий использовал `attacker.currentHp` напрямую из БД без учёта офлайн-регена.

**Fix:** добавить блок регена для атакующего перед `attackerData` (зеркально защитнику), использовать `attackerCurrentHp`.

### Arena opponent: карточка показывает max HP вместо реального (2026-08-01)

`USER_ARENA_FIELDS_GUILD` не включал поля `currentHp, lastHpUpdate, roomType, roomUntil, premiumUntil`. Без них `routes/arena.ts` использовал `stats.hp` (макс) как fallback. Карточка противника всегда показывала полное HP.

**Fix:** 
1. Добавить HP-поля в `USER_ARENA_FIELDS_GUILD` (db/helpers.ts)
2. Применить `applyHpRegen` к противнику в `routes/arena.ts` перед отправкой `currentHp`

### PvP: money — не давать уйти в минус (2026-07-30)

При проигрыше в PvP снимается `moneyStolen` без проверки `money >= amount`. Если у игрока 0 денег, баланс уходит в -1.

**Fix:** `Math.min(moneyStolen, player.money)` для проигравшего. Затронуты: атакующий (строка 185), защитник (строка 208), mercy (строка 124).

### HP ×2 balance (2026-07-30)

Глобальное увеличение HP в 2 раза — бои длятся 1-3 хода, нужно больше. Изменения:

| Файл | Что | Было | Стало |
|------|-----|------|-------|
| `game/stats.ts:218` | HP игрока | `hp: sumStats(st)` | `hp: sumStats(st) * 2` |
| `routes/mobs.ts:161` | HP мобов (бой) | `mob.hp \|\| 50` | `(mob.hp \|\| 50) * 2` |
| `routes/mobs.ts:128` | HP мобов (бестиарий) | `{ ...m }` | `{ ...m, hp: (m.hp \|\| 50) * 2 }` |
| `game/hpRegen.ts:21` | Базовый реген | `HP_REGEN_SECONDS = 10` | `HP_REGEN_SECONDS = 5` |
| `client/GameContext.tsx:130` | Клиентский реген | `/ 10` | `/ 5` |
| `client/HealthBar.tsx:20,47` | Отображение HP/сек | `* 10`, `/ 10` | `* 5`, `/ 5` |

**Важно:** при изменении базового регена нужно обновить ВСЕ три места (сервер + 2 клиентских), иначе UI показывает старые значения.

### PvP: mercy-блок в battle.ts пропускает гильд-квесты, достижения и markDirty (2026-07-30)

`routes/battle.ts` имеет два пути победы:
1. **Обычный бой** (строка 162): `runBattle()` → в конце вызываются `updateGuildQuestProgress`, `checkAchievement`, `markDirty` (строка 214-220)
2. **Mercy/авто-капитуляция** (строки 97-160): когда атакующий в 2.5× сильнее, бой не проводится, сразу `return res.json(...)`

Mercy-блок делает `return` на строке 140 и **никогда не доходит** до строк 214-220. Результат:
- Гильд-квест PvP не инкрементится
- Достижения `pvp_wins` не триггерятся
- `markDirty(..., 'quests')` не вызывается → ежедневные квесты обновляются только на следующем serverTick (задержка)

**Fix:** добавить в mercy-блок перед `return res.json(...)`:
```typescript
if (attacker.guildId) {
    updateGuildQuestProgress(attacker.guildId, 'pvp').catch(e => console.error('guildQuest PvP mercy:', e.message));
}
checkAchievement(attacker.id, 'pvp_wins').catch(() => {});
if (moneyStolen > 0) trackIncome(attacker.id, moneyStolen).catch(() => {});
markDirty(attacker.id, 'quests');
```

**Симптом:** «если соперник сдаётся, победа в кв не засчитывается» / «засчитывается но с большой задержкой».

### PvE: runBattle money steal applies to PvE (double loss)

`runBattle()` has a built-in money-steal mechanic (lines 344-355): winner steals 10-50% of loser's money. In PvE, mobs have negative IDs (`id: -(mob.id)`), so when the mob wins, it steals money from the player ON TOP of the 10% loss penalty already applied in `mobs.ts` (lines 338-343). Player loses money twice.

**Fix:** skip money steal when either participant is a mob (negative ID):
```typescript
if (attacker.id > 0 && defender.id > 0) {
  // ... steal logic ...
}
```

### Guild Boss (2026-08-05)

See `references/guild-boss-architecture.md` — PvE-style battle loop, boss scaling, random effects, WebSocket real-time HP updates.

### WS message data nesting (2026-08-05)

When dispatching `sendToGuild` messages as CustomEvents, the entire message object `{ type, message, data: {...} }` is passed as `detail`. The client listener receives this full object — the actual payload is in `e.detail.data`, NOT directly on `e.detail`.

```typescript
// ❌ WRONG — bossHp is nested inside data
const d = e.detail;
setBoss(prev => ({ ...prev, currentHp: d.bossHp })); // undefined!

// ✅ CORRECT
const msg = e.detail;
const d = msg.data || msg;
setBoss(prev => ({ ...prev, currentHp: d.bossHp }));
```

### Express route ordering: `/:id` shadows specific routes (2026-08-05)

See `references/elo-display.md` — adding ELO step to battle steps, mercy case, and history summary parsing. **Pitfall:** ELO step must be added BEFORE `INSERT INTO battles`.

### Vampirism heal on HP bars

See `references/vampirism-heal-display.md` — displaying healing on character cards during battle animation (PvP + PvE). **Pitfall:** `playerMaxHp` in `useCallback` closure → use ref instead.
