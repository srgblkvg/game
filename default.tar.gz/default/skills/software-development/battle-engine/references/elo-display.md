# ELO Display in Battle Log & History

## Server: Add ELO step to battle steps

In `routes/battle.ts`, add ELO info as a step BEFORE saving to DB:

```typescript
// ⚠️ MUST be BEFORE INSERT INTO battles
const attackerEloChange = newAttackerElo - (attacker.elo || 1000);
const defenderEloChange = newDefenderElo - (defender.elo || 1000);
result.steps.push({
    type: 'info',
    message: `Рейтинг: ${attackerWon ? attacker.username : defender.username} +${eloChangeWinner}, ${attackerWon ? defender.username : attacker.username} ${eloChangeLoser >= 0 ? '+' : ''}${eloChangeLoser}`
});
```

**Pitfall:** DB row field is `username`, not `name`. Using `attacker.name` → "undefined +0".

## Mercy case

Mercy already has `eloChange` calculated (line 111). Add step to mercy steps array:
```typescript
{ type: 'info', message: `Рейтинг: ${attacker.username} +${eloChange}, ${defender.username} ${-eloChange >= 0 ? '+' : ''}${-eloChange}` },
```

## Client: History summary

In `HistoryPage.tsx`, parse ELO from the last step's message:
```typescript
const steps = typeof data.steps === 'string' ? JSON.parse(data.steps) : (data.steps || []);
const lastStep = steps[steps.length - 1];
if (lastStep?.message?.startsWith('Рейтинг:')) eloInfo = lastStep.message.replace('Рейтинг:', '').trim();
```

Display: `<span className="text-[var(--color-accent-info)] ml-1 text-xs">{eloInfo}</span>`
