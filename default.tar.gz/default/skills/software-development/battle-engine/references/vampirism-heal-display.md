# Vampirism Heal Display on HP Bars

During battle animation, vampirism healing (Вампиризм +N HP) must visually
increase the HP bar on the character card, not just appear in the log text.

## PvP (useBattleLogic.ts)

In `executeStep`, after the stun handler:

```typescript
if (step.type === 'info' && step.message?.includes('Вампиризм')) {
    const match = step.message.match(/\+(\d+) HP/);
    if (match) {
        const heal = parseInt(match[1]);
        // Determine which side: the actor of the PREVIOUS damage step
        if (step.actor === 'attacker' || battleSteps[stepIndex - 1]?.actor === 'attacker') {
            setHpLeft(prev => Math.min(maxHpLeft, prev + heal));
        } else {
            setHpRight(prev => Math.min(maxHpRight, prev + heal));
        }
    }
}
```

## PvE (BestiaryPage.tsx)

In the `nextStep` callback, after the damage handler:

```typescript
if (step.type === 'info' && step.message?.includes('Вампиризм')) {
    const match = step.message.match(/\+(\d+) HP/);
    if (match) {
        setPlayerHp(prev => Math.min(playerMaxHpRef.current, prev + parseInt(match[1])));
    }
}
```

**⚠️ Critical pitfall:** `nextStep` is a `useCallback` with `[scrollLog, stopAuto]` deps.
`playerMaxHp` state is NOT in deps → closure captures initial value (0).
`Math.min(0, prev + heal)` = 0 → HP bar drops to 0 and never recovers.

**Fix:** Use a ref: `playerMaxHpRef.current` updated in `selectFloor` alongside `setPlayerMaxHp`.
