# Guild Boss Battle Architecture

Added 2026-08-05. A new combat mode that reuses `runTurn()` from the shared battle engine.

## Combat Flow

Guild boss uses a PvE-style loop (like `routes/mobs.ts`), NOT `runBattle()`:

```
Player attacks → runTurn(ctx1, addStep) → Boss attacks → runTurn(ctx2, addStep) → repeat
```

This is because:
- The boss has persistent HP across multiple player attacks
- No money-steal mechanic (that's PvP-only)
- Anti-stats need to be passed separately for each side

## Key Files

| File | Purpose |
|------|---------|
| `server/src/game/guildBoss.ts` | Boss stats scaling, effect pool, talent logic |
| `server/src/routes/guildBoss.ts` | API endpoints + battle loop + talent upgrade + ratings |
| `server/src/db/migrations/guildBosses.sql` | DB schema (bosses, talents, member columns) |
| `server/src/db/migrations/guildBossBattles.sql` | Battle history table |
| `client/src/pages/GuildPage.tsx` | Boss tab (4) + Talents tab (5) + ratings + battle log |
| `client/src/contexts/ChatContext.tsx` | WS event dispatch (guildBossUpdate, guildBossKill) |
| `client/src/components/QuestsBlock.tsx` | Right sidebar boss HP (under Гильдия:) |

## Boss Lifecycle

### First spawn
`getOrCreateBoss(guildId)` — creates boss with killCount=0, 100k HP, base stats, respawnAt=0.

### Attack (POST /guild/boss/attack)
1. Cooldown check (1 hour per player via `lastBossAttackAt`)
2. `buildPlayerStats(user, 'pve')` + guard faction bonus + scout_hq guild bonus
3. `getAntiStats()` — anti-stats applied to player's TurnContext
4. PvE battle loop (50 turns max)
5. `damageBoss()` — subtract damage, handle kill
6. +1 personal talent point per attack
7. +1 guild talent point on kill
8. Battle log saved to `guild_boss_battles`
9. `sendToGuild()` broadcasts `guild_boss_update` via WS

### Kill → Respawn
When boss HP reaches 0:
- `respawnAt = now + 300` (5 minutes)
- `currentHp = 0`, `killCount` incremented
- Client shows countdown timer
- On next `getOrCreateBoss()` call when `now >= respawnAt`:
  - New boss spawned with updated killCount
  - Random effects re-rolled via `pickBossEffects(newKillCount)`

## Boss Stats & Scaling

```
BOSS_BASE_HP = 100_000
BOSS_HP_PER_KILL = 50_000
BOSS_STAT_SCALE = 0.10  // +10% per kill
BOSS_BASE_LEVEL = 20
BOSS_LEVEL_PER_KILL = 5
BOSS_COOLDOWN = 3600  // 1 hour per player
BOSS_RESPAWN_DELAY = 300  // 5 minutes
```

Stat formula: `base * (1 + 0.10 * killCount)`
HP formula: `100_000 + 50_000 * killCount`

## Random Effects After Rebirth

12 effects in pool, randomly selected after each kill. Count = `min(killCount, 6)`.
Effects scale with killCount via `buildEffectScaled(eff, killCount)`:
- Binary effects (alwaysFirst, execute) don't scale
- Numeric effects scale by `baseValue * (1 + 0.10 * killCount)`
- Extra stats (dodge, fullBlock, crit) go into `extra` object
- Flat stats (vampirism, poisonOnHit, etc.) applied directly via `Object.assign`

Effects are stored as JSON in `guild_bosses.effects` and flattened via `flattenBossEffects()` before battle.

## Talent System

5 talent types: accuracy, fortitude, penetration, control, vampiric.
1 level = 1% anti-effect (subtracted from enemy's corresponding chance in runTurn).

Cost formula: `10 * 2^currentLevel` (0→1:10, 1→2:20, 2→3:40, 3→4:80, ...)

### Investment Model (1 point per click)

Talents have `progress` column (INTEGER DEFAULT 0). Each click invests 1 point; when `progress >= cost`, level auto-increments and progress resets to 0.

```typescript
// Route: POST /guild/talents/upgrade
const newProgress = currentProgress + 1;  // invest 1 point
if (newProgress >= cost) {
  newLevel = currentLevel + 1;
  progress = 0;  // level up, reset progress
} else {
  progress = newProgress;  // accumulate
}
```

Client shows progress bar: `{progress}/{cost}` with fill animation.

### Permission Model
- Personal talents: any guild member can invest their own points
- Guild talents: only the guild leader can invest guild points

## WebSocket Events

### guild_boss_update
```json
{ "type": "guild_boss_update", "message": "...",
  "data": { "bossHp": 50000, "bossMaxHp": 100000, "bossKilled": false,
            "respawnAt": 0, "guildTalentPoints": 3, "ratingsChanged": true,
            "damageDealt": 12345, "attackerName": "..." } }
```

Client listener pattern:
```typescript
const msg = e.detail;  // entire sendToGuild payload
const d = msg.data || msg;  // actual data nested inside
if (d.bossHp !== undefined) updateBossHp(d.bossHp);
if (d.ratingsChanged) loadBoss();  // refresh all ratings
if (d.guildTalentPoints !== undefined) setGuildPoints(d.guildTalentPoints);
```

## Ratings (5 categories)

`GET /guild/boss/ratings` — all queries aggregate from `guild_boss_battles`:

1. **guildTop** — Top 5 in guild by SUM(damageDealt), JOIN users+guilds for level/guildName
2. **personalTop** — Top 5 globally + player's rank via RANK() OVER
3. **guildTopList** — Top 5 guilds by SUM(damageDealt) + guild's rank via RANK() OVER
4. **topHits** — Top 5 strongest single hits from battle `steps` JSON (`s.type === 'damage'` → `s.damage`)
5. **topGuildKills** — Top 5 guilds by `guild_bosses.killCount`

Client renders each as grid card with clickable names:
- Player name → `navigate(/profile/${userId})`
- Guild name → `navigate(/guild/${name})` in green text
- Format: `username [level] [guildName]` with links

## BossBattleLog Component

Renders battle steps with per-TURN background alternation, using `type === 'attack'` as turn delimiter:

```tsx
let isPlayerTurn = true;
steps.map(s => {
  if (s.type === 'attack') isPlayerTurn = s.actor === 'attacker';
  const bg = isPlayerTurn ? 'bg-secondary' : 'bg-input';
  return <div className={bg}>{effectIcon}{s.message}</div>;
});
```

Effect icons: 💥 crit, 🌀 dodge, 🛡 block, 🛡️ fullBlock, ↩️ counter, 💫 stun.

## Pitfalls

### WS message data nesting
`sendToGuild` payload is `{ type, message, data: {...} }`. ChatContext dispatches the ENTIRE object as CustomEvent.detail. Client must extract `d = msg.data || msg`.

### Express route ordering: `/:id` shadows specific routes
`guildRoutes` has `router.get('/guild/:id', ...)` which matches `/guild/boss`. Must mount `guildBossRoutes` BEFORE `guildRoutes` in `setupRoutes.ts`.

**Detection**: curl to server directly returns 200/401, but browser shows 404 — the `:id` handler is rejecting the parameter.

### Backtick corruption in patch tool
When editing JSX files with template literals (`${...}`), the patch tool may mangle backticks. Use `python3 -c` with binary-safe replacements (`content.replace(b'old', b'new')`) or rewrite the file with `write_file`.

### DB column casing
DB columns are lowercase (`row.userid`, `row.guildname`). `camelRows()` adds camelCase variants but for JOIN aliases the case may vary. Always map explicitly in the response: `{ userId: r.userid, guildName: r.guildname }`.

### Testing without login
Generate JWT tokens directly using the secret from `.env`:
```bash
ssh root@194.226.142.237 'cd /opt/game/server && node -e "
const jwt = require('jsonwebtoken');
const JWT_SECRET = '<from .env>';
console.log(jwt.sign({ userId: 314, role: 'player', username: 'TODD' }, JWT_SECRET, { expiresIn: '1h' }));
"'
```
