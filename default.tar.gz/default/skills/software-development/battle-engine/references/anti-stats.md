# Anti-stats Implementation Reference

## Overview

Guild talents (личные + гильдийские) provide counter-extra-stats that reduce enemy chances in battle.
Added 2026-08-05 as part of the guild boss + talent system.

## Talent Types

| Talent | Key | Anti-stat | Effect | TurnContext field |
|--------|-----|-----------|--------|-------------------|
| Меткость | accuracy | antiDodge | -1%/lvl to enemy dodge | `ctx.antiDodge` |
| Стойкость | fortitude | antiCrit | -1%/lvl to enemy crit (on counter) | `ctx.antiCrit` |
| Пробивание | penetration | antiBlock | -1%/lvl to enemy block | `ctx.antiBlock` |
| Контроль | control | antiCounter | -1%/lvl to enemy counter | `ctx.antiCounter` |
| Антивампиризм | vampiric | antiVampiric | -1%/lvl to enemy vampirism healing | `ctx.targetAntiVampiric` |

## Battle.ts Changes

### TurnContext additions (battle.ts:110-114)

```typescript
antiDodge?: number;
antiCrit?: number;
antiBlock?: number;
antiCounter?: number;
antiVampiric?: number;
targetAntiVampiric?: number;
```

### Formula patches in runTurn

Each formula checks `Math.max(0, formulaResult - antiStat/100)`:

```typescript
// dodge (was: dodgeChance(ctx.targetStats, ctx.actorStats))
Math.max(0, dodgeChance(ctx.targetStats, ctx.actorStats) - (ctx.antiDodge || 0) / 100)

// counter-on-dodge (was: counterChance(...))
Math.max(0, counterChance(ctx.targetStats, ctx.actorStats, ...) - (ctx.antiCounter || 0) / 100)

// target crit on counter (was: critChance(ctx.targetStats))
Math.max(0, critChance(ctx.targetStats) - (ctx.antiCrit || 0) / 100)

// block (was: blockChance(ctx.targetStats))
Math.max(0, blockChance(ctx.targetStats) - (ctx.antiBlock || 0) / 100)

// vampirism (was: const vamp = ctx.actorStats.vampirism || 0)
let vamp = ctx.actorStats.vampirism || 0;
vamp = Math.max(0, vamp - (ctx.targetAntiVampiric || 0));
```

## Source: guildBoss.ts

```typescript
// server/src/game/guildBoss.ts
export function getAntiStats(playerTalents, guildTalents) {
  return {
    antiDodge: getTalentAntiBonus(playerTalents, guildTalents, 'accuracy'),
    antiCrit: getTalentAntiBonus(playerTalents, guildTalents, 'fortitude'),
    antiBlock: getTalentAntiBonus(playerTalents, guildTalents, 'penetration'),
    antiCounter: getTalentAntiBonus(playerTalents, guildTalents, 'control'),
    antiVampiric: getTalentAntiBonus(playerTalents, guildTalents, 'vampiric'),
  };
}
```

## Usage Pattern (PvE boss fight)

```typescript
// Player attacks boss — player's anti-stats reduce boss's defensive chances
const ctx1: TurnContext = {
  actorStats: userStats, targetStats: bossStats,
  antiDodge: antiStats.antiDodge,
  antiCrit: antiStats.antiCrit,
  antiBlock: antiStats.antiBlock,
  antiCounter: antiStats.antiCounter,
  // ...
};

// Boss attacks player — player's antiVampiric reduces boss's healing
const ctx2: TurnContext = {
  actorStats: bossStats, targetStats: userStats,
  targetAntiVampiric: antiStats.antiVampiric,
  // ...
};
```

## Talent Level Costs

```
cost = 10 * 2^currentLevel

0→1: 10 pts
1→2: 20 pts
2→3: 40 pts
3→4: 80 pts
4→5: 160 pts
5→6: 320 pts
...
10,230 pts total to reach level 10
```

Each level gives +1% anti-effect (additive). Same cost for both personal and guild talents.

## Incremental Progress System (2026-08-05 update)

Talents use a progress bar: points are invested 1 at a time. When progress reaches the cost, the level auto-advances.

```sql
ALTER TABLE player_guild_talents ADD COLUMN progress INTEGER DEFAULT 0;
ALTER TABLE guild_talents ADD COLUMN progress INTEGER DEFAULT 0;
```

Upgrade flow:
1. Player clicks "Вложить 1" — deducts 1 point, increments `progress`
2. If `progress >= cost`: level += 1, progress = 0 (auto-level up)
3. Client shows progress bar: `progress / cost`

API response includes `leveledUp: true` when level advances, so client can show a notification.

## Boss Respawn Delay (2026-08-05)

After the boss is killed, a new one does NOT spawn immediately. Instead:
- `damageBoss()` sets `respawnAt = now + 300` (5 minutes) and `currentHp = 0`
- `getOrCreateBoss()` auto-respawns when `now >= respawnAt`
- Client shows a countdown timer: "Босс повержен. Новый появится через X:XX"
- WS message includes `respawnAt` so all members see the timer

```sql
ALTER TABLE guild_bosses ADD COLUMN respawnAt INTEGER DEFAULT 0;
```

## DB Tables

- `player_guild_talents` (userId, guildId, talentType, level)
- `guild_talents` (guildId, talentType, level)
- `guild_members.talentPoints` — personal points
- `guilds.talentPoints` — guild points
