# HP / Regen Balance Changes (2026-07-30)

## Files changed

| File | Change | Purpose |
|------|--------|---------|
| `server/src/game/stats.ts` | `hp: sumStats(st) * 2` | Player HP ×2 |
| `server/src/routes/mobs.ts` | `mobHp = (mob.hp \|\| 50) * 2` | Mob HP ×2 (battle) |
| `server/src/routes/mobs.ts` (GET) | `hp: (m.hp \|\| 50) * 2` in enriched | Mob HP ×2 (bestiary display) |
| `server/src/game/hpRegen.ts` | `HP_REGEN_SECONDS = 5` (was 10) | Base regen ×2 |
| `client/src/contexts/GameContext.tsx` | `/ 10` → `/ 5` in calcRegenHp | Client-side HP calc |
| `client/src/components/CharacterCard/HealthBar.tsx` | `* 10` → `* 5`, `/ 10` → `/ 5` | Regen time display + HP/sec |

## HP Formula

- **Player HP** = `(S + A + M) * 2` in `currentStats()`
- **Mob HP** = `(mob.hp \|\| 50) * 2` — DB value doubled at runtime

## Regen Formula

- **Base**: 1 HP per 5 seconds (was 10s)
- **Rooms**: ×3 (closet), ×10 (bed), ×50 (chamber)
- **Premium**: ×3 multiplier on top
- **Hermit set 2pc**: ×2 multiplier on top

Example: chamber + premium = 1/5 * 50 * 3 = 30 HP/sec

## Touches

- `currentStats()` is called everywhere stats are computed → HP ×2 applies globally
- `applyHpRegen()` is called on character load and before PvP battle
- Client-side `calcRegenHp()` in GameContext must stay in sync with server `hpRegen.ts`
