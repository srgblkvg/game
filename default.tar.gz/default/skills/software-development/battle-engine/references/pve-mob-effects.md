# PvE Mob Effects System (2026-08-01)

Mobs can now have special battle effects via a JSON `effects` column.

## DB

```sql
ALTER TABLE mobs ADD COLUMN IF NOT EXISTS effects TEXT DEFAULT NULL;
```

## Code (routes/mobs.ts)

After `currentStats(mobBase, {})`, effects are parsed and merged:

```typescript
const mobStats = currentStats(mobBase, {});
if (mob.effects) {
    try {
        const fx = typeof mob.effects === 'string' ? JSON.parse(mob.effects) : mob.effects;
        Object.assign(mobStats, fx);
    } catch {}
}
```

## Available effects

All fields from `CharStats.extra` are supported:

| Effect | Field | Value |
|--------|-------|-------|
| Block penetration | `blockPen` | % (0-100) |
| Vampirism | `vampirism` | % of damage healed |
| Execute | `execute` | `true` |
| Counter on hit | `counterOnHit` | % chance |
| Poison on hit | `poisonOnHit` | % of target max HP |
| Luck boost | `luckBoost` | flat % added to all chances |
| Resilience | `resiliencePct` | % reduction |
| Always first | `alwaysFirst` | `true` |

## Example (Hell IV mobs)

```sql
UPDATE mobs SET effects = '{"blockPen":80,"vampirism":20,"execute":true,"counterOnHit":25,"luckBoost":15,"poisonOnHit":3}' WHERE id = 60;
```

## Stat balancing for PvE mobs

Key insight: mobs have NO equipment — raw stats (atk/def/agi/mst) are used directly.
To match player power:
- **HP**: stored in DB, doubled in battle (`mobHp = mob.hp * 2`)
- **ATK** (mob damage output): should be ~80-120% of top player S
- **DEF** (mob defense): should be ~60-90% of top player D
- **MST** (mob crit/dodge pen): should be ~50-80% of top player M
- **AGI** (mob dodge): should be ~50-80% of top player A

Check balance with: `mob_dmg = level + 0.55*(atk - level)` vs player block reduction.
