# Combat Formulas — Full Reference

## Stat Config (stats.ts `F`)

```
dodgeDef:   'a'        — уклонение от Ловкости
dodgePen:   'm'        — пробив уклонения Мастерством
crit:       'm'        — крит от Мастерства
block:      'd'        — блок от Защиты
damage:     's'        — урон от Силы
counterDef: ['m','a']  — защита от контры
counterTgt: ['m','d']  — статы цели для контры
stunAtk:    ['s','m']  — оглушение атакой
stunDef:    ['s','d']  — защита от оглушения
```

`sv(stats, key)` — суммирует статы по ключу (включая все бонусы: экипировка, curse, напитки, коллекция, гильдия).

---

## Dodge (Уклонение)

```
dodge% = (A_def / (A_def + 500)) × (1 - M_atk / (M_atk + 500)) / 1.5
       + min(0.5, extraDodge / (extraDodge + 300))
       + luckBonus
```

| A | M | Dodge |
|---|---|-------|
| 100 | 100 | 6.2% |
| 200 | 200 | 11.1% |
| 400 | 400 | 14.8% |
| 1344 | 1194 | 14.3% (runaway vs Некрохирург) |

Кап: ~83% теоретический (без хардкапа). Balance change 2026-08-01: `M/(M+500)` вместо `M/(M+100)`.

---

## Crit (Крит)

```
crit% = min(0.8, M / (M + 500) / 1.5 + extraCrit / (extraCrit + 300)) + luckBonus
mult  = 1.5 + 0.5 × M / (M + 50)    // 1.5–2.0
```

| M | Crit% | Mult |
|---|-------|------|
| 100 | 11.1% | 1.83 |
| 200 | 22.2% | 1.90 |
| 400 | 29.6% | 1.94 |
| 160 (Некро) | ~18% | 1.88 |

Кап крита: 80%. Кап множителя: 2.0.

---

## Block (Блок)

```
block%    = min(0.75, D / (D + 500) / 1.5 + extraBlock / (extraBlock + 300))
reduce%   = min(0.75, 0.9 × D_def / max(1, S_atk))
fullBlock = fb / (fb + 300)   // only from items
```

| D | Block% |
|---|--------|
| 100 | 11.1% |
| 200 | 19.0% |
| 400 | 29.6% |
| 180 (Sallarik) | ~18% |

Кап блока: 75%.

---

## Counter (Контратака)

```
counter% = min(0.5, (defSum/totalSum × 0.5 / 1.5) + extraCounter / (extraCounter + 300))
  defSum   = M_def + A_def
  totalSum = defSum + M_atk + D_atk
```

Срабатывает только при уклонении. Кап: 50%.

---

## Stun (Оглушение)

```
stun% = (S_atk+M_atk) / (S_atk+M_atk+S_def+D_def) × 0.3 × (1 - resiliencePct/100)
```

Кап: 30% (до устойчивости).

---

## Damage (Урон)

```
dmg = level + factor × (S - level)
  factor = треугольное распределение (avg ~0.55)
```

При level=10, S=200: средний урон ~115.

---

## Caps Summary

| Effect | Cap | Nearest player |
|--------|-----|----------------|
| Crit chance | 80% | ~18% (Некрохирург) |
| Crit mult | 2.0× | 1.88× (Некрохирург) |
| Block | 75% | ~18% |
| Counter | 50% | ~15% |
| Stun | 30% | ~5-10% |
| FullBlock | asymp. 100% | ~7% |
| Dodge | asymp. ~83% | ~15% |

---

## Top Players (trained base stats, 2026-08-01)

| Player | Lvl | S | A | D | M |
|--------|-----|---|---|---|---|
| Некрохирург | 10 | 21 | 13 | 15 | 40 |
| Sallarik | 10 | 20 | 33 | 39 | 23 |
| Алчный | 10 | 16 | 15 | 25 | 17 |

Full mythic +6 set adds ~100-150 to each stat.
