# Curse Pack naming convention

Item keys stay descriptive (`curse_x50`, `curse_x100`) for backend routing.
Display titles use Roman numerals: "Проклятый III", "Проклятый IV".

## Adding x50/x100 curse packs (done 2026-08-05)

### Files changed:
1. `server/src/routes/donate.ts` — `deliverCursePack`: add `x50`/`x100` to packs map + function signature
2. `server/src/routes/yukassa.ts` — add `curse_x50`/`curse_x100` to ITEMS, update packType ternary
3. `server/src/routes/vkPayments.ts` — same as yukassa
4. `client/src/pages/CraftPage.tsx` — add entries to PACKS array

### Pack config:
```typescript
// donate.ts
x50:  { silver: 5000000, crystals: 50 },
x100: { silver: 10000000, crystals: 100 },

// yukassa.ts
curse_x50:  { title: 'Сундук «Проклятый III» (5M + 50 кристаллов)', price: 7999, type: 'curse_pack' },
curse_x100: { title: 'Сундук «Проклятый IV» (10M + 100 кристаллов)', price: 14999, type: 'curse_pack' },

// vkPayments.ts
curse_x50:  { ..., price: 1149 },
curse_x100: { ..., price: 2149 },
```

### Handler update:
```typescript
// From: const packType = itemKey === 'curse_small' ? 'small' : 'large';
// To:
const packType = itemKey === 'curse_small' ? 'small' : itemKey === 'curse_large' ? 'large' : itemKey === 'curse_x50' ? 'x50' : 'x100';
```

### Pricing tier:
| Pack | ₽ | ₽/crystal |
|------|-----|-----------|
| Проклятый (×5) | 999 | 200 |
| Проклятый II (×10) | 1799 | 180 |
| Проклятый III (×50) | 7999 | 160 |
| Проклятый IV (×100) | 14999 | 150 |
