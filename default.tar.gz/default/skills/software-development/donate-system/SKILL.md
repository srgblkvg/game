---
name: donate-system
description: "Донат-система MMO Arena: добавление товаров в VK Payments / ЮKassa, выдача предметов, формат craft_item в инвентаре."
---

# Донат-система MMO Arena

Файлы: `routes/donate.ts` (логика выдачи), `routes/vkPayments.ts` (VK колбэк), `routes/yukassa.ts` (ЮKassa).

## Добавление нового товара

1. **`routes/vkPayments.ts`** — добавить в `ITEMS` + обновить `VkItem` интерфейс (новый `type`)
2. **`routes/yukassa.ts`** — добавить в `ITEMS` + обновить `ShopItem` интерфейс
3. **`routes/donate.ts`** — функция выдачи (`deliver*`) + экспорт
4. В обоих колбэках (`order_status_change` / `processDelivery`) добавить `else if`
5. Клиент: VK → `VKWebAppShowOrderBox`, Web → `POST /api/yukassa/create-payment`

## Типы товаров

| type | Назначение | Доп. поля |
|------|-----------|-----------|
| `premium` | Дни премиума | `days` |
| `starter_pack` | Одноразовый стартовый набор | — (проверка `starter_pack_purchased`) |
| `silver` | Серебро в кошелёк | `amount` / `silverAmount` |
| `craft_pack` | Сундук с материалами | — |
| `curse_pack` | Сундук с кристаллами душ + серебро | — |

## Клиентский паттерн покупки

```tsx
const isVK = document.documentElement.classList.contains('vk-iframe');

const buy = (itemName: string) => {
  if (isVK) {
    window.vkBridge.send('VKWebAppShowOrderBox', { type: 'item', item: itemName });
  } else {
    fetch('/api/yukassa/create-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ item: itemName }),
    }).then(r => r.json()).then(d => window.open(d.confirmation_url, '_blank'));
  }
};

// Успешная оплата приходит через WS: window.addEventListener('paymentStatus', ...)
```

## Текущие товары (2026-07-21)

| Ключ | Тип | VK (гол.) | ₽ |
|------|-----|-----------|-----|
| `premium_7d` | premium | 14 | 99 |
| `premium_30d` | premium | 42 | 299 |
| `starter_pack` | starter_pack | 14 | 99 |
| `silver_10000` | silver | 7 | 49 |
| `silver_50000` | silver | 14 | 99 |
| `silver_100000` | silver | 28 | 199 |
| `silver_500000` | silver | 114 | 799 |
| `silver_1000000` | silver | 200 | 1399 |
| `craft_rare` | craft_pack | 14 | 99 |
| `craft_epic` | craft_pack | 28 | 199 |
| `curse_small` | curse_pack | 144 | 999 |
| `curse_large` | curse_pack | 258 | 1799 |
| `curse_x50` | curse_pack | 1149 | 7999 |
| `curse_x100` | curse_pack | 2149 | 14999 |

## Формат craft_item в инвентаре

Ресурсы (материалы, камни) стакаются через `count`. НЕ дублировать отдельными записями.

```typescript
{
  type: 'craft_item',       // всегда 'craft_item'
  id: dbItem.id,            // ID из craft_items (для стакинга)
  name: 'Эссенция мрака',
  rarity_id: 3,
  rarity_display: 'Редкий',
  rarity_color: '#3498db',
  count: 3,                 // количество
  itemType: 'craft',        // 'craft' (материал) или 'upgrade' (камень)
  image: '/fragment/fragment_green.webp',
}
```

**Стакинг:** `inventory.find(i => (i.type === 'craft_item' || i.type === 'material') && i.id === dbId)`. Найден → `existing.count += qty`. Не найден → `push`.

## Пути к изображениям

- **items (экипировка):** без ведущего `/` → `helmet/helmet_white.webp`
- **craft_items (ресурсы):** с ведущим `/` → `/fragment/fragment_green.webp`

При сборке URL: `'https://mmoarena.ru/' + img.replace(/^\//, '')`

Файлы `fragment/` и `stone/` в `client/dist/`, деплоятся с клиентом.

## Питфолы

### JOIN + db.one() — ambiguous column
```typescript
// ❌ column reference "id" is ambiguous
db.one("SELECT id, name FROM craft_items c JOIN rarities r ON c.rarity_id = r.id", [])

// ✅
db.one("SELECT c.id, c.name FROM craft_items c JOIN rarities r ON c.rarity_id = r.id", [])
```

### Камень улучшения — один на все редкости
В игре только один камень: `Камень улучшения (Хлам)`, rarity_id=0. Он улучшает предмет ЛЮБОЙ редкости. НЕ создавать отдельные камни под каждую редкость.
