---
name: mmo-arena-updates
description: "MMO Arena: lottery, shop, treasury, inventory, war."
---

# MMO Arena — Актуальные изменения (июль 2026)

## Кровавая лотерея (бывш. Резня)
Переименована 2026-07-27. Голые статы (база + лудус), без экипировки. Случайный выбор цели. Приз = сборы + 1000 бонуса. В казну не идёт. Иконка: `game-icons:fist`.
- Статы: `baseX + trained_X`, HP = S+A+M
- Цель: `Math.floor(Math.random() * aliveTargets.length)` — полностью случайно
- Приз: `participants.length * entryFee + 1000`
- Лог: `победитель кровавой лотереи!`

## Магазин: ежедневные предложения
- Каждому игроку свой набор из 10 товаров/день (`shop_offers` с `user_id`)
- 1-й лот всегда камни улучшения (Хлам) ×1/×3/×5 (случайно)
- Остальные 9 — по весам редкости: Хлам 40% → Мифик 2%
- Без сетов и артефактов. Один товар = одна покупка в сутки.
- Генерация: все предметы грузятся одним SELECT, выборка в памяти (быстро)
- Цена камня: 2000 серебра/шт. Все предметы `sellable = true`.

## Цены предметов: множители к базе
Хлам ×1 | Обычный ×1.5 | Необычный ×2 | Редкий ×3 | Эпик ×5 | Легендарный ×6 | Мифик ×7

## Казна замка: актуальные ставки
Магазин/Ремесло/Таверна: 22% | Аукцион: 5-10% | Банк: 2% | Турниры: 10% казны | Лотерея: 0%

## Инвентарь: клик → Надеть
- `clickToEquip` prop (default true): клик → кнопка «Надеть» → экипировка
- `clickToEquip={false}`: старое поведение (крафт)
- Кольца: пустой → ring1, иначе ring2, иначе замена худшего (редкость + upgradeLevel)
- Закрытие кнопки: mousedown/touchstart вне слота

## NoMoneyModal
- ToastContext перехватывает «недостаточно» + «серебра/монет/денег» → модальное окно
- Советы + кнопка «💎 Купить» → `/bank?tab=exchange`
- Сервер: суммы в ошибках «Нужно X, есть Y»

## Война гильдий: модалка подтверждения
- GuildViewPage + GuildRatingPage: ⚔️ Война → модалка с правилами
- 24ч ответ / 24ч бои / атака до 3 / защита до 5 на участника
- Казна заморожена, нельзя покинуть/исключать/принимать
- Проигравший → казна победителю. Победа по счёту побед.

## Аукцион: лимит лотов 10/20 (премиум)

С 2026-08-08: базовый лимит 10 лотов, с премиумом 20 (было 5).
- Сервер: `/auction/sell` — `hasPremium = (user.premiumUntil || 0) > now`, `maxLots = hasPremium ? 20 : 10`
- Клиент: `maxSlots = character?.premium ? 20 : 10` (объект premium не-null когда активен)
- Премиум-страница: строка «📦 +10 слотов аукциона (всего 20)» в списке бонусов

## Аукцион: график истории цен (Chart.js)

Эндпоинт `GET /api/auction/price-history?name=X&slot=Y&rarity=Z`:
- Группирует `auction_history` по дням за 30 дней
- Возвращает `{ points: [{ day, count, avg_price, min_price, max_price }] }`
- **Питфол:** `itemData::jsonb->>'slot' = ''` не матчит NULL → использовать `COALESCE(..., '')`

Клиент: `PriceChart` компонент в `AuctionPage.tsx`:
- Кнопка «📈 История цен» → ленивая загрузка → график
- Chart.js + react-chartjs-2, только нужные модули
- Три линии: средняя (жёлтая заливка), мин (зелёный пунктир), макс (красный пунктир)
- **Питфол дат:** `p.day` — полный ISO → `p.day.slice(0, 10)` для `DD.MM`
- **Питфол цен:** на оси Y `k`/`M` вместо `formatMoney()`
- **Питфол смены предмета:** `useEffect` по `itemKey` сбрасывает `points` в `null`
- График показывается и в списке лотов, и при выставлении на продажу

## Аукцион: группировка по upgradeLevel

Предметы с разным уровнем улучшения (+0, +2, +3) — отдельные позиции:
- **Группировка:** ключ `name|slot|rarity_id|upgradeLevel` (сервер + клиент)
- **price-history:** фильтр `COALESCE((itemData::jsonb->>'upgradeLevel')::int, 0) = ?`
- **similar:** фильтр `d.upgradeLevel === upgLevel`
- **Клиент:** `itemKey` в PriceChart, group click key, similar query — все с upgradeLevel
- **Бейдж +N:** на всех изображениях (группы, список, продажа, сетка выбора)

## Аукцион: модалки для ошибок

**«Недостаточно серебра»** → `showNoMoney(msg)` — стандартная NoMoneyModal с кнопкой «Купить серебро».
**«Максимум N лотов»** → локальная `centerModal` с кнопкой «⭐ Премиум (+10 слотов)» (только если премиум не активен).

```tsx
const [centerModal, setCenterModal] = useState<string | null>(null);

// В catch:
if (msg.includes('Недостаточно')) showNoMoney(msg);
else if (msg.includes('Максимум')) setCenterModal(msg);
else setError(msg);

// Рендер:
{centerModal && (
  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setCenterModal(null)}>
    <Card onClick={e => e.stopPropagation()}>
      <p>{centerModal}</p>
      <Button onClick={() => setCenterModal(null)}>Закрыть</Button>
      {!character?.premium && <Button onClick={() => { setCenterModal(null); navigate('/premium'); }}>⭐ Премиум (+10 слотов)</Button>}
    </Card>
  </div>
)}
```

Импорт: `import { showNoMoney } from '../components/NoMoneyModal'`.

## Руны улучшения: фикс редкости

**Проблема:** руны показывали `rarity_display: "Хлам"` при правильном `rarity_id`, картинка фрагмента вместо камня.

**Корень:** `mobs.ts` не JOINил rarities, `character.ts` пропускал энричмент, `getItemImage` не проверяла `itemType`.

**Фиксы:** JOIN rarities в mobs.ts, батчевый энричмент в character.ts, `getRarityDisplay(item)` с фолбэком на `rarity_id`.

## Гильд-босс: персональный кулдаун через WS

**Проблема:** после атаки босса правая панель не обновляла кулдаун до перезагрузки страницы.
**Причина:** `guild_boss_update` шёл через `sendToGuild` (всем), без персонального `cooldownRemaining`.

**Фикс:** добавить `sendToUser` атакующему с персональным кулдауном:
```ts
const { sendToGuild, sendToUser: sendToUserEvent } = await import('../events');
// ... sendToGuild для всех ...
// Персонально атакующему:
const remainingCd = Math.max(0, BOSS_COOLDOWN - (now - (member.lastbossattackat || 0)));
sendToUserEvent(userId, {
  type: 'guild_boss_update',
  data: { cooldownRemaining: remainingCd, bossHp, bossMaxHp },
});
```
Кулдаун: `BOSS_COOLDOWN = 3600` (1 час).

**Питфол правой панели:** клик по боссу на кулдауне НЕ вёл на вкладку (`onClick={() => bossCd <= 0 && navigate(...)}`).
Убрать условие: `onClick={() => navigate('/guild?tab=4')}`.

## RightSidebar: динамическое позиционирование по хедеру

**Проблема:** кнопка «Боевой журнал» и панель были на хардкод-пикселях (`top-[132px]`), перекрывали кнопки хедера при изменении его высоты.

**Фикс:** измерять реальную нижнюю границу хедера через `getBoundingClientRect().bottom` + `ResizeObserver`:
```tsx
const [headerHeight, setHeaderHeight] = useState(132);
useEffect(() => {
  const update = () => {
    const el = document.getElementById('site-header');
    const h = el ? el.getBoundingClientRect().bottom : 132;
    const safeArea = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--vk-top-offset')) || 0;
    setHeaderHeight(Math.max(h, 132) + safeArea);
  };
  update();
  const ro = new ResizeObserver(update);
  const el = document.getElementById('site-header');
  if (el) ro.observe(el);
  window.addEventListener('resize', update);
  return () => { ro.disconnect(); window.removeEventListener('resize', update); };
}, []);

// Кнопка: style={{ top: `${headerHeight}px` }}
// Панель: style={{ top: `${headerHeight + 5}px`, height: `calc(100vh - ${headerHeight + 5}px - 40px)` }}
```

**VK safe-area:** CSS переменная `--vk-top-offset` добавляется в JS (не в CSS), чтобы `!important` в VK-стилях не перебивал динамический `top`.
