---
name: mmo-charts
description: Chart.js graphs for MMO Arena — setup, patterns, pitfalls.
---

# MMO Arena Charts (Chart.js)

Lightweight charts using Chart.js + react-chartjs-2.

## Setup

```bash
cd client && npm install chart.js react-chartjs-2
```

Tree-shake only needed modules:

```typescript
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement,
  LineElement, Tooltip, Filler,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);
```

## Lazy-load Pattern

Don't fetch chart data on mount — N charts × N requests per page. Load on user click:

```tsx
function PriceChart({ item }: { item: any }) {
    const [points, setPoints] = useState<any[] | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const itemKey = `${item.name}|${item.slot || ''}|${item.rarity_id ?? 0}`;

    // RESET on item change — critical!
    useEffect(() => { setPoints(null); setLoading(false); setError(''); }, [itemKey]);

    const fetchData = useCallback(async () => {
        if (points !== null) return;
        setLoading(true);
        try {
            const res = await fetch(`/api/...?...`);
            const data = await res.json();
            setPoints(data.points || []);
        } catch { setError('...'); }
        finally { setLoading(false); }
    }, [itemKey, points]);

    // Button → Loading → Error → Empty → Chart
    if (!points) return <button onClick={fetchData}>📈</button>;
    if (loading) return <div>Загрузка...</div>;
    if (error) return <div>{error}</div>;
    if (points.length < 2) return <div>Недостаточно данных</div>;

    return <Line data={...} options={...} />;
}
```

## Data Format Conventions

- **Dates**: `p.day.slice(0, 10).split('-')` → `07.08` (DD.MM). PG returns full ISO with TZ.
- **Y-axis prices**: compact `1.5k` / `2.3M` instead of full formatMoney. Chart axis is narrow.
- **Lines**: avg (filled yellow), min/max (dashed green/red, no points).

## JSONB Filter Pitfall

For auction_history queries filtering by itemData fields:
```sql
COALESCE(itemData::jsonb->>'slot', '') = ?  -- NOT itemData::jsonb->>'slot' = ?
```
Without COALESCE, NULL slot (materials, runes) never matches empty-string input → zero results.

## Bundle Size

Chart.js + react-chartjs-2 adds ~60KB gzipped. Tree-shake registration via explicit module imports keeps it minimal.
