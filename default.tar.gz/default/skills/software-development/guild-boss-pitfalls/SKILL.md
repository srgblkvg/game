---
name: guild-boss-pitfalls
description: Guild boss — route order, WS data, respawn, talent progress.
---

# Гильд-босс — питфолы и паттерны

## Регистрация роутов: порядок имеет значение

Роутер босса ДОЛЖЕН быть зарегистрирован ДО `guildRoutes` в `setupRoutes.ts`.
Причина: `guildRoutes` содержит `router.get('/guild/:id', ...)` который перехватывает `/guild/boss`
(интерпретируя «boss» как ID). Если `guildRoutes` зарегистрирован первым — `/api/guild/boss` вернёт 404.

```typescript
// ✅ ПРАВИЛЬНЫЙ порядок
app.use('/api', guildBossRoutes);   // сначала конкретные роуты
app.use('/api', guildRoutes);       // потом /guild/:id
```

Для отладки добавить прямой `app.get('/api/guild/boss/ping', ...)` в setupRoutes — канарейка:
- 200 → роутинг работает
- 401 → за auth middleware (нормально для защищённых роутов)
- 404 → проблема с порядком роутов

## WS-сообщения: вложенность данных

`sendToGuild(guildId, payload)` отправляет `JSON.stringify(payload)` как raw WS сообщение.
Клиентский `ChatContext` делает `switch(data.type)` и диспатчит ВЕСЬ `data` объект как `CustomEvent.detail`.
Компонент должен извлекать полезные данные из `e.detail.data`, а не из `e.detail`:

```typescript
// ChatContext.tsx — dispatch
window.dispatchEvent(new CustomEvent('guildBossUpdate', { detail: data }));
// data = { type: 'guild_boss_update', message: '...', data: { bossHp: ..., ... } }

// Компонент — приём
const msg = (e as CustomEvent).detail;  // весь payload
const d = msg.data || msg;              // извлекаем вложенные данные
```

## Респаун босса с задержкой

После убийства босс НЕ спаунится мгновенно:
- `damageBoss` выставляет `currentHp = 0` и `respawnAt = now + BOSS_RESPAWN_DELAY`
- `getOrCreateBoss` при следующем вызове проверяет: если `respawnAt > 0 && now >= respawnAt` — авто-респаун
- Клиент показывает таймер обратного отсчёта

## Таланты: прогресс вместо единоразовой оплаты

Стоимость уровня: `10 * 2^currentLevel`. Очки вкладываются по 1 за клик.
В БД колонка `progress`. Когда `progress >= cost` → уровень +1, `progress = 0`.
Только лидер вкладывает гильдийские очки.

**⚠️ Отображение процентов: личные и гильдийские — раздельно**

Каждый талант имеет `playerLevel` (личный) и `guildLevel` (гильдийский). В бою они СТАКУЮТСЯ (`playerLevel + guildLevel`). Но в UI должны отображаться РАЗДЕЛЬНО:

```tsx
// Личные таланты — только playerLevel
<span>{t.playerLevel}%</span>

// Гильдийские таланты — только guildLevel  
<span>{t.guildLevel}%</span>

// ❌ Ошибка (было): в обоих табах показывалась сумма
<span>{t.playerLevel + t.guildLevel}%</span>
```

Если у игрока Стойкость ур.1 личная и ур.1 гильдийская — должно показывать «1%» в каждом табе, а не «2%».

## Рейтинги: одиночный удар из steps

Для «рекордных ударов» парсить `steps` JSON — `type === 'damage'` и брать `s.damage`.
`MAX(damageDealt)` даёт сумму за бой, не одиночный удар.

## Клиент: GuildPage — только write_file

GuildPage >700 строк, JSX-вложенность 4-5 уровней. Патчи ломают разметку. Перезапись через `write_file`.

## Иконки статов — консистентность с CharacterCard

Из `StatsOverlay.tsx`: Сила=`game-icons:biceps`, Ловкость=`game-icons:sprint`, Защита=`game-icons:shield`, Мастерство=`game-icons:crossed-swords`.

## UI: без сокращений, авто-загрузка, mobile-first

- Полные формулировки: «Побеждён N раз», «Атака доступна раз в час»
- Данные грузятся через `Promise.all` при открытии вкладки, без кнопок «Загрузить»
- Сетки: `grid-cols-1 sm:grid-cols-2` — на мобильном одна колонка
- Числа через `formatNum()`: 1200→1.2K, 1500000→1.5M (HP, урон, рейтинги)
- Серебро только через `formatMoney()` (с суффиксом «серебро/серебра»)

## Ссылки в рейтингах: ник[ур.][гильдия]

Все рейтинги (guildTop, personalTop, topHits) должны показывать:
```
<i>. <ник onclick=profile> <уровень>ур. [гильдия зелёным onclick=guild]
```
Импортировать `useNavigate` и добавлять `onClick` на каждый элемент.

## Чередование фона лога боя — по ХОДАМ

Не по каждому шагу! Делимитер хода — `type: 'attack'`. При встрече `attack` переключать `isPlayerTurn`.
Все шаги одного хода — один фон.

## Таб талантов: loadBoss для tab 5

При переносе талантов в отдельный таб, `useEffect` ДОЛЖЕН включать новый таб:
```tsx
useEffect(() => { if (guild && (tab === 4 || tab === 5)) loadBoss(); }, [guild, tab]);
```

## WS-рейтинги: флаг вместо данных

Не пересылать все 5 рейтингов в WS — добавить `ratingsChanged: true` в payload.
Клиент вызывает `loadBoss()` (который через `Promise.all` грузит всё заново).

## Босс в сайдбаре: QuestsBlock

Секция «Босс:» под гильдийским квестом, HP-бар `h-1` (тонкий как у квестов).
Переход на `/guild?tab=4` — GuildPage читает `searchParams.get('tab')` при инициализации `useState`.
Кулдаун босса — персональный, загружается из `cooldownRemaining` в `/api/guild/boss`.
WS-обновления HP — НЕ ставят кулдаун (только своя атака ставит).

**Авто-появление после респауна:** при `bossKilled` в WS делаем `setGuildBoss(null)` и `setTimeout(300000)` с `fetch('/api/guild/boss')`. Без этого новый босс не появится до перезагрузки страницы.

## KillCount: двойной инкремент

Баг: `damageBoss` увеличивает `killCount` при убийстве. `getOrCreateBoss` при истечении `respawnAt` тоже увеличивал `killCount` → каждый kill считался дважды.
Фикс: `getOrCreateBoss` при респауне использует существующий `boss.killcount`, НЕ делает `+1`.

## Бой с боссом: максимальное HP, без сохранения

Как на турнирах: бой идёт с `userStats.hp` (макс HP), текущее HP игрока НЕ сохраняется после боя.
Убрать `applyHpRegen` перед боем, убрать `UPDATE users SET currentHp = ...` после боя.
Ответ клиенту: `currentHp: user.currentHp` (исходное, без изменений).

## Таверна-комнаты: 5 мест для rate

При добавлении новой комнаты (Люкс, rate=250) надо обновить ВСЕ 5 мест:
1. **server/src/routes/tavern.ts** — объект `rooms` (для API)
2. **server/src/game/hpRegen.ts** — `applyHpRegen()` (серверная регенерация)
3. **client/src/contexts/GameContext.tsx** — `regenRate` (клиентская регенерация)
4. **client/src/components/LeftSidebar.tsx** — `effectiveRoom.type` (отображение HP/сек)
5. **client/src/components/BuffsBlock.tsx** — иконка и название в усилениях

Пропуск любого из них → `+0.6 HP/сек` вместо `+150 HP/сек`, или сброс HP после перезагрузки.
