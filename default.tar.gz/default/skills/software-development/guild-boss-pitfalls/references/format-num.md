# formatNum — компактные числа (K/M)

Функция в `client/src/utils/money.ts`:

```typescript
export function formatNum(n: number | null | undefined): string {
    if (n == null) return '0';
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace('.0', '') + 'M';
    if (n >= 1_000) return (n / 1_000).toFixed(1).replace('.0', '') + 'K';
    return n.toLocaleString();
}
```

## Где использовать

✅ HP (босса, персонажа), урон, значения рейтингов:
- `formatNum(boss.currentHp)` / `formatNum(boss.maxHp)`
- `formatNum(bossResult.damageDealt)`
- `formatNum(b.damageDealt)` в истории атак
- `formatNum(r.total)` в рейтингах
- `formatNum(r.maxDmg)` в рекордных ударах
- `formatNum(guildBoss.currentHp)` в QuestsBlock

❌ НЕ для серебра:
- `toLocaleString()` для казны/цен
- `formatMoney()` для нотификаций (даёт суффикс «серебро/серебра»)

Пример: 1200 → "1.2K", 1500000 → "1.5M", 100000 → "100K", 500 → "500"
