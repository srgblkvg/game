# Talent allocation: check-then-insert race condition

## Where

`server/src/routes/guildBoss.ts` — 4 INSERT points:
- `player_guild_talents` level-up path (line ~453)
- `player_guild_talents` progress path (line ~459)
- `guild_talents` level-up path (line ~509)
- `guild_talents` progress path (line ~515)

## Bug

Код делает `SELECT ... WHERE userId/guildId/talentType` → если нет записи (`row` falsy) → `INSERT`.
При двух одновременных запросах оба видят `row === null`, оба делают INSERT →
`duplicate key violates unique constraint "player_guild_talents_pkey"`.

## Symptom

В PM2 error log:
```
error: duplicate key value violates unique constraint "player_guild_talents_pkey"
    at <anonymous> (/opt/game/server/src/routes/guildBoss.ts:459:9)
```

Сервер не падает, но игрок получает 500 вместо успешного вложения очка таланта.

## Fix

`ON CONFLICT DO NOTHING` на все 4 INSERT:

```typescript
// player_guild_talents — level-up
await db.run('INSERT INTO player_guild_talents (userId, guildId, talentType, level, progress) VALUES (?, ?, ?, 1, 0) ON CONFLICT DO NOTHING', [userId, user.guildid, talentType]);

// player_guild_talents — progress
await db.run('INSERT INTO player_guild_talents (userId, guildId, talentType, level, progress) VALUES (?, ?, ?, 0, ?) ON CONFLICT DO NOTHING', [userId, user.guildid, talentType, newProgress]);

// guild_talents — level-up
await db.run('INSERT INTO guild_talents (guildId, talentType, level, progress) VALUES (?, ?, 1, 0) ON CONFLICT DO NOTHING', [user.guildid, talentType]);

// guild_talents — progress
await db.run('INSERT INTO guild_talents (guildId, talentType, level, progress) VALUES (?, ?, 0, ?) ON CONFLICT DO NOTHING', [user.guildid, talentType, newProgress]);
```
