# Комнаты Трактира — добавление новой

## Файлы для изменений

1. **`server/src/routes/tavern.ts`** — объект `rooms`, добавить ключ с rate/cost1h/cost8h
2. **`client/src/components/BuffsBlock.tsx`** — три мэпа: `roomNames`, `roomIcons`, `roomRates`
3. **`client/src/contexts/GameContext.tsx`** — цепочка `if/else if (roomType === ...) regenRate = ...`

## Пример: добавление Люкса (×250)

tavern.ts:
```typescript
lux: { name: 'Люкс', rate: 250, cost1h: 10000, cost8h: 60000 },
```

BuffsBlock.tsx:
```typescript
const roomNames = { ..., lux: 'Люкс' };
const roomIcons = { ..., lux: 'game-icons:crystal-growth' };
const roomRates = { ..., lux: 250 };
```

GameContext.tsx:
```typescript
else if (roomType === 'lux') regenRate = 250;
```

Формула регенерации: `regenRate / 5` HP/сек, с премиумом ×3.
Клиентский TavernPage грузит комнаты с сервера динамически — доп. правки не нужны.
