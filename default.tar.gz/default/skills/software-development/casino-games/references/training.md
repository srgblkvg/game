# Полигон — тренировка статов

Добавлен: 2026-07-24

## Механика

- Выбор одного из 4 статов: Сила (s), Ловкость (a), Защита (d), Мастерство (m)
- +1 к базовому стату (baseS/baseA/baseD/baseM)
- Кулдаун: 1 час (`training_at` в users)
- Сообщение при кулдауне: «Тренировки выматывают, нужно отдохнуть»

## Стоимость

Формула: `Math.floor(10 × уровень × коэффициент_стата)`

| Стат | Коэффициент | На 1 уровне | На 50 уровне |
|------|------------|-------------|-------------|
| Защита (d) | 1.0 | 10 | 500 |
| Ловкость (a) | 1.2 | 12 | 600 |
| Мастерство (m) | 1.5 | 15 | 750 |
| Сила (s) | 1.8 | 18 | 900 |

## DB

```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS training_at TIMESTAMPTZ;
```

## API

- `GET /api/training` — возвращает `{ level, money, onCooldown, cooldownUntil, costs: {s,a,d,m}, stats: {s,a,d,m} }`
- `POST /api/training` — body `{ stat: 's'|'a'|'d'|'m' }`, возвращает `{ success, stat, label, newValue, cost, message }`
- Кулдаун проверяется: `Date.now() - training_at < 3600000`
- Деньги списываются, стат инкрементится

## Файлы

- Сервер: `server/src/routes/training.ts`
- Клиент: `client/src/pages/TrainingPage.tsx`
- Роут: `App.tsx` → `/training`
- Регистрация: `setupRoutes.ts` → `app.use('/api', trainingRoutes)`

## Клиент

- Таймер обратного отсчёта через `setInterval(1000)` + `useRef`
- После успешной тренировки — локально обновляет статы и баланс, запускает таймер на 1 час
- При кулдауне — карточка с сообщением и таймером
- Без кулдауна — 4 карточки с кнопками-ценами
