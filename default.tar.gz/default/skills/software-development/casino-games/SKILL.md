---
name: casino-games
description: Use when working on casino/igorniy-dom features (blackjack, dice, daily limits, counters).
---

# Casino Games — MMO Arena

## Tables

- `casino_games` — blackjack (game_type='blackjack'), soon poker etc.
- `dice_games` — dice/poker-dice (separate table, not in casino_games)

## Daily limit pattern (10 games/day per game type)

### Server

```typescript
const DAILY_LIMIT = 10;

async function countTodayGames(gameType: string, userId: number): Promise<number> {
    const row = await db.one(
        "SELECT COUNT(*) as cnt FROM casino_games WHERE user_id = ? AND game_type = ? AND created_at::date = CURRENT_DATE",
        [userId, gameType]
    );
    return row.cnt || 0;
}
```

For dice (separate table `dice_games`, no game_type):
```typescript
async function countTodayGames(userId: number): Promise<number> {
    const row = await db.one(
        "SELECT COUNT(*) as cnt FROM dice_games WHERE user_id = ? AND created_at::date = CURRENT_DATE",
        [userId]
    );
    return row.cnt || 0;
}
```

**Status endpoint** — returns active game + counters:
- `GET /casino/active` → `{ game, todayGames, dailyLimit, remaining }`
- `GET /dice/status` → `{ activeGame, todayGames, dailyLimit, remaining }`

**Start check:**
```typescript
const todayCount = await countTodayGames('blackjack', userId);
if (todayCount >= DAILY_LIMIT) return res.status(400).json({ error: `Дневной лимит исчерпан (${todayCount}/${DAILY_LIMIT}).` });
```

### Client: loadCounters vs loadGame (CRITICAL)

**Pitfall:** calling `loadGame()` after hit/stand/double/surrender resets the game screen because `/casino/active` returns `game: null` when game is finished → `setGame(null)` hides the result.

**Fix:** split into two functions:

```typescript
// Only updates counters, NEVER touches game state
const loadCounters = async () => {
    const r = await fetch('/api/casino/active', { headers: getHeaders() });
    const d = await r.json();
    setTodayGames(d.todayGames || 0);
    setRemaining(d.remaining ?? 10);
};

// Full load: game + counters. Only on mount and "New Game" button.
const loadGame = async () => {
    const r = await fetch('/api/casino/active', { headers: getHeaders() });
    const d = await r.json();
    if (d.game) setGame(d.game);
    else setGame(null);
    setTodayGames(d.todayGames || 0);
    setRemaining(d.remaining ?? 10);
};
```

**Call sites:**
- `useEffect(() => { loadGame(); }, [])` — mount
- After `hit` (if bust): `loadCounters()`
- After `stand`: `loadCounters()`
- After `doubleDown`: `loadCounters()`
- After `surrender`: `loadCounters()`
- "New Game" button: `setGame(null); loadGame();`

### UI counter

```tsx
// In betting section (when !game):
{remaining <= 0 ? (
    <p>🚫 Дневной лимит исчерпан (10/10). Возвращайтесь завтра!</p>
) : (
    <>
        <Button disabled={loading || remaining <= 0}>Играть</Button>
        <span>Игр сегодня: <span className={remaining <= 3 ? 'text-warning' : ''}>{todayGames}/10</span></span>
    </>
)}
```

## PG pool exhaustion fix

Symptom: 26 PM2 restarts, error log shows `terminating connection due to administrator command (FATAL)`.

Fix: increase pool from 5 to 20 in `db/index.ts`:
```typescript
const pool = new Pool({ ..., max: 20, ... });
```
PG `max_connections = 100` on VPS — plenty of room.

## Flash prevention: countersLoaded pattern

**Symptom:** button "Играть" visible for 500ms, then replaced by "Лимит исчерпан". Happens because `useState(10)` default is optimistic — shows button before API responds with `remaining: 0`.

**Fix:** add `countersLoaded` flag, default `false`:

```typescript
const [countersLoaded, setCountersLoaded] = useState(false);

// In every counter-loading function (loadCounters, loadGame, loadStatus):
setCountersLoaded(true);
```

```tsx
// In betting section:
{!countersLoaded ? (
    <p>Загрузка...</p>
) : remaining <= 0 ? (
    <p>🚫 Дневной лимит исчерпан</p>
) : (
    // actual game UI
)}
```

Apply to BOTH blackjack (CasinoPage) and dice (DiceGame).

## Dice: выбор ставки (10/100/1000) (2026-07-26)

Сервер `routes/dice.ts`: `POST /dice/play` принимает `{ bet: 10 | 100 | 1000 }`, дефолт 10.
```typescript
const bet = [10, 100, 1000].includes(req.body.bet) ? req.body.bet : 10;
```

Клиент `DiceGame.tsx`: кнопки выбора `[10 сер.] [100 сер.] [1000 сер.]` перед кнопкой «Играть».
Проверка баланса и надпись на кнопке динамические под выбранную ставку.

## Dice: таблица выплат (казино) (2026-07-27)

Пара и две пары = проигрыш (как в реальном казино). Выплаты с сета:

```typescript
const PAYOUTS: Record<string, { name: string; mult: number }> = {
    poker: { name: 'Покер', mult: 100 },
    quads: { name: 'Каре', mult: 25 },
    fullhouse: { name: 'Фулл-хаус', mult: 8 },
    straight: { name: 'Стрит', mult: 5 },
    set: { name: 'Сет', mult: 3 },
    twopair: { name: 'Две пары', mult: 0 },
    pair: { name: 'Пара', mult: 0 },
    none: { name: 'Ничего', mult: 0 },
};
```

**Файлы:** `server/src/routes/dice.ts`, `client/src/components/DiceGame.tsx` (PAYOUT_TABLE).
