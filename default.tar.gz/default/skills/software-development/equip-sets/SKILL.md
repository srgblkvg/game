---
name: equip-sets
description: Use when working with equip sets I/II/III.
---

# Equip Sets (I/II/III)

Three independent equipment loadouts switchable via tabs on CharacterCard.

## DB Schema

```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS equipment_1 JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS equipment_2 JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS equipment_3 JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS active_equip_slot INTEGER DEFAULT 1;
-- Migrate existing:
UPDATE users SET equipment_1 = equipment::jsonb WHERE equipment IS NOT NULL AND equipment != '' AND equipment != '{}';
```

Legacy `equipment` (TEXT) column remains — always mirrors the active slot for backward compat with battle queries (`USER_BATTLE_FIELDS`).

## API

### GET /character/me
Returns: `equipment` (active), `equipment1/2/3`, `activeEquipSlot`

### POST /character/switch-equip
Body: `{slot: 1|2|3}`. Saves current `equipment` to old slot column, loads target slot into `equipment`, updates `active_equip_slot`.
Returns: `{success, activeEquipSlot, equipment}`.

**CRITICAL:** After switch-equip, do NOT manually update character state. Always do full `fetchCharacter()` to get fresh stats.

### POST /character/save-equip-set
Body: `{slot: 1|2|3, equipment}`. Saves to `equipment_N`. Syncs `equipment` column if slot is active.

## Client Integration

### CharacterCard props
- `equipSets: Record<number, Record<string, any>>` — {1: {...}, 2: {...}, 3: {...}}
- `activeEquipSlot: number` — current active tab
- `onSwitchSet: (slot: number) => void` — switch handler

Tabs render as I/II/III buttons. Filled slot: `text-[var(--color-text-primary)]`, empty: `text-[var(--color-text-muted)]`, active: `bg-[var(--color-accent-info)] text-white`.

### LeftSidebar
Always shows tabs. `handleSwitchSet` calls `POST /character/switch-equip` then `fetchCharacter()` + `setCharacter(fresh)`.

### ArenaPage
- Tabs visible ONLY before battle: `equipSets={isBattleActive ? undefined : equipSets}`
- During battle: tabs hidden
- `handleSwitchSet` does `fetchCharacter()` only — NO `loadOpponent` (don't spend money, don't re-roll opponent)

## JSONB Pitfall (CRITICAL)

PG returns JSONB columns as objects, not strings. Old `equipment` is TEXT (needs `JSON.parse`). New `equipment_1/2/3` are JSONB (already objects).

**Always use a safe parser:**
```typescript
const parseEq = (v: any) => typeof v === 'string' ? JSON.parse(v || '{}') : (v && typeof v === 'object' ? v : {});
```

**Symptom without:** `SyntaxError: "[object Object]" is not valid JSON` in `/character/me`.

**INSERT also different:** JSONB needs `?::jsonb` cast:
```sql
UPDATE users SET equipment_1 = ?::jsonb WHERE id = ?
```

## Equip/Unequip Sync Pitfall (CRITICAL)

`POST /character/equip` (in `inventory.ts`) updates `equipment` column but does **NOT** sync to active `equipment_N`. Since `GET /character/me` reads `equipment_N` first (line 35 of `character.ts`), after page refresh the OLD equipment reappears — items visually revert, duplicates appear.

**Chain:**
1. Equip new item → `equipment` = new, `equipment_1` = old (NOT updated)
2. Client shows new item (from API response)
3. F5 / switch-equip → `/character/me` reads `equipment_1` → OLD equipment returned
4. `enrichEquipment` on old equipment writes back to `equipment` → BOTH now stale

**Fix:** After every `UPDATE users SET equipment = ...` in `/character/equip`, also sync:
```typescript
const activeSlot = user.active_equip_slot || 1;
await db.run(`UPDATE users SET equipment_${activeSlot} = ?::jsonb WHERE id = ?`,
    [JSON.stringify(equipment), userId]);
```
This applies to BOTH the unequip branch (no itemId) and the equip branch.

**Real case:** Users reported: «Одеваю новый предмет, на секунду появляется старый, после чего исчезает вместе с новым и заменяется на новый, но выше рангом» and «убираю кольцо, делаю обновление страницы, картинка меняется на то же самое кольцо». Root cause was `equipment_1` never updated by `/character/equip`.

## Files Modified
- `server/src/routes/character.ts` — /character/me + switch-equip + save-equip-set endpoints
- `client/src/components/CharacterCard.tsx` — equipSets/activeEquipSlot/onSwitchSet props + tabs UI
- `client/src/components/LeftSidebar.tsx` — handleSwitchSet with fetchCharacter
- `client/src/pages/Arena/ArenaPage.tsx` — tabs hidden during battle
- `client/src/contexts/GameContext.tsx` — equipment1/2/3 + activeEquipSlot in Character interface
- `client/src/utils/character.ts` — `equipment: character.equipment || {}` fallback
