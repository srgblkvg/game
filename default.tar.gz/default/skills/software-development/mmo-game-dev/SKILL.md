---
name: mmo-game-dev
description: Development patterns for the MMO game project at /mnt/c/project/game — deploy, server patterns, frontend pitfalls, and project-specific conventions.
---

# MMO Game Development
Refs: `workflow-rules`, `auction-flow`, `tournaments`, `items-and-drops`, `server-tick-architecture`, `bot-system`, `critical-pitfalls`, `frontend-ui-patterns`, `item-slots`, `vite-build`, `guild-buildings`, `auction-ui`, `rating-ui`, `deploy-and-debug`, `pg-jsonb-filters`, `websocket-client`.
## Shell escaping
Inline `ssh ...` with nested quotes breaks. Prefer `write_file` + `scp`.

### SSH access
Server: `sshpass -p 're8XyUoMH2PD6UCn' ssh root@194.226.142.237` (password auth).
PG direct access: `PGPASSWORD=game123 psql -h localhost -U game -d game`.

### DB queries/migrations on VPS
```bash
# Write script locally → scp → run
cat > /tmp/script.js << 'EOF'
const { Pool } = require("pg");
const pool = new Pool({host:"localhost",user:"game",password:"game123",database:"game"});
(async()=>{ /* queries */ pool.end(); })();
EOF
scp /tmp/script.js root@194.226.142.237:/opt/game/server/
ssh root@194.226.142.237 "cd /opt/game/server && node script.js"
```

PM2: `pm2 restart game-server` picks up `.ts` changes (runs via `npx tsx`). Client: `cd /opt/game/client && npx vite build` then `rsync` whole dist (see `references/vite-deploy-rsync.md`).

**Build pitfall**: `npm run build` = `tsc -b && vite build`. When client has pre-existing TS errors (unused vars, type mismatches), `tsc -b` fails and blocks the build. Workaround: `npx vite build` directly.

## PG pitfalls: `references/pg-pitfalls.md`
## Reward timing: `references/reward-timing.md`

Servers run with `background=true` in pm2, NO `watch_patterns`. Vite HMR is unreliable — always kill+restart+curl after client changes.

## Server Patterns

### System/Bot User (id=0)

For automated messages (tournament warnings, system announcements):
- Insert: `INSERT OR IGNORE INTO users (id, username, passwordHash, currentHp) VALUES (0, 'system', 'system', 100)`
- MUST include `passwordHash` — it's NOT NULL without default, and `INSERT OR IGNORE` silently fails without it
- MUST exclude id=0 from: rating queries (`WHERE id > 0`), battle opponent selection (`AND id > 0`), any user-facing lists
- After inserting a chat message as system, broadcast via WebSocket:
  ```ts
  import { broadcast } from '../websocket';
  const info = db.prepare('INSERT INTO chat_messages ...').run(0, null, content);
  broadcast('message', { message: { id: info.lastInsertRowid, senderId: 0, senderName: 'system', targetId: null, content, createdAt: new Date().toISOString() } });
  ```

### Quest Progress (Snapshot-Based)

Quests track progress via `getSnapshot(userId)` → save snapshot → later diff `getProgress(userId, snapshot, questType)`.
- Hunt quest: use `pveWins` (victories only), NOT `pveTotalBattles` (all battles including losses)
- Arena quest: use `wins` (PvP wins)

### Quest: Hide Claimed from List

After claiming a quest, it should disappear from the list. Filter on SERVER side in the GET endpoint:
```ts
quests: quests.filter((q: any) => q.status !== 'claimed').map(...)
```
`completedToday` count is computed BEFORE the filter from the full array, so it stays correct.

### Quest Daily Carry-Over

Active quests from yesterday carry over to today with progress preserved:
1. On first visit today: find yesterday's `status='active'` quests
2. UPDATE their date and snapshot to today
3. Generate new `available` quests only for missing types
4. `take` endpoint must filter active count by date (`AND date = ?`)
5. API returns `resetAt` (midnight UTC timestamp)

### Regen HP

`applyHpRegen()` in `server/src/game/hpRegen.ts` — lazy pull model:
- Called in `/character/me` for the player themselves
- Called in `/battle` for the DEFENDER only (not attacker — attacker's HP is fresh from `/character/me`)
- Do NOT apply as a pre-battle burst for the attacker
- Updates `lastHpUpdate` in DB on change (correct — shifts the regen baseline)

### Chat Time in UTC

For consistent server time in chat messages, use UTC methods:
- `d.getUTCHours()` / `d.getUTCMinutes()` instead of `d.getHours()` / `d.getMinutes()`
- For ban display: `toLocaleString('ru-RU', { timeZone: 'UTC' })`

## Frontend Pitfalls

### CSS: backdrop-filter creates containing block

`backdrop-blur`, `backdrop-filter`, `transform`, `filter`, `perspective`, and `will-change: transform` on an ancestor create a NEW containing block for `position: fixed` children. This causes "fixed" elements to position relative to the ancestor instead of the viewport.

**Symptoms**: Tooltips/menus appear in the wrong place — offset from where they should be, or clipped by ancestor boundaries.

**Fix**: `createPortal(<Element />, document.body)` from `react-dom`. This renders the element directly into `<body>`, bypassing any CSS containing blocks. Always use portal for tooltips, modals, and dropdowns that need viewport-relative positioning.

### Zod: float IDs breaking .int() validation

Item IDs in the game are floats (`Date.now() + Math.random()`), but Zod websocket schemas used `z.number().int()`. This silently rejects float IDs — `safeParse` returns `success: false` and the server drops the message without logging.

**Fix**: Use `z.number().positive().optional()` without `.int()` for ID fields that may be floats. The `.positive()` check is sufficient.

### SQL: selective field updates

When updating a row, sending `undefined` for an optional field followed by `undefined || null` overwrites existing values with `null`. This caused job backgrounds to be erased when editing other fields.

**Fix**: Build dynamic UPDATE queries — only include fields that are actually present in the request body:
```javascript
const fields = [];
const values = [];
if (background !== undefined) { fields.push('background=?'); values.push(background || null); }
// ... then db.prepare(`UPDATE ... SET ${fields.join(',')}`).run(...values)
```

See `references/admin-image-upload.md` for the admin image upload system (ImageUploader component, gallery API, body size limits).

### Batch File Editing

When removing a component used across many files (e.g., `<BackButton />`), script-based batch patching may miss files with multiple instances — the first removal shifts line numbers, causing the second instance's old_string to no longer match. Always run a verification search after batch edits.

### Sticky Header z-index

Header uses `sticky top-0 z-40`. Card content elements MUST NOT have their own `z-index` (even `z-10`) — this creates a stacking context that overlaps the header. Use DOM order within cards instead: content after background in markup naturally sits on top. Hierarchy: modals (`z-50`) > header (`z-40`) > everything else (auto).

**Pitfall — settings popup vs RightSidebar toggle button**: The settings dropdown (inside Header) and the RightSidebar toggle button (fixed) compete for stacking. Since the dropdown is `absolute` inside Header's stacking context, raising the dropdown's z-index inside the Header can't lift it above the toggle button in the root stacking context. **Correct fix**: portal the popup to `document.body` via `createPortal` from `react-dom`, using `position: fixed` + independent `z-[70]`. Then set Header to `z-40`, toggle button to `z-[45]`, popup to `z-[70]` — all in the root stacking context. Stacking order: popup > toggle > header.

```tsx
import { createPortal } from 'react-dom';

// Popup uses fixed positioning (not absolute — no longer inside Header's stacking context):
{menuOpen && createPortal(
    <div ref={popupRef} className="fixed right-3 top-11 mt-1 w-44 ... z-[70]">
        ...
    </div>,
    document.body
)}
```

**Pitfall — click-outside detection after portal**: When the popup is portaled to body, it's no longer inside `menuRef`. The click-outside handler must also check `popupRef`:
```tsx
const popupRef = useRef<HTMLDivElement>(null);
// In click-outside handler:
if (menuRef.current && !menuRef.current.contains(target) && popupRef.current && !popupRef.current.contains(target)) {
    setMenuOpen(false);
}
```

### Mobile Scroll + Hash

`window.location.hash = ''` triggers a page scroll to top on mobile (browser behavior). Use `history.replaceState(null, '', window.location.pathname + window.location.search)` to clear the hash without scrolling.

### Spacing Between Inline Spans

Tailwind `ml-1` adds margin but text still runs together visually. Add a leading space inside the span content: ` +{n} XP` rather than `+{n} XP`.

### Server Time (Global Context)

For consistent time across the client, use `ServerTimeContext` (`client/src/contexts/ServerTimeContext.tsx`):
- Fetches `/api/time` once, stores offset from server, ticks every second
- Exposes `{ now }` — always server time (UTC Unix timestamp)
- Endpoint MUST be before `authMiddleware` in setupRoutes (otherwise 401)
- Display: `new Date(now * 1000).toLocaleTimeString('ru-RU', { timeZone: 'UTC' })` — without `timeZone: 'UTC'` it shows local time instead

### Auction Item Images

Items don't have `imageUrl` — use `getItemImage(item)` from `utils/itemUtils.ts` which builds paths like `/sword/sword_blue.webp` from `item.slot`/`item.type`/`item.rarity_id`. Fallback: `/items/default.webp`.

### Tooltip Dual Mode (hover + long-press)

Pattern for showing tooltips on both desktop (hover) and mobile (long-press):
- `supportsHover = useRef(matchMedia('(hover: hover)').matches)` — gate hover events
- `onMouseEnter/Move/Leave` for desktop, guarded by `supportsHover`
- `onTouchStart` (500ms timer) + `onTouchEnd` (clear timer) for mobile
- `onContextMenu={e => e.preventDefault()}` — block browser context menu on long-press
- `ref` on wrapper div around tooltip + document `touchstart`/`mousedown` listener to hide on tap outside
- Pitfall: `ItemTooltip` is not `forwardRef` — wrap in `<div ref={ref}>`

### Battle History: XP Only for Winner

In `HistoryPage.tsx`, `expGained` is stored in the battles table as a single value (the winner's XP). When rendering, wrap `expGained` display in `win &&` check — otherwise losers see `+N XP` they never received.

### formatMoney for All Currency

Always use `formatMoney(n)` from `utils/money` for currency display. Never raw numbers with emoji (e.g., `500 🥇` → `Призовой фонд: 500 серебра`). The function returns `"N серебра"` — the full text including the currency word.

### Breadcrumbs

Header has a `Breadcrumbs` component centered below the main bar. To add a new route, add it to `breadcrumbMap` in `Header.tsx`. The map key is the URL segment, value is the display name. Numeric IDs in paths are automatically skipped. Root is labeled `'Персонаж'` (not `'Главная'`).

### Header Bar Layout

The header bar layout (left to right): Серебро | Защита | Часы | 📓 Сводка | ⚙ Настройки.

Settings popup items: Аккаунт, 📖 Wiki, Сообщество VK.

**Сводка** shows a blinking red dot for: new battle reports (`hasNewBattles`) OR new private messages (`hasUnreadPM`). Both are tracked independently — battles via API polling, PMs via `useGlobalChat().messages` + `localStorage('lastPMSeen')`. Clicking Сводка clears both and navigates to `/history`.

### Settings Popup

The gear icon (mdi:cog) opens a popup portaled to `document.body` with: Аккаунт, 📖 Wiki, Сообщество VK.

Wiki links to `/wiki/` (opens in new tab), uses `game-icons:open-book` icon in green. Added between Аккаунт and VK.

**Сводка** is a standalone button (NOT inside the popup). It shows the notebook icon (`game-icons:notebook`) with a red blinking dot when `hasNewBattles` is true. Click navigates to `/history` via `handleHistoryClick`.

**Red dot indicator**: lives on the Сводка button, NOT on the settings cog. Shows when `hasNewBattles || hasUnreadPM` is true. When Сводка was inside the popup, the dot was on the cog as a signal — after extracting Сводка to a standalone button, move the dot there. The cog should have no indicator.

**PM notification tracking**: Header watches `messages` from `useGlobalChat()` for new private messages (where `targetId === userId && senderId !== userId`). Uses `localStorage` key `lastPMSeen` (timestamp) to determine if the PM is new since the last time Сводка was opened:

```tsx
import { useGlobalChat } from '../contexts/ChatContext';

const { messages } = useGlobalChat();
const [hasUnreadPM, setHasUnreadPM] = useState(false);
const userId = user?.id;

useEffect(() => {
    if (!userId || messages.length === 0) return;
    const lastPMSeen = parseInt(localStorage.getItem('lastPMSeen') || '0');
    const lastMsg = messages[messages.length - 1];
    if (lastMsg.targetId === userId && lastMsg.senderId !== userId) {
        const msgTime = new Date(lastMsg.createdAt).getTime();
        if (msgTime > lastPMSeen) setHasUnreadPM(true);
    }
}, [messages.length, userId]);

const handleHistoryClick = () => {
    localStorage.setItem('lastHistorySeen', Date.now().toString());
    localStorage.setItem('lastPMSeen', Date.now().toString());  // clear PM notification
    setHasNewBattles(false);
    setHasUnreadPM(false);
    setMenuOpen(false);
    navigate('/history');
};
```

The red dot shows when `(hasNewBattles || hasUnreadPM)` — battles OR private messages trigger it. Both are cleared when clicking Сводка.

Pattern for the settings popup:
- `menuOpen` state + `menuRef` for outside-click close
- `useEffect` with `document.addEventListener('mousedown', handler)` to detect click outside
- Popup portaled to `document.body` via `createPortal` (see stacking context pitfall above)
- Menu items: `cursor-pointer` + `hover:bg-hover` + `onClick` that calls `setMenuOpen(false)` before navigating

### Job History: XP Display

Jobs grant XP on completion, but the `job_history` table originally had no column for it. The INSERT in `character.ts` calculated `expGain = jobData.expReward || 0` but never saved it. HistoryPage only showed money + premium bonus.

**DB migration**:
```ts
try { db.exec('ALTER TABLE job_history ADD COLUMN xpGained INTEGER DEFAULT 0'); } catch {}
```

**Server INSERT** (`routes/character.ts`):
```ts
db.prepare('INSERT INTO job_history (userId, jobId, jobName, duration, reward, startedAt, premiumBonus, xpGained) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(userId, jobData.jobId, jobData.name, jobData.duration, jobData.reward, ...startedAt, jobData.premiumBonus || 0, expGain);
```

**Client render** (HistoryPage.tsx — both `renderJobRow` and the "all" tab `renderEntry`):
```tsx
<span>«{j.jobName}» — {formatMoney(j.reward)}
  {j.premiumBonus>0 && <span className="text-[#f1c40f]"> (+{j.premiumBonus} пр.)</span>}
  {j.xpGained>0 && <span className="text-[var(--color-accent-purple)] ml-1">+{j.xpGained} XP</span>}
</span>
```

### PvE History: Premium Bonus Display

PvE battles against mobs grant a +30% gold bonus for premium users. The `pve_battles` table originally had no column for this. The SELECT + INSERT in `mobs.ts` calculated `premiumBonus` but never saved it. HistoryPage showed only `goldGained` without indicating how much was the bonus.

**DB migration**:
```ts
try { db.exec('ALTER TABLE pve_battles ADD COLUMN premiumBonus INTEGER DEFAULT 0'); } catch {}
```

**Server INSERT** (`routes/mobs.ts`):
```ts
db.prepare(`INSERT INTO pve_battles (..., premiumBonus) VALUES (..., ?)`)
    .run(..., premiumBonus);
```

**Client render** (HistoryPage.tsx — both `renderPveRow` and the "all" tab `renderEntry`):
```tsx
{b.goldGained>0 && <span className="text-[var(--color-text-accent)] ml-1">
  +{formatMoney(b.goldGained)}
  {b.premiumBonus>0 && <span className="text-[#f1c40f]"> (+{b.premiumBonus} прем.)</span>}
</span>}
```

The premium bonus is shown in gold color `#f1c40f` next to the total gold, e.g. `+15 (+4 прем.)`. Old records have `premiumBonus = 0` (column didn't exist before).

### TavernPage Quests: Counter Shows Remaining Available (Countdown 5→0)

In the tavern page quests tab (`TavernPage.tsx`), the counter line shows how many MORE quests the player can take today (remaining from the daily limit), counting DOWN from 5 to 0 as quests are taken:

```tsx
Активно: {quests.activeCount}/3 • Доступно сегодня: {quests.dailyLimit - quests.activeCount - quests.completedToday}/{quests.dailyLimit}
```

- Label: "Доступно сегодня" (was "Выполнено сегодня")
- Counter: `dailyLimit - activeCount - completedToday` — remaining, decreases from 5→0
- Initially shows `5/5`, counts down to `0/5` as quests are taken

**Pitfall — QuestsBlock vs TavernPage confusion**: The QuestsBlock (right sidebar) was also changed to use this counter pattern, but the user reverted it — the sidebar should stay simple (`active.length/3`). Only the full tavern page should show the taken-today counter. Always confirm WHICH component the user is referring to before modifying quest logic.

### Import Replacement Pitfall

When adding a new import to a file, verify the patch doesn't accidentally REPLACE an existing import. Example: adding `useServerTime` import where `fetchCharacter` import exists — the `old_string` must include BOTH imports, not just the target line. Symptom: `Cannot find name 'fetchCharacter'` after the change.

### Duplicate Declaration After Refactoring

When moving a `const` declaration later inside a `useCallback` or other block, always remove the OLD declaration at the original position. Symptom: build fails with `Identifier 'X' has already been declared`. This happened when `isGuildInvite` was moved from the top of `renderMessageContent` to after the `accept/decline` functions — both declarations remained. Always verify after refactoring with a search for the variable name.

## TypeScript Pitfalls

### noUncheckedIndexedAccess + Array Indexing

Server tsconfig has `"noUncheckedIndexedAccess": true`. This makes ALL array index accesses return `T | undefined`:

```ts
const parts = str.split(' ');   // parts: string[]
const token = parts[1];          // token: string | undefined  ← guarded!
```

Any function expecting `string` will fail with TS2769. Always add a guard before using indexed array values:

```ts
const token = authHeader.split(' ')[1];
if (!token) return res.status(400).json({ error: 'Невалидный токен' });
jwt.verify(token, JWT_SECRET);  // token is now string
```

This applies to `.split()[n]`, any `arr[n]`, and object bracket notation. The `!` non-null assertion only works on the export side — consumers of the exported value still see the guarded type.

### Zod Silent Validation Failures (WebSocket)

WebSocket message schemas often use `z.number().int()` for IDs. But equipment items get float IDs from `Date.now() + Math.random()` (e.g., `1717932000123.456`). When validation fails, `safeParse` rejects SILENTLY — the handler just returns, no error logged anywhere.

**Symptom**: shift+click on equipment items doesn't work, but craft items work fine. Craft items have integer DB IDs; equipment items have float IDs.

**Fix**: use `z.number().positive()` without `.int()`:
```ts
// Broken for float IDs:
itemId: z.number().int().positive().optional(),
// Works for both int and float:
itemId: z.number().positive().optional(),
```

**Debugging tip**: any `safeParse` followed by silent `return` hides validation bugs. Temporarily add `console.log('validation failed', parsed.error)` to surface the rejection during debugging.

### sendItemLink: Second Argument Required

`sendItemLink(itemId, itemData)` — the second argument (the full item object) is used by the server as `data.itemData`. Without it, the server falls back to inventory lookup by ID, which may fail for equipped/equipment items (different ID format).

**Symptom**: shift+click works for craft items but not equipment items. The server silently returns when `!item` after both `itemData` and inventory lookup fail.

**Fix**: always pass the item object: `sendItemLink(item.id, item)`, never just `sendItemLink(item.id)`.

**Places to check**: Inventory.tsx line ~164 (equipment grid), CharacterCard.tsx (equipped items), CraftPage.tsx, AuctionPage.tsx — any call to `sendItemLink`.

## Chat: DB History + WebSocket + localStorage (Hybrid)

Chat messages come from THREE sources, working together:

1. **DB history** — 10 most recent messages loaded from REST endpoints when opening each tab
2. **WebSocket** — real-time messages delivered live
3. **localStorage** — last 100 messages persisted for survival across page refreshes

`addMessages()` in ChatContext deduplicates by `id`, so DB-loaded and WS-delivered messages merge cleanly — duplicates are silently skipped. In-memory cap is 300 messages.

### DB History Loading (per-tab)

Three `useEffect` hooks in `ChatPanel.tsx` fire when the active tab changes:

```ts
// General (public) tab — when visible and no private/guild tab active
useEffect(() => {
    if (!visible) return;
    if (privateChatWith !== null || guildChatActive) return;
    fetchRecentMessages(10)
        .then((msgs: ChatMessage[]) => addMessages(msgs))
        .catch(console.error);
}, [visible, privateChatWith, guildChatActive, addMessages]);

// Private tab
useEffect(() => {
    if (!visible || privateChatWith === null) return;
    fetchPrivateMessages(privateChatWith, 10)
        .then((msgs: ChatMessage[]) => addMessages(msgs))
        .catch(console.error);
}, [visible, privateChatWith, addMessages]);

// Guild tab
useEffect(() => {
    if (!visible || !guildChatActive || !guildId) return;
    fetch(`${BASE_URL}/guild/chat`, { headers: getHeaders() })
        .then(r => r.json())
        .then((msgs: ChatMessage[]) => addMessages(Array.isArray(msgs) ? msgs : []))
        .catch(console.error);
}, [visible, guildChatActive, guildId, addMessages]);
```

### Client API (`client/src/api/chat.ts`)

```ts
export async function fetchRecentMessages(limit = 10) {
    const res = await fetch(`${BASE_URL}/chat/recent?limit=${limit}`, { headers: getHeaders() });
    return res.json();
}

export async function fetchPrivateMessages(userId: number, limit = 10) {
    const res = await fetch(`${BASE_URL}/chat/private/${userId}?limit=${limit}`, { headers: getHeaders() });
    return res.json();
}
```

### Server Endpoints

- `GET /chat/recent?limit=N` — public messages (ORDER BY createdAt DESC, reversed to ASC; default limit 10)
- `GET /chat/private/:userId?limit=N` — private messages (ORDER BY createdAt DESC, reversed to ASC; default limit 100). Supports `?limit=N` query param for per-tab loading.
- `GET /guild/chat` — guild messages (LIMIT 10, reversed to ASC)

### ChatContext localStorage (auto-save)

```ts
// Init from localStorage on mount
const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try { return JSON.parse(localStorage.getItem('chat_messages') || '[]'); } catch { return []; }
});

// Auto-save last 100 on every change
useEffect(() => {
    try { localStorage.setItem('chat_messages', JSON.stringify(messages.slice(-100))); } catch {}
}, [messages]);
```

### Deduplication + Sorting

`addMessages` deduplicates by `id` and caps at 300 in-memory. `displayedMessages` useMemo must sort by `createdAt` after filtering:

```ts
.filter(...).sort((a, b) =>
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
)
```

## PG CamelCase & Type Pitfalls

See `references/pg-pitfalls.md` for compound column name conversion rules, SQL type mismatches, tournament await fixes, and guild war money filtering.

## Guild System

### DB Schema

```
guilds: id, name (UNIQUE), description, leaderId, joinType (open|request|invite), level, exp, treasury, createdAt
guild_members: guildId, userId (UNIQUE), rank (leader|officer|member), joinedAt — PRIMARY KEY (guildId, userId)
guild_invites: id, guildId, userId, invitedBy, status (pending|accepted|declined), createdAt
users.guildId — FK to guilds.id (nullable)
```

Server: `server/src/routes/guild.ts`, registered in `setupRoutes.ts` before guest-blocked routes.

### Invites via PM

When inviting to guild, send a private message from system (id=0) with `item_data` containing `{ type: 'guild_invite', guildId, guildName }`. Use `broadcast('message', ...)` from websocket so it appears in real time.

### Client Page

`/guild` — `GuildPage.tsx`. Two states:
- **Not in guild**: show create form + guild list with join buttons (text varies by joinType: open→"Вступить", request→"Заявка", invite→"Закрыто")
- **In guild**: show guild info, invite input (leader/officer only), member list

Card in Actions: `{ icon: 'game-icons:castle', title: 'Гильдия', path: '/guild' }` in `castleCards` array.
Breadcrumb: `guild: 'Гильдия'` in `breadcrumbMap`.

### Guild View Page (`/guild/:id`)

Separate public page at `/guild/:id` (`GuildViewPage.tsx`) for viewing a guild's info:

- **Server**: `GET /api/guild/:id` — returns `{ guild: { ...fields, leaderName, memberCount }, members: [...] }`.
- **Client**: Shows guild name, description, level, leader, member count, join type with icon. Member list with clickable usernames to `/profile/:userId`.
- **Non-member**: Shows Вступить/Подать заявку button depending on joinType.
- **Member**: Shows "Управление гильдией" button → `/guild`.
- **Route**: `path="/guild/:id"` in App.tsx, lazy-loaded. Must be AFTER `/guild` in React Router to avoid `:id` matching "my"/"create" etc.
- **Links**: RatingBlock guild names navigate to `/guild/${g.id}`, same for GuildPage guild list.

**Pitfall — route ordering in Express**: `GET /guild/:id` must be defined AFTER ALL literal routes in the guild router. Express matches routes in definition order. If `/guild/:id` catches a literal route name as `:id`, the result is a **404** — the literal route is never reached. **This happened in production**: `/guild/chat` was at the END of the file (after `:id`), so `GET /api/guild/chat` returned 404. The fix was physically moving the chat routes to before `router.get('/guild/:id', ...)`.

All these routes MUST come BEFORE `/guild/:id` in the file: `/guild/my`, `/guild/list`, `/guild/chat`, `/guild/requests`, `/guild/invites`, `/guild/join/:id`, `/guild/request/:id`, `/guild/invite`, `/guild/accept-invite`, `/guild/invite/:id`, `/guild/handle-request`, `/guild/leave`, `/guild/kick`, `/guild/role`, `/guild/cancel-invites`. Same principle for React Router: `/guild/:id` must be AFTER `/guild` and `/guild/rating` in the JSX route definitions.

### Guild Chat Integration

Guild chat uses convention `targetId = -guildId` in `chat_messages` table (negative guild ID = guild message). This reuses the existing `chat_messages` table without schema changes.

**Server endpoints** in `server/src/routes/guild.ts`:
- `GET /api/guild/chat` — returns last 10 guild messages (WHERE targetId = -guildId, LIMIT 10), reversed to chronological
- `POST /api/guild/chat` — inserts message with `targetId = -guildId`, broadcasts to all guild members via WebSocket

**Client integration** in `ChatPanel.tsx`:
- Fetch guild info on mount: `GET /api/guild/my` → set `guildId` and `guildName`
- `guildChatActive` boolean — toggled by guild tab click
- Guild tab in `ChatTabs`: non-closable (no × button), green color — `#2ecc71` text, `#1a3a1a` active background, 🏚️ icon
- Message filter in `displayedMessages`: `msg.targetId === -guildId` when guild tab active
- Guild messages styled green in `MessageList.tsx`: nick color `#2ecc71`, bubble background `#1a3a1a`, bubble text `#2ecc71`. Detection: `const isGuild = firstMsg.targetId !== null && firstMsg.targetId < 0` (negative targetId = guild message)
- Send handler: calls `POST /api/guild/chat` instead of `sendPublic` when guild tab active OR when message starts with `/g `
- `/g текст` command works from ANY chat tab (public or private) — parsed in `handleSend` after `/w` but before the auto-guild check
- `isPrivate` flag on `ChatInput`: true for both private AND guild (hides @mention logic for guild)
- `ChatTabs` props added: `guildChatActive`, `guildName`, `onSelectGuild`
- **Pitfall — sender can't see own messages**: `POST /api/guild/chat` returns `{ message: msg }` in response. Must call `addMessages([d.message])` from the response. The WebSocket broadcast only goes to OTHER guild members (excludes sender). Without adding from response, sender never sees their own guild messages
- **React Hooks Deps Completeness (GENERAL)**: Any `useEffect`, `useCallback`, or `useMemo` that reads state variables MUST include ALL of them in the deps array. Missing deps cause SILENT bugs — the hook body captures stale values from the previous render. This happened 4+ times during guild chat implementation:\n  - `handleSend` useCallback: missing `guildChatActive`, `guildId` → guild tab sent messages to public chat\n  - Guild chat load useEffect: missing `guildChatActive`, `guildId`, `character` → `/api/guild/chat` never called\n  - Guild info useEffect: missing `character?.guildId` → stale after invite accept\n  - `renderMessageContent` useCallback: missing `setCharacter` → ReferenceError\n  **Rule**: after writing a hook body, scan for every state value or derived property used inside it and verify each one appears in the deps array. When in doubt, include more deps — re-running an effect is always safer than running with stale data.\n\n**Pitfall — stale guildId after accept**: `guildId` state in ChatPanel is set from `useEffect([user?.role])`. After accepting an invite, character refreshes but guildId state doesn't. Fix: add `character?.guildId` to the useEffect dependency array

**Pitfall — useCallback stale closure on guildChatActive**: `handleSend` in ChatPanel uses `useCallback` with deps `[privateChatWith, onlineUsers, sendPublic, sendPrivate]` but NOT `guildChatActive` or `guildId`. When the guild tab is selected, the callback still uses stale `guildChatActive=false` and sends messages to public chat instead of guild. **Always include ALL state values used inside the callback in the dependency array**: `[privateChatWith, guildChatActive, guildId, character, onlineUsers, sendPublic, sendPrivate, setChatError, addMessages]`. This is a silent bug — no errors, just wrong behavior. Symptom: guild chat "works with /g but not without /g" when guild tab is active.

**Pitfall**: `ChatTabs` must accept new props (`guildChatActive`, `guildName`, `onSelectGuild`) without breaking existing usage. Guild tab is only rendered when `guildName` is truthy.

**Pitfall — `api()` helper sends GET instead of POST**: When a client helper like `const api = (url, body?) => fetch(url, { method: body ? 'POST' : 'GET', ... })` is called without a body (`api('/guild/join/1')`), the method resolves to GET. Server routes registered as `router.post(...)` return 404 for GET. Always pass an empty object `{}` for POST endpoints with no data: `api('/guild/join/1', {})`. This applies to `join`, `request`, `leave`, and any other POST endpoint that takes no body.

### Guild Management (Kick, Role, Requests)

**Server endpoints** in `server/src/routes/guild.ts`:
- `POST /api/guild/kick` — kick member (leader/officer). Body: `{ targetId }`. Leader can kick anyone except self. Officer can't kick other officers.
- `POST /api/guild/role` — change role (leader only). Body: `{ targetId, rank }`. Rank: 'officer'|'member'. Can't change leader's role.
- `GET /api/guild/requests` — pending join requests (leader/officer). Returns list with `id, userId, username`.
- `POST /api/guild/handle-request` — accept/decline request. Body: `{ requestId, accept: boolean }`.

**Client UI** (GuildPage.tsx):
- Member list: role displayed as text (лидер/офицер/боец) next to username
- Buttons (Офицер/Разжаловать + Исключить) in one row, pushed right via `ml-auto`
- Leader sees role toggle button for non-leader members
- Both leader and officer see kick button (with rank restrictions)

### User Search by Name

Endpoint `GET /api/users/search?q=` in `server/src/routes/character.ts`:
```ts
router.get('/users/search', (req, res) => {
    const q = req.query.q;
    if (!q || q.length < 2) return res.json([]);
    const users = db.prepare('SELECT id, username, level FROM users WHERE username LIKE ? AND id > 0 LIMIT 10').all(`%${q}%`);
    res.json(users);
});
```

Used for guild invite autocomplete. Client: text input → `searchUsers(q)` on change → dropdown list with username + level. Click selects user and sets `inviteTargetId`.

### Guild Invite Autocomplete

In GuildPage.tsx invite section:
- Replace `<input type="number" placeholder="ID игрока">` with `<input type="text" placeholder="Имя игрока">`
- On input change: call `searchUsers(e.target.value)` → sets `inviteSuggestions`
- Dropdown: absolute positioned below input, `z-10`, shows matching users
- Click suggestion: `setInviteName(u.username)`, `setInviteTargetId(u.id)`, clear suggestions
- `handleInvite` checks `inviteTargetId` is set before sending

### Guild Invite Cooldown & Resend

When a pending invite already exists for the same player:
- **< 1 hour**: reject with `Приглашение уже отправлено. Повторно можно через N мин`
- **>= 1 hour**: auto-cancel the old invite (`status = 'declined'`) and send a new one

Server logic in `POST /api/guild/invite`:
```ts
const existing = db.prepare(
    "SELECT id, createdAt FROM guild_invites WHERE guildId = ? AND userId = ? AND status = 'pending'"
).get(guildId, targetId);
if (existing) {
    const elapsed = Math.floor(Date.now() / 1000) - Math.floor(new Date(existing.createdAt + 'Z').getTime() / 1000);
    if (elapsed < 3600) {
        return res.status(400).json({ error: `Повторно можно через ${Math.ceil((3600 - elapsed) / 60)} мин` });
    }
    db.prepare("UPDATE guild_invites SET status = 'declined' WHERE id = ?").run(existing.id);
}
```

### Guild Cancel All Invites

Endpoint `POST /api/guild/cancel-invites` (leader/officer): sets all pending invites for the guild to `'declined'`. Client button: «Отменить все приглашения» in the invite section, shows how many were cancelled.

### Guild Invite Accept/Decline in Chat

When a guild invite appears as a private message with `item.type === 'guild_invite'`, render Принять/Отклонить buttons below the message text:

```tsx
const isGuildInvite = msg.item?.type === 'guild_invite' && !msg.item?.used;
// On accept/decline:
msg.item = { ...msg.item, used: true };  // hides buttons immediately
// ... render buttons that call:
fetch('/api/guild/accept-invite', {
    method: 'POST',
    body: JSON.stringify({ guildId: msg.item.guildId, accept: true/false }),
});
```

**Pitfall — buttons reappear after page reload**: Setting `msg.item = null` only mutates the in-memory object, not the server state. On page reload, chat messages are re-fetched from the server with `item` intact. Solution: add `!character?.guildId` to the `isGuildInvite` condition — once the player is in a guild, buttons are always hidden. Also set `msg.item = { ...msg.item, used: true }` for immediate hiding before character refresh completes. Requires `character.guildId` in the `/character/me` API response (must be explicitly added — `guildId: user.guildId || null`).

**Pitfall — guild messages appear in general chat**: The `displayedMessages` filter for general chat (`privateChatWith === null`) includes `msg.senderId === userId` to show the user's own private messages in the general tab. But guild messages also have `senderId === userId` (with `targetId < 0`). Fix: add `&& !(msg.targetId !== null && msg.targetId < 0)` to exclude all guild messages (negative targetId) from the general tab filter. `MessageList.tsx` checks `msg.item ?` to render item-link bubbles for any message with an `item` property. Guild invites have `item: { type: 'guild_invite', ... }` which would render as `[undefined]`. Fix: change the check to `msg.item && msg.item.type !== 'guild_invite' ?` so guild invites fall through to regular text rendering where `renderContent` adds buttons.

**Pitfall — `setCharacter` must be destructured**: When calling `setCharacter(fresh)` inside a `renderMessageContent` callback, `setCharacter` must be destructured from `useGame()`: `const { character, setCharacter } = useGame()`. If only `character` is extracted, `setCharacter` is `undefined` → `ReferenceError` at runtime. The destructuring is easy to miss when adding guild invite handling to ChatPanel which previously only read `character`.

Endpoint `POST /api/guild/accept-invite` accepts `{ guildId, accept }` — finds the pending invite by `guildId + userId`, accepts or declines. On accept: inserts into `guild_members`, updates `users.guildId`. Must call `setCharacter(fresh)` after accept to refresh the UI.

### Ring Slot Filter: DB `slot: 'ring'` vs Equipment Slots `ring1`/`ring2`

Rings in the DB (`items` table) have `slot: 'ring'`. But equipment slots on the character card are `ring1` and `ring2`. The `slotCategories` map correctly: `ring1 → 'ring'`, `ring2 → 'ring'`. However, `getFilteredItems()` in `CharacterCard.tsx` (the function that lists available inventory items when clicking an empty slot) only checked `item.slot === 'ring1' || item.slot === 'ring2'` — missing `item.slot === 'ring'`.

**Symptom**: click on `ring1`/`ring2` slot → item selector shows no rings. Drag-and-drop works fine (uses `getCompatibleSlots()` which handles `'ring'` correctly).

**Fix**: add `|| item.slot === 'ring'`:
```ts
if (cat === 'ring') return item.slot === 'ring1' || item.slot === 'ring2' || item.slot === 'ring';
```

### Weapon Slot Filter: Show Only Compatible Items per Slot

`getFilteredItems()` in `CharacterCard.tsx` originally returned ALL weapon-category items for any weapon slot click:

```ts
// BROKEN — shows shields in weapon1, swords in shield slot
if (cat === 'weapon') return item.slot === 'weapon1' || item.slot === 'shield';
```

**Symptom**: clicking weapon1 slot shows shields; clicking shield slot shows swords.

**Fix**: filter by the actual clicked slot. Two-handed weapons are stored as `slot: 'weapon1'` and block the shield slot (handled by `isWeapon2Blocked`).

```ts
if (cat === 'weapon') {
    if (selectedSlot === 'shield') return item.slot === 'shield';
    return item.slot === 'weapon1';
}
```

## Chat Unread Indicators (Blinking Dots)

When collapsed or on inactive tabs, show colored blinking dots for new messages from other users. **PMs no longer appear in the general tab** — each PM gets its own auto-created tab with indicators. **Guild messages no longer appear in the general tab** — they only show in the guild tab.

**Pitfall — guild messages double-display**: When `displayedMessages` filter for general tab uses `msg.senderId === userId || msg.targetId === userId`, guild messages sent by the user match `senderId === userId` and appear in BOTH general and guild tabs. Fix: add `&& !(msg.targetId !== null && msg.targetId < 0)` to exclude guild messages (negative targetId) from general tab. The general tab filter should ONLY return messages where `msg.targetId === null` (public).

**Pitfall — guild invite item-link rendering**: `MessageList.tsx` checks `msg.item ?` to render item-link bubbles. Guild invites have `item: { type: 'guild_invite', ... }` → renders as `[undefined]`. Fix: change to `msg.item && msg.item.type !== 'guild_invite' ?` so invites render as text with buttons via `renderContent`.

**State** in ChatPanel:
```ts
const [unreadGeneral, setUnreadGeneral] = useState(0);
const [unreadPrivate, setUnreadPrivate] = useState<Map<number, number>>(new Map());
const [unreadGuild, setUnreadGuild] = useState(0);
```

**Detection** — watch `messages.length` (not the array reference, which doesn't change on append):
```ts
useEffect(() => {
    if (messages.length === 0) return;
    const last = messages[messages.length - 1];
    if (last.senderId === userId) return; // skip own messages
    // General: notify when inactive tab OR collapsed
    if (last.targetId === null && (privateChatWith !== null || guildChatActive || !isPanelOpen)) {
        setUnreadGeneral(c => c + 1);
    // Guild: notify when inactive tab OR collapsed
    } else if (last.targetId < 0 && (!guildChatActive || !isPanelOpen)) {
        setUnreadGuild(c => c + 1);
    // PM: auto-create tab + notify when inactive tab OR collapsed
    } else if (last.targetId > 0 && last.targetId === userId) {
        const fromId = last.senderId;
        if (!isPanelOpen || privateChatWith !== fromId) {
            setUnreadPrivate(prev => { const n = new Map(prev); n.set(fromId, (n.get(fromId)||0)+1); return n; });
        }
        addTab(fromId, last.senderName); // auto-create PM tab
    }
}, [messages.length]);
```

**Key rules**:
- `!isPanelOpen` overrides active-tab checks — when collapsed, ALL unread increment regardless of last active tab
- PMs auto-create a tab for the sender via `addTab(fromId, fromName)`
- General tab filter excludes guild (targetId < 0) and PM (targetId > 0): `return msg.targetId === null;`
- PM filter: `(msg.senderId === userId && msg.targetId === privateChatWith) || (msg.senderId === privateChatWith && msg.targetId === userId)` — shows only the conversation with the selected user

**Display**:
- On ChatTabs: small colored dot next to tab name when `unread > 0 && !isActive`
- On collapsed panel header: blinking dots (white=general, green=guild, purple=PM) via CSS animation:
```css
.chat-blink { animation: blink 1s infinite; }
@keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
```

**Clear** — reset unread on tab switch or panel open: `setUnreadGeneral(0)`, `setUnreadGuild(0)`, `setUnreadPrivate(prev => { n.delete(id); return n; })`.

### Chat Last-Read Tracking (localStorage — Persists Across Refreshes)

Without persistence, after a page refresh ALL cached messages appear as "new." Solution: store the ID of the last read message per chat type in localStorage:

- `chatLastReadGeneral` — general chat
- `chatLastReadGuild` — guild chat
- `chatLastReadPrivate_<userId>` — each private conversation

**Approach: Full recompute on every messages change** (NOT initial+incremental):

The initial+incremental split was unreliable — the `initialScanDone` ref got out of sync, `addMessages` batches confused the incremental logic, and messages arriving between panel close and page refresh caused false unread counts. The fix: ALWAYS recompute unread from scratch. `messages` is capped at 300 — O(n) scan is trivially fast.

```tsx
const LS_GENERAL = 'chatLastReadGeneral';
const LS_GUILD = 'chatLastReadGuild';
const lsPrivate = (uid: number) => `chatLastReadPrivate_${uid}`;
const getLastRead = (key: string): number => parseInt(localStorage.getItem(key) || '0') || 0;
const saveLastRead = (key: string, id: number) => { if (id > getLastRead(key)) localStorage.setItem(key, String(id)); };

// Full recompute — runs on EVERY messages change
const prevMsgCount = useRef(0);
useEffect(() => {
    if (messages.length === 0) return;
    const lastReadGeneral = getLastRead(LS_GENERAL);
    const lastReadGuild = getLastRead(LS_GUILD);
    setUnreadGeneral(messages.filter(m => m.senderId !== userId && m.targetId === null && m.id > lastReadGeneral).length);
    setUnreadGuild(messages.filter(m => m.senderId !== userId && m.targetId !== null && m.targetId < 0 && m.id > lastReadGuild).length);
    const priv = new Map<number, number>();
    // Only auto-open tabs for messages that just arrived (not historical)
    const newMsgs = messages.slice(prevMsgCount.current);
    prevMsgCount.current = messages.length;
    for (const m of messages) {
        if (m.senderId === userId) continue;
        if (m.targetId !== null && m.targetId > 0 && m.targetId === userId) {
            const lastRead = getLastRead(lsPrivate(m.senderId));
            if (m.id > lastRead) priv.set(m.senderId, (priv.get(m.senderId) || 0) + 1);
        }
    }
    // Auto-open tabs only for just-arrived private messages (not historical on page load)
    for (const m of newMsgs) {
        if (m.senderId !== userId && m.targetId !== null && m.targetId > 0 && m.targetId === userId) {
            addTab(m.senderId, m.senderName);
        }
    }
    setUnreadPrivate(priv);
}, [messages, userId]);
```

**Pitfall — auto-opening tabs on page load**: Without the `prevMsgCount` guard, the full recompute loop calls `addTab` for EVERY historical private message on every render. Use `messages.slice(prevMsgCount.current)` to get only newly-arrived messages for tab auto-opening. Unread counting still scans ALL messages.

**Mark as read** — called when switching tabs or closing panel. Saves the max message ID in the current tab:

```tsx
const markRead = useCallback((type: 'general' | 'guild' | number) => {
    const filtered = type === 'general'
        ? messages.filter(m => m.targetId === null)
        : type === 'guild'
            ? messages.filter(m => m.targetId !== null && m.targetId < 0)
            : messages.filter(m => (m.senderId === userId && m.targetId === type) || (m.senderId === type && m.targetId === userId));
    const maxId = filtered.length > 0 ? Math.max(...filtered.map(m => m.id)) : 0;
    if (type === 'general') { saveLastRead(LS_GENERAL, maxId); setUnreadGeneral(0); }
    else if (type === 'guild') { saveLastRead(LS_GUILD, maxId); setUnreadGuild(0); }
    else { saveLastRead(lsPrivate(type), maxId); setUnreadPrivate(p => { const n = new Map(p); n.delete(type); return n; }); }
}, [messages, userId]);

// In tab switch handlers:
onSelectPublic={() => { setPrivateChatWith(null); setGuildChatActive(false); markRead('general'); }}
onSelectGuild={() => { setPrivateChatWith(null); setGuildChatActive(true); markRead('guild'); }}
onSelectPrivate={(id) => { setPrivateChatWith(id); setGuildChatActive(false); markRead(id); }}

// When panel closes:
useEffect(() => {
    if (!isPanelOpen && messages.length > 0) {
        if (guildChatActive) markRead('guild');
        else if (privateChatWith !== null) markRead(privateChatWith);
        else markRead('general');
    }
}, [isPanelOpen]);
```

This is all client-side — no server changes needed. Messages have auto-increment integer IDs from `chat_messages` table.

**Pitfall — notifications only when chat was collapsed on general tab**: The original condition `!guildChatActive && privateChatWith === null && !isPanelOpen` meant general unread only incremented when the user was ALREADY on the general tab before collapsing. If the user was on a PM or guild tab when collapsing, general messages never triggered notifications. Fix: remove the `privateChatWith` and `guildChatActive` checks from the general condition — just `!isPanelOpen`. For guild and PM, add `|| !isPanelOpen` so collapsed always notifies.

**Pitfall — notifications absent when chat is open on a different tab**: Added `privateChatWith !== null || guildChatActive` to the general unread condition so the indicator appears even when chat is open but the general tab is not active.

### Guild Tag in Chat (senderGuild)

Display `[GuildName]` next to the sender's nickname in chat messages, colored green. Shows guild affiliation of each message sender.

**Server** — add `guildName` to WebSocket connection user query and all broadcast message objects:
```ts
// In websocket.ts — JOIN guilds on user lookup
const user = db.prepare(
    'SELECT u.id, u.username, u.level, u.chatBannedUntil, u.isGuest, g.name as guildName FROM users u LEFT JOIN guilds g ON u.guildId = g.id WHERE u.id = ?'
).get(userId);
// Add to every msg object broadcast
senderGuild: user.guildName || null,
```

**Client** — add field to `ChatMessage` type in `types.ts`:
```ts
senderGuild?: string | null;
```

**Display** in `MessageList.tsx` below nickname (NO green background — removed per user feedback). Truncated to 8 chars, navigates to specific guild page via `senderGuildId`:

```tsx
{firstMsg.senderGuild && (
    <span onClick={() => firstMsg.senderGuildId ? navigate(`/guild/${firstMsg.senderGuildId}`) : navigate('/guild/rating')} style={{
        fontSize: '0.6rem', color: '#2ecc71', cursor: 'pointer',
        padding: '0 4px', borderRadius: '3px',
    }}>[{firstMsg.senderGuild.length > 8 ? firstMsg.senderGuild.slice(0, 8) + '…' : firstMsg.senderGuild}]</span>
)}
```
Requires `import { useNavigate } from 'react-router-dom'` and `const navigate = useNavigate()` in MessageList. Also requires `senderGuildId` in the WebSocket broadcast (add `senderGuildId: user.guildId || null` to all msg objects + `u.guildId` to the user SELECT). Add `senderGuildId?: number | null` to the `ChatMessage` type in `types.ts`.

**OnlineList truncation** — same 8-char limit:
```tsx
{u.guildName.length > 8 ? u.guildName.slice(0, 8) + '…' : u.guildName}
```
```

Players without a guild show nothing (no "Без гильдии" tag — only guild members get a tag).

### GuildTag Component (`client/src/components/GuildTag.tsx`)

Reusable component for displaying `[GuildName]` or `[Без гильдии]` next to player names anywhere in the client:

```tsx
export default function GuildTag({ guildName, guildId, hideNoGuild }: { guildName?: string | null; guildId?: number | null; hideNoGuild?: boolean }) {
    const navigate = useNavigate();
    if (!guildName) return hideNoGuild ? null : <span className="text-[0.6rem] text-[var(--color-text-muted)]">[Без гильдии]</span>;
    const short = guildName.length > 10 ? guildName.slice(0, 10) + '…' : guildName;
    return (
        <span onClick={(e) => { e.stopPropagation(); if (guildId) navigate(`/guild/${guildId}`); }}
            className="text-[0.6rem] text-[#2ecc71] px-1 rounded cursor-pointer hover:underline"
            title={guildName}
        >[{short}]</span>
    );
}
```

**Styling rules**:
- NO green background (`bg-[#1a3a1a]` was removed per user feedback — too heavy)
- Text color: `#2ecc71` (green)
- Truncate to 10 chars + `…` (long names break CharacterCard layout on home page)
- Full name in `title` attribute for hover tooltip
- On CharacterCard: h2 has `margin: '0 0 -4px 0', lineHeight: '1.1'` to pull guild tag tight against the name with minimal spacing
- If no guildId, tag is non-clickable (just shows name)
- `e.stopPropagation()` — prevents parent onClick from firing when tag is inside a clickable row
- `hideNoGuild` prop — when true, renders NOTHING if no guild (for monsters/PvE mobs that shouldn't show any guild info)

### Guild Alignment: Fixed Height for Missing Guild

When mobs use `hideNoGuild`, the GuildTag returns `null` and the header area collapses — causing the player card and mob card frames to misalign vertically (mob frame sits higher than player frame). Fix: wrap GuildTag in a **fixed-height** container so both cards have exactly the same height for the guild line.

**Pitfall — `min-h` is NOT enough**: `min-h-[0.85rem]` reserves MINIMUM 17px, but the actual guild tag text (`text-[0.6rem]` at 20px base) is only ~14px tall. The player card gets 14px of content + no extra space, while the mob card gets the full 17px of `min-h` — a 3px difference that throws off vertical alignment. **Use `h-[0.75rem]` (fixed height, 15px)** — both cards always get exactly 15px, regardless of content. The guild tag text (~14px) fits inside with 1px to spare.

```tsx
<div className="h-[0.75rem]">
  <GuildTag guildName={...} guildId={...} hideNoGuild={hideNoGuild} />
</div>
```

This ensures the name area has identical fixed height regardless of whether a guild tag is rendered.

### hideNoGuild for Non-Player Cards

Monsters in PvE (BestiaryPage) should NOT show any guild tag (not even `[Без гильдии]`). Use the `hideNoGuild` prop added to both `GuildTag` and `CharacterCard`:

```tsx
// CharacterCard.tsx — add prop and pass through
hideNoGuild?: boolean; // in CharacterCardProps
hideNoGuild = false;   // in destructuring defaults
<GuildTag ... hideNoGuild={hideNoGuild} />

// BestiaryPage.tsx — for mob card
<CharacterCard isMob hideNoGuild ... />
```

## User Avatars

Users can upload custom character card images (WebP/PNG/JPEG, max 512KB). Stored as files in `/opt/game/server/uploads/avatars/{userId}.{ext}`, path saved in `users.avatar` column.

### Server

**Migration** (`database/migrations.ts`): `ALTER TABLE users ADD COLUMN avatar TEXT`

**Upload endpoint** (`routes/account.ts`): `POST /api/account/avatar` — accepts `{ avatar: "data:image/webp;base64,..." }` in JSON body. Validates format/size, saves file, updates DB.

**Static serving** (`index.ts`): `app.use('/uploads', express.static(...))` + nginx location block:
```nginx
location /uploads/ {
    alias /opt/game/server/uploads/;
    expires 7d;
    add_header Cache-Control "public, immutable";
}
```

**Endpoints that MUST return `avatar`** (data pipeline pitfall — each endpoint has its own SELECT + response):
- `/character/me` → already includes `avatar: user.avatar || null`
- `/api/arena/opponent` → add `u.avatar` to both opponent SELECTs (main + saved), add `avatar` to both response objects
- `/api/character/public/:userId` → add `u.avatar` to SELECT, add `avatar: user.avatar || null` to response

### Client

**CharacterCard**: if `(char as any).avatar` is set, use it as `backgroundImage`; otherwise fall back to gender-based default images.

**Avatar error fallback**: When a custom avatar URL is set but the file is missing (admin deleted it, 404, etc.), the card should show the gender-based default instead of a broken image. Use a hidden `<img>` with `onError` to detect failures — the background-image CSS uses the custom URL immediately (no delay), and the hidden img triggers a fallback when the load fails:

```tsx
const customUrl = (char as any).avatar || null;
const [avatarFailed, setAvatarFailed] = useState(false);
useEffect(() => { setAvatarFailed(false); }, [customUrl]);

const bgImage = isMob ? 'none'
  : (customUrl && !avatarFailed ? `url(${customUrl})` : `url(${defaultAvatar})`);

// Inside the card frame div:
{customUrl && !avatarFailed && (
  <img src={customUrl} alt="" onError={() => setAvatarFailed(true)} className="hidden" />
)}
```

**Pitfall — `new Image()` preloading**: The naive approach of `new Image()` + `onload` in useEffect causes a visible delay (blank background while loading). Always render the custom URL immediately and fall back on error — zero delay for working avatars.

**Upload UI** (AccountPage): file input that reads as data URL → POST to `/api/account/avatar` → refresh character.

**Data pipeline**: same as guildName/guildId — `avatar: (character as any).avatar || null` must be added to ALL places that construct CharacterCardData objects: LeftSidebar, ArenaPage (player + opponent), BestiaryPage, ProfilePage.

When sending item links via Shift+Click in WebSocket `itemLink` handler, inventory items use `rarity_id` as the field name, NOT `rarity`. The broadcast message must handle both:

```ts
itemRarity: item.rarity_id ?? item.rarity,
```

Without this, `itemRarity` is `undefined` and the item link may not render correctly in chat. Symptom: Shift+Click on an item produces a broken or invisible link in chat. This bug was introduced during the `senderGuild`/`senderGuildId` addition to WebSocket broadcasts — the `replace_all` patch accidentally touched the item link section but the rarity field was already wrong before (the patch just called attention to it).

## Chat Panel Layout

The opened panel has three layers (outer `flex-col`, inner `flex-row`, bottom `ChatInput`):

```
┌──────────────────────────────────────┬──────────┬──────────┐
│ ChatTabs                             │          │          │
│ MessageList                          │ полоса   │ Онлайн   │
│                                      │ онлайна  │ список   │
├──────────────────────────────────────┴──────────┴──────────┤
│ ChatInput (всегда полная ширина, вне flex-строки)          │
└────────────────────────────────────────────────────────────┘
```

**Ключевое**: `ChatInput` вынесен из flex-строки в отдельный ряд внешнего `flex-col` — это гарантирует, что инпут всегда на всю ширину и не сжимается при разворачивании списка онлайна.

**Таб-лейбл убран** — раньше между `ChatTabs` и `MessageList` был бар с названием вкладки («Общий чат», «Личные сообщения с ...», «Гильдия ...») и кнопкой онлайна. Теперь его нет — `ChatTabs` сразу переходит в `MessageList`.

### Вертикальный переключатель онлайна

Отдельная полоса справа (между сообщениями и списком онлайна), не привязана к лейблу. Тёмный фон `bg-[#111]`, левая граница `border-l border-[#333]`. При клике переключает `onlineOpen`.

Текст **снизу вверх**: `writingMode: 'vertical-rl'` + `transform: 'rotate(180deg)'` на `<span>`. Обычный порядок символов (не reversed), rotate разворачивает весь блок на 180° — символы оказываются перевёрнутыми, но читаются снизу вверх.

**Стрелки**: `onlineOpen ? '◀' : '▶'` — с учётом rotate(180°) это даёт `▶` (вправо) при развёрнутом списке и `◀` (влево) при свёрнутом.

**Размер текста**: `text-[0.75rem]` — крупнее, чтобы было заметно.

```tsx
<div className="flex-1 flex min-h-0">
    <div className="flex-1 flex flex-col min-w-0">
        <ChatTabs ... />
        <MessageList ... />
    </div>

    {/* Вертикальный переключатель онлайна */}
    <div onClick={() => setOnlineOpen(!onlineOpen)}
        className="flex items-center cursor-pointer bg-[#111] border-l border-[#333] px-1.5 py-2 shrink-0 select-none hover:bg-[#1a1a1a]"
        title={onlineOpen ? 'Скрыть список' : 'Показать список'}
    >
        <span className="text-[0.75rem] text-[#2ecc71] leading-[1.15]"
            style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
            Онлайн: {onlineUsers.length} {onlineOpen ? '◀' : '▶'}
        </span>
    </div>

    {onlineOpen && <OnlineList ... />}
</div>

<ChatInput ... />   {/* вне flex-строки — всегда полная ширина */}
```

**Pitfall — input shrinks when online list expands**: Если `ChatInput` находится внутри flex-строки вместе с `OnlineList`, при разворачивании списка инпут сжимается по ширине. Решение: вынести `ChatInput` из flex-строки на уровень выше (во внешний `flex-col`), чтобы он всегда растягивался на 100% ширины панели.

**Pitfall — writing-mode + rotate для «снизу вверх»**: `writing-mode: vertical-rl` даёт текст сверху вниз. Чтобы получить снизу вверх, применяется `transform: rotate(180deg)` на том же элементе. Символы при этом переворачиваются (оказываются вверх ногами), но порядок чтения становится снизу вверх. Не использовать `flex-col-reverse` с отдельными `<span>` — пользователь предпочитает именно вертикальную надпись через writing-mode.

**Pitfall — иконка `⠿` для drag-хендлов**: иконка resize-хендла (`⠿`) должна быть **видна всегда** (не invisible, не hidden, не только на hover). Пользователь несколько раз отвергал невидимые и еле заметные хендлы. Правильный подход: `opacity-60` по умолчанию + `opacity-100` на hover группы, цвет `#666` → `#ccc`. Хендл должен быть на самом элементе, ширину которого меняют (на левом краю OnlineList, в баре хедера чата), а НЕ в соседнем элементе (не в кнопке-переключателе, не в баре фильтров).

### Динамическая высота чата (drag-to-resize)

Высота панели чата меняется перетаскиванием за хендл `⠿` в баре хедера. Сохраняется в `localStorage('chatHeight')`, восстанавливается при следующем открытии.

**Состояние**:
```tsx
const [chatHeight, setChatHeight] = useState(() => {
    const saved = localStorage.getItem('chatHeight');
    return saved ? parseInt(saved) : 300;
});
const chatHeightRef = useRef(chatHeight);
useEffect(() => { chatHeightRef.current = chatHeight; }, [chatHeight]);
```

**Drag-обработчик** (useCallback на mouseDown/touchStart):
```tsx
const handleDragStart = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const startY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const startH = chatHeight;
    setDragging(true);

    const onMove = (ev: MouseEvent | TouchEvent) => {
        const y = 'touches' in ev ? (ev as TouchEvent).touches[0].clientY : (ev as MouseEvent).clientY;
        const delta = startY - y;
        const h = Math.max(120, Math.min(window.innerHeight * 0.85, startH + delta));
        setChatHeight(Math.round(h));
    };
    const onEnd = () => {
        setDragging(false);
        localStorage.setItem('chatHeight', String(chatHeightRef.current));
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onEnd);
        document.removeEventListener('touchmove', onMove);
        document.removeEventListener('touchend', onEnd);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
}, [chatHeight]);
```

**Хендл в хедере**:
```tsx
{isPanelOpen && (
    <span onMouseDown={handleDragStart} onTouchStart={handleDragStart}
        className="cursor-ns-resize text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] select-none px-1"
        title="Тяни для изменения высоты">⠿</span>
)}
```

**Стиль панели**: `style={{ height: isPanelOpen ? chatHeight : 40 }}`. Transition отключается на время драга: `${dragging ? '' : 'transition-[height] duration-150'}`.

**Pitfall — useCallback + chatHeight в onEnd**: `onEnd` сохраняет `chatHeightRef.current` (ref), а не значение `chatHeight` из замыкания — иначе сохранится высота на момент СТАРТА драга, а не финальная.

**Pitfall — `preventDefault` в React-овом `onTouchStart` ломает мобилки**: React регистрирует `onTouchStart` как пассивный слушатель. Вызов `e.preventDefault()` внутри него выдаёт ошибку `Unable to preventDefault inside passive event listener` на мобильных. Решение: убрать `e.preventDefault()` из React-обработчика. Drag-логика сама вешает свои `touchmove`/`touchend` с `{ passive: false }` на `document`, так что `preventDefault` в стартовом обработчике не нужен.

### OnlineList: фильтры, цвета, перетаскиваемая ширина

Список игроков онлайн в правой колонке чата. Данные о согильдийцах приходят из `GET /api/guild/my` (поле `members[].userId`) и хранятся в `guildMemberIds: Set<number>`.

**Фильтры**: две кнопки в шапке списка — `Все` и `Гильдия (N)`. Активная подсвечена `bg-[#2a2a3e]`. При фильтре «Гильдия» показываются только согильдийцы + сам игрок.

**Цвета**:
- Сам игрок — жёлтый `#f1c40f`
- Активный собеседник (открыта ЛС-вкладка) — жёлтый жирный
- Согильдиец — зелёный `#2ecc71`
- Остальные — белый
- Черезстрочная подсветка: `i % 2 === 1 ? 'bg-[#1e1e38]' : ''` (каждая вторая строка светлее фона `#16162a`)

**Перетаскиваемая ширина**: левый край (4px) — drag-хендл `cursor-col-resize`. Диапазон 100–400px, сохраняется в `localStorage('onlineListWidth')`, по умолчанию 160px. Компонент использует `style={{ width }}` вместо Tailwind-классов ширины.

```tsx
const [width, setWidth] = useState(() => {
    const saved = localStorage.getItem('onlineListWidth');
    return saved ? parseInt(saved) : 160;
});
const widthRef = useRef(width);
useEffect(() => { widthRef.current = width; }, [width]);

const handleResizeStart = useCallback((e) => {
    const startX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const startW = widthRef.current;
    const onMove = (ev) => {
        const x = 'touches' in ev ? ev.touches[0].clientX : ev.clientX;
        const w = Math.max(100, Math.min(400, startW + (startX - x)));
        setWidth(Math.round(w));
    };
    const onEnd = () => {
        localStorage.setItem('onlineListWidth', String(widthRef.current));
        // remove listeners...
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
}, []);
```

**ChatPanel передача данных**:
```tsx
const [guildMemberIds, setGuildMemberIds] = useState<Set<number>>(new Set());

// В эффекте загрузки гильдии:
fetch(`${BASE_URL}/guild/my`, { headers: getHeaders() })
    .then(r => r.json())
    .then(data => {
        if (data.guild) {
            setGuildId(data.guild.id);
            setGuildName(data.guild.name);
            setGuildMemberIds(new Set((data.members || []).map((m: any) => m.userId)));
        }
    });

<OnlineList ... guildMemberIds={guildMemberIds} />
```

### Автоскролл к последнему сообщению при смене вкладки

При открытии вкладки чата список сообщений должен сразу показывать самое нижнее (новое) сообщение.

**Решение — `scrollKey` prop**: MessageList принимает `scrollKey`, который меняется при смене вкладки. При изменении `scrollKey` сбрасываются `initialLoad` и `prevMessageCount`, что заставляет `useLayoutEffect` скроллить вниз при следующем рендере с сообщениями.

```tsx
// MessageList.tsx — добавлен scrollKey в props
interface MessageListProps {
    scrollKey?: number;
}

const initialLoad = useRef(true);
const prevMessageCount = useRef(messages.length);

useEffect(() => {
    initialLoad.current = true;
    prevMessageCount.current = 0;
}, [scrollKey]);

useLayoutEffect(() => {
    if (initialLoad.current && messages.length > 0) {
        containerRef.current.scrollTop = containerRef.current.scrollHeight;
        initialLoad.current = false;
    } else if (prevMessageCount.current > 0 && messages.length > prevMessageCount.current) {
        containerRef.current.scrollTo({ top: containerRef.current.scrollHeight, behavior: 'smooth' });
    }
    prevMessageCount.current = messages.length;
}, [messages]);
```

**ChatPanel проброс**:
```tsx
<MessageList
    scrollKey={guildChatActive ? -1 : (privateChatWith ?? 0)}
    ...
/>
```

Ключ меняется при переключении: общий чат = 0, ЛС = id собеседника, гильдия = -1. При асинхронной загрузке сообщений (fetch + addMessages) скролл происходит дважды: сначала на старых данных (если они есть), потом на новых (через `currentCount > prevCount`). Если старая вкладка пустая, `initialLoad` остаётся `true` до прихода данных — тогда скролл один раз без анимации.

### ChatTabs: тонкий скроллбар

Когда вкладок много, появляется горизонтальный скролл. Кастомный тонкий скроллбар через произвольные Tailwind-селекторы:

```tsx
<div className="... overflow-x-auto [&::-webkit-scrollbar]:h-1 [&::-webkit-scrollbar-thumb]:bg-[#555] [&::-webkit-scrollbar-thumb]:rounded">
```

### Chat Overlay + Body Scroll Lock

При открытом чате весь контент за ним блокируется: затемнённый оверлей `bg-black/40` на весь экран (z-[999]) + `document.body.style.overflow = 'hidden'`. Клик по оверлею закрывает чат:

```tsx
useEffect(() => {
    if (isPanelOpen) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
}, [isPanelOpen]);

// В JSX:
{isPanelOpen && (
    <div className="fixed inset-0 z-[999] bg-black/40" onClick={() => setIsPanelOpen(false)} />
)}
```

**Pitfall — оверлей без body scroll lock недостаточен**: Одного оверлея мало — скролл страницы и навигация по ссылкам за оверлеем всё равно работают. Обязательно добавить `overflow: hidden` на body.

## Chat Panel Layout

The opened panel has three layers: outer `flex-col` → inner `flex-row` (messages + online toggle + online list) → `ChatInput` at bottom.

```
┌──────────────────────────────────────┬──────────┬──────────┐
│ ChatTabs                             │ полоса   │ Онлайн   │
│ MessageList                          │ онлайна  │ список   │
├──────────────────────────────────────┴──────────┴──────────┤
│ ChatInput (всегда полная ширина, вне flex-строки)          │
└────────────────────────────────────────────────────────────┘
```

**Ключевое**: `ChatInput` вынесен из flex-строки — всегда на всю ширину, не сжимается при разворачивании списка.

### Вертикальный переключатель онлайна

Отдельная полоса справа, тёмный фон `bg-[#111]`, `border-l border-[#333]`. Текст снизу вверх: `writingMode: 'vertical-rl'` + `transform: 'rotate(180deg)'`. Стрелки: `onlineOpen ? '◀' : '▶'` (с rotate дают ▶/◀ визуально).

### Динамическая высота (drag-to-resize)

Хендл `⠿` в баре хедера чата. Drag меняет высоту (120–85% экрана), сохраняется в `localStorage('chatHeight')`. Важно: `onEnd` сохраняет `chatHeightRef.current` (ref), а не значение из замыкания. `preventDefault` в React `onTouchStart` ломает мобилки — убран.

### Chat Overlay + Body Scroll Lock

При открытом чате: оверлей `fixed inset-0 z-[999] bg-black/40` + `document.body.style.overflow = 'hidden'`. Одного оверлея недостаточно — скролл страницы работает без `overflow: hidden`.

### OnlineList: фильтры, цвета, перетаскиваемая ширина

Фильтры `Все` / `Гильдия (N)`. Цвета: жёлтый (я), жёлтый жирный (собеседник), зелёный (согильдиец), белый (остальные). Черезстрочная подсветка `bg-[#1e1e38]`. Ширина перетаскивается за левый край (100–400px), сохраняется в `localStorage('onlineListWidth')`. Данные о согильдийцах из `GET /api/guild/my` → `guildMemberIds: Set<number>`.

### Автоскролл к последнему сообщению

MessageList принимает `scrollKey`. При смене вкладки ключ меняется → сбрасывается `initialLoad` → скролл вниз. В ChatPanel: `scrollKey={guildChatActive ? -1 : (privateChatWith ?? 0)}`.

### ChatTabs: тонкий скроллбар

`[&::-webkit-scrollbar]:h-1 [&::-webkit-scrollbar-thumb]:bg-[#555] [&::-webkit-scrollbar-thumb]:rounded`

## Actions Cards: Increased Card Size

Cards in Actions.tsx use larger padding and font sizes for better touch targets and readability:

- Main cards (CardGrid): `p-3` (was `p-2`), title `text-[0.85rem]` (was `0.8rem`), subtitle `text-[0.7rem]` (was `0.65rem`)
- Arena flip-card front: same changes as main cards
- Arena flip-card back: `p-3` (was `p-2`)

These changes apply to BOTH the `outsideCards` (МИР) and `castleCards` (Площадь) grids.

## Arena Opponent: Sticky Tracking (Prevent Cost Bypass)

Arena opponent selection has a 10-silver cost for changing opponents. Users can bypass this by refreshing the page or changing difficulty. Solution: server remembers which opponent was assigned via `arenaOpponentId` column.

### DB Migration

```ts
try { db.exec('ALTER TABLE users ADD COLUMN arenaOpponentId INTEGER DEFAULT NULL'); } catch {}
```

### Server Logic (`routes/arena.ts`)

**GET `/api/arena/opponent?change=false&difficulty=equal`**:

1. If user has `arenaOpponentId` set AND `change=false`:
   - Fetch that opponent from DB (check not protected/deleted)
   - If exists AND matches requested difficulty (level check):
     - Return same opponent — FREE (sticky)
   - If difficulty mismatch: charge 10 silver, pick new opponent
   - If opponent deleted/protected: fall through to new pick (free)
2. If no stored opponent: pick new random opponent, save `arenaOpponentId`
3. If `change=true`: charge 10 silver, pick new (exclude current if requested), save new ID

**Difficulty mismatch detection**:
```ts
const matchesDifficulty =
    (difficulty === 'easy' && saved.level < user.level) ||
    (difficulty === 'hard' && saved.level > user.level) ||
    (difficulty === 'equal' && saved.level === user.level);
```

If mismatch: charge 10 silver just like `change=true` — prevents cycling difficulty to get free rerolls.

**Clear on battle** (`routes/battle.ts` — attacker's UPDATE):
```sql
UPDATE users SET ... arenaOpponentId=NULL WHERE id=?
```

### Cost Flow Summary

| Action | Cost | Behavior |
|---|---|---|
| First visit | Free | Picks random, saves ID |
| Page refresh | Free | Returns stored opponent |
| Change button | 10 silver | Picks new, saves ID |
| Difficulty change | 10 silver | Picks new (difficulty mismatch triggers cost) |
| After battle | Free | Clears stored ID, next visit is fresh |

### excludeId NaN Guard

```ts
if (excludeId !== undefined && !isNaN(excludeId)) {
    opponents = opponents.filter((o: any) => o.id !== excludeId);
}
```

Without `!isNaN`, corrupted client URLs like `excludeId=23:1` produce `NaN` which silently breaks filtering.

Guild names are truncated in three different places with TWO different limits:

1. **GuildTag component** — 10 chars + `…`. Used on CharacterCard, profile, rating, arena, everywhere. Full name in `title` tooltip.
2. **MessageList (chat messages)** — 8 chars + `…`. Inline ternary in JSX: `{firstMsg.senderGuild.length > 8 ? firstMsg.senderGuild.slice(0, 8) + '…' : firstMsg.senderGuild}`. No tooltip (space-constrained).
3. **OnlineList** — 8 chars + `…`. Same inline pattern as MessageList: `{u.guildName.length > 8 ? u.guildName.slice(0, 8) + '…' : u.guildName}`

The 8-char limit in chat/online is tighter than GuildTag's 10-char limit because chat and online list are more space-constrained.

### Actions: Sections and Card Placement

- 🌍 **МИР**: actions with `section='world'` — Охота, Работы, Арена
- 🏰 **Площадь**: actions with `section='castle'` — Магазин, Банк, Крафт, Аукцион, Трактир, Гильдия

Cards loaded dynamically from `actions_config` table. See `references/actions-mobs-admin.md`.

Arena was moved from castleCards to outsideCards because PvP is an outside-world activity.

### Rating: 4-Column Layout (Responsive)

Both the home page RatingBlock and the full RatingPage use 4 columns:
- **Desktop**: Ник (36%), Гильдия (36%), Титул (19%), Очки (9%)
- **Mobile**: Гильдия column hidden (`hidden sm:table-cell`), guild tag shown under name (`sm:hidden`), Title shows only icon, rest full width

RatingBlock uses flex with fixed `width` percentages (`${4/11*100}%` etc). RatingPage uses a table with `style={{ width: '36%' }}`.

**Pitfall — mobile breaks with 4 full columns**: Without responsive hiding, 4 columns overflow on mobile. Must use Tailwind responsive classes: `hidden sm:table-cell` / `sm:hidden` to collapse guild column on mobile and show it under the name instead. Title column on mobile shows only icon (`{p.rank?.icon}`), full text on desktop.

### Actions: Sections and Card Placement

- 🌍 **МИР** (was "За стенами"): `outsideCards` — Охота, Работы, **Арена**
- 🏰 **Площадь**: `castleCards` — Магазин, Банк, Крафт, Аукцион, Трактир, Гильдия

Arena was moved from castleCards to outsideCards because PvP is an outside-world activity.

### RightSidebar Width Constraint

Right column on home page uses `w-full sm:w-[200px] sm:flex-shrink-0` to prevent it from expanding and squeezing center content. Left sidebar uses `w-full sm:w-auto` (bounded by CharacterCard size).

- `LeftSidebar.tsx` (home page) — constructs `char` from `character` fields
- `ArenaPage.tsx` — constructs `char` for BOTH player and opponent
- `BestiaryPage.tsx` — constructs `char` for player (mob card is fine — no guild tag on mobs)
- `ProfilePage.tsx` — constructs `char` from profile data

Fix: add `guildName`/`guildId` to ALL of these constructed objects:
```tsx
guildName: (character as any).guildName,  // or opponent.guildName / profile.guildName
guildId: (character as any).guildId,      // or opponent.guildId / profile.guildId
```

This is a classic "data pipeline" bug — data present at source and destination but lost in a middle component that reconstructs a subset of props. Always check ALL intermediate components that reconstruct CharacterCard props when adding new fields.

**Server prerequisite**: the data source must include `guildName` (and ideally `guildId`). Key server changes:

- `getUserById` in `server/src/db/helpers.ts`: `SELECT u.*, g.name as guildName FROM users u LEFT JOIN guilds g ON u.guildId = g.id WHERE u.id = ?`
- `getUserWithStats`: same LEFT JOIN pattern
- Battle (attacker + both defender queries): add `g.name as guildName` via LEFT JOIN
- Rating: `SELECT u.*, g.name as guildName, u.guildId FROM users u LEFT JOIN guilds g ...`
- History: `a.guildId as attackerGuildId, d.guildId as defenderGuildId` + LEFT JOINs for both attacker and defender
- `/character/me` response: `guildName: user.guildName || null` (user already has guildName from getUserById)
- WebSocket user lookup: `LEFT JOIN guilds g ON u.guildId = g.id` in the connection SELECT, add `senderGuild: user.guildName || null` to all broadcast message objects
- `getUserWithStats` in `server/src/db/helpers.ts` — used by battle/arena logic, MUST add `g.name as guildName` via LEFT JOIN
- `/api/arena/opponent` in `server/src/routes/arena.ts` — separate endpoint from `/api/battle`, needs its own LEFT JOIN for both the user SELECT and opponents SELECT to include `guildName`/`guildId`. Missed during initial guildName rollout — result was opponent cards in arena showing `undefined` guildName

**Pitfall — arena opponent endpoint SEPARATE from battle endpoint**: `/api/arena/opponent` (used by ArenaPage to load opponent card) is a DIFFERENT endpoint from `/api/battle` (used for the actual fight). Both need their own LEFT JOIN for guildName. The arena endpoint was missed during the initial guildName rollout — result was opponent cards showing `undefined` guildName. Adding guildName to `/api/battle` alone is not enough.
- `/api/character/public/:userId` in `server/src/routes/users.ts` — public profile page uses this; must add LEFT JOIN in SELECT and fields in `res.json`
- `getUserById` and `getUserWithStats` in `server/src/db/helpers.ts` — used by `/character/me` and battle logic

**Pitfall — Express route ordering (summary)**: See "Pitfall — route ordering in Express" above — all literal guild routes must precede `/guild/:id`.

**Pitfall — duplicate route definitions**: When moving `/guild/list` earlier in the file (to put it before `:id`), always remove the OLD duplicate from its original position. Two identical routes cause the second to be unreachable but at minimum it's dead code.

**Pitfall — `/guild/requests` and `/guild/invites` ALSO need to be before `/guild/:id`**. Same route ordering issue as `/guild/list` — any GET with a literal path segment after `/guild/` that's defined AFTER `router.get('/guild/:id', ...)` will have its literal matched as an `:id` parameter and return 404. The literal routes to protect: `/guild/my`, `/guild/list`, `/guild/requests`, `/guild/invites`, `/guild/chat`.

**Pitfall — arena opponent endpoint SEPARATE from battle endpoint**: `/api/arena/opponent` (used by ArenaPage to load opponent card) is a DIFFERENT endpoint from `/api/battle` (used for the actual fight). Both need their own LEFT JOIN for guildName. The arena endpoint was missed during the initial guildName rollout — result was opponent cards showing `undefined` guildName. Adding guildName to `/api/battle` alone is not enough.
- `/api/character/public/:userId` in `server/src/routes/users.ts` — public profile page uses this; must add LEFT JOIN in SELECT and fields in `res.json`
- `getUserById` and `getUserWithStats` in `server/src/db/helpers.ts` — used by `/character/me` and battle logic

### hideNoGuild for Non-Player Cards

Monsters in PvE (BestiaryPage) should NOT show any guild tag (not even `[Без гильдии]`). Use the `hideNoGuild` prop added to both `GuildTag` and `CharacterCard`:

```tsx
// GuildTag.tsx
export default function GuildTag({ guildName, guildId, hideNoGuild }: { guildName?: string | null; guildId?: number | null; hideNoGuild?: boolean }) {
    if (!guildName) return hideNoGuild ? null : <span className="text-[0.6rem] text-[var(--color-text-muted)]">[Без гильдии]</span>;
    // ...
}

// CharacterCard.tsx — add prop and pass through
hideNoGuild?: boolean; // in CharacterCardProps
hideNoGuild = false;   // in destructuring defaults
<GuildTag ... hideNoGuild={hideNoGuild} />

// BestiaryPage.tsx — for mob card
<CharacterCard
  isMob
  hideNoGuild
  ...
/>
```

### Guild Rating Page (`/guild/rating`)

Separate page at `/guild/rating` (`GuildRatingPage.tsx`) that shows ONLY the guild list with rankings, NO management UI:
- Route: `<Route path="/guild/rating" ...>` — must be BEFORE `/guild/:id` in React Router to avoid `:id` matching "rating"
- Fetches `GET /api/guild/list` and maps to clickable cards navigating to `/guild/:id`
- «Рейтинг гильдий» on home page (RatingBlock) links to `/guild/rating` not `/guild`
- Guild names in the list link to `/guild/${g.id}` (individual guild view page)

### Guild View Page (`/guild/:id`)

Public page showing a single guild's info:
- Server: `GET /api/guild/:id` returns `{ guild: { ...fields, leaderName, memberCount }, members: [...] }`
- Route: `path="/guild/:id"` in App.tsx — AFTER `/guild` and `/guild/rating` to avoid match conflicts
- Shows: name, description, level, leader, member count, join type
- Member list with clickable usernames to `/profile/:id`
- Non-members: Вступить/Подать заявку button
- Members: «Управление гильдией» button → `/guild`

### RightSidebar: Collapse/Expand Overlay (v2)

The right sidebar (QuestsBlock, TournamentBanner, RatingBlock) collapses/expands via a fixed toggle button. When expanded, it overlays the content — center column takes full space. Panel is **always mounted** (data caches) and slides in/out via transform.

**Block header style (fieldset legend)**: All block `<h3>` headers are centered on the top border of their container. Container gets `relative pt-5` (extra top padding), header gets `absolute -top-3 left-1/2 -translate-x-1/2 px-3 bg-[var(--color-bg-secondary)] whitespace-nowrap`. The background color behind the text hides the border underneath, creating the "title on border" effect.

```tsx
// RightSidebar.tsx
const [open, setOpen] = useState(false);

useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
}, [open]);

return (
    <>
        <button onClick={() => setOpen(!open)}
            className="fixed right-3 top-16 z-50 w-8 h-8 rounded-full ...">
            <Icon icon={open ? 'mdi:close' : 'mdi:menu'} />
        </button>

        <div className={`fixed inset-0 right-[340px] z-15 bg-black/20 transition-opacity duration-200 ${open ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
            onClick={() => setOpen(false)} />

        <div className={`fixed right-0 top-[80px] z-20 w-[340px] bg-[var(--color-bg-primary)]/60 backdrop-blur-xl border-l border-[var(--color-border-default)] overflow-y-auto p-3 pt-5 pb-10 shadow-2xl transition-transform duration-200 ease-out ${open ? 'translate-x-0' : 'translate-x-full'}`}
            style={{ height: 'calc(100vh - 80px - 40px)' }}>
            <QuestsBlock onHighlight={(type) => { handleHighlight(type); if (type) setOpen(false); }} />
            <TournamentBanner />
            <RatingBlock />
        </div>
    </>
);
```

**Key rules**:
- **Always-mounted**: panel always in DOM — data loads once and caches. Use `translate-x-full` ↔ `translate-x-0`, NOT conditional render
- **Body scroll lock**: `document.body.style.overflow = 'hidden'` when open. NO `paddingRight` — user rejected body shift
- **Overlay positioning**: `inset-0 right-[340px]` — covers everything EXCEPT the panel. `z-15` below panel `z-20`
- **Panel dimensions**: `top-[80px]` (below header), `height: calc(100vh - 80px - 40px)` (accounts for header + collapsed chat), width `340px`
- **Padding**: `pt-8 pb-10` — space from header and chat panel. `pt-8` prevents top block from sitting flush against the toggle button
- **Button**: `right-3 top-16 z-[45] cursor-pointer` (above header z-40, below popup z-[70])
- **Animation**: `duration-200 ease-out` — fast and smooth
- **Overlay**: `pointer-events-none` when closed so it doesn't block page interaction
- **Quest click closes panel**: when `onHighlight(type)` fires with a non-null type (user clicked a quest to highlight an action card), auto-close the panel so the highlighted card is visible

### QuestsBlock: Unified Styling

Match the style of other right-column blocks (RatingBlock, TournamentBanner):
```tsx
<div className="bg-[var(--color-bg-secondary)] border-2 border-[var(--color-border-default)] rounded-xl p-4 min-w-[210px] overflow-hidden">
```
Not `p-2 border` — that's the old smaller style.

### RightSidebar Header: overflow-hidden Clips Absolute Headers

When using `absolute -top-3` to center block headers on the top border, `overflow-hidden` on the container CLIPS the header text that extends outside. **Remove `overflow-hidden`** from the container — the absolute positioning needs to overflow. The background color `bg-[var(--color-bg-secondary)]` behind the header text already hides the border line underneath.

```tsx
// WRONG — header clipped
<div className="... overflow-hidden relative">
  <h3 className="absolute -top-3 ...">Задания</h3>

// RIGHT
<div className="... relative">
  <h3 className="absolute -top-3 ...">Задания</h3>
```

### Fixed Positioning + backdrop-blur: Portal Everything to Body

`backdrop-filter` (used by `backdrop-blur-xl` on ChatPanel, RightSidebar) creates a **new CSS containing block** for ALL `position: fixed` descendants. ANY fixed-positioned element inside such a container positions relative to that container, NOT the viewport.

**Affected components** (all fixed-position elements inside chat/right-sidebar):
- ContextMenu (nick click)
- ItemTooltip (hover on item links)
- Any popup/dropdown/tooltip

**Symptom**: element appears at wrong coordinates — shifted by the panel's own position. On desktop with a 300px-tall chat panel at the bottom, a tooltip at `top: cursorY - height` can appear FAR below the cursor because `cursorY` is viewport-relative but the element is panel-relative.

**Fix**: portal to `document.body` via `createPortal` from `react-dom`. This restores viewport-relative positioning AND bypasses any overflow/scroll clipping from ancestor containers:

```tsx
import { createPortal } from 'react-dom';

// ItemTooltip.tsx — portal + useLayoutEffect for sync positioning
const ItemTooltip = ({ item, position }) => {
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [adjustedPos, setAdjustedPos] = useState({ left: 0, top: 0, opacity: 0 });

  // useLayoutEffect — fires synchronously after DOM commit, BEFORE paint.
  // Prevents the 1-frame flash of tooltip at (0,0) that useEffect would cause.
  useLayoutEffect(() => {
    const el = tooltipRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    let left = position.x + 8;
    let top = position.y - rect.height - 8;
    // boundary checks...
    setAdjustedPos({ left, top, opacity: 1 });
  }, [position, item]);

  // visibility: hidden at opacity 0 — double insurance against flash
  return createPortal(
    <div ref={tooltipRef} style={{ position: 'fixed', left: adjustedPos.left, top: adjustedPos.top,
      opacity: adjustedPos.opacity, visibility: adjustedPos.opacity ? 'visible' : 'hidden', zIndex: 99999 }}>
      ...
    </div>,
    document.body
  );
};
```

**Re-render pitfall**: `position` is a new object on every mouse move → `useLayoutEffect` dependency fires every frame. Use `useCallback` for the compute function to avoid stale closures.

**Pitfall — ContextMenu in ChatPanel**: same portal pattern applies. The click-outside handler must use document-level listener since the menu is no longer inside the parent's DOM tree.

**Pitfall — `overflow` ancestor doesn't clip fixed elements... unless it's a containing block**: Without `backdrop-filter`, `overflow: auto` on the chat container wouldn't clip `position: fixed` children. But BECAUSE `backdrop-filter` creates a containing block, the fixed element is trapped. Portal solves both the containing block AND overflow clipping in one shot.

### execute_code File Corruption Hazard

`read_file()` inside `execute_code` returns content with LINE NUMBERS prepended (`1|import ...\n2|export ...`). If you pass this to `write_file()`, the file gets corrupted with literal `1|`, `2|` prefixes. **Symptom**: build fails with `Unexpected token` at apparently valid imports. **Fix**: if you accidentally corrupt files, `git checkout -- <file>` to restore. **Prevention**: never use execute_code's `write_file` on output from execute_code's `read_file`. Use the native `patch` or `write_file` tools directly from the main conversation instead.

When you DO need execute_code for batch edits, strip line numbers before writing:
```python
content = read_file(path)["content"]
clean = re.sub(r'^\d+\|', '', content, flags=re.MULTILINE)
write_file(path, clean)
```
Or better: use main-conversation `patch` with `replace_all=true` for simple string replacements across a whole file.

### RightSidebar Header: Border + Rounded-Full

The block headers (`<h3>`) on the right sidebar have a styled border pill around the text to make them look like proper labels on the frame:

```tsx
<h3 className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 bg-[var(--color-bg-secondary)]
  border border-[var(--color-border-default)] rounded-full
  text-base font-bold cursor-pointer hover:text-[var(--color-accent-info)] ... whitespace-nowrap">
```

The `border` + `rounded-full` creates a pill-shaped frame around the header text, matching the container border color. The `bg-[var(--color-bg-secondary)]` background hides the container border behind the text.

**Consistency — all clickable headers must have both `cursor-pointer` AND `hover:text-[var(--color-accent-info)]`**: The user noticed that only Задания had the hover effect. All three blocks (Задания, Турниры main branch, Рейтинг гильдий, Рейтинг игроков) are clickable and need both classes. Guest/empty TournamentBanner branches are NOT clickable — no cursor-pointer, no hover. When using `replace_all` to add a class, watch out for list-item spans that already had `cursor-pointer` — they'll get doubled up and need cleanup.

### RightSidebar: Unified Text Sizes + Padding

All blocks use consistent sizes and padding:
- **Headers**: `text-base` (16px at 20px base) — same across all blocks
- **Body text**: `text-xs` (12px at 20px base) — quest items, tournament items, empty states
- **Small detail text**: `text-[0.65rem]` — progress numbers, descriptions
- **Container padding**: ALL blocks use `pt-5 pb-4 px-4` — TournamentBanner was `pb-3 px-3`, standardized to match QuestsBlock/RatingBlock
- **Block gap**: outer container uses `flex flex-col gap-4` — 16px between all blocks

QuestsBlock was originally `text-xs` header + `text-[0.65rem]`/`text-[0.55rem]` body — too small compared to other blocks. TournamentBanner used `text-[0.6rem]` for details/timer/completed. Both standardized to `text-base` header + `text-xs` body.

### Anti-Pattern: Empty Responses / Analysis Paralysis

When mid-task, NEVER return an empty response. Every response must contain either tool calls (making progress) or a final result. THINKING in analysis is fine — but the output must DO something. The user had to say "продолжай", "еще раз", "еще раз" over 5 times because I got stuck in a loop of returning `(empty)` responses while thinking.

**The most common trigger**: a tool call succeeds (patch applied, search returned results), and instead of immediately chaining the next action (commit → push → deploy), the agent pauses to think about what to do next. Don't think — execute. After a successful patch, the next steps are ALWAYS: commit, push, deploy. Chain them immediately without pausing.

**The second most common trigger**: a search or read_file returns results, and instead of acting on them, the agent enters a thinking loop without making progress. If the search result tells you what you need, make the next tool call immediately.

**Rule**: if you catch yourself returning empty, stop and immediately make the next tool call. Combine commit+push+deploy into a single `&&` chain to eliminate the pause between steps:

```bash
git add -A && git commit -m "..." && git push && ssh root@194.226.142.237 'bash /opt/game/deploy.sh'
```

This single terminal call eliminates the gap where the empty-response loop typically occurs.

## Global Font Size

```css
/* theme.css */
html {
  font-size: 20px;
}
```

Base font is `20px` (up from default `16px`). All rem-based sizes scale relative to this. User iterated through 17, 18, 20px — settled on 20px for comfortable readability. Change this one value to globally resize the entire UI.

## Wiki Page

Static HTML guide at `/wiki/` served by nginx from `/opt/game/wiki/`. Part of the git repo — deploys automatically via `git pull`.

**nginx config** (added to `/etc/nginx/sites-enabled/mmoarena`):
```nginx
location /wiki/ {
    alias /opt/game/wiki/;
    index index.html;
    try_files $uri $uri/ /wiki/index.html;
}
```
Must be inserted BEFORE the `# SPA fallback` location block.

**New player welcome**: HomePage shows a tip when `character.money === 0 && no inventory`. Includes a link to `/wiki/`:
```tsx
<a href="/wiki/" target="_blank" className="text-[var(--color-accent-info)] underline">📖 Гайд для новичков</a>
```

**Settings menu**: Wiki link between Аккаунт and VK with `game-icons:open-book` icon.

**Pitfall — subdomain requires DNS**: Attempting `wiki.mmoarena.ru` fails because no DNS A record exists. Always use path-based approach (`/wiki/`) unless DNS is configured.



Tournament registration warnings are sent as chat messages (senderId=0, targetId=null). Debug tags like `[tour_warn_102]` must NOT appear in the user-visible message content. The deduplication query should use a generic phrase match instead of a tag:

```ts
// Dedup: check if any tournament warning was sent in last 5 minutes
const already = db.prepare(
    "SELECT id FROM chat_messages WHERE senderId = 0 AND content LIKE '%регистрация закроется через%' AND createdAt > datetime('now', '-5 minutes')"
).get();
```

## Wiki Page

Static HTML guide at `/wiki/` served by nginx from `/opt/game/wiki/`. In git repo — deploys via git pull.

nginx location block (before SPA fallback):
```nginx
location /wiki/ { alias /opt/game/wiki/; index index.html; try_files $uri $uri/ /wiki/index.html; }
```

New player welcome on HomePage links to `/wiki/`. Settings menu has Wiki link (game-icons:open-book, green).

**Pitfall — subdomain requires DNS**: wiki.mmoarena.ru fails without DNS A record. Use path-based `/wiki/`.

## Guest Restrictions Toggle

Testing toggle: `POST /api/admin/toggle-guest` flips global flag. Affects `requireFullAccess`, `guestCooldown`, WebSocket chat, client ChatInput, Actions cards. Full details: `references/guest-toggle.md`.

### Actions Dynamic from DB

Action cards on the home page are now loaded from `actions_config` table via public `/api/actions` endpoint, NOT hardcoded. Admin can edit: title, subtitle, icon, background image, path, cost, section. See `references/actions-mobs-admin.md` for full schema, API, and admin UI.

### Mobs Admin

Mobs have `background` and `description` columns. Admin can edit all mob fields including background image upload. See `references/actions-mobs-admin.md`.

### Admin Image Upload: Body Size Limits (413 Error)

Base64-encoded images inflate by ~33%. A 1MB image becomes ~1.33MB in base64. Two limits must be raised:

1. **Express**: `express.json({ limit: '5mb' })` in `setupMiddleware.ts` (was `1mb`)
2. **Nginx**: defaults to 1MB `client_max_body_size`. Add to server block:
   ```nginx
   client_max_body_size 10m;
   ```

Without both, uploads fail with 413. Also increase the client-side file size check in `ImageUploader` from 2MB to 5MB.

### Partial UPDATE Pattern (Don't Null Out Unprovided Fields)

When updating a record with optional image fields, the naive `UPDATE SET background=?` overwrites existing values with `null` when the field isn't provided by the client. Use dynamic field construction:

```ts
router.put('/jobs/:id', (req, res) => {
    const { name, duration, background } = req.body;
    const fields: string[] = [];
    const values: any[] = [];
    if (name !== undefined) { fields.push('name=?'); values.push(name); }
    if (duration !== undefined) { fields.push('duration=?'); values.push(duration); }
    if (background !== undefined) { fields.push('background=?'); values.push(background || null); }
    if (fields.length === 0) return res.status(400).json({ error: 'Нет данных' });
    values.push(req.params.id);
    db.prepare(`UPDATE jobs SET ${fields.join(',')} WHERE id=?`).run(...values);
});
```

This preserves existing field values when they're not explicitly sent. Applies to any table with optional image/background columns.

Reusable pattern: server accepts base64 → saves to `/uploads/admin/<folder>/` → returns URL. Client `ImageUploader` component: file picker, preview, upload, clear. See `references/admin-image-upload.md` for full code.

### Integration Points

- **AdminItems + EditItemModal**: `folder="items"` → `items.image`
- **AdminCraft resources**: `folder="craft"` → `craft_items.image`  
- **AdminJobs**: `folder="jobs"` → `jobs.background` (needs `ALTER TABLE jobs ADD COLUMN background TEXT` migration)
- **AdminGame actions**: `folder="actions"` → `actions_config.bg_image`
- **AdminGame mobs**: `folder="mobs"` → `mobs.background`

### Job Cancel (Without Reward)

Players can cancel an active job without receiving any reward. Confirmation via modal popup.

**Server** (`routes/jobs.ts`):
```ts
router.post('/jobs/cancel', (req: any, res) => {
    const userId = req.userId;
    const user = db.prepare('SELECT activeJob FROM users WHERE id = ?').get(userId) as any;
    if (!user || !user.activeJob) return res.status(400).json({ error: 'Нет активной работы' });
    db.prepare('UPDATE users SET activeJob = NULL WHERE id = ?').run(userId);
    res.json({ success: true });
});
```

**Client** (`JobsPage.tsx`):
```tsx
const [showCancel, setShowCancel] = useState(false);
const [cancelling, setCancelling] = useState(false);

// In the active job view (wrapped in <>...</> Fragment alongside the job frame):
<Button variant="secondary" size="sm" className="mt-4" onClick={() => setShowCancel(true)}>Отменить работу</Button>

<Modal open={showCancel} onClose={() => setShowCancel(false)} title="Отменить работу?">
    <p className="text-sm mb-4">Вы уверены? Награда и опыт <strong>не</strong> будут получены.</p>
    <div className="flex gap-2 justify-center">
        <Button variant="danger" size="sm" disabled={cancelling} onClick={async () => {
            setCancelling(true);
            try {
                await fetch('/api/jobs/cancel', { method: 'POST', headers: getHeaders() });
                setCharacter({ ...character!, activeJob: null });
                setShowCancel(false);
                navigate('/');
            } catch { setCancelling(false); }
        }}>{cancelling ? '...' : 'Да, отменить'}</Button>
        <Button variant="secondary" size="sm" onClick={() => setShowCancel(false)}>Нет</Button>
    </div>
</Modal>
```

**JSX Fragment pitfall**: The active job view returns both the job frame `<div>` AND the `<Modal>`. They MUST be wrapped in `<>...</>` — returning two sibling JSX elements without a Fragment is a build error.

The active job view on JobsPage shows the background image in a styled frame with dark overlay:

**Server** (`routes/jobs.ts` — `startJobForUser`): include `background` in activeJob JSON AND API response:
```ts
const activeJob = JSON.stringify({ ..., background: job.background || null });
res.json({ ..., background: job.background || null });
```

**Client** (`JobsPage.tsx` — both handler and render):
```tsx
// In handleStart:
activeJob: { ..., background: result.background || null }

// In render:
const bg = (activeJob as any).background;
<div className="relative text-center py-8 px-4 rounded-xl overflow-hidden border-2
     border-[var(--color-border-default)] min-h-[200px] flex flex-col items-center justify-center mt-6 mx-4"
     style={bg ? { backgroundImage: `url(${bg})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
    {bg && <div className="absolute inset-0 bg-black/60" />}
    <div className="relative z-10">
        {/* job name, timer, reward, XP */}
    </div>
</div>
```

The `mt-6 mx-4` provides spacing from header and page edges. The `bg-black/60` overlay ensures text readability. Without a background, the frame still renders with the border.

### Pitfall — DB column required

When adding image support to a new entity, add the column in migrations BEFORE deploying the uploader. Without it, admin CRUD endpoints silently ignore the field (they only UPDATE named columns in their SQL).

## Avatar System

Users upload custom character card images via Account page. Server: `POST /api/account/avatar` (base64 in JSON), static serving via nginx + express.static. Client: CharacterCard uses avatar as backgroundImage if set. Must propagate `avatar` field through ALL CharacterCardData constructors (LeftSidebar, Arena, Bestiary, Profile). See `references/avatars.md`.
