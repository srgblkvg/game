# Guest Toggle — File-by-File Changes

## server/src/middleware/auth.ts
- Added: `guestRestrictionsDisabled` boolean
- Added exports: `isGuestRestrictionsDisabled()`, `setGuestRestrictionsDisabled(v)`, `toggleGuestRestrictions()`
- Modified `requireFullAccess`: `if (guestRestrictionsDisabled) return next()`

## server/src/middleware/guestCooldown.ts
- Imported `isGuestRestrictionsDisabled` from `./auth`
- Added at start of function: `if (isGuestRestrictionsDisabled()) return next()`

## server/src/websocket.ts
- Imported `isGuestRestrictionsDisabled` from `./middleware/auth`
- Changed chat block: `if (user.isGuest && !isGuestRestrictionsDisabled())`

## server/src/setupRoutes.ts
- Added endpoint `POST /api/admin/toggle-guest` with `authMiddleware` + `requireAdmin`

## client/src/components/chat/ChatInput.tsx
- Changed: `isDisabled = isBanned || isGuest` → `isDisabled = isBanned`

## client/src/components/Actions.tsx
- Removed: `guestBlockedPaths`, `guestTooltip`, `isGuestBlocked` variable
- Removed: guest blocking overlay
- Removed: `isGuest` prop from CardGrid
