# db.run auto-adds RETURNING id

`db.run()` in `server/src/db/index.ts` (line 140) automatically appends `RETURNING id` to all INSERT statements:

```typescript
const returningQuery = q.replace(/;?\s*$/, '') + ' RETURNING id';
```

**Pitfall:** If your INSERT already has `RETURNING id` → `RETURNING id RETURNING id` → SQL error. Catch silently falls back to simple insert without RETURNING, returning `lastInsertRowid: 0`.

**Fix:** NEVER include `RETURNING id` in queries passed to `db.run()`. Just write `INSERT INTO ... VALUES (...)`.

**Also:** `db.run()` returns `{ changes, lastInsertRowid }` — NOT `lastID` or `id`.
