# Express Route Ordering Pitfalls

## Static routes must be registered BEFORE parameterised routes
Express matches routes in registration order. A parameterised route like
`GET /resource/:id` will match anything, including sub-resource paths.

### Real bug: /api/guild/quest returning 500
**Symptom:** `GET /api/guild/quest` → 500 with PG error `invalid input syntax for type integer: "NaN"`

**Root cause:** `router.get('/guild/:id', ...)` was registered at line 234,
BEFORE `router.get('/guild/quest', ...)` at line 1016.
Express matched `/guild/quest` against `:id` pattern with `id = "quest"`.
`parseInt("quest")` → `NaN` → passed to PG as integer parameter → crash.

### Fix (2 options)

**Option A — Reorder routes (preferred for new code):**
Register `/guild/quest` BEFORE `/guild/:id`.

**Option B — Guard clause (minimal change):**
```typescript
router.get('/guild/:id', async (req, res, next) => {
    const guildId = parseInt(req.params.id);
    if (isNaN(guildId)) return next(); // pass to next matching route
    // ... rest of handler
});
```
Requires adding `next` to handler params.

### Same pattern applies to
- `/api/users/:id` vs `/api/users/me`
- `/api/items/:id` vs `/api/items/craft`
- Any REST resource with sub-resource endpoints
