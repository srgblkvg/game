# Balance, Battle Rewards & UI Patterns

## WS balance freeze during battles
To prevent serverTick from updating Header money during battle animation, use a global flag:
- `(window as any).__battling = true` **before** any battle fetch call (NOT after — serverTick may fire during await)
- `(window as any).__battling = false` in `finishBattle()`, `handleSkip()`, or animation-end callback
- Header `balance` listener: `if ((window as any).__battling) return;`

## Deferred rewards (PvE/Bestiary) — refs over state
When rewards must appear AFTER animation (not during), use refs instead of React state:
```
const pendingCharRef = useRef<any>(null);
const pendingDropsRef = useRef<any[]>([]);

const applyPending = useCallback(() => {
    if (pendingCharRef.current) {
        setCharacter(pendingCharRef.current);
        pendingCharRef.current = null;
    }
    if (pendingDropsRef.current.length > 0) {
        pendingDropsRef.current.forEach((d, i) => setTimeout(() => showAcquire(d, 1, 'Добыто'), i * 400));
        pendingDropsRef.current = [];
    }
    (window as any).__battling = false;
}, [setCharacter, showAcquire]);
```
- Set refs after fetch resolves, call `applyPending()` in `nextStep()` when `next >= steps.length`
- Do NOT use useEffect with `currentStep` dependency — React batching causes timing gaps on high speed
- Also call `applyPending()` in `handleSkip`

## Arena money flow
- `loadOpponent(change=true)` → server deducts 10 → client `setCharacter({money: deducted})`
- `handleStartBattle` → `__battling = true` BEFORE fetch → no money update
- `finishBattle()` → `money: battleResult.moneyAfter` → `__battling = false`
- `handleSkip()` → also sets final HP + `__battling = false`
- Base PvP reward of 10 silver was removed (only stealing remains)

## camelCase converter pitfalls
The PG adapter's `camelRows` uses suffix-based regex. Watch for false matches:
- `fromaccount` → `fromacCount` (suffix `count` matches!) → needs explicit `.replace(/^fromaccount$/i, 'fromAccount')`
- `toaccount` → same issue → explicit `.replace(/^toaccount$/i, 'toAccount')`
- `item_name` → `item_Name` (suffix `name` matches!) — use original key `row.item_name`, not `row.itemName`
- When adding new columns with compound names, add explicit replace rules BEFORE the generic suffix loop

## Bank transfers — account number auto-generation
Users may not have `accountNumber` set. Generate on first access:
- `GET /bank` — if `!user.accountNumber`, generate 6-char alphanumeric, UPDATE users, return it
- `POST /bank/transfer` — same for sender: if `!sender.accountnumber`, generate and UPDATE
- Raw PG client queries return lowercase keys; use `sender.accountnumber` not `sender.accountNumber`

## Auction patterns
- `GET /auction` list: JOIN `users b ON l.currentBidderId = b.id` to include `currentBidderName`
- Client: validate `amount < minBid` BEFORE sending fetch (browser `min` attribute doesn't block onClick)
- Clear `bidAmount[lotId]` after successful bid so placeholder shows updated minimum
- `minBid = lot.currentBid ? lot.currentBid + max(1, 5%) : lot.startPrice`

## Tournament creation — player check
Before auto-creating official tournaments in `getOrCreateTournament()`:
```
SELECT COUNT(*) FROM users WHERE level >= div.minLevel AND level <= div.maxLevel
```
Skip division if count = 0.

## Collection notifications
- BuffsBlock green dot: fetch BOTH `/api/collections` AND `/api/collections/set-items`
- Only show "addable" if inventory item exists in `collection_set_items` (validSet), not just "in inventory + not collected"
- Endpoint: `GET /collections/set-items` returns all `collection_set_items` rows