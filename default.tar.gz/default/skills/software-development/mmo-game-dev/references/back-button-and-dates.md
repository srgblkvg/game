# BackButton Component

Reusable back button used on all player-facing pages. Located at `client/src/components/BackButton.tsx`.

Usage:
```tsx
import BackButton from '../components/BackButton';
// In page, above the <h1>:
<BackButton />
```

The button calls `navigate(-1)` and shows "← Назад". NOT shown on the home page.

Do NOT put the back button in the Header — the user explicitly rejected that. Each page renders its own.

## Date formatting (ISO strings)

**Pitfall**: when the server returns ISO strings via `new Date().toISOString()`, they already end with `Z`. Adding `+ 'Z'` on the client creates `...ZZ` which is invalid → "Invalid Date".

**Fix**: use `new Date(iso)` directly, check `isNaN(d.getTime())`:
```tsx
const formatTime = (iso: string) => {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleString('ru-RU', { ... });
};
```
