# Forum Patterns

## Markdown Rendering

Use `marked` + `DOMPurify` for safe MD rendering:

```tsx
import { marked } from 'marked';
import DOMPurify from 'dompurify';

marked.setOptions({ breaks: true, gfm: true });

function renderMd(content: string): string {
    const raw = marked.parse(content, { async: false }) as string;
    return DOMPurify.sanitize(raw, {
        ALLOWED_TAGS: ['p', 'br', 'strong', 'em', 'del', 'code', 'pre', 'h1', 'h2', 'h3',
            'ul', 'ol', 'li', 'a', 'blockquote', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'hr', 'img', 'span'],
        ALLOWED_ATTR: ['href', 'src', 'alt', 'title', 'class', 'target'],
    });
}
```

**Styling**: Inject a `<style>` tag scoped to `.forum-content` for blockquotes, code, tables, etc. marked's default blockquotes won't have the blue left border — CSS is required:

```css
.forum-content blockquote {
    border-left: 2px solid var(--color-accent-info);
    padding-left: 0.75rem;
    margin: 0.5rem 0;
    color: var(--color-text-muted);
}
```

## Polls (Голосования)

### DB Tables
- `forum_polls(id SERIAL, thread_id INTEGER UNIQUE REF, question TEXT)`
- `forum_poll_options(id SERIAL, poll_id REF, option_text TEXT, votes_count INT DEFAULT 0)`
- `forum_poll_votes(poll_id, option_id, user_id, UNIQUE(poll_id, user_id))`

Create with:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"CREATE TABLE IF NOT EXISTS forum_polls (...)\""
GRANT ALL ON forum_polls, forum_poll_options, forum_poll_votes TO game;
GRANT USAGE, SELECT ON SEQUENCE forum_polls_id_seq, forum_poll_options_id_seq TO game;
```

### API Endpoints
- `POST /forum/thread` — accepts optional `poll: { question, options: string[] }`, validates 2-10 non-empty options
- `GET /forum/thread/:id` — includes `poll` object with nested `options[]`
- `POST /forum/poll/vote` — body `{ threadId, optionId }`, checks thread not closed, one vote per user

### Client Poll Widget
Display between title and first post. Each option is a button showing vote count + percentage + progress bar. Disable voting when thread is closed.

## Closed Thread Restrictions

When `thread.is_closed === true`:

**Client**:
- Hide "Ответить" and "✎" buttons on all posts (pass `isClosed` prop to PostCard)
- Hide "✎" (edit title) button for author
- Disable poll voting buttons (`disabled={pollVoting || thread.is_closed}`)
- Reply form replaced with "🔒 Тема закрыта" card (existing behavior)

**Server** (defense in depth):
- `PUT /forum/post/:id` — JOIN threads to check `is_closed`, return 403 "Тема закрыта"
- `PUT /forum/thread/:id` — check `is_closed`, return 403
- `POST /forum/poll/vote` — check thread `is_closed`, return 403

## Author Highlight (No Icon)

First post by thread author: use CSS `border-l-4 border-l-[var(--color-accent-info)] bg-[var(--color-bg-card)]` instead of 📢 badge + "Автор" label. Cleaner and works without absolute positioning.

## Reply Target Highlight

When user clicks "Ответить" on a post, that post gets a yellow left border: `border-l-4 border-l-[var(--color-accent-warning)]`. Pass `replyParentId` as `replyTargetId` prop to PostCard.

## MD Toolbar (MdToolbar)

Component at `client/src/components/ui/MdToolbar.tsx`. Inserts markdown syntax into a textarea. Props: `{ textareaId: string }`.

**Standard symbols** (user preference — no game-icons):
- **B** (жирный `**text**`), *I* (курсив `*text*`), ~~S~~ (зачёркнутый `~~text~~`), **H** (заголовок `### `), " (цитата `> `), • (список `- `)
- Removed: code (`\``) and link (`[]()`) — user didn't want them

**Behavior**: if text is selected, wraps selection. If not, inserts placeholder and selects it for replacement. Dispatches `input` event to trigger React's onChange.

**Usage**: `<MdToolbar textareaId="reply-input" />` before the textarea. Textarea must have matching `id` attribute. For multiple textareas (edit forms), use unique IDs like `forum-edit-${post.id}`.

## Quote Handling When Replying

Two critical fixes for the "Ответить" (Reply) button:

### 1. Every line must be prefixed with `>`

Old code only prefixed the first line: `> ${cleaned}`. Multi-line content (markdown headers, lists) appeared as plain text without quote markers.

**Fix**: split on `\n`, prefix EVERY line:
```tsx
const lines = post.content.split('\n');
const quoted = lines.map((l: string) => `> ${l}`).join('\n');
```

### 2. Filter nested quotes when replying to a reply

If post.content is already a reply containing `> quoted text`, the nested quotes shouldn't appear in the new reply — only the author's own text.

**Fix**: filter out lines starting with `>` before quoting:
```tsx
const ownLines = lines.filter((l: string) => !l.startsWith('>'));
const quoted = ownLines.map((l: string) => `> ${l}`).join('\n');
```

### 3. NO truncation

Old code had `MAX_QUOTE_LENGTH = 300` and sliced `.slice(0, 300)`. User wants FULL message quoted. Removed the constant entirely.

## Focus After Reply Click

When clicking "Ответить", `setReplyText` + `setReplyParentId` must be followed by a `setTimeout(50ms)` before `scrollIntoView`/`focus()` on the reply textarea. React needs a tick to render the updated controlled value before the DOM ref is accessible. Without the timeout, subsequent reply clicks may silently fail because the ref hasn't updated.
