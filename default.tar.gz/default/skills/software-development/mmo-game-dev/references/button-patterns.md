# Button Patterns

## Disabled Button + Overlay Tooltip

When a button should be disabled but still show a tooltip on click, use an invisible overlay div on top of the disabled button. `disabled` buttons don't fire click events in most browsers.

```tsx
<div className="relative">
  <Button disabled={!hasPremium} onClick={hasPremium ? handleAction : undefined}>
    Действие
  </Button>
  {!hasPremium && (
    <div
      className="absolute inset-0 cursor-pointer"
      onClick={e => { e.stopPropagation(); setShowHint(true); }}
    />
  )}
  {showHint && (
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-3 py-1
      text-xs text-[var(--color-accent-gold)] bg-[var(--color-bg-secondary)]
      border border-[var(--color-border-default)] rounded whitespace-nowrap shadow-lg z-50">
      Доступно с Премиум
    </div>
  )}
</div>
```

Dismiss on outside click:
```tsx
useEffect(() => {
  if (!showHint) return;
  const handler = () => setShowHint(false);
  document.addEventListener('click', handler);
  return () => document.removeEventListener('click', handler);
}, [showHint]);
```

Check premium: `const hasPremium = Number((character as any)?.premium?.until || 0) > Math.floor(Date.now()/1000);`

## HP Bar Heal Button

The HealthBar component shows a `+` button on the right side of the bar when HP is not full. Click navigates to `/tavern?tab=heal`.

Props:
- `showHealButton?: boolean` — defaults to `true`, set `false` in battle pages

Usage in battles (where it should NOT show):
```tsx
<CharacterCard ... showHealButton={false} />
```

Main character card (LeftSidebar) keeps default `true` — shows the button.
