# Auction Logic Patterns

## Minimum Bid Calculation
**Rule**: new bid must ALWAYS exceed current bid by at least 1.

**Wrong** (credit this session):
```
const minBid = Math.floor(lot.currentBid * 1.05);
```
Problem: small bids (e.g. currentBid=10 → floor(10.5)=10) allow equal bids.

**Correct**:
```
const minBid = lot.currentBid
    ? lot.currentBid + Math.max(1, Math.floor(lot.currentBid * 0.05))
    : lot.startPrice;
```

Both server (`routes/auction.ts`) and client (`AuctionPage.tsx` placeholder) must use the same formula.

## Lot Cancellation
Endpoint: `POST /auction/cancel` (body: `{ lotId }`)
- Checks `lot.sellerId === userId`
- Returns item to seller's inventory (merges stackable items)
- Refunds current bid to the highest bidder
- Deletes the lot
- Commission (5% listing fee) is NOT refunded

## Buy tab: cancel button
Shown only for seller's own lots (`lot.sellerId === user?.id`).
Red-styled button with `confirm()` before cancel.
