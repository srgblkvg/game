# Admin Image Upload Infrastructure

## Server Endpoint

`POST /api/admin/upload-image` in `server/src/routes/admin.ts`:
- Accepts `{ image: "data:image/...;base64,...", folder: "items" }`
- Validates base64 format (webp/png/jpg/jpeg)
- Saves to `/opt/game/server/uploads/admin/<folder>/<timestamp>_<random>.<ext>`
- Returns `{ success: true, url: "/uploads/admin/<folder>/<file>" }`
- Directory created recursively via `fs.mkdirSync(dir, { recursive: true })`

## Gallery API

`GET /api/admin/images?folder=items` — lists all uploaded images in that folder:
```javascript
router.get('/images', (req, res) => {
    const dir = path.join(ADMIN_UPLOADS_DIR, req.query.folder || '');
    const files = fs.readdirSync(dir)
        .filter(f => /\.(webp|png|jpg|jpeg)$/i.test(f))
        .map(f => `/uploads/admin/${folder}/${f}`)
        .sort().reverse();
    res.json(files);
});
```

## Client Component

`ImageUploader` at `client/src/components/ImageUploader.tsx`:
- File input (accept="image/*") — reads as base64 via FileReader, POSTs to upload endpoint
- Preview thumbnail (w-12 h-12, object-cover)
- Upload/Replace button, Clear (✕) button
- 📁 Gallery button — opens Modal with 4-column grid of uploaded images, click to select
- Props: `currentUrl`, `folder`, `onUploaded(url)`, `label`, `className`

Usage:
```tsx
<ImageUploader
  currentUrl={formData.image || null}
  folder="items"
  onUploaded={(url) => setForm({ image: url })}
  label="Изображение предмета"
/>
```

## Body Size Limits

- Express: `express.json({ limit: '5mb' })` in `setupMiddleware.ts`
- Nginx: `client_max_body_size 10m;` in `/etc/nginx/sites-enabled/mmoarena`
- Base64 adds ~33% overhead — a 1MB image becomes ~1.33MB in JSON

## Adding a New Admin Tab

1. Create `client/src/pages/AdminPanel/AdminNewFeature.tsx`
2. Import and add to `tabs` array + render in `AdminPanel.tsx`
3. Server routes: create file in `server/src/routes/`
4. Register in `setupRoutes.ts`: `app.use('/api/admin', authMiddleware, requireAdmin, newRoutes)`
