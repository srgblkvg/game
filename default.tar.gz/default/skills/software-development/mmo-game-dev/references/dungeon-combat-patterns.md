# Dungeon Combat Patterns (2026-08-09)

Key patterns from dungeon combat rework session.

## COMBAT_SPEED multiplier

To slow down tick-based combat proportionally, add a single multiplier constant:

```typescript
const COMBAT_SPEED = 1/3; // 3x slower combat
```

Apply to ALL per-second rate calculations in the tick loop:
- `run.autoTimer += (TICK_MS / 1000) * COMBAT_SPEED`
- `enemy._lastAttack += (TICK_MS / 1000) * COMBAT_SPEED`
- `enemy.stunTimer -= (TICK_MS / 1000) * COMBAT_SPEED`
- `run.rage -= rate * COMBAT_SPEED`
- **Do NOT apply to HP regen** — floors to 0 for small values

Client progress bars must also use the same multiplier.

## targetIndex pattern

Instead of reordering enemies array to track target, use `targetIndex` field:
```typescript
targetIndex: number;
function getTarget(run) { return run.enemies[run.targetIndex]; }
```
- Never reorder or remove dead enemies
- Validate in state endpoint: if target dead, auto-switch to first alive
- Client uses `i === targetIndex` for 🎯 marker

## Dead enemies visual
Keep dead enemies in list, client: `opacity-40 grayscale`, no click, no attack bar.
Claim endpoint: check `enemies.some(e => e.hp > 0)`, NOT `enemies.length > 0`.

## Stun must reset _lastAttack
```typescript
target.stunTimer = stun;
target._lastAttack = 0; // REQUIRED — else attacks immediately after stun
```
Send `stunned: true` in state for client visual (frozen bar + indicator).

## Computed progress bars (not CSS animation)
```tsx
const elapsed = (Date.now()/1000) - lastAttackAt;
const pct = Math.min(100, (elapsed / (interval * 3)) * 100);
```
Use 50ms `setInterval` + `frameTick` state for smooth updates.

## Deferred loot
Claim accumulates, flee awards. Checkpoint preserved on death (UPDATE startedAt, not DELETE).

## Floating combat text
Parse battle log entries for damage/effects, render absolutely inside entity cards with `floatUp` CSS keyframe. Track `enemyIndex` to position per-target.
