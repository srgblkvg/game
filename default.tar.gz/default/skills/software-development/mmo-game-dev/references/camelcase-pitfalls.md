# CamelCase Converter Pitfalls

The converter at `server/src/db/index.ts` transforms PG lowercase column names to camelCase
for the `db.query()` / `db.one()` layer. It uses a suffix regex + explicit rules.

## How it works
1. PG returns all-lowercase keys (e.g., `attackerguildid`)
2. Suffix regex matches the LAST recognizable suffix: `/(hash|hp|id|until|at|time|name|type|count|...)$/i`
3. Explicit `.replace(/pattern$/i, 'Replacement')` rules handle special cases
4. **If `cc !== key`, the camelCase variant is added as a NEW property — the original lowercase key REMAINS**
5. **Golden rule: always use the original snake_case key directly on the client.** If your SQL alias is `participant_count`, read `data.participant_count`. Never guess the converted name.

## Critical limitations
- **Only ONE suffix is matched** — the regex stops at the first match from the end.
  `attackerguildid` → matches `id` → `attackerguildId` (NOT `attackerGuildId`)
- **Short words can eat characters:** `fromaccount` → matches `count` → `fromacCount` (ate 'c' from 'ac')
- Multi-word camelCase keys need **explicit rules** BEFORE the generic regex.

## Known required explicit rules
Whenever a column has two camelCase words (e.g., `attackerGuildId`), add an explicit rule:
```
.replace(/^attackerguildid$/i, 'attackerGuildId')
.replace(/^defenderguildid$/i, 'defenderGuildId')
.replace(/^currentbiddername$/i, 'currentBidderName')
.replace(/^fromaccount$/i, 'fromAccount')
.replace(/^toaccount$/i, 'toAccount')
```

Also add missing suffix words to the regex when needed: `bid`, `by`.

## PascalCase vs camelCase trap
The converter sometimes produces PascalCase when camelCase is needed:
- `taxrate` → `TaxRate` (PascalCase) should be `taxRate` (camelCase)
- Always check what the CLIENT expects vs what the converter produces.

## Number conversion
Numbers are converted from strings if:
- `n > 2147483647` OR the key matches the ID/number regex
- Suffix `id` is in the regex, so `guildid` → number (via `guildId` rule)
- But `currentbid` → NOT converted to number if the value is small (< 2^31)

## Debugging pattern
When a value is `undefined` on the client:
1. Check what PG returns (raw lowercase query on VPS)
2. Trace through camelRows conversion
3. Check what the client accesses (exact casing)
4. Add explicit rule if mismatch found
