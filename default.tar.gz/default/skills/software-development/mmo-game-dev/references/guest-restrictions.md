# Guest Restrictions Removal Pattern

When asked to remove guest restrictions for a feature, check THREE places:

## 1. Server Router Middleware
Open the route file (e.g., server/src/routes/bank.ts) and look for:
  router.use('/bank', requireFullAccess);
Comment it out:
  // router.use('/bank', requireFullAccess); // отключено для гостей

## 2. setupRoutes.ts Block
Check server/src/setupRoutes.ts — some routes are in a dedicated requireFullAccess block:
  app.use('/api', authMiddleware, requirePlayer, requireFullAccess, guestCooldown);
  app.use('/api', tournamentRoutes);
Move the route OUT of this block (before it).

## 3. Client-Side Guards
Open the page component and check for:
- if (!isGuest) loadData() in useEffect — change to loadData() unconditionally
- if (isGuest) { return <Locked message> } — remove the entire block

## Tracking
Log ALL changes in .hermes/guest/block-unblock with:
- What was removed/disabled
- Exact file + line where the change was made
- How to revert each change

## Files Already Modified (09.06.2026)
- auction.ts:8 — router.use('/auction', requireFullAccess) commented
- bank.ts:7 — router.use('/bank', requireFullAccess) commented
- craft.ts:8 — router.use('/craft', requireFullAccess) commented
- setupRoutes.ts:99 — tournamentRoutes moved before requireFullAccess block
- websocket.ts:172 — guest chat block commented out
- BankPage.tsx:30 — isGuest guard removed from useEffect
- BankPage.tsx:59 — guest lock screen removed
- TournamentPage.tsx:83 — isGuest guard removed from useEffect
- TournamentPage.tsx:133 — guest lock screen removed
- TournamentBanner.tsx:94 — guest lock block in right sidebar removed
