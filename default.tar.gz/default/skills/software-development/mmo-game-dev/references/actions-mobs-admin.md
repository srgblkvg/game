# Actions + Mobs + Floors Admin System

## DB Schema

### actions_config table (migration)

```ts
try { db.exec(`CREATE TABLE IF NOT EXISTS actions_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    section TEXT NOT NULL DEFAULT 'world',
    title TEXT NOT NULL,
    subtitle TEXT DEFAULT '',
    icon TEXT DEFAULT 'game-icons:castle',
    bg_image TEXT,
    path TEXT,
    cost INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0
)`); } catch {}
```

### Mobs columns (migration)

```ts
try { db.exec('ALTER TABLE mobs ADD COLUMN background TEXT'); } catch {}
try { db.exec('ALTER TABLE mobs ADD COLUMN description TEXT'); } catch {}
```

### Floors table (migration)

```ts
try { db.exec(`CREATE TABLE IF NOT EXISTS floors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    background TEXT,
    sort_order INTEGER DEFAULT 0
)`); } catch {}
```

After migration, seed floors from existing mob locations:

```ts
const locs = db.prepare('SELECT DISTINCT location FROM mobs').all();
const ins = db.prepare('INSERT OR IGNORE INTO floors (name) VALUES (?)');
for (const l of locs) ins.run(l.location);
```

### Seed default actions

If actions_config is empty after migration, seed the 9 default actions:

```ts
const stmt = db.prepare('INSERT INTO actions_config (section,title,subtitle,icon,bg_image,path,cost,sort_order) VALUES (?,?,?,?,?,?,?,?)');
stmt.run('world','Охота','Бестиарий (PvE)','game-icons:death-skull','/action_arena.webp','/bestiary',0,1);
stmt.run('world','Работы','Экспедиции','game-icons:swap-bag','/action_adventures.webp','/jobs',0,2);
stmt.run('world','Арена','PvP бой','game-icons:crossed-swords','/action_arena.webp',null,10,3);
stmt.run('castle','Магазин','Снаряжение','game-icons:buy-card','/action_shop.webp','/shop',0,1);
stmt.run('castle','Банк','Хранилище','game-icons:bank','/action_craft.webp','/bank',0,2);
stmt.run('castle','Крафт','Улучшения','game-icons:anvil','/action_craft.webp','/craft',0,3);
stmt.run('castle','Аукцион','Торги','game-icons:auction','/action_shop.webp','/auction',0,4);
stmt.run('castle','Трактир','Лечение и квесты','game-icons:drink-me','/action_adventures.webp','/tavern',0,5);
stmt.run('castle','Гильдия','Объединения','game-icons:castle','/action_shop.webp','/guild',0,6);
```

## Server Routes

### adminGame.ts — admin CRUD

```ts
// Actions CRUD
router.get('/actions', ...)   // SELECT * FROM actions_config ORDER BY section, sort_order
router.post('/actions', ...)  // INSERT with all fields
router.put('/actions/:id', ...)
router.delete('/actions/:id', ...)

// Mobs
router.get('/mobs', ...)      // SELECT * FROM mobs ORDER BY location, level
router.put('/mobs/:id', ...)  // UPDATE all fields including background, description
router.get('/mob-locations', ...) // SELECT DISTINCT location FROM mobs

// Floors CRUD
router.get('/floors', ...)    // SELECT * FROM floors ORDER BY sort_order, name
router.post('/floors', ...)
router.put('/floors/:id', ...)
router.delete('/floors/:id', ...)
```

Register in setupRoutes:
```ts
app.use('/api/admin', authMiddleware, requireAdmin, adminGameRoutes);
```

### Public endpoints

```ts
// actions.ts — public endpoint (before authMiddleware)
router.get('/actions', ...) // SELECT * FROM actions_config ORDER BY section, sort_order

// floors — inline in setupRoutes (before authMiddleware)
app.get('/api/floors', (_req, res) => {
    res.json(db.prepare('SELECT * FROM floors ORDER BY sort_order, name').all());
});
```

## Client: BestiaryPage — Floor Backgrounds + Mob Images

### Floor card backgrounds

Floor backgrounds come from the `floors` table (fetched via `/api/floors`). The API is public — no auth headers needed.

```tsx
const [floorsData, setFloorsData] = useState<any[]>([]);
useEffect(() => {
    fetch('/api/floors').then(r => r.json()).then(setFloorsData).catch(() => {});
}, []);

const floorBgMap = new Map(floorsData.map(f => [f.name, f.background]));
```

Floor cards render with optional background + dark overlay:
```tsx
const bg = floorBgMap.get(floor);
<Card style={bg ? { backgroundImage: `url(${bg})`, backgroundSize: 'cover' } : {}}>
    {bg && <div className="absolute inset-0 bg-black/70" />}
    <div className="relative z-10">...</div>
</Card>
```

**Pitfall**: Floor order should match mob levels (original behavior), NOT the floors table order. Build floor list from `mob.location` deduplication, but look up backgrounds from the floors table separately.

### Mob images in battle

Mob `background` is passed as `avatar` to CharacterCard:
```tsx
<CharacterCard char={{ ...selectedMob, avatar: selectedMob.background || null }} isMob />
```

CharacterCard needed a fix: for `isMob`, the bgImage now uses customUrl if available, otherwise 'none':
```tsx
const bgImage = isMob
    ? (customUrl && !avatarFailed ? `url(${customUrl})` : 'none')
    : (customUrl && !avatarFailed ? `url(${customUrl})` : `url(${defaultAvatar})`);
```

Before this fix, `isMob` always forced `bgImage = 'none'`, ignoring any avatar.

## Client: Actions.tsx — Dynamic Loading

Before: hardcoded `outsideCards` and `castleCards` arrays + `bgClassLookup` object.
After: fetch `/api/actions`, group by `section`, render dynamically:

```tsx
const [cards, setCards] = useState<ActionCard[]>([]);

useEffect(() => {
    fetch('/api/actions', { headers: getHeaders() })
        .then(r => r.json())
        .then((data: any[]) => {
            const mapped = data.map(a => ({ ...a, buttonText: a.cost > 0 ? 'В бой' : 'Перейти' }));
            setCards(mapped);
        });
}, []);

const worldCards = cards.filter(c => c.section === 'world');
const castleCards = cards.filter(c => c.section === 'castle');
```

Background image: `bgStyle = card.bg_image ? { backgroundImage: `url(${card.bg_image})` } : {}` — applied directly as inline style instead of `bgClassLookup`.

## Client: AdminGame.tsx

Admin tab with subtabs: Действия + Мобы + Этажи.

Actions subtab:
- Create/edit form: section select, title, subtitle, icon select, path, cost, sort_order
- ImageUploader for bg_image (folder="actions")
- Table: section, title, path, edit/delete buttons

Mobs subtab:
- Edit modal with ALL mob fields: name, level, hp, atk, agi, def, mst, xp, gold_min/max, location, description, background
- ImageUploader for background (folder="mobs")
- Location input with datalist from `/api/admin/mob-locations`
- Table: name, level, hp, location, edit button

Floors subtab:
- Create/edit: name, sort_order, ImageUploader for background (folder="floors")
- Card grid with background previews + dark overlay
- Click card to edit

Register in AdminPanel.tsx:
```tsx
import AdminGame from './AdminGame';
const tabs = [..., { key: 'game', label: 'Игра' }, ...];
{tab === 'game' && <AdminGame />}
```

## DB Schema

### actions_config table (migration)

```ts
try { db.exec(`CREATE TABLE IF NOT EXISTS actions_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    section TEXT NOT NULL DEFAULT 'world',
    title TEXT NOT NULL,
    subtitle TEXT DEFAULT '',
    icon TEXT DEFAULT 'game-icons:castle',
    bg_image TEXT,
    path TEXT,
    cost INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0
)`); } catch {}
```

### Mobs columns (migration)

```ts
try { db.exec('ALTER TABLE mobs ADD COLUMN background TEXT'); } catch {}
try { db.exec('ALTER TABLE mobs ADD COLUMN description TEXT'); } catch {}
```

### Seed default actions

If actions_config is empty after migration, seed the 9 default actions:

```ts
const stmt = db.prepare('INSERT INTO actions_config (section,title,subtitle,icon,bg_image,path,cost,sort_order) VALUES (?,?,?,?,?,?,?,?)');
stmt.run('world','Охота','Бестиарий (PvE)','game-icons:death-skull','/action_arena.webp','/bestiary',0,1);
stmt.run('world','Работы','Экспедиции','game-icons:swap-bag','/action_adventures.webp','/jobs',0,2);
stmt.run('world','Арена','PvP бой','game-icons:crossed-swords','/action_arena.webp',null,10,3);
stmt.run('castle','Магазин','Снаряжение','game-icons:buy-card','/action_shop.webp','/shop',0,1);
stmt.run('castle','Банк','Хранилище','game-icons:bank','/action_craft.webp','/bank',0,2);
stmt.run('castle','Крафт','Улучшения','game-icons:anvil','/action_craft.webp','/craft',0,3);
stmt.run('castle','Аукцион','Торги','game-icons:auction','/action_shop.webp','/auction',0,4);
stmt.run('castle','Трактир','Лечение и квесты','game-icons:drink-me','/action_adventures.webp','/tavern',0,5);
stmt.run('castle','Гильдия','Объединения','game-icons:castle','/action_shop.webp','/guild',0,6);
```

## Server Routes

### adminGame.ts — admin CRUD

```ts
// Actions CRUD
router.get('/actions', ...)   // SELECT * FROM actions_config ORDER BY section, sort_order
router.post('/actions', ...)  // INSERT with all fields
router.put('/actions/:id', ...)
router.delete('/actions/:id', ...)

// Mobs
router.get('/mobs', ...)      // SELECT * FROM mobs ORDER BY location, level
router.put('/mobs/:id', ...)  // UPDATE all fields including background, description
router.get('/mob-locations', ...) // SELECT DISTINCT location FROM mobs
```

Register in setupRoutes:
```ts
app.use('/api/admin', authMiddleware, requireAdmin, adminGameRoutes);
```

### actions.ts — public endpoint

```ts
router.get('/actions', ...) // SELECT * FROM actions_config ORDER BY section, sort_order
```

Register BEFORE authMiddleware in setupRoutes:
```ts
app.use('/api', actionsRoutes);
```

## Client: Actions.tsx — Dynamic Loading

Before: hardcoded `outsideCards` and `castleCards` arrays + `bgClassLookup` object.
After: fetch `/api/actions`, group by `section`, render dynamically:

```tsx
const [cards, setCards] = useState<ActionCard[]>([]);

useEffect(() => {
    fetch('/api/actions', { headers: getHeaders() })
        .then(r => r.json())
        .then((data: any[]) => {
            const mapped = data.map(a => ({ ...a, buttonText: a.cost > 0 ? 'В бой' : 'Перейти' }));
            setCards(mapped);
        });
}, []);

const worldCards = cards.filter(c => c.section === 'world');
const castleCards = cards.filter(c => c.section === 'castle');
```

Background image: `bgStyle = card.bg_image ? { backgroundImage: `url(${card.bg_image})` } : {}` — applied directly as inline style instead of `bgClassLookup`.

## Client: AdminGame.tsx

Admin tab with subtabs: Действия + Мобы.

Actions subtab:
- Create/edit form: section select, title, subtitle, icon select, path, cost, sort_order
- ImageUploader for bg_image (folder="actions")
- Table: section, title, path, edit/delete buttons

Mobs subtab:
- Edit modal with ALL mob fields: name, level, hp, atk, agi, def, mst, xp, gold_min/max, location, description, background
- ImageUploader for background (folder="mobs")
- Location input with datalist from `/api/admin/mob-locations`
- Table: name, level, hp, location, edit button

Register in AdminPanel.tsx:
```tsx
import AdminGame from './AdminGame';
const tabs = [..., { key: 'game', label: 'Игра' }, ...];
{tab === 'game' && <AdminGame />}
```
