# Tournament Bracket UI Component

Location: `client/src/components/BracketTree.tsx`

## Features
- Compact round-grouped layout (not wide horizontal columns)
- Round labels: 1/32, 1/16, 1/8, 1/4, Полуфинал, 🏆 Финал
- Match cards show player names, winners highlighted green with 🏆
- Click any match → modal with full battle log
- Battle log shows: character stats (level, S/A/D/M, HP, 🍺 drinks, 📚 collection), HP bars, per-step HP values after damage, steps separated by divider lines
- Handles `bye` slots (null players) gracefully

## Data format expected
```typescript
interface Match {
  id: number; round: number;
  player1Name: string | null; player2Name: string | null;
  winnerName: string | null;
  player1Id: number | null; player2Id: number | null;
  winnerId: number | null;
  log?: any; // JSON array of battle steps with hp1/hp2/maxHp1/maxHp2
}
```

## Server integration
Both active and completed tournament endpoints return `matches` array with `log` parsed from JSON. Completed tournaments also include `log` (added via `references/tournament-guild-fixes.md`).
