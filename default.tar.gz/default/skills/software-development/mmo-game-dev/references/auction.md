# Auction system patterns

## Server endpoints
- `GET /api/auction` — list active lots with seller name, current bidder name
- `POST /api/auction/bid` — place bid (transaction with FOR UPDATE lock)
- `POST /api/auction/buyout` — full buyout (records history, notifies seller)
- `POST /api/auction/buy-partial` — partial buy from stack
- `POST /api/auction/sell` — create lot
- `POST /api/auction/cancel` — remove own lot
- `GET /api/auction/history` — public trade history (`auction_history` table)

## Table: auction_history
```sql
CREATE TABLE auction_history (
    id SERIAL PRIMARY KEY,
    sellerId INTEGER NOT NULL,
    buyerId INTEGER NOT NULL,
    itemName TEXT NOT NULL,
    itemData TEXT,
    price INTEGER NOT NULL,
    commission INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL
);
```
Records inserted at buyout and partial-buy. History is public (no userId filter).

## Live updates via WS
- `broadcast('auction_changed', {})` — called after bid, buyout, partial-buy, sell
- Client dispatches `window.dispatchEvent(new CustomEvent('auctionChanged'))`
- `AuctionPage.tsx` listens and calls `load()` to refresh lots

## Badge on Actions card
- Server sends `sendToUser(sellerId, { type: 'auction_badge', count: 1 })` on buyout
- For offline sellers, `pushNotification({ type: 'auction_sold' })` queues for next serverTick
- `ChatContext.tsx` handles `auction_badge` → increments `window.__auctionBadge` → dispatches `auctionBadge` event
- `Actions.tsx` reads `window.__auctionBadge` (global, survives navigation) and shows red counter
- Badge resets to 0 when user clicks auction card

## Key pitfalls
- `currentBid` camelCase: `bid` MUST be in suffix list, otherwise `currentbid` stays lowercase
- `currentBidderName`: needs explicit rule (compound: `bidder` + `name` → only `name` suffix matches)
- Min bid calculation: `currentBid + max(1, 5%)`, validated client-side BEFORE sending
- Race condition on bid: use `SELECT ... FOR UPDATE` inside transaction to prevent two concurrent bids seeing same null `currentBid`
