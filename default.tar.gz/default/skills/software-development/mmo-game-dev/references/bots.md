# Game Bots — World Population System

Bots are autonomous guest players that perform random gameplay actions via the HTTP API. Used for world population and testing.

## Script Location

`server/bots/runner.js` — single Node.js file, no dependencies (uses built-in `fetch`).

## How It Works

1. Registers guest accounts via `POST /api/guest`
2. Every 5–30 seconds, picks a random action (weighted):
   - PvE (25%) — attacks mobs matching bot level, 300s cooldown
   - Job (20%) — starts random job (10/30/60 min), 600s cooldown
   - Auction (15%) — bids on or buys out lots, 60s cooldown
   - PvP (10%) — attacks random player, 300s cooldown
   - Shop (10%) — buys affordable items, 120s cooldown
   - Craft (10%) — attempts crafting if ingredients available, 120s cooldown
   - Rest (10%) — heals at tavern when HP is low, 120s cooldown

## Usage

```bash
# Run 5 bots (default)
node server/bots/runner.js 5

# PM2 permanent
pm2 start server/bots/runner.js --name game-bots -- 5
pm2 save
```

## Key Design Decisions

- **Guest accounts** — no email verification needed, disposable. Some features blocked (craft, tavern room rental) but core actions (PvE, PvP, auction, shop) work.
- **API-based** — no browser, no DOM. Calls game API directly with JWT tokens.
- **Resilient** — all actions wrapped in try/catch, graceful degradation when features are blocked or resources insufficient.
- **Cooldown system** — per-action cooldowns prevent spam and simulate realistic player pacing.

## Adding New Actions

1. Add entry in `ACTIONS` object with `{ weight, cooldown }`
2. Implement `async function doNewAction(token, botId)` 
3. Add to `actionMap` in `botLoop()`

## Caveats

- Guests have some restrictions (craft, tavern rooms). If more access needed, toggle guest restrictions via admin API or mark bot accounts as non-guest in DB.
- Bot accounts accumulate in DB — they're guest accounts (`isGuest=1`), distinct from real players.
- Each PM2 restart creates NEW bots (new guest registrations). Old bot accounts remain but stop being used.
