# Floors & Mob Backgrounds in Bestiary

## Floors table
```sql
CREATE TABLE floors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  background TEXT,
  sort_order INTEGER DEFAULT 0
);
```

## Admin: AdminGame → tab "Этажи"
- Add/edit floor name, sort_order, background via ImageUploader
- Seed from existing mob locations: `INSERT OR IGNORE INTO floors (name) SELECT DISTINCT location FROM mobs`

## Public API
GET /api/floors — returns all floors (no auth needed, defined in setupRoutes.ts)

## Client: BestiaryPage
1. Fetch floors: `fetch('/api/floors').then(r => r.json())`
2. Build bg map: `new Map(floorsData.map(f => [f.name, f.background]))`
3. Keep floor order from mobs (by level), NOT from floors table sort_order
4. Floor cards get `style={bg ? {backgroundImage: url(bg)} : {}}` with `bg-black/70` overlay

## Mob backgrounds in battle
CharacterCard has `isMob` prop. For mobs, `bgImage` falls back to `customUrl` (the background):
```typescript
const bgImage = isMob
  ? (customUrl && !avatarFailed ? `url(${customUrl})` : 'none')
  : ...
```
Pass via `char={{ avatar: selectedMob.background || null }}`.
API returns background automatically (`SELECT * FROM mobs` includes the column).
