# Dungeon (Подземелье) Development Patterns

## Architecture
- Solo dungeon with infinite floors, auto-combat with manual skills
- Server: tick-based combat engine (250ms ticks) vs normal turn-based battles
- Client: DungeonPage with tabs (Вылазка/Подготовка) and combat view

## Skills → Умения (Naming)
- Always use "умения" not "скиллы" in client text
- Always use full words: "уровень" not "ур.", "серебра" not "сер."
- Upgrade button: "Улучшить (N серебра)" not "⬆ N сер."

## Skill System
- 8 skills total, first 3 are base (start at level 1)
- Skills 4-8 require level 1 to equip (10 skill pages required)
- Level scaling: `skillBonus(level, perLevel) = (level - 1) * perLevel`
- Upgrade cost: `10 + level * 15` pages + `1000 * Math.pow(3, level)` silver
- Pages are per-skill (skill_pages.userId + skillId unique)
- Skill icons use emoji per skill ID

## Layout: Prepare Tab
- Desktop: flex row — CharacterCard (220px) left + skills right, inside `max-w-3xl` centered container
- Mobile: stacked, CharacterCard centered via `flex justify-center`
- Skills block: equipped slots (4 grid) at top, full skill list below
- Gap between card and skills: `gap-8` (32px)

## Layout: Status Tab
- Floor selection cards with checkpoints (1, 5, 10, 15...)
- Shows remaining runs, cooldown timer
- Inside same `max-w-3xl` centered container

## Layout: Combat View
- Enemies with HP bars (clickable for targeting) + attack progress bars below
- Player HP bar + auto-attack progress bar (labeled "Автоатака")
- First enemy = current target (highlighted)
- Skills grid: compact icons (4 columns), CD countdown overlay on icon, rage cost shown under icon
- Combat log below
- "Сбежать (награда потеряна)" button at bottom

## Post-Combat Room
- Auto-transitions after all enemies defeated (when `cleared` = true)
- Shows player HP + rage bars (rage continues to decay)
- Loot block: "Добыча (забирается при выходе)" — click to reveal rewards
- Continue (next floor) / Exit buttons
- On exit: full-screen loot summary with "Продолжить" to return to status tab

## Attack Progress Bars
- Player: labeled "Автоатака" above bar, fills based on autoTimer / (1/attackSpeed)
- Enemies: thin orange bar below HP, fills based on _lastAttack / 2.5s
- Smooth CSS transitions: `duration-300 ease-linear` (HP), `duration-200 ease-linear` (attack bars)
- Progress sent from server in `/dungeon/state`: `playerAttackProgress`, `enemies[].attackProgress`

## Rage Management
- Rage decays passively every tick:
  - 0.5/sec while enemies are alive (in combat)
  - 5/sec when no enemies alive (post-combat room)
- This means rage drops fast in the post-combat room — players should use skills during combat

## Player Stats
- HP and stats come from `buildPlayerStats(user, 'pve')` — uses same formulas as all other combat
- Stats are refreshed on `/dungeon/continue` (player may switch equipment between floors)
- NEVER use hardcoded formulas like `50 + level * 12` — always use `buildPlayerStats`

## Critical Server Pitfall
- `buildPlayerStats` and `/api/character/me` had a fallback chain: if active slot equipment is empty → fallback to `equipment_1` → fallback to `equipment`
- Empty `{}` is truthy in JS, so `parseEq(...) || parseEq(equipment_1)` never falls through
- FIX: check `Object.keys(equip).length === 0` instead of relying on `||` short-circuit
- This is fixed in both `db/helpers.ts` and `routes/character.ts`

## Endpoints
- GET /dungeon/status — remaining runs, cooldown, checkpoint floor
- GET /dungeon/pages — all 8 skills with levels and page counts
- POST /dungeon/start — begin run from checkpoint floor
- GET /dungeon/state — poll combat state
- POST /dungeon/skill — cast skill by ID
- POST /dungeon/target — switch auto-attack target
- POST /dungeon/claim — claim rewards and exit
- POST /dungeon/continue — proceed to next floor
- POST /dungeon/flee — escape (lose loot)
- POST /dungeon/upgrade-skill — spend pages + silver to level up
