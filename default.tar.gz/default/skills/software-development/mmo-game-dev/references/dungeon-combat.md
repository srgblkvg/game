# Dungeon Combat System

## Server Architecture
- Tick-based combat engine in-memory (Map<userId, DungeonRun>)
- TICK_MS = 100 for smooth progress bars
- State polled by client every 100ms via `/dungeon/state`
- Enemies stored in `run.enemies` with `_lastAttack` and `_attackInterval`

## buildPlayerStats — required SELECT fields
Must include ALL of: `id, level, baseS, baseA, baseD, baseM, inventory, equipment, equipment_1, equipment_2, equipment_3, active_equip_slot, drinkuntil, activedrink`
- Missing `id` → no collection/guild bonus (HP wrong)
- Missing `inventory` → collection count broken
- Missing `drinkuntil/activedrink` → drink bonuses missing

## Empty equipment slots — fallback bug
`buildPlayerStats` and `/api/character/me` had fallback: empty slot → equipment_1 → equipment.
`parseEq(null)` returns `{}` (truthy object!), so `||` never falls through.
Fix: check `Object.keys(equip).length > 0` instead of truthiness.

## Rage mechanics
- +5 per player auto-attack (+2 with Battle Cry buff)
- +3 when taking damage from enemy
- Decay: -0.5/sec in combat, -5/sec when all enemies dead
- Max 100, displayed with `Math.round(rage)`

## Enemy generation
Enemies come from `mobs` table (not hardcoded prefixes):
```ts
async function loadMobs() { return db.query('SELECT name, background, level, hp, atk FROM mobs'); }
```
Each enemy gets random `_attackInterval` (0.5-2s), label shows real value.

## Progress bar animation
DON'T use requestAnimationFrame — just poll server every 100ms with CSS `transition-all duration-200`.
The server sends `playerAttackProgress` and `attackProgress` per enemy.
Player progress: `autoTimer / (1/attackSpeed)`
Enemy progress: `_lastAttack / _attackInterval`

## Auto-attack speed formula
`baseSpeed = WEAPON_SPEED[rarity]` (e.g. 0=0.5, 6=1.8 attacks/sec)
`speed = baseSpeed / (1 + weaponStrBonus * 0.005)`, min 0.3
Only the weapon's STR bonus is used (not total STR), so weapons of same rarity differ by ~1-2%.

## Base skills
Defined by `BASE_SKILL_IDS = new Set([7, 2, 3])` — Рывок, Размах, Боевой клич.
Skill descriptions use `descScale` field to show per-level growth.

## Looting flow
1. Enemies cleared → auto-trigger loot (no manual button)
2. Progress bar: 1 second per corpse
3. Show per-floor loot ("Собрано с этажа N")
4. Show accumulated loot ("Вся добыча за поход")
5. Exit → return to dungeon status page (no separate exit screen)

## Checkpoints
Saved as `floor + 1` (not the boss floor), so resume starts after the boss.
Client shows: Этаж 1, Этаж 6, Этаж 11... (after bosses 5, 10, 15).
