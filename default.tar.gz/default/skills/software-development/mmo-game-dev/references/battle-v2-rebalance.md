# Battle v2 Rebalance (pg-native, June 2026)

## Chance formulas — base contribution: X/(X+500)
Extra stats: 0.33% per point (÷300 instead of ÷200/÷100).

| Mechanic | Formula |
|----------|---------|
| Crit chance | `min(0.8, M/(M+500) + extraCrit/300)` |
| Dodge chance | `max(0, A/(A+500)*(1−atkM/(atkM+100)) + min(0.5, extraDodge/300))` |
| Block chance | `min(1, D/(D+500) + extraFullBlock/300)` |
| Full block | `extraFullBlock/300` |
| Counter | `min(0.5, (defM+defA)/(defM+defA+atkM+atkD)*0.5 + extraCounter/300)` |
| Stun | `(atkS+atkM)/(atkS+atkM+defS+defD)*0.3` |
| Block reduction | `min(0.75, 0.5*D/max(1,atkS))` |
| Crit multiplier | `1.5 + 0.5*M/(M+50)` (unchanged) |

## Damage: mixed distribution `rollDamage(S, level)`
- 1% chance → damage = `level` (minimum)
- 98% chance → triangular distribution peaking at `level + 0.7*(S-level)`
- 1% chance → damage = `S` (maximum)

Implementation in `server/src/game/battle.ts`.

## currentStats() additions
Added `drinks` and `collection` to return type:
```typescript
return { s, a, d, m, hp, bonuses, extra,
  drinks: drinkBonuses || { s:0, a:0, d:0, m:0 },
  collection: collectionBonus || 0 };
```
`collectionBonus` = COUNT from `collections` table — each item = +1% to all stats.

## Migration notes
- Changed from `X/(X+50)` → `X/(X+150)` → `X/(X+300)` → `X/(X+500)` (iterative)
- Extra stats: `÷200` → `÷300` for crit/dodge/counter/block, `÷100` → `÷300` for fullBlock
- Old damage: `if S>level: random(level,S) else S`
- New damage: `rollDamage(S, level)` with mixed distribution
