# Dynamic UI Positioning

When positioning fixed/sticky UI elements relative to the header (which changes height dynamically — VK safe-area, faction badge, etc.), use JS measurement instead of hardcoded pixel values.

## Pattern: getBoundingClientRect + ResizeObserver

```tsx
const [headerHeight, setHeaderHeight] = useState(132);

useEffect(() => {
    const update = () => {
        const el = document.getElementById('site-header');
        const h = el ? el.getBoundingClientRect().bottom : 132;
        const safeArea = parseInt(getComputedStyle(document.documentElement)
            .getPropertyValue('--vk-top-offset')) || 0;
        setHeaderHeight(Math.max(h, 132) + safeArea);
    };
    update();
    const ro = new ResizeObserver(update);
    const el = document.getElementById('site-header');
    if (el) ro.observe(el);
    window.addEventListener('resize', update);
    return () => { ro.disconnect(); window.removeEventListener('resize', update); };
}, []);
```

Then use inline style:
```tsx
<button style={{ top: `${headerHeight}px` }} className="fixed right-3 z-45 ...">
```

**Key details:**
- `getBoundingClientRect().bottom` — exact bottom of element relative to viewport (includes breadcrumbs, faction badge, XP bar)
- `ResizeObserver` — re-measures when header height changes (content loads, VK safe-area changes)
- `--vk-top-offset` — VK WebView safe area, must be added to measured height
- Fallback to 132px if header not yet rendered

## Common elements needing this

| Element | ID | Default offset from header bottom |
|---|---|---|
| Right sidebar button | `#right-sidebar-toggle` | 0px (centered on boundary via `-12px`) |
| Right sidebar panel | `#right-sidebar-panel` | 0px |
| Notification toast | `#notification-toast` | varies |

## VK CSS overrides

When switching from hardcoded values to dynamic JS positioning, remove `!important` overrides in `theme.css` that would conflict:

```css
/* REMOVE these — now handled by JS */
html.vk-iframe #right-sidebar-toggle {
  /* top: calc(132px + var(--vk-top-offset)) !important; */
}
```
