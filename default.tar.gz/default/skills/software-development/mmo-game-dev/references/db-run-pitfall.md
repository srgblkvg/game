# db.run() Pitfall: lastInsertRowid (NOT lastID)

`db.run()` for INSERT returns `{ changes: number, lastInsertRowid: number }`.

**Common mistake:**
```typescript
const result = await db.run("INSERT INTO ...", [...]);
const id = (result as any).lastID || (result as any).id;  // ❌ undefined!
```

**Correct:**
```typescript
const result = await db.run("INSERT INTO table (col) VALUES (?)", [val]);
const id = result.lastInsertRowid;  // ✅
```

Symptom: `id` is `undefined` → subsequent SELECT/UPDATE by id fails silently → "игра не найдена", "не работает".
Occurred: dice games (2026-07-23).
