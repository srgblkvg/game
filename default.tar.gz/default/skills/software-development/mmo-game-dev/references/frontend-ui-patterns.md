# Frontend UI Patterns

## Shared Components (see also: `reusable-ui-components.md`)
- **BackButton**: `← Назад` text, no icon. Import from `../components/BackButton`.
- **PlayerBadge**: Avatar + nick + HP bar, clickable → home. Import from `../components/PlayerBadge`.
- **HealthBar "+"**: Heal button on HP bar. `showHealButton` prop (default true, false in battles).

## Admin Panel (see also: `admin-panel-patterns.md`)
- Pagination: 10 items, client-side slice or server-side LIMIT.
- Image thumbnails in table lists (w-8 h-8 for items, w-6 h-6 rounded-full for avatars).
- Action blocks in 4-column grid below user list.
- Auto-fill user ID on row click.

## VK WebView Header (see also: `vk-webview-header.md`)
- NO arbitrary padding-top. Use only `env(safe-area-inset-top, 0px)`.
- Header rendering is identical for VK and non-VK.
- Fixed elements offset via `calc(BASE + var(--vk-top-offset))`.

## Chat: Adding a New System-Message Tab (e.g., Auction, Battles)

Pattern for adding a new filterable tab to the chat panel that shows system-generated messages without mixing them into the General tab.

### Server: Insert system messages into `chat_messages`

```ts
// senderId: 0 (system), targetId: null (not private), item_data: JSON with type prefix
const itemData = JSON.stringify({
  type: 'auction_lot',  // prefix for client filtering
  lotId, itemData, startPrice, currentBid, buyoutPrice,
  currentBidderName, sellerName, endsAt, createdAt,
});
const info = await db.run(
  'INSERT INTO chat_messages (senderId, targetId, content, item_data, senderguild, senderguildid) VALUES (?, NULL, ?, ?, NULL, NULL)',
  [0, `📦 ${sellerName} выставил лот`, itemData]
);
const chatMsg = {
  id: info.lastInsertRowid, senderId: 0, senderName: 'Аукцион',
  targetId: null, content: `📦 ${sellerName} выставил лот`,
  createdAt: new Date().toISOString(),
  item: { type: 'auction_lot', lotId, itemData, ... },
};
broadcast('message', { message: chatMsg });
```

### Client: Tab + Filter + Unread + Render

1. **ChatTabs.tsx** — add tab with `onSelectAuction` handler, `unreadAuction` indicator
2. **ChatPanel.tsx** — `auctionChatActive` state, filter in `displayedMessages`:
   ```tsx
   if (auctionChatActive) return msg.item?.type?.startsWith('auction_');
   // Exclude from general:
   if (privateChatWith === null) return msg.targetId === null && !msg.item?.type?.startsWith('auction_');
   ```
3. **Unread tracking** — add `LS_AUCTION` key, count messages where `item?.type?.startsWith('auction_')` and `id > lastRead`
4. **MessageList.tsx** — check `msg.item?.type?.startsWith('auction_')` before generic item/text rendering, return custom card
5. **Collapsed indicator** — add colored dot in the collapsed header:
   ```tsx
   {unreadAuction > 0 && <span className="chat-blink w-2.5 h-2.5 rounded-full bg-[var(--color-accent-warning)] inline-block" />}
   ```
6. **Disable input** on system-message tabs — wrap ChatInput or show "только чтение" placeholder

### Cleanup: Delete messages when source data is removed

```ts
// Server: after deleting the lot
await db.run('DELETE FROM chat_messages WHERE item_data LIKE ?', [`%"lotId":${lotId}%`]);
broadcast('auction_message_removed', { lotId });  // ← CRITICAL: notify clients!
```

```tsx
// Client (ChatContext.tsx): remove from state
case 'auction_message_removed': {
  setMessages(p => p.filter(m => m.item?.lotId !== data.lotId));
  break;
}
```

**Pitfall**: DB DELETE alone is NOT enough — clients cache messages in React state + localStorage. Always pair with a WS broadcast event.



The auction buy tab filters and sorts lots client-side (server returns all active lots unpaginated). Three controls work together:

```tsx
const [auctionSearch, setAuctionSearch] = useState('');
const [category, setCategory] = useState('all');
const [sort, setSort] = useState('quality_desc');

const filteredLots = useMemo(() => {
  let result = [...lots];
  if (auctionSearch) {
    const q = auctionSearch.toLowerCase();
    result = result.filter(l => {
      const item = l.itemData;
      return item?.name?.toLowerCase().includes(q) || l.sellerName?.toLowerCase().includes(q);
    });
  }
  if (category !== 'all') {
    result = result.filter(l => getCategory(l.itemData) === category);
  }
  result.sort((a, b) => { /* price per item, buyout per item, rarity */ });
  return result;
}, [lots, auctionSearch, category, sort]);
```

### Category Detection

Categories map item properties to filter keys:

| Key | Detection |
|-----|-----------|
| `weapon` | `slot.startsWith('weapon')` |
| `shield` | `slot === 'shield'` |
| `chest` | `slot === 'chest'` |
| `helmet` | `slot === 'helmet'` |
| `gloves` | `slot === 'gloves'` |
| `boots` | `slot === 'boots'` |
| `ring` | `slot === 'ring' \|\| slot.startsWith('ring')` |
| `amulet` | `slot === 'amulet'` |
| `belt` | `slot === 'belt'` |
| `material` | `type === 'craft_item' \|\| type === 'material'` |
| `upgrade` | `itemType === 'upgrade' \|\| name.includes('Камень улучшения')` |

**🔴 Critical: upgrade check MUST come before material check** — upgrade stones have `type === 'craft_item'` which would match `material` first. Order: upgrade → material → slot match.

**🔴 Slot names in game DB** (`validation.ts` enum): `helmet`, `chest`, `gloves`, `boots`, `amulet`, `ring`, `belt`, `weapon1`, `shield`. These are DIFFERENT from common naming conventions (`head`, `hands`, `feet`, `necklace`). Always verify with `grep 'slot.*enum' validation.ts` before using slot names.

### Sort Options

Six sort modes, each computes per-item price first:
- `quality_desc/asc`: by `rarity_id`, then price as tiebreaker
- `price_asc/desc`: by `(currentBid || startPrice) / count`
- `buyout_asc/desc`: by `buyoutPrice / count` (999999999 if no buyout)

**Pitfall**: stackable lots need per-item division before sorting, otherwise 100-item stacks dominate price sorting.

### ItemTooltip — Required `position` Prop + Mobile Dismissal

`ItemTooltip` requires BOTH `item` and `position` props:
```tsx
// ✅ Correct
<ItemTooltip item={tooltip.item} position={{ x: tooltip.x, y: tooltip.y }} onDismiss={() => setTooltip(null)} />

// ❌ Missing position — crashes with "Cannot read properties of undefined (reading 'x')"
<ItemTooltip item={tooltip.item} />
```

The tooltip uses `position` for screen-edge clamping (prevents overflow). Without it, the component throws on `position.x`.

**Mobile touch dismissal (CRITICAL):** On mobile, `long press` (500ms) shows the tooltip but does NOT generate a `click` event. The global `document.addEventListener('click', dismiss)` never fires → tooltip gets stuck → interface feels «blocked».

**Fix (working approach):** Add `touchstart` listener on `document` that dismisses the tooltip, but skip touches on slot elements (which are part of the long-press gesture):

```tsx
// Inventory.tsx — dismiss handler
useEffect(() => {
    const handleClick = () => setTooltipData(null);
    const handleTouch = (e: TouchEvent) => {
        const target = e.target as HTMLElement;
        if (target.closest('[data-slot]')) return; // long press on slot → don't dismiss
        setTooltipData(null);
    };
    document.addEventListener('click', handleClick);
    document.addEventListener('touchstart', handleTouch, { passive: true });
    return () => {
        document.removeEventListener('click', handleClick);
        document.removeEventListener('touchstart', handleTouch);
    };
}, []);
```

**SlotBase.tsx must have `data-slot` attribute** for the `closest('[data-slot]')` check to work:
```tsx
// SlotBase.tsx
<div data-slot draggable={...} ...>
```

**❌ DO NOT use fullscreen backdrop** (`fixed inset-0 z-[99998]`) — it intercepts mouse/touch events, causing:
- Desktop: infinite tooltip flickering (backdrop blocks mouseenter/mouseleave on items)
- Mobile: browser context menu (backdrop catches touchstart before SlotBase's `onContextMenu preventDefault`)

This pattern should be applied in ALL components with tooltips: Inventory, CharacterCard, etc. Remove `title` attribute from equipment slots too — browser's native tooltip appears alongside custom tooltip on long press.

### Auction Card Layout — Right-Side Buttons

For the buy tab, buttons (Выкупить, Ставка, Купить) should be on the RIGHT side of the card:
```tsx
<div className="flex justify-between items-start gap-3">
  {/* Left: item image + info (flex-1 min-w-0 for truncation) */}
  <div className="cursor-default flex gap-3 flex-1 min-w-0">...</div>
  {/* Right: timer + buttons (flex-col items-end gap-2 shrink-0) */}
  <div className="flex flex-col items-end gap-2 shrink-0">
    <div className="text-xs text-muted">{hoursLeft}ч</div>
    <Button>Выкупить</Button>
    <div className="flex items-end gap-1">
      <input /> <Button>Ставка</Button>
    </div>
  </div>
</div>
```

## Rating: Server-Side ILIKE Search + ELO Filter

Search on the rating page is server-side (pagination requires it). Query params:

```ts
// server/src/routes/rating.ts
const search = (req.query.search as string) || '';
const minElo = parseInt(req.query.minElo as string) || 0;
// ... WHERE u.username ILIKE ? AND u.elo >= ?
```

Client sends via `fetchRating(page, limit, search, minElo)` using `URLSearchParams`:
```ts
const params = new URLSearchParams({ page: String(page), limit: String(limit) });
if (search) params.set('search', search);
if (minElo) params.set('minElo', String(minElo));
fetch(`${BASE_URL}/rating?${params}`, { headers: getHeaders() });
```

### Live Debounced Search

Instead of Enter-to-search, use a debounced effect that fires on every keystroke:
```tsx
const [search, setSearch] = useState('');
const [searchInput, setSearchInput] = useState('');
const debounceRef = useRef<ReturnType<typeof setTimeout>>();

useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
        setSearch(searchInput);
        setPage(1);
    }, 300);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
}, [searchInput]);
```

Input changes trigger debounce → after 300ms silence, `search` state updates → `useEffect` fires `fetchRating`. No search button needed. The `✕` button clears both `searchInput` and `search`.

### Rank Filter Dropdown

ELO range filter as a dropdown with predefined tiers matching `getRank()`:
```tsx
const rankFilters = [
    { label: 'Все звания', min: 0 },
    { label: '👑 Смерть (2100+)', min: 2100 },
    { label: '♦♦♦ Вечность (1900+)', min: 1900 },
    // ... down to
    { label: '• Пепел (0+)', min: 0 },
];

<select value={minElo} onChange={e => { setMinElo(+e.target.value); setPage(1); }}>
    {rankFilters.map(r => <option key={r.min} value={r.min}>{r.label}</option>)}
</select>
```

## Vite Deployment

After `npx vite build`, ALL chunks get new hashes. Deploy EVERYTHING, not selectively:

```bash
ssh root@194.226.142.237 "rm -rf /opt/game/client/dist/assets/*"
for f in client/dist/assets/*; do
  scp "$f" root@194.226.142.237:/opt/game/client/dist/assets/
done
scp client/dist/index.html root@194.226.142.237:/opt/game/client/dist/
```

**🔴 Selective SCP of changed files breaks the site** — index.html references new hashes, old chunks deleted, missing files return HTML 404s.

To verify: `grep -o 'assets/[^"]*\.\(css\|js\)' /opt/game/client/dist/index.html` on prod should match `ls /opt/game/client/dist/assets/`.

### Game-Icons Availability

Not all `game-icons:` names exist. Test locally by checking if the icon renders, or use known-good icons:

### Double-Fetch Prevention: initialRender Ref

When both a mount `useEffect` and a filter-debounce `useEffect` trigger `load()` on page entry, the data loads twice. Prevent by skipping the debounce effect on first render:

```tsx
const initialRender = useRef(true);
useEffect(() => {
    if (initialRender.current) { initialRender.current = false; return; }
    // debounce logic + load()
}, [filterDeps]);
```

The mount effect (e.g. `useEffect([user])`) handles the initial load. The filter effect only fires on subsequent filter changes.

### 🔴 Double-Submit Prevention: useRef Guard (CraftPage buttons)

`setState(false)` is asynchronous — between the first click and React's re-render, the button is still enabled. A fast double-tap fires the handler twice, sending duplicate requests. Use a ref for instant blocking:

```tsx
const craftingRef = useRef(false);

const handleUpgrade = async () => {
    if (!upgradeInfo || craftingRef.current) return;
    craftingRef.current = true;
    setCrafting(true);
    try {
        // ... async work ...
    } finally {
        craftingRef.current = false;
        setCrafting(false);
    }
};
```

**Apply to ALL mutation handlers**: Create, Upgrade, Curse. The ref blocks before React state updates, preventing race conditions where two concurrent requests both read the same pre-mutation state (e.g., both upgrade from +6 to +7, double-spending resources and sending duplicate chat messages).

## Collapsible Categories (▶/▼ Arrows)

Use Unicode `▶`/`▼` arrows (matching BuffsBlock and OverflowStorage patterns), NOT iconify icons. Default collapsed:

```tsx
const [expandedCats, setExpandedCats] = useState<Record<string, boolean>>({});
// expandedCats[cat] is undefined → collapsed by default

const cats = { /* group items by category */ };
Object.entries(cats).sort(/* custom order */).map(([cat, items]) => {
    const expanded = expandedCats[cat];
    return (
        <div key={cat}>
            <h3 onClick={() => setExpandedCats(prev => ({ ...prev, [cat]: !prev[cat] }))}
                className="cursor-pointer select-none flex items-center gap-1">
                <span className="text-xs">{expanded ? '▼' : '▶'}</span>
                {cat}
            </h3>
            {expanded && <div className="grid ...">{items.map(...)}</div>}
        </div>
    );
});
```

To hoist a specific category to the top: `.sort(([a], [b]) => a === 'Top' ? -1 : b === 'Top' ? 1 : a.localeCompare(b))`

## Description Banner Above Tabs

Matching tavern pattern — a muted description box above tab content, styled with `bg-[var(--color-bg-secondary)] rounded p-2`:

```tsx
<h1>Page Title</h1>
<p className="text-xs text-[var(--color-text-muted)] bg-[var(--color-bg-secondary)] rounded p-2 mb-3">
    Description text explaining the page mechanics.
</p>
{/* Tabs and content below */}
```

Use this instead of inline "Правила" cards at the bottom of each tab.
- ✅ `elf-helmet` (helmet) — NOT `visor`
- ✅ `pentacle` (amulet) — NOT `amulet`
- ✅ `crossed-swords` (weapons)
- ✅ `shield` (shield)
- ✅ `chest-armor` (chest)
- ✅ `leather-vest` (gloves)
- ✅ `boots` (boots)
- ✅ `ring` (rings)
- ✅ `belt` (belt)
- ✅ `upgrade` (upgrades)
- ✅ `powder` (materials)
- ✅ `pay-money` (coins + hand — good for auction/shop)
- ✅ `money-stack` (stack of coins)
- ✅ `cash` (cash/coins)
- ✅ `two-coins` (two coins)

### Action Card Icons — Hot DB Update

Action cards on the main page (Охота, Магазин, Банк, etc.) load icons from `actions_config` table via `/api/actions`. **No restart needed** — changes take effect on next page load.

```bash
# Check current icons
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT title, icon FROM actions_config ORDER BY sort_order;\""

# Update an icon
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"UPDATE actions_config SET icon = 'game-icons:pay-money' WHERE title = 'Аукцион';\""
```

## Guild Buildings UI

Collapsible card on `GuildPage.tsx` below treasury. Loaded on expand via `GET /api/guild/:id/buildings`. List of buildings with icon, name, description, current level, bonus %, and upgrade button.

```tsx
const [showBuildings, setShowBuildings] = useState(false);
const [buildings, setBuildings] = useState<any[]>([]);

const loadBuildings = async () => {
    if (!guild?.id) return;
    const r = await fetch(`${BASE_URL}/guild/${guild.id}/buildings`, { headers: getHeaders() });
    if (r.ok) setBuildings(await r.json());
};

const handleUpgradeBuilding = async (type: string) => {
    const r = await fetch(`${BASE_URL}/guild/${guild.id}/buildings/upgrade`, {
        method: 'POST', headers: getHeaders(),
        body: JSON.stringify({ buildingType: type }),
    });
    const d = await r.json();
    if (!r.ok) { setError(d.error); return; }
    setTreasuryBalance(d.treasury); // treasury updated on server
    loadBuildings(); // refresh levels
};
```

Only leader see upgrade buttons. Button disabled if treasury < cost or guild level < required. Hints shown: \"Только лидер\", \"Нужен ур. гильдии N\", \"Недостаточно в казне\". Server returns `canUpgrade`, `reqLevel` per building. Price icon: 💰 (not 🥇).

## CharacterCard StatsOverlay: Collection + Guild Bonuses

The `StatsOverlay` component shows a flip view (⤢ button) with equipment bonuses, extra stats, collection bonus, and guild building bonus. Getting all props through the chain requires careful mapping:

### Data Flow
```
Server: /character/me → { stats: { bonuses, extra }, collectionCount, guildBonus }
  ↓
GameContext: stores raw character object
  ↓
LeftSidebar: calculateStats() → { baseStats, equipmentBonuses, extraStats }
  ↓  ALSO passes: collectionCount: character.collectionCount, guildBonus: character.guildBonus
  ↓
CharacterCard: resolves props from stats object or char fields:
  eqBonuses = stats?.bonuses || char.equipmentBonuses  // calculateStats uses 'equipmentBonuses', API uses 'bonuses'
  exStats = stats?.extra || char.extraStats            // same mismatch
  collBonus = char.collectionCount || char.collectionBonus  // server sends 'collectionCount', some callers use 'collectionBonus'
  gBonus = char.guildBonus
  ↓
StatsOverlay: receives as explicit props, renders in flip view
```

### Naming Mismatch (CRITICAL)

`calculateStats()` returns `equipmentBonuses` and `extraStats`, but the server API returns `stats.bonuses` and `stats.extra`. The CharacterCard must resolve both:
```tsx
const eqBonuses = stats?.bonuses || (char as any).equipmentBonuses || { s: 0, a: 0, d: 0, m: 0 };
const exStats = stats?.extra || (char as any).extraStats || { crit: 0, dodge: 0, counter: 0, fullBlock: 0 };
```

### Show Flip Button When Only Collection/Guild Data Exists

The flip button was gated by `hasBonuses = baseStats && equipmentBonuses`. If equipment has zero bonuses but collection/guild data exists, the button won't show. Fix:
```tsx
const hasBonuses = baseStats && equipmentBonuses;
const hasExtra = collectionBonus || guildBonus;
const showFlip = hasBonuses || hasExtra;
// Use showFlip for both the button visibility AND the flipped view condition
```

### HP Regen: Client-Side Premium Integration

The client-side `getRegenHp()` in GameContext doesn't need premium awareness — `LeftSidebar` already computes `effectiveRoom`:
```tsx
const effectiveRoom = character.room || (
    (character.premium?.until || 0) > serverTime
        ? { type: 'closet', until: character.premium!.until }
        : null
);
const regenHp = getRegenHp(character.currentHp, stats.hp, serverTime, effectiveRoom?.type, effectiveRoom?.until);
```

Premium users auto-get closet (×3 regen) without renting a room. The server-side `applyHpRegen()` also checks `premiumUntil` independently. Both must agree for consistent HP display.

## Glassmorphism: Semi-Transparent Cards with Backdrop Blur

Replace flat `--color-bg-card` with semi-transparent value + targeted `backdrop-blur`:

```css
/* In @theme block */
--color-bg-card: rgba(30, 30, 55, 0.65);      /* was: #2a2a3e */
--color-bg-secondary: rgba(20, 20, 40, 0.85);  /* was: #1e1e30 */
```

Add `backdrop-blur-sm` to the shared `Card` component OR modal containers:

```tsx
// Card.tsx
className={['bg-[var(--color-bg-card)] rounded-xl backdrop-blur-sm', ...]}
```

**Do NOT** apply `backdrop-filter` globally via `[class*="rounded"]` — it hits buttons, inputs, and icons, hurting performance and appearance. Target the Card component and modal containers (`[class*="shadow-2xl"]`).

**Light theme**: also use semi-transparent values so cards show depth against the light gradient background.

## Battle Animations (Arena)

### Architecture

`useBattleLogic.ts` drives card animations during battle via `executeStep()`. On each battle step, it adds CSS classes to the fighter frame elements (`#fighter-left`, `#fighter-right`) and text overlays to `#effect-left` / `#effect-right` inside `CharacterCard`. All animation keyframes live in `theme.css`.

**Key DOM elements:**
| Element | Selector | Purpose |
|---------|----------|---------|
| Fighter frame | `#fighter-left`, `#fighter-right` | Attack/dodge/stun CSS classes applied here |
| Fighter card | `.fighter-card.left`, `.fighter-card.right` | z-index raised during attacks, damage-float appended here |
| Effect overlay | `#effect-left`, `#effect-right` | Text popups (УКЛОНЕНИЕ!, КРИТ!, etc.) |
| Battle arena | `[data-battle-arena]` | Screen-shake target on crit |

### 🔴 CSS Selector Mismatch Pitfall

JS adds classes to `#fighter-left` / `#fighter-right` (the inner frame), but CSS selectors may target `.fighter-card` (the outer card). These are DIFFERENT elements — the animation won't fire:

```css
/* ❌ BROKEN — JS adds class to #fighter-left, not .fighter-card */
.fighter-card.dodging { animation: dodge-anim 0.5s ease-out; }
.fighter-card.stunned { animation: stun-pulse 0.5s infinite alternate; }
.fighter-card.blocking { box-shadow: 0 0 15px 5px #3498db; }

/* ✅ CORRECT — matches the element JS targets */
#fighter-left.dodging, #fighter-right.dodging { animation: dodge-slide 0.55s ease-out; }
#fighter-left.stunned, #fighter-right.stunned { animation: stun-shake 0.8s ease-in-out; }
#fighter-left.blocking, #fighter-right.blocking { box-shadow: 0 0 20px 8px #3498db; }
```

Verify after changes: `grep -c 'critting\|stun-shake\|dodge-slide' dist/assets/index-*.css` should return > 0.

### Animation Classes Reference

| Battle Step | CSS Class | Duration | Visual Effect |
|-------------|-----------|----------|---------------|
| `attack` | `attacking` | 0.6s | rotate 10° + translateX 30px |
| `crit` | `critting` | 0.7s | rotate 20° + scale 1.15 + brightness 1.4 + red drop-shadow |
| `dodge` | `dodging` | 0.55s | translateX -45px + blur(2px) |
| `counter` | `attacking` | 0.6s | same as attack (counter-attacker swings) |
| `block` / `fullBlock` | `blocking` | 0.6s | blue box-shadow glow + inset |
| `stun` | `stunned` | 0.8s | shake ±7px + rotate ±3° + ✨ stars + yellow aura |

### Crit: Screen Shake + Damage Float

Crit triggers two extra effects beyond the `critting` animation on the frame:
1. **Screen shake**: `[data-battle-arena]` gets `animation: screen-shake 0.5s ease-out`
2. **Big damage number**: `showDamageNumber()` adds class `crit-damage` — 2rem red with glow, floats higher

The `data-battle-arena` attribute must be on the flex container wrapping both CharacterCards in ArenaPage:
```tsx
<div data-battle-arena className="flex justify-between sm:justify-center ...">
  <CharacterCard ... />
  <CharacterCard ... />
</div>
```

### Crit Detection in executeStep

The crit step and its damage step are adjacent in `battleSteps[]`. Look backward:
```ts
const isCritDamage = step.type === 'damage' && battleSteps[stepIndex - 1]?.type === 'crit';
```
This requires `executeStep(step, stepIndex)` — the step index is passed from `nextStep()`.

### Effect Overlay Timing

`showEffectText()` sets `#effect-left.show` or `#effect-right.show` which triggers `effect-fade` (1.2s scale+fade). The overlay auto-removes on `animationend`. Make sure the `effect-overlay` div exists in CharacterCard (line 213):
```html
<div className="effect-overlay" id={`effect-${side}`}></div>
```

### Preventing Animation Conflict

When adding classes, clear filters/styles after animation ends:
```ts
// Dodge: clear blur after animation
setTimeout(() => {
    frame?.classList.remove('dodging');
    frame!.style.filter = '';
}, 550);
```

## Rarity Glow on Item Slots

CSS-only pulsing border glow for epic, legendary, mythic items:

```css
@keyframes glowEpic {
  0%, 100% { box-shadow: 0 0 8px rgba(155,89,182,0.4), inset 0 0 8px rgba(155,89,182,0.1); }
  50% { box-shadow: 0 0 18px rgba(155,89,182,0.7), inset 0 0 14px rgba(155,89,182,0.2); }
}
.rarity-epic { animation: glowEpic 2.5s ease-in-out infinite; }
/* Same pattern for .rarity-legendary (gold) and .rarity-mythic (red) */
```

Bind via `rarity_id` → class name in `itemUtils.ts`:
```ts
const rarityClasses = ['rarity-junk','rarity-common','rarity-uncommon','rarity-rare','rarity-epic','rarity-legendary','rarity-mythic'];
export function getRarityClass(item: any): string {
    return item?.rarity_id != null ? rarityClasses[item.rarity_id] || '' : '';
}
```

Apply in `SlotBase.tsx`:
```tsx
const rarityClass = getRarityClass(item);
const slotClassName = `... ${rarityClass} ...`;
```

## Particle Effects (Coins, Sparks, Confetti)

Vanilla JS — no dependencies. Creates temporary DOM elements with CSS `@keyframes particle-fly`:

```ts
// utils/particles.ts
export function spawnParticles(type: 'coins'|'sparks'|'confetti', x?, y?) { ... }
```

CSS animation uses custom properties for direction:
```css
@keyframes particle-fly {
  0% { opacity: 1; transform: translate(0, 0) scale(1); }
  100% { opacity: 0; transform: translate(var(--px), var(--py)) scale(0); }
}
```

**Integration points:**
- **Coins**: in `Header.tsx` `onBalance` handler — if `money > prevMoney` → `spawnParticles('coins')`
- **Sparks**: in `CraftPage.tsx` after successful craft — `spawnParticles('sparks')`
- **Confetti**: in `Header.tsx` `onBalance` — if `level > prevLevel` → `spawnParticles('confetti')`

Use `useRef` for tracking previous money/level values to detect increases.

## Theme-Specific Backgrounds (MOBILE-SAFE)

**🔴 CRITICAL: `background-attachment: fixed` is BROKEN on mobile browsers** (Yandex, Safari iOS, Chrome Android).
The background renders at viewport size but `body` extends beyond (due to `padding-bottom` or content overflow), leaving a stripe in the gap.

### PRIMARY APPROACH: Background on `html` (canvas) ← RECOMMENDED

The `html` element's background IS the browser canvas. It always fills the ENTIRE viewport, regardless of content size,
browser toolbar show/hide, scroll position, or viewport changes. No `position: fixed`, no `z-index`, no pseudo-elements needed.

**This is the simplest, most reliable approach. Use this first.**

```css
/* Dark theme — one linear-gradient on html */
html {
  font-size: 24px;
  background: linear-gradient(180deg, #0a0a1e 0%, #12122a 40%, #1a1a35 100%);
}

/* Light theme — override on html itself */
html[data-theme="light"] {
  background: linear-gradient(180deg, #f5f0e8 0%, #ede4d4 40%, #e8dcc8 100%);
}

/* body is clean — only padding */
body {
  padding-bottom: max(env(safe-area-inset-bottom, 0px), 40px);
}
```

**✅ Advantages over `body::before` approach:**
- No `position: fixed` / `z-index` stacking context issues
- No pseudo-element rendering quirks
- Works instantly with viewport changes (toolbar show/hide)
- Canvas background is the first thing the browser paints — no gap possible

### ALTERNATIVE: `position: fixed` pseudo-element (fallback if canvas approach fails)

Only use this if the html-canvas approach somehow doesn't work. It has known issues with `z-index` stacking
and may still show stripes on some mobile browsers.

```css
body::before {
  content: '';
  position: fixed;
  inset: 0;
  z-index: -1;
  background: linear-gradient(180deg, #0a0a1e 0%, #12122a 40%, #1a1a35 100%);
}
body { background: transparent; }
```

### 🔴 Avoid many radial-gradient layers on mobile

16+ `radial-gradient()` layers for star effects are **very expensive** to render on mobile GPUs.
They cause scroll jank and battery drain. Use a single `linear-gradient` instead.
If stars are needed, limit to 3-5 layers max and test on real mobile devices.

### Selector pitfalls

**🔴 `[data-theme="light"] html` does NOT work** — `html` is the root element with no ancestors.
The correct selector is `html[data-theme="light"]` (attribute on the element itself).

`[data-theme="light"] body` DOES work because `body` is a descendant of `<html>` which carries the `data-theme` attribute.

**🔴 `background:` shorthand resets `background-color` to `transparent`.** When using multiple background layers and
`background-color` as fallback, use `background-color:` + `background-image:` as separate properties instead of the shorthand.

### Dynamic viewport height: `100dvh` for mobile toolbar

**🔴 `min-height: 100vh` produces a stripe when browser toolbars hide on scroll** (Yandex, Chrome Android, Safari iOS).
When the user scrolls down, the browser hides its address bar. The viewport grows, but `100vh` was calculated
with the toolbar visible (smaller height). Content doesn't reach the new bottom → visible gap.

**Fix**: Use `100dvh` (dynamic viewport height) as a progressive enhancement:

```css
html, body, #root {
  min-height: 100vh;       /* fallback for older browsers */
  min-height: 100dvh;      /* dynamically adjusts as toolbar shows/hides */
}
```

`dvh` updates in real-time when the browser chrome changes. Supported in Chrome 108+, Firefox 101+, Safari 15.4+.
Yandex (Chromium-based) supports it.

### Padding-bottom must match fixed bottom elements

If the page has a fixed bottom bar (chat header, nav), the body's `padding-bottom` should match its height
exactly — not larger. Otherwise the gap between content end and the fixed bar shows as a visible stripe.

```css
body {
  /* 40px = высота свёрнутого чат-бара. Без зазора между контентом и баром. */
  padding-bottom: max(env(safe-area-inset-bottom, 0px), 40px);
}
```

Too-large padding (e.g., 50px with a 40px bar) leaves a 10px visible band of background color.
On non-iOS devices, `safe-area-inset-bottom` is 0, so `max(0, 40px) = 40px` — exactly the bar height.

### Build note

Vite/minifier converts `::before` to `:before` in production builds — both work identically. When grepping
built CSS, use `:before` (single colon).

## Tutorial System (TutorialOverlay)

Driven by `data/tutorialSteps.ts` — array of `TutorialStep` objects. Each step has `targetSelector` (CSS selector), `title`, `description`, optional `tooltipPosition` and `action`. The `action` dispatches a `CustomEvent` when the step is shown.

### Multiple actions per step (comma-separated)

`TutorialOverlay.tsx` supports comma-separated actions:
```typescript
// Dispatch
if (step?.action) {
  step.action.split(',').forEach(a => {
    window.dispatchEvent(new CustomEvent(a.trim()));
  });
}
```

Step definition example:
```typescript
{ action: 'tutorial-collapse-stats, tutorial-expand-buffs', ... }
```

### Event-driven expand/collapse

Components listen for tutorial events via `window.addEventListener`:
```typescript
// StatAllocation.tsx
useEffect(() => {
    const expand = () => setCollapsed(false);
    const collapse = () => setCollapsed(true);
    window.addEventListener('tutorial-expand-stats', expand);
    window.addEventListener('tutorial-collapse-stats', collapse);
    return () => { /* remove listeners */ };
}, []);
```

**Pitfall**: Don't put collapse on the same step that shows the element — it collapses immediately. Instead, collapse on the FIRST step of the NEXT section, so the user sees the element, clicks "Next", then it collapses:
```
Step 7: Mastery (last stat — no collapse)
Step 8: Buffs (first of next section) → action: 'tutorial-collapse-stats, tutorial-expand-buffs'
```

### Scroll with chat panel clearance

When scrolling element into view during tutorial, account for both header AND chat panel at bottom:
```typescript
const chatEl = document.querySelector('.chat-panel');
const chatH = chatEl ? chatEl.getBoundingClientRect().height : 0;
const bottomClearance = chatH;

const isFullyVisible = rect.bottom <= vh - bottomClearance;

// After scrollIntoView, if still under chat:
if (afterRect.bottom > vh - bottomClearance - 16) {
    window.scrollBy({ top: -(afterRect.bottom - (vh - bottomClearance) + 16) });
}
```

### Tooltip gap for highlights

On narrow screens (VK iframe 911×700), tooltip may overlap highlight box. Increase gap:
```typescript
const gap = 48; // default was 24 — bumped to avoid overlap
```

### Tab switching from tutorial

Actions component listens for tab switch events:
```typescript
useEffect(() => {
    const toWorld = () => setActiveTab('world');
    const toCastle = () => setActiveTab('castle');
    window.addEventListener('tutorial-tab-world', toWorld);
    window.addEventListener('tutorial-tab-castle', toCastle);
    return () => { /* cleanup */ };
}, []);
```

Step definition: `{ action: 'tutorial-tab-castle', ... }` — switches to Площадь tab.

### PageHeader component

Full-width banner on pages from action cards. Uses `<img>` tag (not CSS `background-image`) for VK WebView compatibility. Accepts `title`, `icon`, `bgImage` props. Positioned inside the page's content container for width-matching.

## Inventory Performance: useMemo + useCallback + React.memo

**Symptom:** на мобилке лагает при открытом инвентаре. Причина: пересчёт `orderedEquipment` O(n²) на каждом рендере + пересоздание inline-функций.

**Fixes applied (Inventory.tsx):**

### 1. useMemo для дорогих вычислений
```tsx
// ❌ Было — пересчёт на каждом рендере
const sortedEquipment = sortItems(equipmentItems, sortEquipment);
const orderedEquipment = inventoryOrder.length > 0 ? (() => {
    const idToItem = new Map(...);
    const ordered = inventoryOrder.map(id => idToItem.get(id));
    for (const item of equipmentItems) {
        if (!inventoryOrder.includes(String(item.id))) ordered.push(item); // O(n²)
    }
    return ordered;
})() : sortedEquipment;

// ✅ Стало
const sortedEquipment = useMemo(() => sortItems(equipmentItems, sortEquipment), [equipmentItems, sortEquipment]);
const orderedEquipment = useMemo(() => {
    if (inventoryOrder.length === 0) return sortedEquipment;
    const idToItem = new Map(equipmentItems.map(i => [String(i.id), i]));
    const orderSet = new Set(inventoryOrder); // O(1) lookup
    const ordered = inventoryOrder.map(id => idToItem.get(id)).filter(Boolean);
    for (const item of equipmentItems) {
        if (!orderSet.has(String(item.id))) ordered.push(item);
    }
    return ordered;
}, [equipmentItems, inventoryOrder, sortedEquipment]);
```

### 2. inventoryOrder effect — не пересчитывать без нужды
```tsx
// ❌ Было — срабатывал на КАЖДОЕ изменение character.inventory (HP-тик)
useEffect(() => {
    const equipment = character.inventory.filter(i => !isCraftItem(i));
    setInventoryOrder(equipment.map(i => String(i.id)));
}, [character?.inventory]);

// ✅ Стало — проверяет состав по строке ID
const inventoryRef = useRef<string>('');
useEffect(() => {
    if (!character?.inventory) return;
    const equipIds = character.inventory
        .filter(i => !isCraftItem(i))
        .map(i => String(i.id)).join(',');
    if (equipIds === inventoryRef.current) return;
    inventoryRef.current = equipIds;
    setInventoryOrder(equipIds ? equipIds.split(',') : []);
}, [character?.inventory]);
```

### 3. React.memo на дочерних компонентах
```tsx
const LongPressItemSlot = React.memo(function LongPressItemSlot({...}) { ... });
export default LongPressItemSlot;
```
Работает только если пропсы стабильны — для этого useCallback на обработчиках.

### 4. useCallback на стабильных обработчиках
```tsx
const handleLongPress = useCallback((item, e) => {
    const touch = e.touches?.[0] ?? e;
    setTooltipData({ item, x: touch.clientX, y: touch.clientY });
}, []);
```
Зависимости `[]` корректны, если используется только `setTooltipData` (React гарантирует стабильность setState).

### Bundle: все три оптимизации дают заметный прирост на мобилке
- useMemo убирает O(n²) на каждом рендере
- inventoryRef предотвращает лишние setState при HP-тиках
- React.memo + useCallback предотвращают ререндер 30+ слотов в гриде

Controller for inventory collapse state and sort preference:
```typescript
const [collapsed, setCollapsed] = useState(
    () => localStorage.getItem('invCollapsed') === '1'
);
const [sortEquipment, setSortEquipment] = useState<SortOrder>(
    () => (localStorage.getItem('invSort') as SortOrder) || 'none'
);

useEffect(() => { localStorage.setItem('invCollapsed', collapsed ? '1' : '0'); }, [collapsed]);
useEffect(() => { localStorage.setItem('invSort', sortEquipment); }, [sortEquipment]);
```

Pass `collapsible={false}` to disable collapse (e.g., on CraftPage where inventory must stay expanded).

## Platform Adapter pattern

`src/platforms/` — pattern for multi-platform support (browser, VK, future OK/Yandex):

```
types.ts        — PlatformAdapter interface
browser.ts      — BrowserAdapter (default, no customizations)  
vk.ts           — VkAdapter (custom keyboard, scroll lock, zoom fix)
adapter.ts      — getPlatformAdapter(): factory (singleton)
```

The factory detects platform from URL params + sessionStorage:
```typescript
export function getPlatformAdapter(): PlatformAdapter {
    if (_adapter) return _adapter;
    const params = new URLSearchParams(window.location.search);
    if (params.get('vk_user_id') || sessionStorage.getItem('isVkIframe') === '1') {
        _adapter = new VkAdapter();
        return _adapter;
    }
    _adapter = new BrowserAdapter();
    return _adapter;
}
```

`main.tsx` uses the adapter before rendering:
```typescript
const platform = getPlatformAdapter();
platform.init();
document.documentElement.classList.add(platform.bodyClass);
// viewport meta, keyboard init, etc.
```

**Pitfall**: After VK frame reload, `vk_user_id` may be absent from URL. Check `sessionStorage` too:
```typescript
const wasVk = sessionStorage.getItem('isVkIframe') === '1';
const isVk = !!(vid || wasVk);
localStorage.setItem('isVK', isVk ? '1' : '0');
```

Without this, `isVK` resets to 0 after frame reload and VK-specific UI (payments, keyboard) disappears.

## MD Toolbar: Cursor Position with Controlled Textarea (VK)

When inserting text programmatically into a React controlled `<textarea value={state}>`, React resets the cursor to the end after every state update. This breaks Markdown toolbars on VK's custom keyboard.

**Fix**: Use native `HTMLTextAreaElement.value` setter (bypass React), dispatch `input` event for state sync, restore cursor via `useEffect` + `requestAnimationFrame`:

```tsx
const pendingSelections = new Map<string, { start: number; end: number }>();

export function setMdSelection(id: string, start: number, end: number) {
    pendingSelections.set(id, { start, end });
}

function MdToolbar({ textareaId }: { textareaId: string }) {
    useEffect(() => {
        const sel = pendingSelections.get(textareaId);
        if (sel) {
            pendingSelections.delete(textareaId);
            const ta = document.getElementById(textareaId) as HTMLTextAreaElement | null;
            if (ta) requestAnimationFrame(() => {
                ta.focus();
                ta.setSelectionRange(sel.start, sel.end);
            });
        }
    });
    // insert(): nativeSetter.call(ta, newValue) + dispatchEvent('input')
}
```

**Pitfall**: `requestAnimationFrame` alone is NOT enough — the effect MUST run after React's commit via `useEffect` (no deps). Direct `onClick` manipulation gets overwritten by React's controlled-component re-render.

## Item Upgrade Preview: Show Stat Changes Before Committing

When the user places an item + upgrade stone in the craft slots, show what stats will change BEFORE they click "Улучшить". This prevents confusion when low-stat items get no visible benefit from early upgrade levels due to `Math.round(base * (1 + level * 0.1))`.

### Formula (must match server `stats.ts`):
```ts
const scaleStat = (base: number, level: number) => Math.round(base * (1 + level * 0.1));
```

### Implementation in CraftPage.tsx

Inside the `upgradeInfo` block (which appears when item + stone are in slots), compute before/after for each stat:

```tsx
{upgradeInfo && (() => {
    const item = upgradeInfo.item;
    const curLvl = item.upgradeLevel || 0;
    const nextLvl = upgradeInfo.nextLevel;
    const scaleStat = (base: number, lvl: number) => Math.round(base * (1 + lvl * 0.1));

    // Collect all non-zero stats from bonuses + extra
    const statNames = { s:'Сила', a:'Ловк', d:'Защ', m:'Маг', crit:'Крит', dodge:'Уклон', counter:'Контр', fullBlock:'Блок' };
    const allStats: [string, number][] = [];
    for (const k of ['s','a','d','m']) if (bonuses[k]) allStats.push([k, bonuses[k]]);
    for (const k of ['crit','dodge','counter','fullBlock']) if (extra[k]) allStats.push([k, extra[k]]);

    return (
        <div>
            {allStats.map(([k, base]) => {
                const cur = scaleStat(base, curLvl);
                const next = scaleStat(base, nextLvl);
                const same = cur === next;
                return (
                    <div key={k}>
                        {statNames[k]}: {cur} → <span className={same ? 'text-muted' : 'text-success'}>{next}</span>
                        {same && <span className="text-[0.6rem] text-muted ml-1">(без изменений)</span>}
                    </div>
                );
            })}
        </div>
    );
})()}
```

**Key UX decisions:**
- Stats that won't change are shown in muted color + "(без изменений)" label
- Stats that will increase are shown in green
- This lets the player see BEFORE spending resources that their +1 sword still has 1 strength

## User Style Preferences

**Minimal, functional UI — no decorative flourishes.** The user consistently rejects:
- **Animations**: Card deal/flip animations were added then immediately removed. No CSS keyframe animations on UI elements.
- **Decorative emoji icons**: Tournament names should be plain text labels only.
- **What to keep**: Functional emoji are fine (timers, money, battle icons). The rule is: no decorative icons that duplicate or embellish text labels.

**Client language — no abbreviations, no slang:**
- Use "уровень" not "ур."
- Use "серебра" not "сер."
- Use "умения" not "скиллы"
- Use "Улучшить (1000 серебра)" not "⬆ 1000 сер."
- Use "нужен уровень 1" not "нужен ур. 1"
- All Russian text must be full, formal, and descriptive. No mixed-language abbreviations.

**Page width — unified max-w-3xl (768px):**
- All gameplay pages use same wrapper class
- Exception: login/register forms keep max-w-md
- Exception: dungeon combat uses full width (no max-w)
- To batch-update: `sed -i 's/max-w-OLD/max-w-3xl/g' pages/*.tsx`

**🔴 mx-auto centering pitfall:** When `mx-auto` doesn't center content (common with complex nested layouts), use the flexbox pattern instead:
```tsx
// ✅ Reliable flexbox centering
<div className="flex justify-center px-4 py-4">
    <div className="w-full max-w-3xl">
        {/* page content */}
    </div>
</div>
```
This works even when margin auto fails due to parent constraints or CSS specificity.

**Right sidebar — dynamic header-based positioning:**
- Use `getBoundingClientRect().bottom` of #site-header + ResizeObserver
- Include `--vk-top-offset` CSS variable for VK safe area
- Never use hardcoded pixel values (115px, 132px etc.) — header height changes
- Button centered on the bottom edge of header: `top: headerHeight - halfButtonHeight`
- Panel starts at header bottom: `top: headerHeight`
- Pattern:
```tsx
const [headerHeight, setHeaderHeight] = useState(132);
useEffect(() => {
    const update = () => {
        const el = document.getElementById('site-header');
        const h = el ? el.getBoundingClientRect().bottom : 132;
        const safeArea = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--vk-top-offset')) || 0;
        setHeaderHeight(Math.max(h, 132) + safeArea);
    };
    update();
    const ro = new ResizeObserver(update);
    const el = document.getElementById('site-header');
    if (el) ro.observe(el);
    window.addEventListener('resize', update);
    return () => { ro.disconnect(); window.removeEventListener('resize', update); };
}, []);
// Button: style={{ top: `${headerHeight - 12}px` }}
// Panel: style={{ top: `${headerHeight}px`, height: `calc(100vh - ${headerHeight}px - 40px)` }}
```
Remove VK-specific hardcoded `top` CSS overrides — the JS dynamic positioning handles it.

**🔴 CharacterCard set switching in new pages:** When adding equipment set switching to a new page, copy the pattern from `LeftSidebar.tsx`:
```tsx
const handleSwitchSet = async (slot: number) => {
    const res = await fetch('/api/character/switch-equip', {
        method: 'POST',
        headers: { ...getHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ slot }),
    });
    if (res.ok) {
        const { fetchCharacter } = await import('../api/character');
        const fresh = await fetchCharacter();
        setCharacter(fresh);
    }
};
```
**Pitfall**: The API returns `{ activeEquipSlot, equipment }` — NOT `{ character }`. Do NOT check `data.character`. Always use `fetchCharacter()` to reload the full profile.
**Memo pitfall**: If CharacterCard doesn't re-render after switch, add `key={activeEquipSlot}` to force remount:
```tsx
<CharacterCard key={activeSlot} char={toCharCardData(character)} ... />
```
The `equipSets` prop must always be provided (never `undefined`):
```tsx
const equipSets = {
    1: c?.equipment1 ?? {},
    2: c?.equipment2 ?? {},
    3: c?.equipment3 ?? {},
};
const activeSlot = c?.activeEquipSlot || 1;
```
- Pattern:
```tsx
const [headerHeight, setHeaderHeight] = useState(132);
useEffect(() => {
    const update = () => {
        const el = document.getElementById('site-header');
        const h = el ? el.getBoundingClientRect().bottom : 132;
        const safeArea = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--vk-top-offset')) || 0;
        setHeaderHeight(Math.max(h, 132) + safeArea);
    };
    update();
    const ro = new ResizeObserver(update);
    const el = document.getElementById('site-header');
    if (el) ro.observe(el);
    window.addEventListener('resize', update);
    return () => { ro.disconnect(); window.removeEventListener('resize', update); };
}, []);
// Button: style={{ top: `${headerHeight - 12}px` }}
// Panel: style={{ top: `${headerHeight}px`, height: `calc(100vh - ${headerHeight}px - 40px)` }}
```

When in doubt, choose the simpler, text-only version. If the user wants visual flair, they will ask for it.

## Modal → Full Page Refactoring

When a creation form outgrows a modal, convert to inline page using `mode` state:

```tsx
const [mode, setMode] = useState<'list' | 'new'>('list');
// mode === 'list' → show list + button
// mode === 'new' → show form with Cancel button → setMode('list')
```

- Remove Modal import, replace `showNew` with `mode`
- BackButton stays, Cancel button returns to list
- After creation: navigate to new item or resetForm

Applied: ForumPage (создание темы).

## Audio Player (Icecast/Shoutcast Radio)

Floating audio player component for live radio streams. Uses native `<audio>` element directly — no proxy needed for Icecast streams, browser handles them natively.

### Component structure

```tsx
// AudioPlayer.tsx — станции + play/pause + выбор станции
interface Station { name: string; url: string; }

const STATIONS: Station[] = [
    { name: 'Radio 1', url: 'http://host:8058/stream' },
    { name: 'Radio 2', url: 'http://host:18058/stream' },
];

// Audio ref создаётся в useEffect, preload='none'
// togglePlay: audio.src = STATIONS[idx].url; audio.load(); audio.play()
// switchStation: если playing — переключить src без остановки
```

### Key details
- `<audio preload="none">` — не грузить до нажатия play
- `audio.play().catch(() => setError(true))` — обработка недоступности потока
- Панелька с `absolute right-0 mt-2` для позиционирования под кнопкой
- Кнопка-триггер в Header: иконка меняется в зависимости от playing/не playing
- Очистка в useEffect return: `audio.pause()` + remove event listeners

### Integration
```tsx
// Header.tsx — добавить в ряд кнопок
import AudioPlayer from './AudioPlayer';
// ...
<div className="relative">
    <AudioPlayer />
</div>
```

## 🔴 React Pitfall: Component Inside Component (Causes Full Remount + Image Flickering)

Defining a component (`const Inner = () => { ... }`) inside another component's render function creates a **new function reference on every render**. React treats it as a different component type and **FULLY REMOUNTS** all its children (images, state, effects), causing:
- Image flickering (browser re-decodes and re-renders images)
- State reset (useState values lost)
- Effects re-run (useEffect cleanup + re-init)

```tsx
// ❌ BROKEN — Inner component re-created every render
function Parent() {
  const Inner = () => {
    const [val, setVal] = useState(0); // state resets on every Parent render!
    return <img src="..." />; // flickers on every Parent render!
  };
  return <Inner />;
}

// ✅ CORRECT — extracted to module level, props passed explicitly
function Inner({ isVK }: { isVK: boolean }) {
  const [val, setVal] = useState(0); // state persists
  return <img src="..." />; // no flicker
}
function Parent() {
  const isVK = ...;
  return <Inner isVK={isVK} />;
}
```

**Symptom**: images flicker/blink on every state change in the parent (WebSocket ticks, timer updates, etc.). The inner component's useEffect cleanup fires and re-initialises continuously.

**Fix**: extract the inner component to module level (outside the parent function). If it needs parent state, pass it as props. Also move static data (arrays, configs) to module-level `const` to avoid recreation.

**Real case**: `CraftPacks()` was defined inside `CraftPage()`, causing material/stone images to flicker on every WebSocket tick. Fixed by extracting to module level with `isVK` prop and moving `PACKS` array to module-level `const`.

## 🔴 React Pitfall: `key={idx}` Causes Visual Item Shifting

When rendering a list where items can be removed (inventory, auction lots, etc.), using array index as the React key causes **visual shifting**: when item at index N is removed, React reuses the DOM node at index N for the item that was at N+1, making it appear that items "slide" into new positions rather than the removed slot becoming empty.

```tsx
// ❌ BROKEN — items visually shift when one is removed
{items.map((item, idx) => <div key={idx}>{item.name}</div>)}

// ✅ CORRECT — stable IDs preserve visual positions
{items.map(item => <div key={item.id ?? `empty-${item.slot}`}>{item.name}</div>)}
```

**Applied in**: `Inventory.tsx` equipment grid (collection add removes item → remaining items stay in place). For grid slots where some positions may be empty, use `item?.id ?? 'empty-${idx}'` pattern.

## 🔴 React Pitfall: CollectionsPage Doesn't Update GameContext

When a page mutates server state (e.g., adding to collection), it must also update `GameContext` via `setCharacter()` so the sidebar Inventory and other components show fresh data immediately, not stale data from the last `/character/me` fetch.

```tsx
const { setCharacter } = useGame();
// After successful mutation:
setCharacter((prev: any) => ({ ...prev, inventory: charRes.inventory, collectionCount: charRes.collectionCount }));
```

**Symptom**: sidebar Inventory still shows the item that was just added to collection, until a WebSocket tick or page refresh updates GameContext independently.
