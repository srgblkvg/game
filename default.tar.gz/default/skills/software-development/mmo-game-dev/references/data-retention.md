# Data Retention — Auto-Cleanup

## Problem
Bots (or normal play) can generate massive amounts of historical data:
- Tournament matches: 427K rows, 334MB after 8h of 50 bots
- Chat messages: 7K+
- All record types: battles, PvE, auction, quests, jobs

Without cleanup, DB grows unbounded → slow queries → OOM.

## Solution: Daily Cleanup Cron

Added to `server/src/index.ts`:

```typescript
import { cleanupOldData } from './cleanup';
// Run 60s after startup, then every 24h
setTimeout(() => { cleanupOldData().catch(() => {}); }, 60000);
setInterval(() => { cleanupOldData().catch(() => {}); }, 24 * 3600 * 1000);
```

## Cleanup Script (`server/src/cleanup.ts`)

Deletes records older than 7 days:

| Table | Column | Condition |
|-------|--------|-----------|
| tournament_matches | via tournaments.completedAt | `< weekAgo` |
| tournament_participants | via tournaments.completedAt | `< weekAgo` |
| tournaments | completedAt | `< weekAgo` |
| chat_messages | createdAt | `< weekAgoISO` |
| battles | createdAt | `< weekAgo` |
| pve_battles | createdAt | `< weekAgo` |
| auction_history | createdAt | `< weekAgo` |
| quest_history | createdAt | `< weekAgo` |
| job_history | endTime | `< weekAgo` |

Uses `db.run()` which returns `{ changes: number }` (mapped from `rowCount` in PG).

## Emergency Manual Cleanup

```sql
-- Tournament explosion (bots)
DELETE FROM tournament_matches WHERE id NOT IN (SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 1000);
DELETE FROM tournament_participants WHERE tournamentId NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM tournaments WHERE id NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);
DELETE FROM bot_accounts WHERE active = 1;
VACUUM FULL tournament_matches;
```
