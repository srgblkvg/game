# Наполнение БД (seed / fill)

## Штатный сид
При запуске сервера (`npx tsx src/index.ts`) автоматически через `runSeed()` заполняются:
- rarities (7)
- items (189 предметов)
- stat_names (9)
- jobs (20)
- craft_items (14 материалов + камней)
- craft_recipes (20 рецептов)
- upgrade_chances (70)
- mobs (30)

## Что НЕ заполняется автоматически
- **floors** (этажи) — только через админку `POST /api/admin/floors`
- **actions_config** (карточки действий) — только через `POST /api/admin/actions`
- **users** — регистрация или SQL вручную

## Быстрое наполнение через админку
```python
# Получить токен админа
token = ... # POST /api/login с admin/admin123

# Создать floors
POST /api/admin/floors {"name": "...", "background": "...", "sort_order": N}

# Создать actions
POST /api/admin/actions {"section": "world|castle", "title": "...", "subtitle": "...", "icon": "...", "path": "...", "cost": 0, "sort_order": N}
```

## SQL-дамп
`server/seed_data.sql` — содержит INSERT'ы для предметов, мобов, работ, upgrade_chances.
Рецепты крафта зависят от автоинкрементных ID → заполняются только через runSeed().

## Копирование БД с прода
```bash
scp root@194.226.142.237:/opt/game/server/game.db /mnt/c/project/game/server/game.db
```
После копирования локальный сервер будет идентичен проду.
