# Deployment

## After vite build: always rsync, never selective scp
After `npx vite build`, chunk hashes change unpredictably across many files.
Selective `scp` of only `index.js` + `index.html` causes MIME type errors
(`Expected a JavaScript module but the server responded with a MIME type of "text/html"`)
when the browser requests chunks that don't exist on the server.

### Correct workflow
```bash
cd /mnt/c/project/game/client && npx vite build
scp -i ~/.ssh/id_ed25519 server/src/routes/*.ts root@194.226.142.237:/opt/game/server/src/routes/
scp -i ~/.ssh/id_ed25519 server/src/websocket.ts root@194.226.142.237:/opt/game/server/src/
rsync -avz -e "ssh -i ~/.ssh/id_ed25519" client/dist/ root@194.226.142.237:/opt/game/client/dist/
ssh root@194.226.142.237 "pm2 restart game-server"
```

### Common failure: CSS disappears
If styles vanish after deploy, the CSS file hash changed. `index.html` references
the new hash but the old file is still on the server. `rsync` prevents this.

### VPS paths
- Server code: `/opt/game/server/src/`
- Client dist: `/opt/game/client/dist/`
- PM2: `pm2 restart game-server` (runs `PORT=3001 npx tsx server/src/index.ts` from `/opt/game`)
