# Forum Threading & Pagination

## Thread page structure

- **First post** always pinned at top (yellow left border + "Автор" label)
- **Remaining posts** paginated below (9 per page)
- **Reply tree**: posts with `parent_id` are nested under their parents
- **Block quotes**: `> text` lines rendered as styled `<blockquote>` with blue left border
- **Quote stripping**: when clicking "Ответить", existing `>` prefixes are stripped before generating the quote

## Server pagination

Endpoint: `GET /api/forum/thread/:id?page=N`

- `limit = 9` (remaining posts after first)
- `firstPost` — always fetched separately (first post by created_at ASC)
- `posts` — fetched with `p.id != firstPost.id` and `OFFSET = (page-1) * 9`
- `totalPages = Math.max(1, Math.ceil((total - 1) / 9))`
- `page = 0` (or `page=last` in URL) means last page

## Client navigation

- ThreadPage uses `useSearchParams` for `page` query parameter
- On first visit (page=0): fetch page 1 to get thread info + totalPages, then fetch the actual last page
- After reply: `goToPage(0)` to return to last page
- ForumPage/CastlePage navigate to `/forum/:id?page=last`

## Date fields

New tables (forum_posts, forum_threads) use **snake_case** in client code because the camelCase converter produces `created_At` not `createdAt`:

```ts
// CORRECT:
post.created_at
post.updated_at
thread.is_closed

// WRONG (returns undefined):
post.createdAt
post.updatedAt
thread.isClosed
```

## Thread management

- **Close/Open**: author-only, `PUT /api/forum/thread/:id/close` with `{ closed: boolean }`
- **Edit title**: author-only, `PUT /api/forum/thread/:id` with `{ title: string }`
- **Edit post**: author-only, `PUT /api/forum/post/:id` with `{ content: string }`
- Closed threads block replies (403) and show lock icon

## DB schema

```sql
forum_threads: id, title, author_id, created_at, updated_at, posts_count, is_closed
forum_posts: id, thread_id, author_id, content, created_at, updated_at, parent_id
```

`parent_id` references `forum_posts(id) ON DELETE SET NULL`.
