# Auction System

## Bid endpoint: transaction + FOR UPDATE

Race condition: two simultaneous bids both read `currentBid = null` and both place at `startPrice`. SELECT and UPDATE are separate queries — between them, another request interleaves.

**Fix:** `db.tx()` with `SELECT ... FOR UPDATE`:
```typescript
await db.tx(async (client) => {
    const lot = (await client.query(
        'SELECT * FROM auction_lots WHERE id = $1 AND endsAt > $2 FOR UPDATE',
        [lotId, now]
    )).rows[0];
    // validate, process...
    await client.query('UPDATE auction_lots SET currentBid = $1, currentBidderId = $2', [...]);
});
```

## Bid display: currentBidderName via JOIN

Server returns `currentBidderName` via LEFT JOIN on auction list:
```sql
LEFT JOIN users b ON l.currentBidderId = b.id
```

camelCase pitfall: `currentbiddername` → (regex matches `name` suffix) → `currentbidderName`. But `currentBidderName` is expected. **Added explicit rule:**
```
.replace(/^currentbiddername$/i, 'currentBidderName')
```

Also added `bid` to suffix regex for `currentbid` → `currentBid`.

## Min bid calculation

Server and client both compute: `currentBid + max(1, floor(currentBid * 0.05))`. Client validates BEFORE sending (prevents UI from allowing repeat bids at same price).

## History table

```sql
CREATE TABLE auction_history (
    id SERIAL PRIMARY KEY,
    sellerId INTEGER NOT NULL,
    buyerId INTEGER NOT NULL,
    itemName TEXT NOT NULL,
    itemData TEXT,
    price INTEGER NOT NULL,
    commission INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL
);
```

INSERT happens at buyout and partial-buy. History is PUBLIC (no userId filter) — all trades visible.

## Sold notification

When a lot is bought, `pushNotification(lot.sellerId, { type: 'auction_sold' })` fires. Client shows:
1. Toast notification (💰 yellow icon)
2. Red badge counter on auction card in Actions (resets on click)

Client badge code (Actions.tsx):
```tsx
const [auctionBadge, setAuctionBadge] = useState(0);
useEffect(() => {
    const handler = (e: Event) => {
        const notifs = (e as CustomEvent).detail;
        const sold = notifs.filter((n: any) => n.type === 'auction_sold').length;
        if (sold > 0) setAuctionBadge(prev => prev + sold);
    };
    window.addEventListener('notifications', handler);
    return () => window.removeEventListener('notifications', handler);
}, []);
```

Notification type must be added to:
- `websocket.ts` Notification interface: `'auction_sold'`
- `NotificationToast.tsx` type union, iconMap, colorMap

## Fee structure

- Listing fee: 5% of start price
- Bid: no fee, money held from bidder, returned to previous leader
- Buyout commission: 10%
- Transfer commission: 2%
