# Collection Badge on Item Tooltips

Show "✓ В коллекции" / "✗ Нет в коллекции" on item tooltips everywhere
(inventory, auction, shop).

## Server: return collected items in /api/character/me
```typescript
// character.ts — add after collectionCount
const collectedItems = collectionCount > 0
  ? await db.query('SELECT itemname as itemName, slot FROM collections WHERE userId = ?', [userId])
  : [];

// In response:
collectedItems: (collectedItems || []).map(c => ({ itemName: c.itemname || c.itemName, slot: c.slot })),
```

## Client: check in ItemStats component
ItemStats is used by inventory, auction, shop tooltips. Add collection check there:
```typescript
import { useGame } from '../contexts/GameContext';

// Inside ItemStats:
let inCollection = false;
try {
  const { character } = useGame();
  if (character?.collectedItems && item.name && item.slot) {
    inCollection = character.collectedItems.some(
      c => c.itemName === item.name && c.slot === item.slot
    );
  }
} catch {}

// Render badge:
{!resource && item.name && item.slot && (
  <div className={inCollection ? 'text-green' : 'text-yellow'}>
    {inCollection ? '✓ В коллекции' : '✗ Нет в коллекции'}
  </div>
)}
```

## Caveat
- PG column is `itemname` (lowercase, no underscore), not `item_name`
- Only show for equipment (skip craft resources)
- Resource items (materials) don't have a slot — skip the badge
