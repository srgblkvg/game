# Добавление новой игры в Игорный дом

## Архитектура

Каждая игра — это React-компонент без шапки/хлебных крошек (их добавляет страница).
Компонент принимает `onBalanceChange?: () => void` для обновления баланса в родителе после ставки/выигрыша.

## Структура

```
client/src/components/<GameName>.tsx  — переиспользуемый компонент игры
client/src/pages/CasinoPage.tsx        — добавляется новый таб
server/src/routes/<game>.ts            — серверная логика
```

## Шаги добавления

### 1. Создать компонент игры

```tsx
// client/src/components/MyGame.tsx
export default function MyGame({ onBalanceChange }: { onBalanceChange?: () => void }) {
    // ... логика игры
    // При списании/начислении серебра вызывать onBalanceChange?.()
}
```

### 2. Добавить таб в CasinoPage

```tsx
// Импорт
import MyGame from '../components/MyGame';

// В табах добавить кнопку:
<button onClick={() => setTab('mygame')} className={...}>🎮 Моя игра</button>

// После закрывающего </div> блэкджека:
{tab === 'mygame' && (
    <div className="bg-[var(--color-bg-secondary)] rounded-xl p-4 border border-[var(--color-border-default)]">
        <MyGame onBalanceChange={loadBalance} />
    </div>
)}
```

### 3. Серверный роут

Создать `server/src/routes/myGame.ts`, зарегистрировать в `setupRoutes.ts`.

При использовании INSERT в `db.run()` — НЕ добавлять `RETURNING id`, драйвер делает это сам.
Свойство с ID: `result.lastInsertRowid` (не `lastID`).

Создать таблицу на VPS:
```bash
sudo -u postgres psql game -c "CREATE TABLE ..."
sudo -u postgres psql game -c "GRANT ALL ON <table> TO game; GRANT ALL ON <table>_id_seq TO game;"
```

### 4. Статистика (общая с другими играми)

Все игры пишут в одни и те же колонки таблицы `users`:
- `casino_games_played` — инкремент на каждую сыгранную игру
- `casino_won` — сумма выигрышей
- `casino_lost` — сумма ставок (проигрышей)

```ts
await db.run(
    'UPDATE users SET casino_games_played = casino_games_played + 1, casino_won = casino_won + ?, casino_lost = casino_lost + ? WHERE id = ?',
    [winAmount, bet, userId]
);
```

Профиль (`users.ts`) читает эти колонки напрямую — менять ничего не нужно.

## Ставки и UI

По умолчанию одна фиксированная ставка 10 сер. Если нужно несколько — кнопки выбора.
Кнопка «Играть»: `variant="danger"` красная, справа (`flex justify-end`).
Описание: `text-[var(--color-text-muted)]` (серый, как в блэкджеке).

### Выделение выбранной ставки

Для выделенной кнопки использовать CSS-переменные проекта, а не Tailwind `dark:`:
```tsx
className={`cursor-pointer px-3 py-1.5 rounded text-sm font-bold transition-colors ${
    bet === b
        ? 'bg-[var(--color-accent-primary)] text-[var(--color-text-primary)] border-2 border-[var(--color-text-primary)]'
        : 'bg-[var(--color-bg-input)] text-[var(--color-text-muted)] border-2 border-transparent'
}`}
```

⚠️ НЕ использовать `dark:text-white` и т.п. — в проекте нет `dark` класса на `<html>`, темы через CSS-переменные.
`color-text-primary` сам переключается: тёмный на светлой теме, светлый на тёмной.
`color-bg-primary` делает наоборот (белый на светлой, чёрный на тёмной) — для текста на accent-фоне не подходит.
