# Bot Cleanup — DB Bloat from Overnight Bots

## Problem
Running 50 bots overnight generated massive DB bloat:
- **427K tournament_matches** (334MB!) — each bot-vs-bot fight created matches
- Chat messages grew to 7,591
- DB total: 379MB on a 955MB VPS → guaranteed OOM

## Symptoms
- Server OOM loops (heap OOM, `FatalProcessOutOfMemory`)
- API timeouts (504 on tournament endpoint)
- High restart count in PM2
- Memory grows from 150MB to 900MB+ within minutes

## Diagnosis Commands
```bash
# Check DB size
sudo -u postgres psql -d game -c "SELECT pg_size_pretty(pg_database_size('game'));"

# Find bloated tables
sudo -u postgres psql -d game -c "
SELECT relname, n_live_tup as rows, pg_size_pretty(pg_total_relation_size(relid)) as size
FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 10;
"

# Check bot accounts
sudo -u postgres psql -d game -c "SELECT count(*) FROM bot_accounts WHERE active = 1;"
```

## Cleanup
```sql
-- Kill bot accounts
DELETE FROM bot_accounts WHERE active = 1;

-- Delete old tournament data
DELETE FROM tournament_matches WHERE tournamentId NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM tournament_participants WHERE tournamentId NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM tournaments WHERE id NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);

-- Or more aggressive: keep only last 1000 matches
DELETE FROM tournament_matches WHERE id NOT IN (SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 1000);

-- Clean chat
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);

-- Reclaim disk space
VACUUM FULL tournament_matches;
```

After cleanup: DB went from 379MB → 46MB, server stabilized.
