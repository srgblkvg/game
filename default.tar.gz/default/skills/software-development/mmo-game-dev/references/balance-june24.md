# Боевой баланс — изменения 24 июня 2026

## HP = S + A + M (защита исключена)
- Было: `sumStats(s)` = S+A+D+M
- Стало: `sumStats(s)` = S+A+M
- Защита даёт блок, не HP. Танки больше не double-dip.
- Изменено в: `server/src/game/stats.ts:sumStats()`
- Синхронизировано: `client/src/utils/stats.ts:sumStats()`

## Блок — кап 75%
- `blockChance(): Math.min(0.75, D/(D+500) + fullBlock/(fullBlock+300))`
- Было `Math.min(1, ...)` — танк мог стать неубиваемым

## Extra-статы — мягкий кап x/(x+300)
- Все extra-статы: dodge, crit, block, counter, fullBlock
- Было `x/300` (линейный рост)
- Стало `x/(x+300)` (асимптота 100%)
- Пороги: 100→25%, 300→50%, 600→67%

## Затронутые функции (battle.ts)
- `dodgeChance()` — `extraDodge/(extraDodge+300)`
- `critChance()` — `extraCrit/(extraCrit+300)`
- `blockChance()` — `extraBlock/(extraBlock+300)`, кап 0.75
- `counterChance()` — `extraBonus/(extraBonus+300)`
- `runTurn()` fullBlock — `fb/(fb+300)`

## Множитель заточки для extra-статов
- `stats.ts:currentStats()` — `multiplier = 1 + level * 0.1`
- Вынесен на уровень выше (доступен и bonuses, и extra)
- Extra-статы тоже умножаются: `Math.round(extra[k] * multiplier)`
