# formatLastSeen — Russian Time Ago Utility

Location: `client/src/utils/time.ts`

Formats elapsed time since a date into Russian human-readable strings:

| Range | Output |
|-------|--------|
| < 60s | `сейчас` |
| 1–59 min | `N мин назад` |
| 1–23 hrs | `N ч. назад` |
| 1–29 days | `N дн. назад` |
| 1–11 months | `Nм назад` |
| 1+ years | `N г. назад` |

**Overloading**: accepts Unix timestamp (seconds), Date object, ISO string, or PG timestamp string. Uses `safeDate()` from `utils/date.ts` for string parsing.

**Online detection**: prefer server-provided `online` flag from WebSocket (`isUserOnline()`) over timestamp heuristics. The `getLastSeen()` function also returns `{ text, online }` but the WS-based check is more accurate.

**Usage**:
```tsx
import { formatLastSeen } from '../utils/time';

// With server-provided online flag (preferred):
if (m.online) return <span className="text-green-500">В игре</span>;
return <span>Был в игре: {formatLastSeen(m.lastLoginAt)}</span>;

// Without WS flag (fallback):
const { text, online } = getLastSeen(m.lastLoginAt);
if (online) return <span className="text-green-500">В игре</span>;
return <span>Был в игре: {text}</span>;
```

**Note**: `getLastSeen().online` uses a 5-minute threshold — any `lastLoginAt` ≤ 300s ago counts as online. This is less accurate than the WS-based check which reflects actual connection state. The server updates `lastLoginAt` every 5 minutes in the auth middleware, so the timestamp can lag.
