# Actions Config and Floors Seeding

## actions_config — not in seed.ts

The `actions_config` table is created by migrations but NEVER seeded by `seed.ts`. It must be populated via admin API.

### Required sections (client expects these exact names):
- `world` — main page cards (Бестиарий, Арена, Турнир, Рейтинг)
- `castle` — town square cards (Магазин, Ремесло, Банк, Аукцион, Работы, Таверна)

**PITFALL:** The client code in `Actions.tsx` filters by `section === 'castle'`, NOT `'town'`. Using `'town'` will result in cards appearing in the admin list but NOT on the page.

### Populating via admin API:
```bash
# Login first
curl -s -X POST http://localhost:3001/api/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"admin123"}'

# Then POST each action (use the token from login)
curl -s -X POST http://localhost:3001/api/admin/actions \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <token>' \
  -d '{"section":"world","title":"Бестиарий","subtitle":"Охота на монстров","icon":"game-icons:bestial-fangs","bg_image":null,"path":"/bestiary","cost":0,"sort_order":1}'
```

Standard set (10 cards):
```
world:  Бестиарий, Арена, Турнир, Рейтинг
castle: Магазин, Ремесло, Банк, Аукцион, Работы, Таверна
```

Note: Use "Ремесло" not "Крафт" for the craft card title.

## floors — not in seed.ts

`floors` table is created by migrations but NEVER seeded. Must be populated via admin API.

Standard 14 floors (ordered by level):
```
Склеп, Подземелье, Катакомбы, Деревня Пепла, Лес Черепов,
Старый Тракт, Ядовитые луга, Первый ярус, Гнилая Топь,
Чёрный Монастырь, Башня Плакальщиц, Некрополь Королей,
Бездонный Овраг, Врата Бездны
```

Endpoint: `POST /api/admin/floors` with `{name, background, sort_order}`.
