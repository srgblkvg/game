# Craft System Changes (pg-native, June 2026)

## Upgrade stones
- Stone recipes REMOVED from `seed.ts` and production DB
- Material creation costs ÷4 (e.g. Пыль→Осколок: 5 gold)
- **Any rarity stone upgrades any rarity item** — rarity check removed
- Upgrade cost/chance uses **item's** rarity (`itemSlot.rarity_id`), not stone's
- Junk stone (Хлам) drops from mobs at 5% independent chance
- Migration script ran on prod: deleted 7 stone recipes, updated 6 material costs

## isCraftItem async bug (CRITICAL)
In `server/src/routes/craft.ts`:
```typescript
// WRONG — Promise<boolean> is always truthy → validation always fails
async function isCraftItem(item: any): boolean { ... }

// CORRECT
function isCraftItem(item: any): boolean { ... }
```
The `async` keyword makes the function return a Promise, which is always truthy in boolean context. All craft/upgrade validations silently fail with 400.

## Error popups in CraftPage
All gameplay alerts replaced with `errorPopup` state + modal:
```tsx
const [errorPopup, setErrorPopup] = useState<string | null>(null);
// JSX:
{errorPopup && (
  <div className="fixed inset-0 z-[1100] flex items-center justify-center">
    <div className="absolute inset-0 bg-black/50" onClick={() => setErrorPopup(null)} />
    <div className="relative bg-[var(--color-bg-card)] border border-[var(--color-accent-danger)] rounded-xl p-6 ...">
      <p>{errorPopup}</p>
      <Button onClick={() => setErrorPopup(null)}>OK</Button>
    </div>
  </div>
)}
```
This replaced alerts for: ошибки создания/улучшения/разбора, слоты заняты, нет ресурсов, недостаточно ресурсов.

## Craft animation popup
`CraftPopup` component at `client/src/pages/CraftPage/CraftPopup.tsx`:
- Progress bar fills over ~2s (100% for success, 45% for fail)
- Success: yellow "Успех!" text, acquire popup shown AFTER animation
- Fail: red "Провал" text
- Auto-dismisses after 1.5s
- Uses `useRef(onDone)` to preserve closure (not recreated on re-renders)

## Acquire popup timing
`showAcquire` called in `onDone` callback, not immediately:
```tsx
<CraftPopup result={craftAnim} onDone={() => {
    if (craftAnim.acquire) showAcquire(...);
    setCraftAnim(null);
}} />
```

## Curse flow (July 2026)
Resources (100k silver + 1 Soul Crystal) are deducted at `/craft/curse` (preview step), NOT at `/craft/curse/apply`.
- `/craft/curse` — validates item+crystal, deducts both, rolls curse, saves DB, returns preview
- `/craft/curse/apply` — only applies/keeps curse on item, NO deduction
- Client: "Оставить" and "Заменить" buttons have NO price text (cost already paid)
- If item has no existing curse (`needsConfirm=false`), apply is called immediately from handleCurse
- If item has existing curse, shows confirm dialog with old vs new curse

## Double-submit prevention (all craft buttons)
React `setState` is async — between click and re-render the button is still enabled. Use a ref alongside state:
```tsx
const craftingRef = useRef(false);

const handleX = async () => {
    if (!info || craftingRef.current) return;
    craftingRef.current = true;
    setCrafting(true);
    try { /* ... */ } finally {
        craftingRef.current = false;
        setCrafting(false);
    }
};
```
Applied to: handleUpgrade, handleCreate, handleCurse, handleDisassemble.

## Crafter Faction Bonus (Aug 2026)

Crafters get progressive bonus to craft and upgrade chance:
- **+10% base** bonus if user.faction === 'crafter'
- **+1% per 100 successful crafts/upgrades** — `faction_craft_count` increments only inside `if (success)` blocks
- Total: `10 + floor(faction_craft_count / 100)` percent
- `faction_craft_count` resets to 0 on faction change

**Server-side** (craft.ts):
- Craft creation: `craftBonus = user.faction === 'crafter' ? 10 + floor(faction_craft_count/100) : 0`
- Upgrade: `factionBonus = user.faction === 'crafter' ? 10 + floor(faction_craft_count/100) : 0`
- `/craft/upgrade-info` endpoint: queries `faction_craft_count` from DB and returns `factionBonus` in response

**Client-side** (CraftPage.tsx):
- Shows `(+X% фракция)` next to craft/upgrade chance
- Upgrade info: `totalChance = Math.min(100, data.chance + stoneBonus + factionBonus)`
