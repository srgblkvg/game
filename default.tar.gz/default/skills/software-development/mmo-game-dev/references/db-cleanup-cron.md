# DB Cleanup Cron — Auto-delete Old Data

Keeps DB lean by deleting records older than 7 days. Runs every 24 hours.

## Server code (cleanup.ts)
```typescript
import { db } from './db/index';

export async function cleanupOldData() {
  const weekAgo = Math.floor(Date.now() / 1000) - 7 * 24 * 3600;
  const weekAgoISO = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
  
  // Tournament data
  await db.run(`DELETE FROM tournament_matches WHERE tournamentId IN (SELECT id FROM tournaments WHERE status = 'completed' AND completedAt < ?)`, [weekAgo]);
  await db.run(`DELETE FROM tournament_participants WHERE tournamentId IN (SELECT id FROM tournaments WHERE status = 'completed' AND completedAt < ?)`, [weekAgo]);
  await db.run(`DELETE FROM tournaments WHERE status = 'completed' AND completedAt < ?`, [weekAgo]);
  
  // Messages
  await db.run(`DELETE FROM chat_messages WHERE createdAt < ?`, [weekAgoISO]);
  
  // Battles
  await db.run(`DELETE FROM battles WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM pve_battles WHERE createdAt < ?`, [weekAgo]);
  
  // Auction
  await db.run(`DELETE FROM auction_history WHERE createdAt < ?`, [weekAgo]);
  
  // Quests & Jobs
  await db.run(`DELETE FROM quest_history WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM job_history WHERE endTime < ?`, [weekAgo]);
}
```

## Wiring in index.ts
```typescript
import { cleanupOldData } from './cleanup';
setTimeout(() => { cleanupOldData().catch(() => {}); }, 60000); // first run after 1 min
setInterval(() => { cleanupOldData().catch(() => {}); }, 24 * 3600 * 1000);
```

File location: `server/src/cleanup.ts`
