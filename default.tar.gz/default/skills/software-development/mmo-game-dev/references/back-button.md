# Back Button Pattern

## Component: client/src/components/BackButton.tsx
```tsx
import { useNavigate } from 'react-router-dom';
import { Icon } from '@iconify/react';
export default function BackButton() {
    const navigate = useNavigate();
    return (
        <button onClick={() => navigate(-1)}
            className="inline-flex items-center gap-1 text-xs text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] transition-colors mb-3 cursor-pointer">
            <Icon icon="mdi:arrow-left" width="16" height="16" /> Назад
        </button>
    );
}
```

## Adding to pages
1. Import: `import BackButton from '../components/BackButton';` (or `../../components/` for subdirectories)
2. Place `<BackButton />` ABOVE the page title (h1/h2), not below.
3. NOT needed on HomePage (no place to go back to).

## Pages that have BackButton
All player-facing pages: Arena, Bestiary, Shop, Bank, Craft, Auction, Jobs, History, Rating, Tavern, Tournament, Orders, Premium, Guild, GuildView, GuildRating, Profile, Account.
