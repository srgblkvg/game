# Feedback Form

## Table
`feedback_messages` — id, userId, username, subject, message, createdAt, read (0/1)

## Routes
- `POST /api/feedback` — public (auth required), saves message
- `GET /api/admin/feedback` — admin only, list with pagination
- `POST /api/admin/feedback/read` — admin only, mark as read

## Route registration
Admin routes must use `authMiddleware` + `requireAdmin`:
```ts
app.use('/api/admin', authMiddleware, requireAdmin, adminFeedbackRouter);
```

Public route:
```ts
app.use('/api', feedbackRoutes); // POST /feedback
```

⚠️ Do NOT put admin routes under `/api` prefix without auth middleware — they won't have `req.userRole` set and will fail silently.

## Client
- Page: `/feedback` — standalone page with subject + message + submit
- Button: settings menu (⚙️) → 📧 Обратная связь
- Admin: tab "Обращения" in AdminPanel
