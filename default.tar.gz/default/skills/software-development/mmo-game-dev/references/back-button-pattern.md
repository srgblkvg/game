# BackButton Component

Component at `client/src/components/BackButton.tsx`:

```tsx
import { useNavigate } from 'react-router-dom';
import { Icon } from '@iconify/react';

export default function BackButton() {
    const navigate = useNavigate();
    return (
        <button onClick={() => navigate(-1)}
            className="inline-flex items-center gap-1 text-xs text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] transition-colors mb-3 cursor-pointer">
            <Icon icon="mdi:arrow-left" width="16" height="16" />
            Назад
        </button>
    );
}
```

## Adding to pages

Import and place ABOVE the page title (h1/h2):
```tsx
import BackButton from '../components/BackButton';  // from pages/
import BackButton from '../../components/BackButton'; // from pages/Arena/
```

JSX: `<BackButton />` before the `<h1>` or `<h2>` tag.

## Pages that have BackButton

All player-facing pages: ArenaPage, AuctionPage, BankPage, BestiaryPage, CraftPage, GuildPage, GuildRatingPage, GuildViewPage (has own back link), HistoryPage, JobsPage, OrdersPage, ProfilePage, RatingPage, ShopPage, TavernPage, TournamentPage.

HomePage does NOT need a back button (nowhere to go back to).

## Pitfall: subdirectory imports

Pages in `pages/Arena/` need `../../components/BackButton` (two levels up), not `../components/BackButton`.
When batch-adding imports, check for subdirectory pages separately.
