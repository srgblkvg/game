# camelCase Debugging — PG Migration

## Pattern (CRITICAL)
When a feature is broken after PG migration: **check camelCase FIRST**. 95% of PG bugs are missing suffix or PascalCase vs camelCase mismatch.

## How camelCase Works
`camelRows()` in `server/src/db/index.ts` processes PG-lowercased column names:
1. Suffix regex matches at END of key: `/(hash|hp|id|until|at|time|name|type|count|level|...|bid|by)$/i`
2. Specific rules applied after suffix: `.replace(/attacktime$/i, 'AttackTime')`
3. If converted key differs from original, BOTH are set on the object

## Suffix List (keep updated)
`hash|hp|id|until|at|time|name|type|count|level|slots|bonus|logins|amount|price|pool|fee|cost|won|lost|gained|rowid|data|wins|losses|pvp|bankvisit|max|min|job|order|image|chance|battles|money|created|upgraded|broken|seconds|xp|end|start|elo|score|number|players|ticket|stats|place|tag|text|chat|from|guild|role|last|first|ip|url|path|size|width|height|color|tier|slot|icon|attacked|made|round|log|code|expires|verified|drink|date|bid|by`

## Specific Rules (keep updated)
```
.replace(/attacktime$/i, 'AttackTime')
.replace(/pveattacktime$/i, 'PveAttackTime')
.replace(/attacksec$/i, 'AttackSec')
.replace(/pveattacksec$/i, 'PveAttackSec')
.replace(/taxrate$/i, 'taxRate')       // WAS TaxRate — PascalCase bug!
.replace(/verified$/i, 'Verified')
.replace(/hpupdate$/i, 'HpUpdate')
.replace(/^bases$/i, 'baseS')
.replace(/^basea$/i, 'baseA')
.replace(/rewardxp$/i, 'rewardXp')
.replace(/^accountnumber$/i, 'accountNumber')
.replace(/^fromaccount$/i, 'fromAccount')
.replace(/^toaccount$/i, 'toAccount')
.replace(/^currentbiddername$/i, 'currentBidderName')
.replace(/^attackerguildid$/i, 'attackerGuildId')
.replace(/^defenderguildid$/i, 'defenderGuildId')
.replace(/^arenatopponentid$/i, 'arenaOpponentId')
```

## Suffixes Added This Session
- `bid` — `currentbid` → `currentBid` (was missing, broke auction card)
- `by` — `invitedby` → `invitedBy` (was missing)

## Specific Rules Added This Session
- `fromaccount`/`toaccount` — without explicit rules, `count` suffix ate letters: `fromaccount` → `fromacCount`
- `currentbiddername` — `name` suffix gave `currentbidderName` (lowercase b), client expected `currentBidderName`
- `attackerguildid`/`defenderguildid` — only `id` matched → `attackerguildId`, but code accessed `attackerGuildId` (capital G)
- `taxrate` — was `TaxRate` (PascalCase), client expected `taxRate` (camelCase)

## Debugging Workflow
1. When feature broken → grep the column name across server code
2. Check what key the code accesses: `obj.someKey`
3. Check what camelRows produces for that PG column
4. If mismatch → add suffix or specific rule
5. Deploy db/index.ts + restart PM2

## Client-side Fallback Pattern
When fixing urgent, add BOTH keys: `(lot.currentBidderName || lot.currentbiddername)`. Then fix server-side properly.

Note: `db.query` (SQLite adapter) applies camelRows. Raw `client.query` (PG native) does NOT — use lowercase keys directly: `lot.currentbid`, `lot.sellerid`.
