# Auction UI Features — Patterns & Pitfalls

## Price History Chart (Chart.js)

Chart.js integration for auction lot price history. Lightweight, proven library.

### Server endpoint: GET /auction/price-history

```ts
router.get('/auction/price-history', async (req, res) => {
    const name = req.query.name as string;
    const slot = req.query.slot as string;
    const rarity = parseInt(req.query.rarity as string) || 0;
    const upgLevel = parseInt(req.query.upgradeLevel as string) || 0;
    if (!name) return res.json({ points: [] });

    const rows = await db.query(`
        SELECT DATE(createdAt::timestamp) as day,
               COUNT(*) as count, AVG(price)::int as avg_price,
               MIN(price) as min_price, MAX(price) as max_price
        FROM auction_history
        WHERE itemName = ?
          AND COALESCE(itemData::jsonb->>'slot', '') = ?
          AND COALESCE((itemData::jsonb->>'rarity_id')::int, 0) = ?
          AND COALESCE((itemData::jsonb->>'upgradeLevel')::int, 0) = ?
          AND createdAt::timestamp > NOW() - INTERVAL '30 days'
        GROUP BY DATE(createdAt::timestamp)
        ORDER BY day ASC
    `, [name, slot, rarity, upgLevel]) as any[];
    res.json({ points: rows });
});
```

Key: use `COALESCE` for JSONB fields — `->>'slot'` returns NULL for items without a slot (craft items, runes), and `NULL = ''` is false in SQL.

### Client: PriceChart component

Uses `react-chartjs-2` + `chart.js` with minimal registrations:
```ts
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);
```

Pattern:
- Lazy load: show "📈 История цен" button, fetch on click
- Reset on item change: `useEffect(() => setPoints(null), [itemKey])` where `itemKey = name|slot|rarity|upgradeLevel`
- Date formatting: `p.day.slice(0, 10).split('-')` → `DD.MM`
- Y-axis compact: `v >= 1M ? '1.5M' : v >= 1k ? '1.5k' : v`
- Chart shown on buy tab (each lot card) AND sell tab (below similar stats)

### Price chart bundle size
AuctionPage goes from ~140KB to ~195KB with Chart.js. Acceptable trade-off.

## Grouping by upgradeLevel

Items with different `upgradeLevel` must be treated as separate items:

- **Group key**: `name|slot|rarity_id|upgradeLevel` (was `name|slot|rarity_id`)
- **Similar lots**: add `upgradeLevel` query param + filter
- **Price history**: add upgradeLevel to WHERE clause
- **Group cards**: show `+N` in name and badge on image
- **Sell tab**: badge on images + `+N` in name for grid items and selected item

## NoMoneyModal for auction errors

Use `showNoMoney()` from `NoMoneyModal` for "недостаточно серебра" errors. Shows centered modal with "Купить серебро" button.

For "Максимум лотов" errors, use a custom centered modal with "Премиум (+10 слотов)" button (only if premium not active):

```tsx
const [centerModal, setCenterModal] = useState<string | null>(null);

// In error handler:
if (msg.includes('Недостаточно')) showNoMoney(msg);
else if (msg.includes('Максимум')) setCenterModal(msg);
else setError(msg);

// Render:
{centerModal && (
  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={...}>
    <Card><p>{centerModal}</p>
      <Button onClick={close}>Закрыть</Button>
      {!character?.premium && <Button onClick={() => navigate('/premium')}>⭐ Премиум (+10 слотов)</Button>}
    </Card>
  </div>
)}
```

## Slot Limits & Premium

Server: check `premiumUntil` on user, `maxLots = hasPremium ? 20 : 10`.
Client: `maxSlots = character?.premium ? 20 : 10`.

Premium page: add "📦 +10 слотов аукциона (всего 20)" to benefits list.
