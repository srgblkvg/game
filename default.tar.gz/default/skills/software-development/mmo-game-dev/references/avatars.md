# Avatar System — Full Pipeline

## Server Endpoints That Must Include `avatar`

| Endpoint | File | What to add |
|---|---|---|
| `GET /api/character/me` | `routes/character.ts` | `avatar: user.avatar \|\| null` in res.json |
| `GET /api/arena/opponent` | `routes/arena.ts` | `u.avatar` in main opponent SELECT + saved opponent SELECT; `avatar: ... \|\| null` in both response objects |
| `GET /api/character/public/:userId` | `routes/users.ts` | `u.avatar` in SELECT; `avatar: user.avatar \|\| null` in res.json |

## Client CharacterCardData Constructors

Every place that builds a `{ username, level, equipment, stats, ... }` object for CharacterCard:

| Component | File | Avatar source |
|---|---|---|
| LeftSidebar | `LeftSidebar.tsx` | `(character as any).avatar` |
| ArenaPage (player) | `Arena/ArenaPage.tsx` | `(character as any).avatar` |
| ArenaPage (opponent) | `Arena/ArenaPage.tsx` | `opponent.avatar \|\| null` |
| BestiaryPage | `BestiaryPage.tsx` | `(character as any).avatar` |
| ProfilePage | `ProfilePage.tsx` | `profile.avatar \|\| null` |

## Static Serving

Nginx serves `/uploads/` directly from `/opt/game/server/uploads/` with 7-day cache. No auth needed — files are public.

Express also serves via `app.use('/uploads', express.static(...))` as fallback.

## Upload Flow

1. User picks file in AccountPage → canvas-based resize (max 512KB WebP)
2. POST to `/api/account/avatar` with `{ avatar: "data:image/webp;base64,..." }`
3. Server validates format/size, writes to `/opt/game/server/uploads/avatars/{userId}.webp`
4. Updates `users.avatar` column with `/uploads/avatars/{userId}.webp`
5. Client calls `fetchCharacter()` to refresh, picks up new avatar path
