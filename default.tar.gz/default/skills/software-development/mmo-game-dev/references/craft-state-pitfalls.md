# Craft State Management Pitfalls

Крафт-страница (`CraftPage.tsx`) использует три источника состояния для отображения инвентаря:

- `character.inventory` — серверное состояние, НЕ мутируется локально
- `craftSlots` — локальное состояние слотов крафта (9 ячеек)
- `materialUsage` — счётчик использованных материалов `{ [id]: count }`

`displayInventory` вычисляется из этих трёх:
```js
const slotIds = new Set(craftSlots.filter(s => s !== null && !isCraftItem(s)).map(s => s.id));
return character.inventory
    .filter(item => !slotIds.has(item.id))  // убираем equipment уже в слотах
    .map(item => {
        if (isCraftItem(item)) {
            const used = materialUsage[item.id] || 0;
            const remaining = item.count - used;
            return remaining > 0 ? { ...item, count: remaining } : null;
        }
        return item;
    })
    .filter(Boolean);
```

### Правило: materialUsage ДОЛЖЕН быть согласован с craftSlots

Каждый раз когда craft-предмет (материал ИЛИ камень улучшения) добавляется в слот — `materialUsage[id]++`. Каждый раз когда убирается — `materialUsage[id]--`.

**Баг: upgrade-камни исключались из tracking**

В `handleSlotClick` и `handleDropOnInventory` была проверка:
```js
if (isCraftItem(item)) {
    if (item.itemType !== 'upgrade') {
        setMaterialUsage(prev => ...); // decrement
    }
}
```

При этом `handleMaterialClick` ВСЕГДА инкрементировал `materialUsage` для любых craft-предметов, включая upgrade-камни. Из-за этого при возврате камня из слота `materialUsage` не уменьшался, `displayInventory` считал `remaining = count - used = 0`, и камень исчезал из инвентаря.

**Фикс:** убрать `itemType !== 'upgrade'` — `materialUsage` должен decrement'иться для ВСЕХ craft-предметов.

### Правило: перетаскивание стака → только 1 предмет в слот

В `handleDropOnSlot` и `handleItemClick` для craft-предметов всегда использовать `{ ...item, count: 1 }`, а не весь объект с оригинальным `count`. Иначе при перетаскивании стака из 3 камней все 3 попадают в слот (а визуально отображается 1), и `materialUsage` расходится с реальностью.

Для upgrade-камней в `handleDropOnSlot` раньше было исключение — они шли в `else` ветку `n[index] = item` (весь стак). Нужно обрабатывать их так же как материалы: `{ ...item, count: 1 }` + `materialUsage++`.

### Правило: `handleItemClick` для upgrade-камней

`handleItemClick` позволяет кликать по камням улучшения в гриде снаряжения (не в разделе ресурсов). Раньше камень клался целиком (`n[index] = item`). Теперь: проверка `materialUsage`, `{ ...item, count: 1 }`, и `materialUsage++`.

### Симптомы рассинхронизации

- Камень не отображается в инвентаре после возврата из слота → `materialUsage` не уменьшен
- При перетаскивании стака камней в слот кладётся весь стак → нет `count: 1` в `handleDropOnSlot`/`handleItemClick`
