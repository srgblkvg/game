# Faction System

Added Aug 2026. Three factions available at level 5. First choice free, change costs 10000 silver (resets karma + crafting counter + bandit reputation).

## Factions

| Faction | Key | PvP Bonus | Other Bonuses |
|---------|-----|-----------|---------------|
| Бандиты | `bandit` | +10% stats vs Crafters | Attack range ±4 levels (others ±2), reputation: +1% PvP income per 100 wins, ½ attack cooldown |
| Ремесленники | `crafter` | — | +10%+progressive craft/upgrade chance, ×2 job reward |
| Стражники | `guard` | +10% stats vs Bandits, +10% PvE | Karma: +1 for bandit/mob kill, -1 for others. Salary ±100% |

## Database

```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS faction TEXT DEFAULT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS karma INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS faction_craft_count INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS bandit_reputation INTEGER DEFAULT 0;
```

Karma is Guard-only. Range: -100 to +100, starts at 0.
faction_craft_count tracks SUCCESSFUL crafts+upgrades only (not failures), resets on faction change.
bandit_reputation tracks PvP wins for Bandits, resets on faction change.

**CRITICAL**: `USER_ARENA_FIELDS_GUILD` has its OWN field list — adding fields to `USER_BATTLE_FIELDS` does NOT add them to arena queries. Must add `u.faction` (and any other new field) to BOTH field lists.

## API

### Routes (server/src/routes/faction.ts)

- `GET /api/faction` — returns `{ factions, current, canChoose, changeCost, canChange, memberCounts }`
- `POST /api/faction/choose` — first pick, free, requires level 5+, no existing faction
- `POST /api/faction/change` — costs 10000 silver, resets karma, faction_craft_count, and bandit_reputation

### Character endpoint
`/api/character/me` returns `faction`, `karma`, `factionCraftCount`, `banditReputation`.

## Battle Bonuses (battle.ts)

Faction bonus applied BEFORE currentStats() by multiplying base stats ×1.10.

### Level Range
Bandits: ±4 levels, others: ±2. Enforced in battle.ts AND arena.ts.

### Bandit Reputation (NEW — replaced flat +100% bonus)
- +1 reputation per PvP win (both mercy and normal paths)
- Stolen money multiplier: `1 + floor(reputation/100) / 100`
- Applied AFTER normal money calculation, BEFORE applying to attacker
- Defender loses same amount regardless of reputation

### Bandit Attack Cooldown
`attackCooldown = Math.floor(baseCooldown / 2)` for bandits. Applied in BOTH battle.ts AND character.ts pvpCdSec.

## Crafter Bonus (craft.ts)

+10% base + floor(faction_craft_count / 100)% to creation and upgrade chance.
**Only incremented on SUCCESSFUL crafts and upgrades** (inside `if (success)` blocks).
`/craft/upgrade-info` returns `factionBonus` so client shows correct total.

## Guard Karma

- +1 PvP: killing bandit → +1, killing crafter/guard → -1
- +1 PvE: killing ANY mob → +1 (mobs.ts)
- Salary: base × (1 + karma/100), range 0% to 200%

## Salary Scheduler (salary.ts)

Processes players individually. Guard salary = baseAmount × (1 + karma/100).

## Client Files

- `Header.tsx` — faction tag in first row, right side. Shows craft exp (crafter) or rep (bandit). No karma in header.
- `FactionPage.tsx` — faction view/selection. Guard: karma progress bar. Crafter: crafting exp. Bandit: reputation counter.
- `CastlePage.tsx` — faction block + member count bar chart. Colors: bandit #991b1b, crafter #60a5fa (lighter for dark bg), guard #a16207.
- `CraftPage.tsx` — shows `(+X% фракция)` next to chances. upgrade-info returns factionBonus.
- `RatingPage.tsx` — faction badges, level filter via minLevel/maxLevel.

## Pitfalls
1. Arena has its own field list (USER_ARENA_FIELDS_GUILD) — add new columns there too.
2. Arena opponent selection is in arena.ts, NOT battle.ts.
3. CRLF files: run `sed -i 's/\r$//'` before read_file on server .ts files.
4. Faction change resets ALL faction-specific counters.
5. Crafter text was `text-blue-300` on `bg-blue-900/20` — invisible on light theme. Changed to `text-blue-600`.
