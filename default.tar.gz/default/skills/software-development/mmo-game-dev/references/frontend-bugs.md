# Common Frontend Bugs & Fixes

## Missing CSS Variables → invisible elements

Symptom: element renders but is invisible (progress bar, colored text, icon).
Cause: `var(--color-accent-gold)` used but never defined in `theme.css`.
Fix: Add `--color-accent-gold: #f1c40f;` to both `:root` and `[data-theme="light"]` blocks in `client/src/styles/theme.css`.

## Hardcoded localhost:3001 in fetch() calls

Symptom: admin panel calls `http://localhost:3001/api/...` — fails on production (401/502).
Fix: replace with relative paths: `fetch('/api/...')` so it works on both local and prod.

Files to check: `AdminPanel/AdminUsers.tsx`, `AdminRegisterPage.tsx`.

## `useState` accidentally removed during patch

When editing a component, be careful not to delete `useState` declarations for `now`, `collapsed`,
`hasCollectionItems`, etc. The component will still compile (the `useState` import exists) but
will crash at runtime with "X is not defined".

## useLongPress: onTouchMove must cancel, NOT call onClick

`client/src/hooks/useLongPress.ts` — the hook separates three handlers:
- `onTouchStart` / `onMouseDown` → start 500ms timer for long press
- `onTouchEnd` / `onMouseUp` → if timer didn't fire (short tap), call onClick
- `onTouchMove` → **cancel the timer only**, do NOT call onClick or end

**Bug:** `onTouchMove` was set to `end` (same as `onTouchEnd`). On mobile, any micro-movement during a tap triggers `touchmove` → calls `end()` → fires `onClick` immediately. Then `touchend` fires `end()` again → `onClick` fires twice. Result: double-triggering, popup not opening reliably, items added twice.

**Fix:** Extract a `cancel()` function that only clears the timer:
```typescript
const cancel = useCallback(() => {
    if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; }
}, []);
// onTouchMove: cancel,   NOT end
// onTouchEnd: end        (clears timer + fires onClick on short tap)
```

## CraftPage: materialUsage must be bidirectional for ALL craft types

`client/src/pages/CraftPage.tsx` — `materialUsage` tracks how many of each craft item are used in slots. `displayInventory` subtracts `used` from `count`.

**Bug:** `handleMaterialClick` (adding to slot) increments `materialUsage` for all craft items including upgrade stones. But `handleSlotClick` (removing from slot) only decremented for `itemType !== 'upgrade'`. So upgrade stones' `materialUsage` stayed incremented → `remaining = count - used = 0` → stone disappeared from inventory.

**Fix:** Remove the `itemType !== 'upgrade'` guard — decrement `materialUsage` for ALL craft items when removing from slot. Same fix in `handleDropOnInventory`.

**Rule:** Any code path that adds a craft item to a slot (incrementing `materialUsage`) MUST have a corresponding removal path (decrementing `materialUsage`), regardless of `itemType`.

## calculateStats callers: must pass all stat sources

`client/src/utils/stats.ts` — `calculateStats(character, drinkBonuses?, collectionBonus?)` computes final stats. When a new stat source is added (drinks, collections), ALL call sites must pass the new parameter.

**Bug:** `useBattleLogic.ts:73` called `calculateStats(character, drinkBonuses)` — missing `collectionBonus`. The ArenaPage CharacterCard passed it correctly (line 86), but the HP bar used `maxHpLeft` from the hook which was computed WITHOUT collection bonus. Result: HP bar never reached full because `maxHpLeft < actualMaxHp`.

**Fix:** Add the missing parameter: `calculateStats(character, drinkBonuses, collectionCount || 0)`.

**Rule:** After adding a new stat source parameter to `calculateStats`, grep ALL callers:
```bash
grep -rn "calculateStats(" client/src/ --include="*.tsx" --include="*.ts"
```
Every caller must pass the new parameter. Same for server-side `currentStats()`.

## Progress bar using hardcoded total

Don't hardcode `189` for total collection items. Use `totalCollectionItems` from the
`/api/character/me` response (added to `server/src/routes/character.ts`):

```ts
const totalCollectionItems = (db.prepare('SELECT COUNT(*) as cnt FROM collection_set_items').get() as any).cnt;
```
