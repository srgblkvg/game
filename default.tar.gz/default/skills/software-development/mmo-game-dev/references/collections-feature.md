# Collections Feature

Pattern for adding a new game feature with admin CRUD + player-facing page.

## Database

Tables in `server/src/database/schema.ts`:
- `collections` (userId, itemName, slot, rarity_id) — what the player has collected, UNIQUE(userId, itemName, slot)
- `collection_sets` (name, description, bonus_percent, sort_order) — admin-defined sets
- `collection_set_items` (set_id, item_name, slot) — items belonging to each set, UNIQUE(set_id, item_name, slot)

Seed data in `server/src/database/seed.ts`:
- 7 sets (one per rarity), each containing all items of that rarity (27 items per set: 9 slots × 3 variants)

## API Structure

Player routes (`server/src/routes/collections.ts`):
- `GET /api/collections` — returns `{ items: [...], sets: [{...set, totalItems, collectedCount, completed}] }`
- `POST /api/collections/add` — removes item from inventory, adds to collections, FK to users(id)

Admin routes (`server/src/routes/adminCollections.ts`):
- `GET/POST/PUT/DELETE /api/admin/collection-sets` — CRUD for sets (items array optional on create/update)

Registration in `server/src/setupRoutes.ts`:
- Player: `app.use('/api', collectionsRoutes)` — after auth middleware
- Admin: `app.use('/api/admin', authMiddleware, requireAdmin, adminCollectionsRoutes)`

## Bonus application

In `server/src/routes/character.ts`, after stats calculation:
```ts
const collectionCount = db.prepare('SELECT COUNT(*) as cnt FROM collections WHERE userId = ?').get(userId).cnt;
if (collectionCount > 0) {
    const bonus = 1 + collectionCount / 100; // +1% per item
    stats.s = Math.round(stats.s * bonus);
    stats.a = Math.round(stats.a * bonus);
    stats.d = Math.round(stats.d * bonus);
    stats.m = Math.round(stats.m * bonus);
    stats.hp = Math.round(stats.hp * bonus);
}
```

IMPORTANT: Client also recalculates stats locally via `calculateStats()`. Must pass `collectionCount` as `collectionBonus` parameter:
```ts
// LeftSidebar.tsx
const stats = calculateStats(character, drinkBonuses, (character as any).collectionCount || 0);
```

And in `calculateStats()`:
```ts
if (collectionBonus && collectionBonus > 0) {
    const multiplier = 1 + collectionBonus / 100;
    return { s: Math.round(s * multiplier), a: Math.round(a * multiplier), ... };
}
```

## Client

Page: `client/src/pages/CollectionsPage.tsx`
- Loads `/api/shop/items` + `/api/character/me` + `/api/collections`
- Renders sets with collapsible rarity blocks
- Click on item with matching inventory → select modal → confirm modal → POST add
- After add: reload character/me + collections to sync state
- StatsOverlay shows collection bonus on flip-side

BuffsBlock integration:
- Loads `/api/collections` (items + sets) for indicator and percentage
- Percentage: `collected / totalItems × 100` from API
- Green dot on header when inventory has items not in collection AND not equipped

Admin panel tab: `client/src/pages/AdminPanel/AdminCollections.tsx`
- Register in `AdminPanel.tsx`: add to `tabs` array and conditional render
- CRUD form for sets (name, description, bonus_percent, sort_order)

Breadcrumbs: add to `breadcrumbMap` in `Header.tsx`: `collections: 'Коллекция'`
