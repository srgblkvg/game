# Bot Cleanup Aftermath

After running 50 bots overnight, the following data balloons:

| Table | Before | After bots |
|-------|--------|-----------|
| tournament_matches | few | **427K (334MB)** |
| tournaments | few | 863 |
| chat_messages | few | 7591 |
| DB total | ~50MB | 379MB |

## Fix

```sql
-- Kill bots
DELETE FROM bot_accounts WHERE active = 1;

-- Clean tournaments (keep only last 10)
DELETE FROM tournament_matches WHERE id NOT IN (SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 1000);
DELETE FROM tournament_participants WHERE tournamentId NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM tournaments WHERE id NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);

-- Clean chat (keep last 500)
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);

-- Vacuum
VACUUM FULL tournament_matches;
```

Bots also create corrupted tournaments where all participants are the same bot (player1Id == player2Id).
