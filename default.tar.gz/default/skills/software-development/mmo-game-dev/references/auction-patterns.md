# Аукцион: транзакции, бейджи, история

## WebSocket-бейдж на карточке Actions
Паттерн для бейджа на карточке Аукциона при продаже лота (переживает навигацию):

1. **Глобальная переменная** `window.__auctionBadge` — счётчик
2. **ChatContext** при serverTick: фильтрует `auction_sold`, инкрементит `__auctionBadge`, диспатчит `auctionBadge`
3. **Actions**: читает `__auctionBadge` на старте + слушает событие + опрос каждые 2с
4. **Прямой WS**: `sendToUser(id, { type: 'auction_badge', count: 1 })` — мгновенно, но только онлайн
5. `pushNotification` НЕ дропать для офлайн: убрать `if (!clients.has(userId)) return;`

## Гонка ставок: db.tx + FOR UPDATE
Без транзакции два SELECT видят `currentBid=null` → оба ставят `startPrice`.
Фикс: `db.tx()` + `SELECT ... FOR UPDATE` с raw `client.query` и `$N`.
`FOR UPDATE` работает только внутри транзакции.

## История сделок
Таблица `auction_history` (sellerId, buyerId, itemName, itemData, price, commission, createdAt).
INSERT при buyout и partial-buy. `GET /auction/history` — общая, JOIN users для имён.
Клиент: вкладка «История», формат `📥 Куплено X за N — Продавец A, покупатель B`.

## Живое обновление
`broadcast('auction_changed', {})` при создании/ставке/выкупе.
Клиент слушает `auctionChanged` → `load()`.
