# Faction System Pitfalls

## Crafter Bonus Calculation
The bonus `+1% per 100 experience` must be applied in ALL THREE places:
1. Craft route (`chance = base + craftBonus`) — line ~134
2. `/craft/upgrade-info` endpoint (returns `factionBonus` to client) — line ~239
3. Upgrade execution (calculates `finalChance`) — line ~291

**Pitfall**: The variable in (1) is `craftBonus`, but in (2) and (3) it's `factionBonus`. A `replace_all` on `craftBonus` won't touch `factionBonus`. Always verify all three.

## Experience threshold: 80%
`faction_craft_count` only increments when total chance (base + faction bonus + stone bonus) < 80%. Check in all three places:
- Craft creation: `chance < 80`
- Upgrade with rating: `finalChance < 80`
- Upgrade without rating: `finalChance < 80`

## Guard Karma from PvE
In `mobs.ts`, after successful PvE victory: increment karma for guards just like in PvP:
```ts
if (playerWon && user.faction === 'guard') {
    await db.run('UPDATE users SET karma = karma + 1 WHERE id = ?', [userId]);
}
```

## Guild Leadership Transfer
When promoting a member to `leader` rank, MUST:
1. Update `guild_members.rank = 'leader'` for the new leader
2. Update `guilds.leaderId` to the new leader's userId
3. Demote old leader to `officer` rank

**Pitfall**: Only step 1 was implemented — `guilds.leaderId` wasn't updated, causing stale leaderName in guild cards.

## Missing `faction` in DB queries
When adding `faction` to a response, check ALL queries:
- `USER_ARENA_FIELDS_GUILD` — needs `u.faction`
- Guild member queries — need `u.faction`
- WebSocket `onlineUsers` connect query — needs `u.faction`
- Arena opponent response — needs `faction` field explicitly

**Pitfall**: The WS connect query (`SELECT u.id, u.username, u.level, ...`) didn't include `u.faction`, so `onlineUser.faction` was always null even though the field existed in the interface.
