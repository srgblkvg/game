# Auction UI — Categories, Search, Sorting, Pagination

## Architecture: Server-Side Filtering + Pagination

As of June 2026, auction filtering/sorting/pagination moved to the **server** (`GET /auction` accepts query params). Client sends params, server returns `{ lots, totalCount, page, totalPages, limit }`. No client-side `useMemo` filtering — the server does all the work.

### Query Params
```
GET /auction?page=1&limit=10&search=меч&category=weapon&sort=quality_desc
            &minStr=5&minRarity=2&maxRarity=6
```

All params optional, defaults: `page=1, limit=10, sort=quality_desc, minRarity=0, maxRarity=6`.

## Server-Side Implementation Pattern

### Dynamic WHERE Building
```ts
const where: string[] = ['l.endsAt > ?'];
const params: any[] = [now];

// Text search
if (search) {
    where.push(`(itemdata::jsonb->>'name' ILIKE ? OR u.username ILIKE ?)`);
    params.push(`%${search}%`, `%${search}%`);
}

// Category filter
if (category === 'material') {
    where.push(`(itemdata::jsonb->>'type' IN ('craft_item', 'material'))`);
} else if (category !== 'all') {
    where.push(`(itemdata::jsonb->>'slot' = ?)`);
    params.push(category);
}

// Rarity range
where.push(`COALESCE((itemdata::jsonb->>'rarity_id')::int, 0) >= ?`);
params.push(minRarity);

// Stat filters — only add when value > 0 (for query efficiency)
if (minStr > 0) { where.push(`COALESCE((itemdata::jsonb->'bonuses'->>'s')::int, 0) >= ?`); params.push(minStr); }
if (minCrit > 0) { where.push(`COALESCE((itemdata::jsonb->'extra'->>'crit')::int, 0) >= ?`); params.push(minCrit); }
```

**Key pattern:** Only add stat filter clauses when the value > 0 — avoids unnecessary JSONB extraction on every row.

### JSONB Access Pattern for itemData (stored as TEXT)
The column is `itemData TEXT` in the schema. PG's `::jsonb` cast lets us query into the JSON:

| Stat | JSONB Path |
|------|-----------|
| Strength | `itemdata::jsonb->'bonuses'->>'s'` |
| Agility | `itemdata::jsonb->'bonuses'->>'a'` |
| Defense | `itemdata::jsonb->'bonuses'->>'d'` |
| Magic | `itemdata::jsonb->'bonuses'->>'m'` |
| Crit | `itemdata::jsonb->'extra'->>'crit'` |
| Dodge | `itemdata::jsonb->'extra'->>'dodge'` |
| Counter | `itemdata::jsonb->'extra'->>'counter'` |
| Block | `itemdata::jsonb->'extra'->>'fullBlock'` |
| Rarity | `itemdata::jsonb->>'rarity_id'` |
| Slot | `itemdata::jsonb->>'slot'` |
| Name | `itemdata::jsonb->>'name'` |
| Type | `itemdata::jsonb->>'type'` |

**CRITICAL:** Always wrap in `COALESCE(..., 0)` before arithmetic — missing bonuses/extra keys are NULL, and `NULL::int >= 5` is NULL (falsy), silently dropping rows.

**Case note:** Write `itemdata` (lowercase) in SQL — the camelCase converter (`pgLowerIdentifiers`) lowercases `itemData` to `itemdata` anyway, and `camelRows` converts it back in JS results.

### COUNT + Pagination Pattern
```ts
// 1. COUNT query with same WHERE (no ORDER/LIMIT)
const countResult = await db.one(
    `SELECT COUNT(*) as cnt FROM auction_lots l
     JOIN users u ON l.sellerId = u.id
     LEFT JOIN guilds g ON u.guildId = g.id
     LEFT JOIN users b ON l.currentBidderId = b.id
     WHERE ${whereClause}`,
    params
) as any;

// 2. Data query with ORDER + LIMIT + OFFSET
const lots = await db.query(`
    SELECT l.*, u.username as sellerName, ...
    FROM auction_lots l ... JOIN ...
    WHERE ${whereClause}
    ${orderClause}
    LIMIT ? OFFSET ?
`, [...params, limit, offset]);

// 3. Response shape
res.json({ lots: lots.map(l => ({ ...l, itemData: JSON.parse(l.itemData) })), totalCount, page, totalPages, limit });
```

### Server-Side Sorting
```ts
switch (sort) {
    case 'quality_desc': orderClause = `ORDER BY COALESCE((itemdata::jsonb->>'rarity_id')::int, 0) DESC, l.endsAt ASC`; break;
    case 'price_asc':   orderClause = `ORDER BY COALESCE(l.currentBid, l.startPrice) / GREATEST(COALESCE((itemdata::jsonb->>'count')::int, 1), 1) ASC`; break;
    case 'buyout_asc':  orderClause = `ORDER BY COALESCE(l.buyoutPrice, 999999999) / GREATEST(COALESCE((itemdata::jsonb->>'count')::int, 1), 1) ASC`; break;
    // ... etc
}
```

## Client-Side: Smart Search with Debounce

### Dynamic filtering useEffect

```tsx
const searchTimer = useRef<ReturnType<typeof setTimeout>>();

useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => load(1), 300);
    return () => { if (searchTimer.current) clearTimeout(searchTimer.current); };
}, [auctionSearch, category, sort]);
```

**Pitfall:** WITHOUT this useEffect, changing the search input does NOT trigger a reload — the page only loads on mount and on `auctionChanged` WebSocket events. The search input must be wired to `load()` through a useEffect.

### parseSearch Function — Stat Keywords (presence-only, prefix matching)

Stats are **presence-only** — no numeric values parsed from search input. The user types stat names; the server filters items that have any value (>0) for those stats. **Prefix matching from 1 character** — `с` matches `сила`, `к` matches `крит` or `контратака`.

```ts
const STAT_KEYWORDS: Record<string, string> = {
    'сила': 'minStr', 'силы': 'minStr',
    'ловкость': 'minAgi', 'ловкости': 'minAgi',
    'защита': 'minDef', 'защиты': 'minDef',
    'мастерство': 'minMag', 'мастерства': 'minMag',
    'крит': 'minCrit', 'крита': 'minCrit',
    'уклон': 'minDodge', 'уклонения': 'minDodge',
    'контратака': 'minCounter', 'контратаки': 'minCounter',
    'блок': 'minBlock', 'блока': 'minBlock',
};
```

**Note on `m` stat:** The `m` bonus corresponds to **мастерство** (mastery), NOT магия (magic). All items have `m: 0` in seed data, but the stat exists in the schema and should be searchable.

### parseSearch Function (with prefix matching and category/slot detection)

Stats are **presence-only** — no numeric values parsed from search input. The user just types stat names; the server filters items that have any value (>0) for those stats. **Prefix matching from 1 character** runs on both stat and slot keywords.

```ts
const SLOT_KEYWORDS: Record<string, string> = {
    'оружие': 'weapon', 'меч': 'weapon', 'топор': 'weapon', 'копьё': 'weapon', 'копье': 'weapon', 'лук': 'weapon', 'посох': 'weapon',
    'щит': 'shield',
    'нагрудник': 'chest', 'броня': 'chest', 'кираса': 'chest', 'доспех': 'chest',
    'шлем': 'helmet', 'капюшон': 'helmet',
    'перчатки': 'gloves', 'рукавицы': 'gloves',
    'сапоги': 'boots', 'ботинки': 'boots',
    'кольцо': 'ring', 'кольца': 'ring',
    'амулет': 'amulet',
    'пояс': 'belt', 'ремень': 'belt',
    'материал': 'material', 'материалы': 'material', 'ресурс': 'material',
    'улучшение': 'upgrade', 'камень': 'upgrade', 'камни': 'upgrade',
};

function parseSearch(query: string): { text: string; stats: Record<string, number>; category: string } {
    const stats: Record<string, number> = {};
    let category = 'all';
    const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    const textParts: string[] = [];
    
    const matchPrefix = (token: string, dict: Record<string, string>): string | undefined => {
        // exact match first
        if (dict[token]) return dict[token];
        // prefix match (from 1 char)
        for (const [key, val] of Object.entries(dict)) {
            if (key.startsWith(token)) return val;
        }
        return undefined;
    };
    
    for (const token of tokens) {
        const statField = matchPrefix(token, STAT_KEYWORDS);
        const slotField = matchPrefix(token, SLOT_KEYWORDS);
        if (statField) {
            stats[statField] = 1;  // presence only, sent as minStat=1 to server
        } else if (slotField) {
            category = slotField;
        } else {
            textParts.push(token);
        }
    }
    
    return { text: textParts.join(' '), stats, category };
}
```

**Prefix matching examples (1 char+):**
- `с` → сила, `л` → ловкость, `з` → защита, `м` → мастерство
- `к` → крит (first match in dict order), `у` → уклон, `б` → блок
- `п` → перчатки, `ш` → шлем, `г`/`н` → нагрудник, `щ` → щит
- `ко` → кольца, `ка` → камень/улучшение
- `а` → амулет, `с` → сила (not сапоги — exact match wins, then first dict entry wins)

### Usage in load()

```ts
const load = async (pg?: number) => {
    const { text, stats, category: parsedCategory } = parseSearch(auctionSearch);
    const qs = new URLSearchParams();
    qs.set('page', String(pg || page));
    qs.set('limit', String(limit));
    if (text) qs.set('search', text);
    const activeCategory = parsedCategory !== 'all' ? parsedCategory : category;
    if (activeCategory !== 'all') qs.set('category', activeCategory);
    qs.set('sort', sort);
    for (const [k, v] of Object.entries(stats)) {
        if (v > 0) qs.set(k, String(v));
    }
    // ...
};
```

**Category priority:** Search-parsed category wins over button-selected category. If the user types "перчатки крит 3", category becomes 'gloves'. If they type something without a slot keyword, the category button value is used instead.

### Search Bar Placeholder

Keep it simple:
```
placeholder="Поиск..."
```

The user knows to type stat names and item types. No verbose hints needed.

### UX Behavior
- Typing `крит` → filters to items with any crit stat (minCrit=1 sent to server)
- Typing `к` → same (prefix match: `к` → `крит`, first match in STAT_KEYWORDS)
- Typing `перчатки` → category becomes 'gloves' (slot-based filter)
- Typing `п` → same (prefix match: `п` → `перчатки`)
- Typing `сила перчатки` → gloves with strength ≥ 1
- Typing `шлем` → category becomes 'helmet'
- Typing `блок щит` → shields with block stat
- Typing `сила ловкость защита` → items with ALL three stats
- Typing `контратака уклон` → items with counter AND dodge
- Typing `сил маст груд` → нагрудники с силой и мастерством (prefix matching!)
- Non-stat, non-slot words become the `search` param (ILIKE on item name + seller name)
- **Debounce 300ms, filter from 1 character** (empty string = show all)
- Every keystroke resets to page 1
- **NO separate filter panel or button** — the search bar does everything

## Category Filtering (unchanged)
12 categories based on item `slot` field:
```
{ key: 'all', label: 'Все' }
{ key: 'weapon', label: 'Оружие' }       // slot starts with 'weapon'
{ key: 'shield', label: 'Щит' }           // slot === 'shield'
{ key: 'chest', label: 'Нагрудник' }      // slot === 'chest'
{ key: 'helmet', label: 'Шлем' }          // slot === 'helmet'
{ key: 'gloves', label: 'Перчатки' }      // slot === 'gloves'
{ key: 'boots', label: 'Сапоги' }         // slot === 'boots'
{ key: 'ring', label: 'Кольца' }          // slot starts with 'ring'
{ key: 'amulet', label: 'Амулет' }        // slot === 'amulet'
{ key: 'belt', label: 'Пояс' }            // slot === 'belt'
{ key: 'material', label: 'Материалы' }   // type === 'craft_item' or 'material'
{ key: 'upgrade', label: 'Улучшения' }    // itemType === 'upgrade' or name includes 'Камень улучшения'
```

**Critical ordering**: Check upgrade stones BEFORE materials, or they'll be caught by the broader material check.

## Sorting Options
6 sort modes (now server-side):
```ts
const SORT_OPTIONS = [
    { key: 'quality_desc', label: 'Качество ↓' },
    { key: 'quality_asc', label: 'Качество ↑' },
    { key: 'price_asc', label: 'Цена/шт ↑' },
    { key: 'price_desc', label: 'Цена/шт ↓' },
    { key: 'buyout_asc', label: 'Выкуп/шт ↑' },
    { key: 'buyout_desc', label: 'Выкуп/шт ↓' },
];
```

## Layout (unchanged)
Card layout for each lot: `flex justify-between items-start gap-3`:
- **Left**: item image + name + rarity/seller + prices (flex-1 min-w-0 with truncate)
- **Right**: hours left + action buttons (flex-col items-end gap-2 shrink-0)
- Buttons stacked vertically: Выкупить → [Ставка input + button] → [Купить часть]

## Pitfalls
- **Upgrade stones miscategorized**: If `type === 'craft_item'` check runs before `itemType === 'upgrade'`, upgrade stones appear under "Материалы". Always check upgrade first.
- **Icon availability**: Not all game-icons exist. Test icons: `visor` and `amulet` don't exist in game-icons set. Use `elf-helmet` and `pentacle`.
- **ItemTooltip requires two props**: `item` AND `position` (`{x, y}`). Missing `position` causes "Cannot read properties of undefined (reading 'x')".
- **JSONB NULL coalescing**: Always `COALESCE((itemdata::jsonb->'bonuses'->>'s')::int, 0) >= ?` — never bare `(itemdata::jsonb->'bonuses'->>'s')::int >= ?`. NULL comparisons silently drop rows.
- **itemdata vs itemData**: Write `itemdata` (lowercase) in SQL. The `pgLowerIdentifiers` converter lowercases all camelCase identifiers. `camelRows` restores them in JS results. Writing `itemData` in SQL is harmless but misleading — it'll be lowercased before reaching PG.
- **Params order**: `pgParams` converts `?` to `$1,$2,...` sequentially. Keep params array order matching the SQL's `?` order. LIMIT/OFFSET params go LAST in both SQL and params array.

## Price History Chart

Each auction lot and the sell form show a price history chart (📈 button). See `references/auction-price-chart.md` for full implementation: backend endpoint, Chart.js integration, lazy loading, date formatting, compact axis labels.

## Auction Lot Limits

- Base: **10 lots** per player
- Premium: **20 lots** (checked via `character.premium` on client, `premiumUntil > now` on server)
- Server check in `POST /auction/sell`: `const maxLots = hasPremium ? 20 : 10`
