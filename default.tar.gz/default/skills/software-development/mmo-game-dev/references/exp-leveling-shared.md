# EXP and Leveling — Shared Logic

## applyExp() in `server/src/db/helpers.ts`

Avoid duplicating the EXP/level-up formula. Use the shared helper:

```ts
export function expForLevel(level: number): number {
  return 10 * Math.pow(2, level - 1);
}

export const STAT_POINTS_PER_LEVEL = 5;

export function applyExp(db, userId, expGain, currentExp, currentLevel, currentStatPoints) {
  let exp = currentExp + expGain;
  let level = currentLevel;
  let gained = 0;
  while (exp >= expForLevel(level)) {
    exp -= expForLevel(level);
    level++;
    gained++;
  }
  const sp = currentStatPoints + gained * STAT_POINTS_PER_LEVEL;
  return { newExp: exp, newLevel: level, levelsGained: gained, newStatPoints: sp };
}
```

## Usage
```ts
import { applyExp } from '../db/helpers';
const { newExp, newLevel, levelsGained, newStatPoints } = applyExp(db, userId, expGain, user.exp, user.level, user.statPoints || 0);
db.prepare('UPDATE users SET level=?, exp=?, statPoints=? WHERE id=?').run(newLevel, newExp, newStatPoints, userId);
```

## Files using applyExp
- `server/src/routes/character.ts` — job completion
- `server/src/routes/battle.ts` — PvP attacker and defender
- `server/src/routes/mobs.ts` — PvE battles

The old inline `while(true){const required=10*Math.pow(2,newLevel-1)}` was duplicated across all three files.
