# Auction Page UI Patterns

## Category Filtering
Items use game slot names, NOT UI display names:
- `helmet` (not `head`) → Шлем
- `gloves` (not `hands`) → Перчатки
- `boots` (not `feet`) → Сапоги
- `amulet` (not `necklace`) → Амулет
- `belt` → Пояс
- `weapon1`, `shield` → weapon group
- `ring`, `ring1`, `ring2` → ring group
- `craft_item`, `material` type → Материалы
- `itemType === 'upgrade'` or name includes 'Камень улучшения' → Улучшения

Category check order matters: upgrade check MUST come BEFORE material check because upgrade stones may have `type: 'craft_item'`.

## Sorting
Client-side sort via `useMemo`:
- `price_asc/desc`: (currentBid || startPrice) / count
- `buyout_asc/desc`: buyoutPrice / count, items without buyout rank last (999999999)
- `quality_asc/desc`: rarity_id

## ItemTooltip
`<ItemTooltip>` requires BOTH props: `item` AND `position={{ x, y }}`.
It uses `createPortal` to `document.body`, computing its own position from the passed coordinates.
Do NOT wrap it in a positioned div — let the component handle placement.

## Layout
Auction lot cards: `flex justify-between items-start gap-3`
- Left: item image + info (flex-1 min-w-0)
- Right: time + buttons (flex-col items-end gap-2 shrink-0)
