# Client-Side Real-Time Timers (serverTick Pattern)

## Architecture
1. **Server** (`websocket.ts`): `setInterval(() => broadcast('serverTick', { time: unixtime }), 1000)` — one message/sec for all clients
2. **ChatContext** (`ChatContext.tsx`): receives `serverTick` → dispatches `window.dispatchEvent(new CustomEvent('serverTick', { detail: time }))`
3. **GameContext** (`GameContext.tsx`): listens to `serverTick` → updates `serverTime` state → triggers re-render in all consumers
4. **Consumers**: use `serverTime` from `useGame()` for real-time calculations

## Key Functions (useServerTime.ts)
```typescript
export function useServerTime(): number  // re-renders component every tick
export function getRemaining(endTime: number): number  // seconds left, min 0
export function formatRemaining(seconds: number): string  // "M:SS" or "H:MM:SS"
```

## Cooldown Pattern (HomePage.tsx)
```typescript
const { serverTime } = useGame();
const isPremium = (character.premium?.until || 0) > serverTime;
const cd = isPremium ? 150 : 300; // premium ×0.5
const attackCooldownSec = getRemaining((character.lastAttackTime || 0) + cd);
```

## Critical: IGNORE server CooldownSec
Server returns `attackCooldownSec` / `pveCooldownSec` in `/api/character`. These are only fresh at poll time (10s interval). Using `character.attackCooldownSec ?? getRemaining(...)` causes timers to freeze at stale values between polls.
**ALWAYS** use `getRemaining(lastAttackTime + cd)` for live countdown — the server fields are snapshots, not live values.

## HP Regen Pattern (LeftSidebar.tsx)
```typescript
// Server formula: 1 HP every 10 seconds, ×rate from room
//   closet=×3, bed=×10, chamber=×50
// Premium activates closet (×3) if no room rented
const effectiveRoom = character.room 
  || ((character.premium?.until || 0) > serverTime 
    ? { type: 'closet', until: character.premium!.until } 
    : null);
const regenHp = getRegenHp(character.currentHp, stats.hp, serverTime, 
  effectiveRoom?.type, effectiveRoom?.until);
```
The snapshot (`_hpSnapshot`) is updated in GameProvider when `setCharacter()` fires, so HP base is always fresh.

## React Hooks Warning
`useServerTime()` MUST be called before any conditional returns. Placing it after `if (!character) return <Loading/>` causes React error #310 (different hook count on re-render).

## Files Modified for serverTick
- `server/src/websocket.ts` — serverTick interval
- `client/src/contexts/ChatContext.tsx` — dispatch CustomEvent
- `client/src/contexts/GameContext.tsx` — serverTime state + getRegenHp
- `client/src/hooks/useServerTime.ts` — useServerTime, getRemaining, formatRemaining
- `client/src/pages/HomePage.tsx` — cooldowns via getRemaining
- `client/src/pages/JobsPage.tsx` — job timer via serverTime (no polling)
- `client/src/pages/BestiaryPage.tsx` — PvE cooldown via getRemaining
- `client/src/pages/GuildWarPage.tsx` — war timers via useServerTime
- `client/src/components/LeftSidebar.tsx` — HP regen via getRegenHp
