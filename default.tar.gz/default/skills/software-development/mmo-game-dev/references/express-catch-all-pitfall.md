# Express Middleware Catch-All Pitfall

## Symptom
Guest accounts get 403 `"На гостевом аккаунте доступ к этой функции заблокирован"` for a route that SHOULD be guest-accessible.

## Root Cause
In `server/src/setupRoutes.ts`, there's a catch-all at the bottom:
```ts
// Line 109 — catches ALL unmatched /api routes
app.use('/api', authMiddleware, requirePlayer, requireFullAccess, guestCooldown);
```

If a route doesn't match any registered handler ABOVE this line, Express falls through to this middleware. Since `requireFullAccess` runs BEFORE any 404 handler, guests get the 403 error instead of a 404.

Common causes:
1. Wrong endpoint name (e.g., `/craft/craft` instead of `/craft/execute`)
2. Wrong HTTP method (POST vs GET)
3. Missing route registration in setupRoutes

## Fix
1. Verify the correct endpoint name by checking the route file:
   ```bash
   grep -n "router\.\(post\|get\)" server/src/routes/<name>.ts
   ```
2. Match the exact path and method in the calling code
3. If the endpoint genuinely should exist, register it in setupRoutes BEFORE line 109

## Example
Bot called `/api/craft/craft` — returned 403 for guests. Correct endpoint is `/api/craft/execute`. The wrong path didn't match any router, fell through to `requireFullAccess`.
