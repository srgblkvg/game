# CSS Mobile Background Pitfalls

## `background-attachment: fixed` is broken on mobile

**Symptom:** White/dark stripe at page bottom when scrolling on mobile browsers (Yandex, Safari iOS, Chrome Android).

**Root cause:** `background-attachment: fixed` renders the background relative to the viewport, but on mobile the viewport changes dynamically (URL bar hide/show, keyboard). The background gets clipped, leaving the element's `background-color` (default `transparent`) visible in the padding/overflow area.

**The fix:** Put the background on `html` (the canvas element), not on `body`.

```css
/* WRONG — shows white stripe on mobile */
body {
  background: linear-gradient(...) fixed;
  padding-bottom: 50px;
}

/* RIGHT — background on canvas, always fills viewport */
html {
  background: linear-gradient(180deg, #0a0a1e 0%, #12122a 40%, #1a1a35 100%);
}
body {
  /* transparent, no background needed */
}

html[data-theme="light"] {
  background: linear-gradient(180deg, #f5f0e8 0%, #ede4d4 40%, #e8dcc8 100%);
}
```

**Why this works:** The `html` element's background becomes the **canvas background** in CSS — it always fills the entire viewport regardless of content size, browser toolbars, or dynamic viewport changes. No `position: fixed`, no `z-index`, no pseudo-elements needed.

## `100vh` vs `100dvh` on mobile

**Symptom:** Visible gap at bottom when browser toolbar hides during scroll.

**Root cause:** `100vh` is calculated with the toolbar visible (smaller viewport). When the toolbar hides, the viewport grows but `100vh` doesn't recalculate, leaving uncovered area.

**Fix:** Use `dvh` (dynamic viewport height) as progressive enhancement:

```css
html, body, #root {
  min-height: 100vh;
  min-height: 100dvh; /* adjusts when browser toolbar shows/hides */
}
```

## Selector gotcha: `[data-theme="light"] html`

**THIS DOES NOT WORK:** `[data-theme="light"] html` — means "html element that is a DESCENDANT of an element with data-theme=light". Since `html` is the root element, it has no ancestors. This selector never matches.

**USE THIS INSTEAD:** `html[data-theme="light"]` — the html element ITSELF has the attribute.

```css
/* WRONG */
[data-theme="light"] html { background-color: #f5f0e8; }

/* RIGHT */
html[data-theme="light"] { background-color: #f5f0e8; }
```

For `body`, descendant selector works because body IS a descendant of html:
```css
/* This works — body is inside html */
[data-theme="light"] body { ... }
```

## Performance: too many gradients

16 `radial-gradient()` layers for stars + `linear-gradient` = heavy GPU rendering on mobile. Remove stars, keep only one linear gradient for mobile performance.
