# Active Job Blocking

When a user has an active job (character.activeJob is truthy), certain pages/actions must be blocked.

## Client-side blocking

### Page redirects
Add a `useEffect` in BestiaryPage and ArenaPage:
```tsx
useEffect(() => { if (character?.activeJob) navigate('/jobs'); }, [character?.activeJob, navigate]);
```

### HomePage redirect
Already exists in HomePage:
```tsx
useEffect(() => { if (character?.activeJob) navigate('/jobs'); }, [character, navigate]);
```

### Actions card buttons
Pass `hasActiveJob` from HomePage → MainBar → Actions:
```tsx
// HomePage
<MainBar hasActiveJob={!!character?.activeJob} ... />

// MainBar — add to interface and pass through
<Actions hasActiveJob={hasActiveJob} ... />

// Actions — block Hunt and Arena
const huntDisabled = isHunt && (pveCooldownSec > 0 || hasActiveJob);
const arenaDisabled = isArena && (!canAttack || hasActiveJob);
```

Button text when blocked by active job: `'Работа...'` instead of cooldown timer.
