# Guild Boss System

## Architecture

```
server/src/
├── game/guildBoss.ts       — константы, эффекты, таланты, getOrCreateBoss, damageBoss
├── routes/guildBoss.ts     — GET/POST /guild/boss, /guild/talents, /guild/boss/battles
├── db/migrations/
│   ├── guildBosses.sql     — таблицы guild_bosses, player_guild_talents, guild_talents
│   └── guildBossBattles.sql — история боёв guild_boss_battles

client/src/pages/GuildPage.tsx — вкладки Босс (tab 4) и Таланты (tab 5)
```

## DB Schema

```sql
guild_bosses: guildId PK, killCount, currentHp, maxHp, atk, agi, def, mst, level, effects TEXT, respawnAt INTEGER
guild_members: +lastBossAttackAt, +talentPoints
guilds: +talentPoints
player_guild_talents: userId, guildId, talentType (accuracy|fortitude|penetration|control|vampiric), level, progress
guild_talents: guildId, talentType, level, progress
guild_boss_battles: id, guildId, userId, username, damageDealt, bossHpBefore, bossHpAfter, playerWon, bossKilled, steps TEXT, createdAt
```

## Boss Scaling

- Base: 100k HP, S=80/A=50/D=60/M=50, level=20
- Per kill: +50k HP, +10% stats, +5 level
- Effects: 12 types, scaled by `baseValue * (1 + 0.10 * killCount)`, max 6 effects
- Respawn: 5-minute delay (`BOSS_RESPAWN_DELAY = 300`). `respawnAt` column, auto-respawn in `getOrCreateBoss()`

## Talent System

- 5 types: accuracy (anti-dodge), fortitude (anti-crit), penetration (anti-block), control (anti-counter), vampiric (anti-vampirism)
- Cost: `10 * 2^currentLevel` (10, 20, 40, 80...)
- Progress-based: invest 1 point per click, auto-level when progress >= cost
- Personal talents: any guild member can invest
- Guild talents: only leader can invest
- Effect: 1% per combined level (personal + guild), applied as flat subtraction from enemy extra-stat chance

## Battle Engine Integration (battle.ts)

TurnContext fields added:
```typescript
antiDodge?: number;    // reduces defender's dodge chance
antiCrit?: number;     // reduces defender's crit chance (on counter-attacks)
antiBlock?: number;    // reduces defender's block chance
antiCounter?: number;  // reduces defender's counter chance
targetAntiVampiric?: number; // target's anti-vampirism reduces attacker's healing
```

Applied in runTurn: `Math.max(0, chance - antiStat/100)` for each formula.

## WS Real-time Updates

- After attack: `sendToGuild(guildId, { type: 'guild_boss_update', data: { bossHp, bossKilled, respawnAt, guildTalentPoints } })`
- ChatContext dispatches: `window.dispatchEvent(new CustomEvent('guildBossUpdate', { detail: data }))`
- GuildPage listener extracts: `const d = msg.data || msg` (data is nested)

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /guild/boss | Boss info + talents + cooldown |
| POST | /guild/boss/attack | Attack boss (runTurn PvE) |
| GET | /guild/boss/battles?userId=X | Battle history |
| GET | /guild/talents | All talents + points |
| POST | /guild/talents/upgrade | Invest 1 point (body: {talentType, scope:'personal'|'guild'}) |

## Route Registration

**CRITICAL**: `guildBossRoutes` must be registered BEFORE `guildRoutes` in setupRoutes.ts because `guildRoutes` has `/guild/:id` which matches `/guild/boss`.

```typescript
app.use('/api', guildBossRoutes);  // ← BEFORE guildRoutes
app.use('/api', guildRoutes);
```

## Pitfalls

1. **RSYNC multi-file**: `rsync file1 file2 user@host:/path/` fails. Use separate `scp` calls or rsync with a single source.
2. **WS data nesting**: `sendToGuild` sends `{type, message, data: {...}}`. ChatContext dispatches the whole object. Client must do `msg.data || msg`.
3. **PG column ownership**: ALTER TABLE needs `sudo -u postgres psql` if table owner is postgres, not game user.
4. **Vite build**: `npx vite build` is detected as a server process. Use `background=true` or `> /tmp/out.txt 2> /tmp/err.txt`.
