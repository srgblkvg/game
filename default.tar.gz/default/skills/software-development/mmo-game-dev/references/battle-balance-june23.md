# Battle Balance Changes (23 June 2026)

## Three changes applied:

### 1. Block cap: 100% → 75%
`Math.min(0.75, ...)` — no more immortal tanks.
Location: `server/src/game/battle.ts` — `blockChance()`

### 2. HP formula: S+A+D+M → S+A+M
Defense no longer contributes to HP. Defense gives block chance, not raw HP.
This prevents tanks from double-dipping (high block + high HP).
Location: `server/src/game/stats.ts` — `sumStats()`

### 3. Extra stats: linear → soft cap (diminishing returns)
Old: `extra / 300` (linear, reached 100% at 300)
New: `extra / (extra + 300)` (soft cap, approaches 100% asymptotically)
- At 100: 25% (was 33%)
- At 300: 50% (was 100%)
- At 600: 67% (was 200%)

Applied to: dodgeChance, critChance, blockChance, counterChance, fullBlockChance
Locations: `server/src/game/battle.ts` — all formula functions

## Impact on +10 amulets/rings/belts
With ×2 multiplier on extra stats from upgrade:
- 150 extra → 150/(150+300) = 33% (was 50% with old linear formula)
- Still powerful but no longer breaks the game
