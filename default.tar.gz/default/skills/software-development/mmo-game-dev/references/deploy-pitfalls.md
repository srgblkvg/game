# Deploy Pitfalls

## rsync entire dist, never cherry-pick chunks
After `npx vite build`, hashes change across MANY chunks, not just index.js. Picking individual files WILL miss chunks (ChatContext, BackButton, CSS, etc.) causing `Failed to load module script` errors.

**CORRECT:** `rsync -avz -e "ssh -i ~/.ssh/id_ed25519" client/dist/ root@194.226.142.237:/opt/game/client/dist/`
**WRONG:** `scp index-*.js GuildPage-*.js` — you'll miss something.

## Express route order after PG migration
Express matches routes in registration order. Parameterised paths (`/guild/:id`) capture ANY segment, including literal path names. If `/guild/:id` is registered before `/guild/quest`, `parseInt("quest")` → `NaN` → PG error.
**Fix:** add `if (isNaN(guildId)) return next();` in `:id` handler to pass through.

## React hooks ordering
Hooks MUST be called before any conditional return:
```tsx
// WRONG — React error #310
if (!character) return <Loading/>;
const _st = useServerTime();

// CORRECT
const _st = useServerTime();
if (!character) return <Loading/>;
```
