# Guild Badge Persistence Fix

## Problem
Server sends `guildBadge` in every WebSocket `serverTick`. Client clears badge via `localStorage.setItem('guildBadge', '0')` when clicking the guild card, but the next serverTick immediately restores it.

## Root Cause
The badge is always overwritten in ChatContext regardless of whether the count changed:
```ts
// WRONG — always restores badge on every tick
if (data.guildBadge !== undefined) {
  localStorage.setItem('guildBadge', String(data.guildBadge));
  window.dispatchEvent(new CustomEvent('guildBadge'));
}
```

## Fix: Track "seen" vs "current"

### ChatContext.tsx
Only update badge if count grew beyond what user last saw:
```ts
if (data.guildBadge !== undefined) {
  const cur = parseInt(localStorage.getItem('guildBadge') || '0');
  const seen = parseInt(localStorage.getItem('guildBadgeSeen') || '0');
  if (data.guildBadge > seen) {
    localStorage.setItem('guildBadge', String(data.guildBadge));
    window.dispatchEvent(new CustomEvent('guildBadge'));
  } else if (data.guildBadge <= seen && cur !== 0) {
    localStorage.setItem('guildBadge', '0');
    window.dispatchEvent(new CustomEvent('guildBadge'));
  }
}
```

### Actions.tsx
Save seen count before clearing badge:
```ts
onGuildClick={() => {
  localStorage.setItem('guildBadgeSeen', String(guildBadge));
  localStorage.setItem('guildBadge', '0');
  setGuildBadge(0);
}}
```

## How it works
- Server sends badge=3 → 3 > seen(0) → show "3"
- User clicks guild card → seen=3, badge=0
- Server sends badge=3 → 3 <= seen(3) → badge stays 0
- New request arrives → badge=4 → 4 > seen(3) → show "4"

## Files affected
- `client/src/contexts/ChatContext.tsx` — badge update logic
- `client/src/components/Actions.tsx` — guild card click handler (both world and castle sections)
