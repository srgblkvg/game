# Collections System

## Overview
Предметы из инвентаря добавляются в коллекцию через модалку на странице `/collections`. Каждый предмет даёт +1% к s,a,d,m,hp. Сеты коллекций группируют предметы по редкостям, управляются через админку.

## Database

### collections
```sql
CREATE TABLE collections (
  userId INTEGER NOT NULL,
  itemName TEXT NOT NULL,
  slot TEXT NOT NULL,
  rarity_id INTEGER NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id),
  UNIQUE(userId, itemName, slot)
);
```

### collection_sets + collection_set_items
```sql
CREATE TABLE collection_sets (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  bonus_percent INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER DEFAULT 0
);

CREATE TABLE collection_set_items (
  set_id INTEGER NOT NULL,
  item_name TEXT NOT NULL,
  slot TEXT NOT NULL,
  FOREIGN KEY (set_id) REFERENCES collection_sets(id) ON DELETE CASCADE,
  UNIQUE(set_id, item_name, slot)
);
```

7 стандартных сетов создаются в seed.ts — по одному на каждую редкость (Хлам → Мифический).

## Server API

### Player endpoints
- `GET /api/collections` → `{ items: [...], sets: [{...set, totalItems, collectedCount, completed}] }`
- `POST /api/collections/add` → удаляет предмет из инвентаря, добавляет в коллекцию. Тело: `{ itemName, slot, itemId }`

### Admin endpoints
- `GET /api/admin/collection-sets` — все сеты с items
- `POST /api/admin/collection-sets` — создать сет (`{ name, description, bonus_percent, sort_order }`)
- `PUT /api/admin/collection-sets/:id` — обновить сет
- `DELETE /api/admin/collection-sets/:id` — удалить сет

## Bonus Application (CRITICAL)

Бонус коллекции = количество предметов в `collections` × 1%. Применяется через `currentStats(base, equip, drinkBonuses, collectionBonus)`.

**ВСЕ места где вызывается `currentStats` должны передавать collectionBonus:**
- `character.ts` (character/me)
- `battle.ts` (PvP бои + defenderMaxHp + ответ API)
- `mobs.ts` (PvE бои)
- `guild.ts` (гильдийские битвы)
- `tournament.ts` (турниры + loadPlayerForBattle)
- `tavern.ts` (таверна — расчёт maxHp для лечения)
- `arena.ts` (арена — соперники)
- `users.ts` (профиль игрока)
- `inventory.ts` (пересчёт HP при экипировке)

Питфол: если currentStats вызван без 4-го параметра, бонус коллекции не применяется — игроки с коллекцией не получают преимущества в этих режимах.

## Client

### CollectionsPage
- Загружает три эндпоинта: shop/items + character/me + collections
- Группирует предметы по редкостям (сетам) — каждая группа сворачиваемая
- Три состояния предмета: в коллекции (✓), в инвентаре (зелёная рамка), не собрано (серая)
- Клик по слоту с подходящим предметом → модалка выбора из инвентаря → подтверждение
- Тултип через стандартный ItemTooltip + useLongPress для мобильных
- Блок «Текущий бонус» + сворачиваемый «Как работает коллекция»

### BuffsBlock
- Индикатор: зелёная точка если в инвентаре есть предмет для коллекции (не в коллекции и не надет)
- Процент: собрано / 189 × 100
- Данные инвентаря/equipment передаются через пропсы из LeftSidebar для мгновенного обновления
- `/api/collections` грузится один раз при mount

### StatsOverlay
- На flip-стороне карточки: «Коллекция +X%» золотым цветом
- `collectionBonus` передаётся через CharacterCard → StatsOverlay

## Admin Panel
Вкладка «Коллекция» в AdminPanel. Создание/редактирование/удаление сетов, настройка bonus_percent.
