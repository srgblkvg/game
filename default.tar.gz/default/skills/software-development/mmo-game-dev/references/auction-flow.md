# Auction Lifecycle: Money & Item Flow

Every auction action has a precise money and item flow. Changes here affect multiple users simultaneously — always trace the full lifecycle.

## Sell (POST /auction/sell)

- **Seller pays**: listing fee = 5% of total startPrice (min 1)
- **Item removed** from seller inventory (stack split if partial)
- **Lot created** with `currentBid = null`, `currentBidderId = null`
- **Broadcast**: `auction_changed`

## Bid (POST /auction/bid) — uses db.tx + FOR UPDATE

- **New bidder pays**: `amount` deducted from money
- **Previous bidder refunded**: `lot.currentBid` returned (if any)
- **Lot updated**: `currentBid = amount`, `currentBidderId = bidder`
- **Broadcast**: `auction_changed` (with lotId)
- **Notifications**: seller gets `auction_outbid` toast; previous bidder (if any) gets `auction_outbid` toast ("Вашу ставку перебили")
- **Race condition guard**: `FOR UPDATE` locks the row until commit

Money state: only the CURRENT highest bidder has money held. All outbid players already got refunds.

## Buyout (POST /auction/buyout)

- **Buyer pays**: full `buyoutPrice`
- **Previous bidder refunded**: `lot.currentBid` returned (if any)
- **Item transferred** to buyer inventory (stack merge if same craft_item)
- **Seller paid**: `buyoutPrice - 10% commission`
- **History recorded**: `auction_history` row
- **Notifications**: seller gets `auction_sold` toast + badge; buyer gets `auction_won` toast
- **Broadcast**: `auction_changed`
- **Quests**: `markDirty` for both buyer and seller

## Buy Partial (POST /auction/buy-partial)

- **Price per item**: `ceil(totalPrice / stackCount)`
- **Cost**: `pricePerItem × quantity`
- **Commission**: 10% of cost, **proportional**
- If remaining > 0: lot stays with reduced count, recalculated prices
- If remaining = 0: lot deleted
- **No bidder refund** — partial buys don't involve bids
- **Notifications**: seller gets `auction_sold` toast + badge; buyer gets `auction_won` confirmation
- **Quests**: `markDirty` for both buyer and seller

## Cancel (POST /auction/cancel)

**RESTRICTION**: only allowed if `currentBidderId IS NULL` (no bids placed). Returns 400 if bids exist.

- **Item returned** to seller inventory (stack merge if same type)
- **Lot deleted**
- **Broadcast**: `auction_changed`

No money moves — listing fee is non-refundable.

## Expiry (handled in GET /auction)

This runs when ANYONE views the auction page — processes all expired lots.

### With bids (currentBidderId IS NOT NULL):
- **Seller paid**: `currentBid - 10% commission`
- **Item transferred** to winner's inventory (stack merge)
- **History recorded**: `auction_history` row
- **Lot deleted**
- **Quests**: `markDirty` for both seller and winner
- **Notifications**: winner gets `auction_won` toast; seller gets `auction_sold` toast + badge + `auction_sales` DB increment

### Without bids (currentBidderId IS NULL):
- **Item returned** to seller inventory (stack merge)
- **Lot deleted**

No money moves in either direction — listing fee stays with house.

## Money Flow Summary

| Action | Seller money | Bidder money | Item destination |
|--------|-------------|-------------|-----------------|
| Sell | -listingFee | — | Lot (escrow) |
| Bid | — | -amount, +prev refund | Lot |
| Buyout | +price-10% | -price, +prev refund | Buyer |
| Cancel (no bids) | — | — | Seller |
| Expiry (sold) | +bid-10% | — (already paid) | Winner |
| Expiry (unsold) | — | — | Seller |

**Key invariant**: money is NEVER lost — every deduction has a corresponding credit (seller, refund, or house commission). Verify every code path maintains this.

## GET /auction — Pagination & Stat Filters

As of 2026-06-20, `GET /auction` returns a paginated response with server-side filtering.

### Query Parameters

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `page` | int | 1 | Page number |
| `limit` | int | 10 | Items per page (max 50) |
| `search` | string | — | Search by item name or seller (ILIKE) |
| `category` | string | `all` | Slot filter: weapon, helmet, chest, etc. Also `material`, `upgrade` |
| `sort` | string | `quality_desc` | One of: quality_desc, quality_asc, price_asc, price_desc, buyout_asc, buyout_desc |
| `minRarity` | int | 0 | Minimum rarity_id |
| `maxRarity` | int | 6 | Maximum rarity_id |
| `minStr` | int | 0 | Minimum bonus strength |
| `minAgi` | int | 0 | Minimum bonus agility |
| `minDef` | int | 0 | Minimum bonus defense |
| `minMag` | int | 0 | Minimum bonus magic |
| `minCrit` | int | 0 | Minimum extra crit |
| `minDodge` | int | 0 | Minimum extra dodge |
| `minCounter` | int | 0 | Minimum extra counter |
| `minBlock` | int | 0 | Minimum extra fullBlock |

### Response shape

```json
{
  "lots": [{...lot, itemData: {...}}],
  "groups": [{item: {...}, count: 3, minBid: 500, minBuyout: 2000}],
  "totalCount": 47,
  "page": 1,
  "totalPages": 5,
  "limit": 10,
  "groupTotalCount": 23,
  "groupTotalPages": 2,
  "groupPage": 1
}
```

### Group pagination

Groups are paginated separately from lots (12 per page). Query params: `groupPage`, `groupLimit`.
Client: show ← → pagination controls on groups view, reset `groupPage` to 1 on search/category change.
In groups view (`viewMode === 'groups' && !groupFilter`), hide the lot pagination.

**BREAKING CHANGE**: response is now an object, NOT a flat array. Client code that expected `lots.map(...)` directly on the response must be updated to `data.lots.map(...)`.

### Implementation notes

- All filters use PostgreSQL JSONB operators: `itemdata::jsonb->'bonuses'->>'s'`

### Notification types

All auction endpoints push real-time WebSocket notifications via `pushNotification()`:

| Endpoint | Seller notified | Buyer notified | Previous bidder |
|---|---|---|---|
| `POST /bid` | `auction_outbid` | — | `auction_outbid` |
| `POST /buyout` | `auction_sold` | `auction_won` | — |
| `POST /buy-partial` | `auction_sold` | `auction_won` | — |
| Expired lots | `auction_sold` | `auction_won` | — |

All also call `markDirty(userId, 'quests')` for both parties, broadcast `auction_changed`, and increment `auction_sales` for the badge counter.
- Sorting is server-side — no client-side `filteredLots` useMemo needed
- Client sends all filter params as query string, resets to page 1 on filter change
- `pgLowerIdentifiers` converts `itemData` → `itemdata` in SQL; write `itemdata::jsonb` in queries (not `itemData::jsonb`)
- The `camelRows` converter in `db/index.ts` handles `itemdata` → `itemData` via `data` suffix rule

### Upgrade Level Grouping — Items with +N Are Separate Entities

Items with different `upgradeLevel` are treated as completely separate auction items:

**Group key** (server, line 204):
```ts
const key = `${lot.itemData?.name || ''}|${lot.itemData?.slot || ''}|${lot.itemData?.rarity_id ?? ''}|${lot.itemData?.upgradeLevel ?? 0}`;
```

**Group filter** (server, line 238):
```ts
const key = `${l.itemData?.name || ''}|${l.itemData?.slot || ''}|${l.itemData?.rarity_id ?? ''}|${l.itemData?.upgradeLevel ?? 0}`;
return key === groupFilter;
```

**Similar lots query** includes `upgradeLevel` param:
```ts
const upgLevel = parseInt(req.query.upgradeLevel as string) || 0;
return d.name === name && d.slot === slot && d.rarity_id === rarity && d.upgradeLevel === upgLevel;
```

**Price history** — separate history for each upgrade level:
```ts
AND COALESCE((itemData::jsonb->>'upgradeLevel')::int, 0) = ?
```

**Client** — all item keys include upgradeLevel:
```tsx
const itemKey = `${item.name}|${item.slot || ''}|${item.rarity_id ?? 0}|${item.upgradeLevel ?? 0}`;
const qs = `...&upgradeLevel=${item.upgradeLevel ?? 0}&sellCount=1`;
```

**Display**: upgrade badge on images and +N in names for group view, sell view, and lot list.
