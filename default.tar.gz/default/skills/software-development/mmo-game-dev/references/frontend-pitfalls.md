# Frontend Pitfalls

## useLongPress: onTouchMove ломает onClick на мобильных

**Паттерн-баг:** хук `useLongPress` возвращал `onTouchMove: end`, где `end()` не только отменяла таймер, но и вызывала `onClick`. На мобильных любое микро-движение пальца при тапе → `touchmove` → `end()` → `onClick()` срабатывает ДО `touchend`. Затем `touchend` снова вызывает `onClick()`. Двойное срабатывание ломает логику (например, попап коллекции не открывается).

**Фикс:** `onTouchMove` должна только отменять таймер без вызова `onClick`:

```typescript
const cancel = useCallback(() => {
    if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
    }
}, []);

return {
    onTouchStart: start,
    onTouchEnd: end,      // end вызывает onClick при коротком тапе
    onTouchMove: cancel,  // cancel ТОЛЬКО отменяет таймер, НЕ вызывает onClick
    onMouseDown: start,
    onMouseUp: end,
};
```

**Где:** `client/src/hooks/useLongPress.ts`. Используется в `CollectionSlot`, `LongPressItemSlot`, `LongPressResourceSlot`.

## RatingBlock: рейтинги не обновляются — useEffect с пустыми deps

**Паттерн-баг:** `useEffect(fn, [])` выполняет загрузку данных один раз при монтировании. Если компонент всегда в DOM (правая панель), данные никогда не обновляются.

**Фикс:** добавить `setInterval` с очисткой в cleanup:

```typescript
useEffect(() => {
    const load = () => { fetchData().then(setData); };
    load();
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
}, []);
```

**Где:** `client/src/components/RatingBlock.tsx` (рейтинг игроков + гильдий). Интервал 30 секунд.

## Чат: хардкод-цвета пузырей в светлой теме

**Проблема:** фон пузырей в MessageList использовал хардкод-цвета (`#1a3a1a`, `#2d1f3d`, `linear-gradient(#3b5998,#4a6fa5)`), которые нечитаемы в светлой теме (тёмно-зелёный текст на тёмно-зелёном фоне).

**Фикс:** заменить на CSS-переменные в `theme.css` с разными значениями для тёмной и светлой тем:

```css
/* Тёмная тема */
--color-chat-own-bg: rgba(59, 89, 152, 0.75);
--color-chat-guild-bg: rgba(46, 204, 113, 0.12);
--color-chat-private-bg: rgba(155, 89, 182, 0.12);

/* Светлая тема */
--color-chat-own-bg: rgba(59, 89, 152, 0.7);
--color-chat-guild-bg: rgba(26, 122, 58, 0.12);
--color-chat-private-bg: rgba(123, 63, 158, 0.1);
```

**Где:** `client/src/styles/theme.css`, `client/src/components/chat/MessageList.tsx`.

## Крафт: materialUsage для upgrade-камней

**Паттерн-баг:** `handleMaterialClick` увеличивал `materialUsage` для камней при добавлении в слот, но `handleSlotClick` НЕ уменьшал (из-за проверки `itemType !== 'upgrade'`). Камень висел в `used`, `displayInventory` показывал `remaining = 0`.

**Фикс:** убрать условие — `materialUsage` должен сбрасываться для ВСЕХ craft-предметов при возврате из слота. Так же для `handleDropOnSlot`: все craft-предметы (включая upgrade) должны добавляться с `count: 1` и трекаться через `materialUsage`.

**Где:** `client/src/pages/CraftPage.tsx` — `handleSlotClick`, `handleDropOnInventory`, `handleDropOnSlot`, `handleItemClick`.

## Мобильные: синтетический click закрывает попапы

См. `references/mobile-synthetic-click.md` — паттерн когда попап открывается и мгновенно закрывается на мобильных из-за синтетического `click` через ~300мс после `touchend`.
