# Bestiary Floors — Difficulty Groups

## Architecture
Floors are grouped by difficulty on the SERVER, not the client.
Client receives `{ floors: [{...difficulty:0-3}], groups: [{label,icon,difficulty}] }`.

## Server
`server/src/setupRoutes.ts` — public `/api/floors` endpoint:
```typescript
const DIFF_MAP: Record<string,number> = {
    'Склеп':0,'Подземелье':0,'Катакомбы':0,'Деревня Пепла':0,
    'Лес Черепов':1,'Старый Тракт':1,'Ядовитые луга':1,'Первый ярус':1,
    'Гнилая Топь':2,'Чёрный Монастырь':2,'Башня Плакальщиц':2,'Некрополь Королей':2,
    'Бездонный Овраг':3,'Врата Бездны':3,
};
const DIFF_LABELS = ['Легко','Нормально','Сложно','Ад'];
const DIFF_ICONS = ['🟢','🟡','🟠','🔴'];
```

## Client
`client/src/pages/BestiaryPage.tsx`:
- `FloorGroup` component with collapse/expand (▶/▼ arrows)
- localStorage remembers expanded state per group: `floor_${diff.label}`
- Default: all collapsed
- Groups filtered by `floorsData[].difficulty`

## Adding a new floor
1. Add floor name to `DIFF_MAP` with difficulty 0-3
2. Client picks it up automatically — no client changes needed
