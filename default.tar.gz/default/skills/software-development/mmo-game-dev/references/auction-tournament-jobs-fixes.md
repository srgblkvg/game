# Аукцион, турниры, работы — геймплейные фиксы (сессия 21.06.2026)

## Аукцион: доставка предметов + overflow storage

### Критический питфол: `currentBidderId` в PG native
PG возвращает колонки lowercase → код читает `lot.currentBidderId` (camelCase) = undefined.
**Фикс:** `const buyerId = lot.currentbidderid || lot.currentBidderId;`. То же для `sellerId`.

### Инвентарь полон → overflow
При завершении лота проверяется заполненность инвентаря. Материалы/камни не считаются:
```typescript
const isGear = !!itemData.slot;
const equipCount = inv.filter((i: any) => !!i.slot).length;
if (isGear && equipCount >= maxSlots) {
  await addToOverflow(buyerId, itemData, lot.id);
}
```

### При покупке (buyout) — ошибка
При попытке выкупа с полным инвентарём → `res.status(400).json({ error: 'Инвентарь заполнен' })`.

## Работы: награда × уровень
```typescript
const scaledMax = job.rewardMax * (user.level || 1);
let reward = Math.floor(Math.random() * (scaledMax - job.rewardMin + 1)) + job.rewardMin;
```

## Турниры: авто-отмена при <2 участников
```typescript
const pCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_participants WHERE tournamentId = ?', [tId]) as any).cnt;
if (pCount < 2) {
  await db.run('UPDATE tournaments SET status = ?, completedAt = ? WHERE id = ?', ['cancelled', now, tournamentId]);
  return;
}
```

## Турниры: `IN ()` с пустым массивом → syntax error
Когда турниров/матчей нет, `map(() => '?').join(',')` даёт пустую строку → `IN ()` → syntax error.
**Фикс:** guard `if (allTournaments.length > 0)` перед запросом.

## Аукцион: сортировка «не мои» вверху
```sql
ORDER BY CASE WHEN l.currentBidderId = $userId THEN 1 ELSE 0 END, COALESCE(l.currentBid, l.startPrice) ASC
```

## ServerTick батчинг: один запрос на всех
```typescript
const userIds = Array.from(clients.keys());
const rows = await db.query(
  `SELECT id, money, bank FROM users WHERE id IN (${userIds.map(() => '?').join(',')})`,
  userIds
);
const batch = new Map(rows.map(r => [r.id, r]));
```

## Боты: очистка после массового запуска
50 ботов за ночь → 427K tournament_matches (334MB), БД 379MB.
```sql
DELETE FROM tournament_matches WHERE id NOT IN (SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 100);
DELETE FROM tournaments WHERE status = 'completed';
VACUUM;
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);
DELETE FROM bot_accounts WHERE active = 1;
```

## Дата/время: UTC вместо локального браузера
`fmtSafeDate` использует `toLocaleString('ru-RU', { timeZone: 'UTC', ... })`.
