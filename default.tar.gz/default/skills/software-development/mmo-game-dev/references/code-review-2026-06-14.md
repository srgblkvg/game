# Code Review — 2026-06-14

Review file: `/mnt/c/project/game/.hermes/review.md`

## Critical (fix ASAP)

| # | Finding | Counter / Context |
|---|---------|-------------------|
| 1 | `async async` в 197+ местах | No counter — genuine copy-paste bug. JS tolerates duplicate `async`. One global regex replace fixes it. |
| 2 | JWT-секрет = строка `"openssl rand -hex 32"` | No counter — the command string is the secret. Run the command and put output in `.env`. |
| 3 | Хардкод пароля БД `'game123'` | No counter — should read from `process.env`. Fix is trivial (add env var + default). |

## High Priority (debatable)

| # | Finding | Counter / Context |
|---|---------|-------------------|
| 4 | CSRF middleware not wired | Bearer tokens in `Authorization` header are NOT vulnerable to CSRF (browser doesn't auto-attach them). CSRF matters only for cookie-based auth. Current architecture doesn't need it. Wire it only if switching to httpOnly cookies. |
| 5 | In-memory state lost on restart | Acceptable trade-off for solo project. Redis adds operational complexity. `tokenBlacklist`: short-lived tokens (15-30min) + rare restarts = acceptable risk. `websocket.ts`: ephemeral by nature. `guestCooldown.ts`: guests recreate on restart. `oauth.ts` PKCE: verifiers live seconds. |
| 6 | Guest cooldown disabled (`GUEST_COOLDOWN_MS = 0`) | Likely intentional for dev/testing. Enable for production — not a bug, a feature flag left off. |
| 7 | No tests | Solo project in active development. Tests before stable architecture = double work (rewrite tests on refactor). Priority: battle logic (pure functions, no I/O) first. Full coverage is overkill at this stage. |

## Medium Priority (taste)

| # | Finding | Counter / Context |
|---|---------|-------------------|
| 8 | 50 migrations in one 591-line file | Pragmatic for solo dev. `try/catch` swallowing errors IS a real problem (should fail loudly). Migration framework (knex/drizzle) adds dependency + abstraction overhead — ROI questionable for one dev. |
| 9 | seed.ts 400+ lines, seed_data.sql exists | Not duplication — different layers. `seed_data.sql` = raw data, `seed.ts` = TypeScript-typed seeding logic with idempotency. |
| 10 | `GameItem` duplicated in 3 places | Shared package adds monorepo build complexity. For 3-5 types, copying is cheaper. Fix: at least import from `types/items.ts` instead of inline in `GameContext.tsx`. |
| 11 | email.ts uses `/usr/sbin/sendmail` | Works on Ubuntu VPS with Postfix out of the box. For a few emails/day (password reset, verification), SendGrid/Mailgun = registration + domain verification + free tier limits + another service to monitor. Breaks in Docker though. |
| 12 | `async` on `initDB()` with empty body | Harmless, remove in 5 seconds. |

## Low Priority (nitpicks)

| # | Finding | Counter / Context |
|---|---------|-------------------|
| 13 | `console.log` in oauth.ts:170 | Debug leftover. Replace with `logger.debug()` or remove. |
| 14 | `z.any()` in wsItemLinkSchema | Compromise. Complex nested item structure — writing full Zod schema for every variant is expensive. `z.any()` > no validation at all. |
| 15 | Hardcoded IP `194.226.142.237` | `env \|\| default` pattern. IP is public, not a secret — acceptable. |
| 16 | Server tsconfig has `jsx: "react-jsx"` | Harmless if server doesn't import `.tsx`. Remove for cleanliness. |
| 17 | `VITE_API_URL` unused | Vite template leftover. Delete. |
| 18 | No validation on admin routes | Real risk if admin panel is on public domain. No counter — add validation. |

## Immediate Action Items (15 min total)

1. Generate JWT secret: `openssl rand -hex 32` → `.env`
2. Replace `async async` globally (one regex)
3. Move DB password to `process.env`
4. Set `GUEST_COOLDOWN_MS` to real value for production
