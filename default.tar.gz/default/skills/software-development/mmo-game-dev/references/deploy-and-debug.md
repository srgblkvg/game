# Deploy Verification & Battle Query Completeness

## Client Build: Stale Asset Cleanup

After `rsync`-ing a new client `dist/` to VPS, old hashed assets from previous builds can linger. While they won't be referenced by the new `index.html`, they pile up and cause confusion during debugging (e.g., grepping for function names hits old files). Clean them explicitly:

```bash
# Remove old page-specific assets by pattern
ssh root@host "rm -f /opt/game/client/dist/assets/BattleSimPage-*.js"
# Then rsync new dist/ — only the new hash remains
rsync -avz -e "ssh -i ~/.ssh/id_ed25519" client/dist/ root@host:/opt/game/client/dist/
# Verify only one remains
ssh root@host "ls /opt/game/client/dist/assets/BattleSimPage-*.js"
```

Also clean old `index-*.js` and `index-*.css` chunks that the new build doesn't reference:
```bash
# Check which index the HTML loads
ssh root@host "grep -o 'index-[^\"]*\\.\\(css\\|js\\)' /opt/game/client/dist/index.html"
# Delete ALL index chunks, then redeploy — only the new one will land
ssh root@host "rm -f /opt/game/client/dist/assets/index-*.js /opt/game/client/dist/assets/index-*.css"
rsync -avz -e "ssh -i ~/.ssh/id_ed25519" client/dist/ root@host:/opt/game/client/dist/
```

### 🔴 Symptom: Autocomplete / Dynamic Features Broken After Deploy

**Symptom**: After deploying new client build, autocomplete suggestions (e.g., player search on BattleSimPage) don't appear even though the API endpoint works fine. Other pages load but specific features are dead.

**Cause**: Multiple `index-*.js` chunks exist on VPS from different builds. The old index chunk still references old page hashes, and the browser may load the stale one. Even if `index.html` references the correct chunk, service workers or browser cache can serve old index entries.

**Fix**: Delete ALL index-*.js and index-*.css chunks before/after deploy (see above). Verify with:
```bash
ssh root@host "ls /opt/game/client/dist/assets/index-*.js"
# Should show exactly ONE file
```
If two index files exist and reference different page hashes (verify with `grep 'BattleSimPage' /opt/game/client/dist/assets/index-*.js`), the stale one must go.

## Server Health Check (One-Liner)

Quick diagnostic without logging into VPS interactively:

```bash
ssh root@host 'echo "=== PROCESS ===" && pgrep -a node && echo "=== PM2 ===" && pm2 list && echo "=== RESOURCES ===" && free -h && uptime && echo "=== DB SIZE ===" && du -sh /opt/game/server/*.db 2>/dev/null && echo "=== NODE MEM ===" && ps -o pid,rss,pcpu -p $(pgrep -f "dist/index.js") --no-headers && echo "=== RECENT ERRORS ===" && pm2 logs game-server --lines 5 --nostream 2>/dev/null | grep -i "error\|fail" || echo "(no errors)"'
```

Key metrics to watch:
- **uptime** < 1 min after restart → crash loop, check error log
- **mem** > 500 MB on 2GB VPS → approaching swap territory
- **DB size** > 100MB → check for bot bloat (tournament_matches)
- **load average** > 1.0 on 2-core → CPU-bound
- Error log lines after restart → fresh bugs

## Deploy Verification Pattern
After deploying server files, always verify each file landed correctly:
```bash
ssh root@host "grep -c 'expectedFunc' /opt/game/server/src/path/file.ts"
```
Zero count = file not deployed or wrong version. Multi-file:
```bash
ssh root@host "grep -c 'getGuildBonus' /opt/game/server/src/routes/{mobs,arena,battle,tournament,guild}.ts"
```
Expected: mobs=2, arena=3, battle=3, tournament=2, guild=3.

## PvP Query Field Completeness
`battle.ts` queries for attacker and defender must SELECT all fields needed by downstream functions:

| Function | Required fields |
|---|---|
| `getDrinkBonuses()` | `activeDrink, drinkUntil` |
| `getGuildBonus()` | `id` |
| `applyHpRegen()` | `roomType, roomUntil, premiumUntil, lastHpUpdate` |
| `getBaseStats()` | `baseS, baseA, baseD, baseM` |
| `currentStats()` | `equipment` |

Missing any field → that bonus silently returns zero. Classic symptom: PvP battle log HP < main card HP, despite guild bonus being active.

## tsc Compilation: rootDir/include mismatch

`craft.ts` and `seed.ts` live in `/opt/game/server/` (root), but `tsconfig.json` sets `rootDir: "./src"`. Without `"include": ["src"]`, `npx tsc` picks up those root files and fails with:
```
error TS6059: File '/opt/game/server/craft.ts' is not under 'rootDir' '/opt/game/server/src'
```

Fix: `tsconfig.json` must have `"include": ["src"]` at the end (after `compilerOptions`). If it's missing, add it and scp the tsconfig before running tsc.

## VPS Test Scripts: NODE_PATH\n\nStandalone test scripts on VPS need `NODE_PATH` to find server dependencies (`pg`, etc.):\n```bash\nssh root@host 'NODE_PATH=/opt/game/server/node_modules node /tmp/test.js'\n```\nWithout it: `Error: Cannot find module 'pg'` — the module is in the server's `node_modules`, not global.\n\n## ALTER TABLE Ownership\n\nSome DB tables (`guild_members`, `guilds`) are owned by `postgres`, not `game`. ALTER TABLE as `game` user fails with `must be owner of table`. Run as postgres:\n```bash\nsudo -u postgres psql -d game -c \"ALTER TABLE guild_members ADD COLUMN IF NOT EXISTS ...\"\n```\nCheck ownership first: `psql -c \"\\dt table_name\"` shows Owner column.\n\n## Quick DB Config Changes

For one-liner config updates that don't need server restart (icons, hints, action metadata — anything in `actions_config` or similar config tables):

```bash
ssh root@host "sudo -u postgres psql -d game -c \"UPDATE actions_config SET icon = 'game-icons:pay-money' WHERE title = 'Аукцион';\""
```

The `/api/actions` endpoint reads directly from DB — no server restart needed.
When card stats differ from battle log stats, the root cause is nearly always different calculation paths:
1. **Main card**: `calculateStats()` (client) or `/character/me` (server) — uses enriched equipment, full data
2. **Battle log**: `runBattle()` → `currentStats()` — uses raw DB columns from SELECT query

### Debugging steps:
1. Check which fields the DB query SELECTs vs what the function needs
2. Compare `calculateStats` inputs with `currentStats` inputs (drinks, collection, guildBonus)
3. Verify server files deployed with correct content (see deploy verification)
4. Test API directly: `curl` the relevant endpoint and inspect the response

### Known mismatch causes (fixed):
- `battle.ts` attacker query missing `activeDrink/drinkUntil` → drink bonus = 0 in PvP
- `arena.ts` opponent display missing `getGuildBonus()` → opponent card showed lower stats than battle
- `mobs.ts` PvE missing `getGuildBonus()` → PvE battle didn't apply scout_hq bonus
- `battleSim.ts` missing `getGuildBonus()` entirely → simulator didn't reflect guild building bonuses. Now supports all 4 PvP contexts (`arena`, `tournament`, `war_attack`, `war_defense`) via `context` API parameter. PvE (`pve`) was removed — battle sim is PvP-only. **Rule**: battleSim MUST mirror the real `/api/battle` route — every bonus applied in real combat (drinks, collections, guild buildings per context) must also apply in simulation.

## 🔴 tsc -b blocks vite build on TS6133

Build script: `"build": "tsc -b && vite build"`. If `tsc -b` fails (even on unused-variable warnings), `vite build` NEVER runs. The old `dist/` remains unchanged — user sees no updates.

**Symptom**: All changes deployed, server restarted, browser still shows old page. `grep` on VPS dist shows old function names.

**Fix**: Run `npx tsc --noEmit` before deploying. Zero errors = build will pass. Fix TS6133 by removing unused vars or prefixing with `_`.

Common TS6133 sources: unused imports (Icon, components), unused state variables, unused destructured props.

**Symptom**: Deployed new code, verified files on VPS have correct content, but browser still shows old page. Server log shows old endpoint behavior. `grep` on VPS finds the NEW function name, old file chunk is gone from `ls`, but `index.html` still references the OLD hash.

**Cause**: `rsync` with `--delete` SHOULD remove old chunks, but sometimes the VPS has leftover `index.html` from a previous deploy that references old chunk names. Also: nginx may serve cached versions, and browser service workers/cache persist.

**Fix — nuclear option**: Delete everything on VPS first, then rsync:
```bash
ssh root@host 'rm -rf /opt/game/client/dist/*'
rsync -avz --delete /mnt/c/project/game/client/dist/ root@host:/opt/game/client/dist/
ssh root@host 'grep -o "PageName[^\"]*" /opt/game/client/dist/index.html'  # verify new chunk names
```
**Verification**: After deploy, `index.html` should reference the NEW chunk hash. If old hash still appears, delete `dist/*` again and re-deploy.
