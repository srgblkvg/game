# Bestiary Difficulty Groups — Server-Side Approach

## Problem
Client hardcoded floor names with difficulty mapping. Breaks when:
- Floor names change case (API: "Лес Черепов" vs code: "Лес черепов")
- New floors added
- Difficulty rebalancing needed

## Solution
Difficulty lives on the SERVER. Client receives groups from API.

### Server: `/api/floors` (setupRoutes.ts)
```typescript
app.get('/api/floors', async (_req, res) => {
    const rows = await db.query('SELECT * FROM floors ORDER BY sort_order, name');
    const DIFF_MAP: Record<string,number> = {
        'Склеп':0, 'Подземелье':0, 'Катакомбы':0, 'Деревня Пепла':0,
        'Лес Черепов':1, 'Старый Тракт':1, 'Ядовитые луга':1, 'Первый ярус':1,
        'Гнилая Топь':2, 'Чёрный Монастырь':2, 'Башня Плакальщиц':2, 'Некрополь Королей':2,
        'Бездонный Овраг':3, 'Врата Бездны':3,
    };
    const DIFF_LABELS = ['Легко','Нормально','Сложно','Ад'];
    const DIFF_ICONS = ['🟢','🟡','🟠','🔴'];
    const floors = rows.map(r => ({...r, difficulty: DIFF_MAP[r.name] ?? 0}));
    const groups = DIFF_LABELS.map((label,i) => ({label, icon: DIFF_ICONS[i], difficulty: i}));
    res.json({ floors, groups });
});
```

### Client: BestiaryPage.tsx
```tsx
const [diffGroups, setDiffGroups] = useState<any[]>([]);
useEffect(() => {
    fetch('/api/floors').then(r => r.json())
        .then(data => { setFloorsData(data.floors); setDiffGroups(data.groups || []); });
}, []);

// Render groups from API, filter floors by difficulty
{diffGroups.map(diff => {
    const groupFloors = floors.filter(f =>
        floorsData.some(fd => fd.name === f && fd.difficulty === diff.difficulty)
    );
    return <FloorGroup diff={diff} floors={groupFloors} ... />;
})}
```

## Pitfalls
- **Case mismatch**: API returns "Врата Бездны", DIFF_MAP has "Врата Бездны" — must match EXACTLY
- **Old API format**: Before this change, `/api/floors` returned a flat array. Client must handle new `{floors, groups}` format
- **Initial render**: `diffGroups` is `undefined` until API loads → use `(diffGroups || []).map(...)`
- **Two endpoints exist**: Public `/api/floors` (setupRoutes.ts) and Admin `/api/admin/floors` (adminGame.ts). Client uses PUBLIC one.

## Rule
**NEVER hardcode data on the client that the server can provide.**
Adding a new floor → add to DIFF_MAP on server. Client auto-updates.
