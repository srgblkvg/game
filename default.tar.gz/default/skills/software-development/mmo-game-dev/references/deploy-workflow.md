# Deploy & Sync Workflow

## rsync deploy (preferred over scp for bulk)

When multiple files changed, use rsync to sync the entire `src/` directory. This also **deletes stale files** on prod (old duplicates, abandoned code).

```bash
# Sync src/ to prod (--delete removes files not present locally)
rsync -avz --delete -e "ssh -i ~/.ssh/id_ed25519" /mnt/c/project/game/server/src/ root@194.226.142.237:/opt/game/server/src/

# Copy config separately
scp -i ~/.ssh/id_ed25519 /mnt/c/project/game/server/tsconfig.json root@194.226.142.237:/opt/game/server/

# Compile + restart
ssh -i ~/.ssh/id_ed25519 root@194.226.142.237 "cd /opt/game/server && npx tsc && pm2 restart game-server"
```

**CRITICAL**: PM2 process is named `game-server`, NOT `game`.

## Single-file deploy

For one or two files, scp is fine:
```bash
scp -i ~/.ssh/id_ed25519 /mnt/c/project/game/server/src/routes/tavern.ts root@194.226.142.237:/opt/game/server/src/routes/
```

## Prod stale files (historical)

As of 2026-06-22, rsync removed these stale root-level duplicates from prod:
- `src/auction.ts`, `src/mobs.ts`, `src/tournament.ts`, `src/users.ts`
- `src/chat.ts`, `src/auth.ts`, `src/botManager.ts`, `src/overflow.ts`
- `src/stats.ts`
- `src/routes/setupRoutes.ts` (old duplicate)
- `src/sse.ts` (abandoned feature)

All actual code lives in `src/routes/`, `src/game/`, `src/db/`, etc.
