# Don't Assume — Wait for Exact Instructions

The user gives precise requirements step by step. Do NOT:
- Anticipate what they might want next
- Over-engineer or add features not explicitly asked for
- Guess between multiple interpretations — ask if ambiguous

Wrong assumptions waste time and cause frustration. When the user says "не думай на перед" — they mean it.

This applies to all features in the MMO game project.
