# Font Management

## Current font: Kurale
- Google Fonts: `https://fonts.googleapis.com/css2?family=Kurale&display=swap&subset=cyrillic`
- Single weight (400), no italic needed
- Body: `font-size: 16px`, `font-weight: 500`
- Headings: `font-weight: 600`

## Switching fonts
1. Update Google Fonts link in `client/index.html`
2. Update `font-family` in `client/src/styles/theme.css` (2 places: body + headings)
3. Remove old font CSS import from `client/src/main.tsx` if local font files were used

## Past fonts tried
- Cormorant Garamond (local TTF files in `styles/cormorant.css`) — too ornate
- EB Garamond (Google Fonts) — cleaner but user wanted different
- Cormorant Infant (Google Fonts) — decent but user wanted different
- Kurale (Google Fonts) — current, decorative serif with Cyrillic

## Font weight adjustments
- Body: user prefers 500 (not too thin, not too bold)
- Headings: 600
- If switching to a font with multiple weights, include them all in the Google Fonts URL
