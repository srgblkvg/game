# Actions Card Order

The action cards on the home page are fetched from `/api/actions` which queries `actions_config` table ordered by `section, sort_order`.

## Reordering cards

Direct DB update on VPS:

```bash
ssh root@194.226.142.237 "cd /opt/game/server && node -e \"
const Database=require('better-sqlite3');
const db=new Database('game.db');
db.prepare('UPDATE actions_config SET sort_order = 2 WHERE title = ?').run('Арена');
db.prepare('UPDATE actions_config SET sort_order = 3 WHERE title = ?').run('Работы');
\""
```

No server restart needed — the endpoint queries the table fresh on each request.

## Current order (world section)

1. Охота (sort_order=1)
2. Арена (sort_order=2)
3. Работы (sort_order=3)

## Server endpoint

```ts
// server/src/routes/actions.ts
router.get('/actions', (_req, res) => {
    const actions = db.prepare('SELECT * FROM actions_config ORDER BY section, sort_order').all();
    res.json(actions);
});
```
