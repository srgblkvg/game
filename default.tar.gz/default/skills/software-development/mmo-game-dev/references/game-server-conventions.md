---
name: game-server
description: Conventions and architecture rules for the MMO game server (Express 5 + PostgreSQL + WS). Load when modifying server routes, game logic, combat, regen, or deploying.
---

# Game Server Architecture

Project: /mnt/c/project/game (React 19 + Vite + Tailwind v4 client, Express 5 + PostgreSQL 18 + WS server).

## Database: PostgreSQL (production via pg-promise)

Server runs on PostgreSQL 18 with a pg-promise wrapper that mimics better-sqlite3 API (`db.prepare(sql).get/all/run(params)`). The wrapper handles: `?` → `$1` conversion, lowercase SQL identifiers, camelCase result keys, transactions via `db.tx()`.

**Key**: All route handlers are `async`. All `db.prepare().get/all/run()` calls use `await`. Module-level prepared statements (`const stmt = db.prepare(...)`) are converted to async functions.

See `references/postgresql-migration.md` for migration details and the `sqlite-to-pg-migration` skill for the full playbook.

## Local Development

Run both server and client locally (background, no watch_patterns):

```bash
# Terminal 1 — Server (port 3001):
cd /mnt/c/project/game/server
npx tsx src/index.ts    # Uses SQLite (game.db)

# Terminal 2 — Client (port 5173):
cd /mnt/c/project/game/client
npx vite --host 0.0.0.0
```

**Pitfalls**:
- **Never `node dist/index.js`** — `dist/` is compiled from whichever branch last ran `tsc`. After switching branches, dist is stale.
- **bcryptjs is synchronous**: `bcrypt.compareSync()` returns boolean, NOT a Promise. Do NOT use `await bcrypt.compare()` — it will crash the server.
- **Startup takes ~15s** with tsx (first run compiles). Wait for port 3001: `ss -tlnp | grep 3001`.
- **Branch work**: no deploy unless explicitly asked. Deploy only from main (or when user says so).
- **DB is SQLite**: `game.db` file. Server opens it relative to CWD. On VPS, PM2 starts from `/opt/game`, so DB must be at `/opt/game/game.db`.

## Deploy

### Never stop production for testing
When testing PG migration or any big change, use a SEPARATE port:
```bash
PORT=3002 npx tsx server/src/index.ts  # test on 3002 while prod on 3001
```
Only swap after verifying the test port works. `pm2 stop` on production should be the LAST step, not the first.

### Standard deploy (no backup)
```
cd /mnt/c/project/game
git add ... && git commit -m "описание на русском"
git push
ssh root@194.226.142.237 'cd /opt/game && git fetch && git reset --hard origin/main && bash deploy.sh'
```

### Deploy with VPS backup
```bash
# Бэкап SQLite БД:
ssh root@194.226.142.237 'cp /opt/game/game.db /opt/game_backup_$(date +%Y%m%d_%H%M).db'

# Деплой:
cd /mnt/c/project/game
git add -A && git commit -m "описание" && git push && \
ssh root@194.226.142.237 'cd /opt/game && git fetch && git reset --hard origin/main && bash deploy.sh'
```

Commits: русский язык. Сервер перезапускается через pm2 внутри deploy.sh.

### Post-deploy checks
1. `ssh root@194.226.142.237 'curl -s http://127.0.0.1:3001/api/time'`
2. `ssh root@194.226.142.237 'pm2 list'` — проверять что uptime растёт, а не ↺
3. Если ↺ растёт → crash loop: `pm2 stop game-server && pm2 start game-server`
4. Если 502 но сервер жив → `nginx -s reload`
5. После `git reset --hard` могли удалиться uploads — восстановить из бэкапа: `cp -r /opt/game_backup_*/server/uploads/* /opt/game/server/uploads/`\n6. **Uploads в .gitignore**: добавить `uploads/` в `.gitignore` чтобы git-операции (checkout, reset) не трогали аватары и загруженные файлы. Без этого аватары пропадают при КАЖДОМ `git checkout`/`git reset --hard` — приходится постоянно восстанавливать из бэкапа.
## HP Regen

Реген HP: +1 HP каждые 10 секунд вне боя. Ускорение от комнат: closet=×3, bed=×10, chamber=×50.

**Архитектура**: lazy-актуализация через `applyHpRegen()` в `server/src/game/hpRegen.ts` — HP восстанавливается с темпом +1/10сек, даже когда игрок офлайн. Функция считает elapsed от `lastHpUpdate`, применяет реген, пишет в БД если изменилось, возвращает актуальное HP.

**Где вызывается**:
- `/character/me` — для самого игрока при любом запросе (его HP всегда актуально)
- `/battle` — **только для защитника**, перед формированием `defenderData`. Атакующий — без регена (его HP свежее через `/character/me`)

**Питфол**: не применять `applyHpRegen` для атакующего в `/battle` — его HP и так актуально. Реген защитника — это не «восстановление перед боем», а подтягивание того, что уже должно было накопиться за время офлайна. `lastHpUpdate` у защитника обновится — это правильно, точка отсчёта сдвинулась.

Реализация регена: `server/src/game/hpRegen.ts` — чистая функция, возвращает актуальный HP и пишет в БД если изменился. Подробнее: [references/hp-regen.md](references/hp-regen.md).

## Related Skills

After every deploy, verify server health quickly:

```bash
# Check server is running
ssh root@194.226.142.237 'curl -s http://127.0.0.1:3001/api/time'

# Check PM2 stability (uptime growing, restarts not climbing)
ssh root@194.226.142.237 'pm2 list'

# If ↺ counter is climbing → crash loop:
ssh root@194.226.142.237 'pm2 stop game-server && pm2 start game-server'
```

## PG Table Name Mismatch: `tournament` vs `tournaments`

SQLite code uses `tournaments` (with 's') throughout. PG schema had `tournament`. If queries fail with `relation "tournaments" does not exist`, rename the PG table:

```sql
ALTER TABLE tournament RENAME TO tournaments;
```

And update `schema.ts` to use `tournaments` for future deployments.

## PG `login_logs.username` NOT NULL Crash

Guest registration inserts into `login_logs` without a `username` field: `INSERT INTO login_logs (userId, ip) VALUES (?, ?)`. PG schema had `username TEXT NOT NULL` → server crashes on guest registration.

Fix: `ALTER TABLE login_logs ALTER COLUMN username DROP NOT NULL` and update `schema.ts` to `username TEXT` (nullable).

## System User (id=0)

В таблице `users` создан системный пользователь `id=0, username='system'` для автосообщений (турниры, чат). Миграция: `db.prepare('INSERT OR IGNORE INTO users (id, username, passwordHash, currentHp) VALUES (?, ?, ?, ?)').run(0, 'system', 'system', 100)`.

**Питфолы**:
- Системный пользователь НЕ должен попадать в рейтинг: `WHERE id > 0` в `/api/rating`
- НЕ должен быть выбран противником на арене: `AND id > 0` в `/api/battle` (подбор случайного противника)
- `passwordHash` — NOT NULL без DEFAULT, обязательно включать в INSERT. Без него INSERT OR IGNORE молча проваливается (0 changes).
- В чате отображается как «system». Турнирные уведомления (`senderId=0, targetId=null`) — FOREIGN KEY satisfied.

## WebSocket Broadcast из админских/системных эндпоинтов

Если админский эндпоинт вставляет сообщение в `chat_messages`, он должен отправить broadcast через WebSocket чтобы сообщение появилось сразу у всех онлайн-игроков (без обновления страницы).

**Паттерн**:
1. Экспортировать `broadcast` из `server/src/websocket.ts`:
```ts
export { broadcast };
```
2. В админском роуте импортировать и вызвать после INSERT:
```ts
import { broadcast } from '../websocket';

const info = db.prepare('INSERT INTO chat_messages (...) VALUES (...)').run(...);
const msg = {
    id: info.lastInsertRowid,
    senderId: 0,
    senderName: 'system',
    targetId: null,
    content,
    createdAt: new Date().toISOString(),
};
broadcast('message', { message: msg });
```

Формат `msg` должен совпадать с тем что возвращает обычный эндпоинт чата.

## Поиск пользователя по нику

Эндпоинт `GET /api/users/find?username=` в `server/src/routes/character.ts`. Используется для перехода из чата в профиль (ChatPanel → ProfilePage). Клиент: `findUserByUsername()` в `client/src/api/chat.ts`.

## Tournament FOREIGN KEY Pitfall

Турнир (`/api/tournament`) падает с 500 и ошибкой `SqliteError: FOREIGN KEY constraint failed` если пытается вставить `chat_messages` с `senderId` которого нет в `users`. Решение: системный пользователь id=0 (см. выше). Подробнее: [references/tournament-fk-pitfall.md](references/tournament-fk-pitfall.md). Для новых фич, добавляющих автосообщения — всегда проверять что senderId существует в БД.

## DB Schema Changes

Schema is defined in `server/src/database/schema.ts` using PG `CREATE TABLE IF NOT EXISTS`. Migrations (`migrations.ts`) are skipped in PG mode — all fields are in the main schema.

To add a new column/table: add to `schema.ts` and run `ALTER TABLE` on VPS separately:
```bash
ssh root@194.226.142.237 "cd /opt/game/server && node -e \"
const {Pool} = require('pg');
const pg = new Pool({database:'game',user:'game',password:'game123'});
pg.query('ALTER TABLE users ADD COLUMN new_field INTEGER DEFAULT 0').then(() => pg.end());
\""
```

## Header

Закреплённый header: `sticky top-0 z-40` в `client/src/components/Header.tsx`. Двухрядный: верхний ряд — серебро/щит/иконка настроек, нижний ряд — хлебные крошки на всю ширину.

**Иконка настроек**: кнопки Аккаунт/Сводка/VK свёрнуты в иконку шестерёнки (`mdi:cog` — НЕ `game-icons:gear`, его нет в наборе) с выпадающим меню. При новых боях — красная точка на иконке. Меню закрывается по клику вне (useRef + mousedown listener). Админская кнопка остаётся отдельно.

**Паттерн закрытия меню по клику вне**:
```tsx
const menuRef = useRef<HTMLDivElement>(null);
useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
        if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
}, [menuOpen]);
```

**Cursor pointer**: все кликабельные элементы должны иметь `cursor-pointer`: ссылки хлебных крошек, иконка настроек, пункты меню (Аккаунт, Сводка, VK). Кнопки (Button) уже имеют pointer по умолчанию.

**Хлебные крошки** (Breadcrumbs):
- Парсят `location.pathname`, строят цепочку: Персонаж › Арена, Персонаж › Трактир и т.д.
- Корневой путь — «Персонаж» (не «Главная»)
- Текущая страница выделена плашкой (`bg-secondary`, `font-semibold`), не кликабельна
- Промежуточные — голубые ссылки с `hover:underline`
- **По центру экрана**: внешний `div` + внутренний `div` с `max-w-max mx-auto`. `justify-center` недостаточно — с `overflow-x-auto` он не центрирует при переполнении. Два вложенных div'а: внешний для фона, внутренний для центрирования контента.
- Разделитель `›` с `select-none`
- Цифровые сегменты пути (ID) пропускаются
- Карта имён: `breadcrumbMap` в Header.tsx
- На главной: просто плашка «Персонаж» (isHome)

Кнопка «← Назад» УБРАНА — вместо неё хлебные крошки. Со всех страниц локальные `BackButton` удалены.

### Z-Index Stacking Pitfall

Карточки Actions имели `z-10` на внутреннем контенте (чтобы быть над фоновым изображением с `z-0`). Это создавало новый stacking context, который перекрывал sticky-хедер при скролле. **Решение**: убрать `z-10` и `z-0` с дочерних элементов карточки. Порядок в DOM (контент после фона) сам обеспечивает правильное наложение внутри карточки, без выхода за её пределы.

Иерархия z-index после исправления: модалки (`z-50`) > хедер (`z-40`) > всё остальное (auto).

### Tournament Banner Prize Pool

Блок турниров на главной (`TournamentBanner.tsx`) показывал призовой фонд как `{t.prizePool} 🥇`. Заменено на `Призовой фонд: {formatMoney(t.prizePool)}` — полный текст с «серебра». Не забывать импортировать `formatMoney`.

## Quests: hunt = pveWins (not pveTotalBattles)

Квест типа `hunt` считает прогресс по `pveWins` (только победы), а не по `pveTotalBattles` (все бои включая поражения). И `getSnapshot`, и `getProgress` в `server/src/routes/quests.ts` должны использовать `pveWins`. Поле `pveWins` уже есть в таблице users (инкрементится в `mobs.ts`).

## Quests: перенос незавершённых на сегодня

При первом заходе в таверну за новый день (`GET /tavern/quests`):
1. Если на сегодня нет квестов — ищем вчерашние со статусом `active`
2. Переносим их на сегодня: `UPDATE daily_quests SET date = ?, snapshot = ?` (снепшот обновляется)
3. Генерируем недостающие `available` квесты только для типов, которых нет среди перенесённых
4. `take` эндпоинт считает `activeCount` **с фильтром по дате** (`AND date = ?`), иначе старые квесты невидимо блокируют взятие новых

API возвращает `resetAt` — Unix-timestamp полуночи UTC. Клиент показывает таймер: `(сброс через N ч M мин)` с использованием `now` из состояния (тик раз в секунду).

## History: XP only for winner

В `client/src/pages/HistoryPage.tsx` — `expGained` показывается только при `win && expGained > 0`. Без проверки `win` опыт показывался бы и победителю и проигравшему (потому что `expGained` в таблице battles — одно значение на бой).

## Auction

### Item Images

Предметы НЕ имеют поля `imageUrl`. Изображения вычисляются через `getItemImage(item)` из `client/src/utils/itemUtils.ts`. Функция строит путь на основе `item.slot`, `item.type`, `item.rarity_id`: `/sword/sword_blue.webp`, `/fragment/fragment_green.webp` и т.д. Всегда использовать `getItemImage(item) || '/items/default.webp'`.

### Sell Grid

Вкладка «Продажа» использует визуальную сетку предметов вместо `<select>`: `grid grid-cols-3 sm:grid-cols-6 gap-2`. Каждый предмет — карточка с иконкой, названием, редкостью и счётчиком (×N). Выбранный предмет подсвечен: `border-[var(--color-accent-info)] ring-1`. При выборе показывается превью с иконкой.

### Tooltips (hover + long-press)

Паттерн двойного режима для `ItemTooltip`:

```tsx
const supportsHover = useRef(window.matchMedia('(hover: hover)').matches);

// Desktop: hover
const showTooltip = (e, item) => { if (!supportsHover.current) return; setTooltip({...}); };
const hideTooltip = () => { if (!supportsHover.current) return; setTooltip(null); };

// Mobile: long press (500ms)
const handleTouchStart = (e, item) => {
    timer.current = setTimeout(() => setTooltip({...}), 500);
};
const handleTouchEnd = () => { clearTimeout(timer.current); };

// Запрет контекстного меню браузера при долгом нажатии:
onContextMenu={e => e.preventDefault()}

// Скрытие по тапу вне тултипа:
useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setTooltip(null); };
    document.addEventListener('touchstart', handler);
    document.addEventListener('mousedown', handler);
    return () => { ... };
}, [tooltip]);
```

**Питфол**: `ItemTooltip` не `forwardRef`, поэтому `ref` вешается на div-обёртку вокруг него. Без привязанного ref клик вне тултипа не скрывает его (висит бесконечно).

**Питфол**: `matchMedia('(hover: hover)')` надёжнее чем `isTouching` флаг с таймаутом. Флаг с 300ms давал гонки: при быстрых кликах тултип то появлялся, то нет.

## Hash Scroll Pitfall

`window.location.hash = ''` вызывает скролл страницы наверх. Для сброса хэша без скролла использовать `history.replaceState` + явную очистку состояния:

```ts
// Правильно (без скролла):
setHighlightedCard(null);
history.replaceState(null, '', window.location.pathname + window.location.search);

// Неправильно (скроллит наверх):
window.location.hash = '';
```

Актуально для `client/src/components/Actions.tsx` (подсветка карточек заданий) и любых других мест где хэш используется для временного выделения.

## Memory conventions

Пользователь: русский, коротко, без fluff. Ненавидит: английские коммиты, неработающие фичи, заглушки, повторные баг-репорты. Требует: прямые исправления без делегирования, перезапуск серверов + curl перед «готово».

Серверы: background=true БЕЗ watch_patterns. Vite HMR ненадёжен: kill+restart+curl.

## Actions Configuration

Action cards (Охота, Арена, Работы, etc.) are DB-driven via `actions_config` table — reorder by updating `sort_order` on VPS. See [references/actions-config.md](references/actions-config.md).

## Character API: guildId Field

`/character/me` must return `guildId` for guild-related UI logic. Add to the response JSON:

```ts
guildId: user.guildId || null,
```

This field is checked by ChatPanel to hide guild invite buttons after a player joins a guild (`!character?.guildId`). Without it, `character.guildId` is always undefined and invite buttons never disappear after page reload.

## Chat: WS-Only Delivery (No DB History on Client)

Client no longer loads chat history from the database via REST endpoints. All messages (public, private, guild) arrive exclusively via WebSocket `broadcast`. The server still stores messages in `chat_messages` table, but the client does not call `fetchRecentMessages`, `fetchPrivateMessages`, or `/guild/chat` GET. Client-side persistence is via localStorage (see `mmo-game-dev` skill).

## Arena Opponent Endpoint (guildName)

`/api/arena/opponent` is a SEPARATE endpoint from `/api/battle` — both need `guildName` LEFT JOIN. The arena page loads opponents via `GET /api/arena/opponent` (not `/api/battle`). Both the user SELECT and opponents SELECT in `server/src/routes/arena.ts` must include `g.name as guildName, u.guildId FROM users u LEFT JOIN guilds g ON u.guildId = g.id`. Without this, `opponent.guildName` is `undefined` in the arena CharacterCard.

## Sticky Resource Pattern (Arena Opponent Tracking)

When assigning a resource to a player (arena opponent, quest target, daily lockout), the server should remember what was assigned and return the same resource on repeat requests until the player takes an action (fight, complete, change). This prevents client-side exploits where reloading the page or re-navigating bypasses costs.

### How It Works

1. **DB column**: `arenaOpponentId INTEGER DEFAULT NULL` on the `users` table — stores the ID of the currently assigned opponent.
2. **On `change=false` (first visit / page refresh)**: If `arenaOpponentId` is set and the saved opponent still exists and is not protected, return the SAME opponent for free. No new random pick, no cost.
3. **On `change=true` (manual reroll)**: Charge 10 silver, pick a new opponent, update `arenaOpponentId`.
4. **Difficulty mismatch**: Even when `change=false`, if the saved opponent's level doesn't match the requested difficulty, treat it as a change — charge 10, pick new. This prevents bypassing the cost by switching difficulty on the main menu.
5. **After battle**: Clear `arenaOpponentId=NULL` in the `POST /battle` handler's attacker UPDATE. Next visit gets a fresh free pick.

### Server Code (key parts)

```ts
// In SELECT: pull arenaOpponentId
const user = db.prepare('SELECT ... u.arenaOpponentId ... FROM users u ...').get(userId);

// If not a change and we have a saved opponent, check it:
if (!change && user.arenaOpponentId) {
    const saved = db.prepare('SELECT ... FROM users WHERE id = ? AND (protectionUntil IS NULL OR protectionUntil < ?)').get(user.arenaOpponentId, now);
    if (saved) {
        // Check difficulty match:
        const matchesDifficulty =
            (difficulty === 'easy' && saved.level < user.level) ||
            (difficulty === 'hard' && saved.level > user.level) ||
            (difficulty === 'equal' && saved.level === user.level);
        if (matchesDifficulty) {
            return res.json(/* same opponent, no cost */);
        }
        // Difficulty changed — charge and fall through to new pick
        if (user.money < 10) return res.status(400).json({ error: 'Недостаточно монет (10 бронзы)' });
        db.prepare('UPDATE users SET money = money - 10 WHERE id = ?').run(userId);
        user.money -= 10;
    }
    // Opponent disappeared (deleted/protected) — fall through to new pick
}

// ... pick new opponent ...

// Save the chosen opponent:
db.prepare('UPDATE users SET arenaOpponentId = ? WHERE id = ?').run(opponent.id, userId);
```

### After Battle Cleanup

In `POST /battle`, add `arenaOpponentId=NULL` to the attacker's UPDATE:

```sql
UPDATE users SET ... arenaOpponentId=NULL WHERE id=?
```

### parseInt Safety

When parsing `excludeId` from query params, guard against malformed values (e.g. `23:1` from corrupted client state):

```ts
const excludeId = req.query.excludeId ? parseInt(req.query.excludeId as string) : undefined;
// Later:
if (excludeId !== undefined && !isNaN(excludeId)) {
    opponents = opponents.filter(o => o.id !== excludeId);
}
```

`parseInt("23:1")` returns `NaN`. Without `!isNaN()`, the filter `o.id !== NaN` is always true (NaN !== anything), silently doing nothing. With the guard, malformed values are just ignored.

## Tournament: guildName/guildId in participant lists

When returning tournament participants via `.map()`, the API must include `guildName` and `guildId` in the response. The DB query already JOINs `guilds` correctly via `LEFT JOIN guilds g ON u.guildId = g.id`, but if the `.map()` strips these fields, the client gets `guildName: undefined`.

**Питфол**: две копии одного и того же `.map()` — в `/tournament` (активные турниры) и в `/tournament?tab=completed` (завершённые). Обе нужно фиксить.

```ts
// Было:
participants: participants.map((p: any) => ({
    id: p.userId, username: p.username, goldenTicket: p.goldenTicket,
    snapshotStats: p.snapshotStats ? JSON.parse(p.snapshotStats) : null,
}))

// Стало:
participants: participants.map((p: any) => ({
    id: p.userId, username: p.username, goldenTicket: p.goldenTicket,
    guildName: p.guildName, guildId: p.guildId,
    snapshotStats: p.snapshotStats ? JSON.parse(p.snapshotStats) : null,
}))
```

## Official Tournament Delay

Официальные турниры создаются через 1 час после завершения предыдущего (не сразу).

**Реализация**:
1. **Миграция**: `ALTER TABLE tournaments ADD COLUMN completedAt DATETIME` — время завершения турнира
2. **При завершении** (`finishTournament`): `db.prepare('UPDATE tournaments SET status = ?, completedAt = datetime(?) WHERE id = ?').run('completed', new Date().toISOString(), tournamentId)`
3. **При отмене** (`generateBracket`, participants < 2): тоже ставить `completedAt = datetime(?)` — чтобы пауза работала и для несостоявшихся турниров
4. **При создании нового** (`autoAdvance` и `getOrCreateTournament`): проверка `completedAt` ПОСЛЕДНЕГО завершённого турнира дивизиона, а не текущего обрабатываемого:

```ts
const lastCompleted = db.prepare(
    "SELECT completedAt FROM tournaments WHERE division = ? AND type = 'official' AND status IN ('completed', 'cancelled') ORDER BY id DESC LIMIT 1"
).get(div.name) as any;
if (lastCompleted?.completedAt) {
    const completedTime = new Date(lastCompleted.completedAt + 'Z').getTime();
    if (Date.now() < completedTime + 3600 * 1000) continue; // ещё не прошёл час
}
```

**Питфол**: `autoAdvance` вызывается для ВСЕХ недавних турниров (24ч окно). Если в дивизионе два завершённых турнира (538 в 13:40, 542 в 14:10), то при обработке более старого (538) час уже прошёл → новый турнир создаётся игнорируя свежий (542). Решение: проверять `completedAt` **последнего** турнира дивизиона (`ORDER BY id DESC LIMIT 1`), а не текущего `t.completedAt`.

5. **После ожидания**: создаётся новый турнир с `registrationStart = now, registrationEnd = now + REGISTRATION_WINDOW`

Турнир не появляется в списке до истечения часа после `completedAt`.

Для отображения таймеров на клиенте — API возвращает `upcomingOfficial` массив:
```ts
// Для каждого дивизиона без активного турнира:
// Проверяем completedAt последнего завершённого/отменённого
// Если час не прошёл — добавляем в upcomingOfficial
upcomingOfficial.push({
    division, label, icon, minLevel, maxLevel,
    registrationOpensAt: Math.floor(completedTime + 3600 * 1000 / 1000),
});
```

Клиент рендерит блок «⏳ Скоро откроется запись» с обратным отсчётом `formatTimer(registrationOpensAt - now)`.

Призовой фонд распределяется динамически в зависимости от числа участников:
- **2 участника**: 70% / 30% — весь фонд
- **3+ участников**: 50% / 30% / 20%
- **1 участник**: турнир отменяется (`generateBracket` → `participants.length < 2` → cancelled)

Код в `finishTournament()`: `if (!secondPlaceId) firstPrize = prizePool; else if (!thirdPlaceId) 70/30; else 50/30/20`.

## Auction: minBid Guards

Формула минимальной ставки: `currentBid + Math.max(1, Math.floor(currentBid * 0.05))`. Старая формула `Math.floor(currentBid * 1.05)` давала равную ставку при малых числах (e.g. bid=10 → min=10). Новая всегда даёт минимум +1.

Обновить в двух местах: сервер (`routes/auction.ts`) и клиент (`AuctionPage.tsx` placeholder/min).

## Auction Lot Cancellation

Эндпоинт `POST /auction/cancel` — снятие своего лота:
- Возвращает предмет в инвентарь (stack merge для craft_item/material)
- Возвращает деньги текущему лидеру ставок
- Удаляет лот из `auction_lots`
- Кнопка «Снять лот» только для продавца (`lot.sellerId === user?.id`)

## lastLoginAt in Auth Middleware

`lastLoginAt` обновлялся только при логине (`POST /login`). Игроки с сохранённым токеном никогда не обновляли поле. Решение: обновление в `authMiddleware` раз в 5 минут (троттлинг через `Map<string, number>` в памяти):

```ts
const lastLoginUpdates = new Map<string, number>();
// в authMiddleware, после decoded:
if (decoded.role === 'player') {
    const now = Math.floor(Date.now() / 1000);
    const key = `llu_${decoded.userId}`;
    const last = lastLoginUpdates.get(key) || 0;
    if (now - last > 300) {
        lastLoginUpdates.set(key, now);
        db.prepare('UPDATE users SET lastLoginAt = ? WHERE id = ?').run(now, decoded.userId);
    }
}
```

## Feedback System Pattern

Обратная связь — отдельная страница `/feedback`, кнопка в меню настроек.

**БД**: `feedback_messages(id, userId, username, subject, message, createdAt, read)`.

**Роуты**:
- `POST /api/feedback` — публичный, через `app.use('/api', feedbackRoutes)` (нужен authMiddleware для userId)
- `GET /api/admin/feedback` — админский, через `app.use('/api/admin', authMiddleware, requireAdmin, adminFeedbackRouter)`
- `POST /api/admin/feedback/read` — отметить прочитанным

**Клиент**: `FeedbackPage.tsx` с BackButton, форма (тема + сообщение), кнопка в Header.tsx выпадающем меню.

**Админка**: вкладка «Обращения» в AdminPanel, `AdminFeedback.tsx` с пагинацией и кнопкой «Прочитано».

**Питфол**: админские роуты НЕ регистрировать через `app.use('/api', router)` — тогда `req.userRole` не будет установлен authMiddleware. Только через `app.use('/api/admin', authMiddleware, requireAdmin, router)`.

## Craft: Upgrade Stone Disassembly

Эндпоинт `POST /craft/disassemble` — разбор камня улучшения в материал:

```ts
router.post('/craft/disassemble', (req, res) => {
    const { itemId } = req.body;
    // Найти камень в инвентаре: isCraftItem(i) && i.itemType === 'upgrade'
    // Найти материал той же редкости: WHERE c.rarity_id = ? AND c.type = 'craft'
    // Списать камень (count-1 или splice)
    // Добавить материал (stack merge)
    // UPDATE users SET inventory
});
```

На клиенте: камни перетаскиваются в крафт-слоты (как предметы) и разбираются той же кнопкой «Разобрать». Слоты разрешают upgrade-камни: `isCraftItem(item) && item.itemType !== 'upgrade'` — только upgrade проходит, остальные craft-итемы блокируются для материалов/рецептов.

Кнопка «Разобрать» обрабатывает оба типа:
- `!isCraftItem(s)` → `salvageItems()` (обычные предметы)
- `isCraftItem(s) && s.itemType === 'upgrade'` → `POST /craft/disassemble`

## Right Panel Dynamic Refresh

Компоненты правой панели (QuestsBlock, TournamentBanner) загружаются один раз при монтировании и не обновляются при изменении данных на сервере. Решение: polling через `setInterval`:

```ts
useEffect(() => {
    if (user) {
        load();
        const i = setInterval(load, 10000);
        return () => clearInterval(i);
    }
}, [user]);
```

Интервал 10 секунд. Применять ко всем компонентам правой панели, которые показывают динамические данные (квесты, турниры, etc).

**Затронутые компоненты**:
- `QuestsBlock.tsx` — `useEffect(() => { if (user) { loadQuests(); const i = setInterval(loadQuests, 10000); return () => clearInterval(i); } }, [user]);`
- `TournamentBanner.tsx` — та же схема, `load()` обёрнут в именованную функцию, вызывается сразу + в интервале

## RightSidebar Overflow Clipping

Панель `RightSidebar` имела `overflow-y-auto` на внешнем `div`. Этот overflow обрезал заголовки карточек с `absolute -top-3` (как в TournamentBanner и QuestsBlock). Решение: перенести `overflow-y-auto` с внешнего div на внутренний wrapper:

```tsx
// Было (обрезает absolute-заголовки):
<div className="... overflow-y-auto p-3 pt-8 pb-10 ...">
    <div className="flex flex-col gap-4">
        <TournamentBanner />
    </div>
</div>

// Стало (overflow только на inner div):
<div className="... ...">
    <div className="flex flex-col gap-4 overflow-y-auto h-full p-3 pt-8 pb-10">
        <TournamentBanner />
    </div>
</div>
```

## Multiple Render Path Pitfall

Когда компонент имеет несколько `return`-веток (ранние возвраты для разных состояний), все они должны быть консистентны. Пример: `TournamentBanner` имел ТРИ пути рендеринга:
1. `if (loading) return (...)` — заголовок без onClick
2. `if (noTournaments) return (...)` — заголовок БЕЗ onClick (пропущен!)
3. Основной `return (...)` — заголовок с onClick

Только пути 1 и 3 были обновлены для кликабельности; путь 2 оставался некликабельным пока пользователь не указал на это. **Каждое изменение пропсов/поведения должно применяться ко ВСЕМ return-веткам компонента.**

## Related Skills

- `mmo-game-dev` — comprehensive guide for client patterns, guild system, chat indicators, guild tags, React pitfalls, and project conventions. Load this alongside game-server for full-stack tasks.

## Collections System

Предметы добавляются в коллекцию из инвентаря (удаляются). Каждый предмет даёт +1% к s,a,d,m,hp. Сеты коллекций управляются через админку.

**БД**: `collections(userId, itemName, slot, rarity_id)` — уникальный на (userId, itemName, slot).
`collection_sets` + `collection_set_items` для группировки предметов по сетам.

**API**:
- `GET /api/collections` — `{ items, sets }` с прогрессом каждого сета
- `POST /api/collections/add` — удаляет из инвентаря, добавляет в коллекцию
- `GET/POST/PUT/DELETE /api/admin/collection-sets` — CRUD сетов (админка)

**Бонус**: применяется в `character.ts` через `currentStats` с параметром `collectionBonus`. ВАЖНО: бонус должен применяться во ВСЕХ местах где вызывается `currentStats` — бой, турнир, гильдия, таверна, инвентарь, арена, профиль. Клиент НЕ должен дублировать бонус (сервер уже возвращает готовые статы).

**Клиент**: `CollectionsPage.tsx` — страница с сетами, прогресс-барами, модалкой выбора предмета и подтверждением. `BuffsBlock.tsx` — индикатор и процент коллекции. `StatsOverlay.tsx` — бонус на flip-стороне карточки.

Подробнее: [references/collections-system.md](references/collections-system.md).

## Vite HMR в WSL

WSL не поддерживает inotify на NTFS-дисках. Для автообновления добавить polling:

```ts
// vite.config.ts
server: {
  watch: {
    usePolling: true,
    interval: 500,
  },
}
```

## BuffsBlock Pattern

Блок усилений в левом сайдбаре: свёрнут по умолчанию, показывает сводку активных усилений. Разделы «Временные» (Комната, Напиток, Премиум) и «Постоянные» (Коллекция). Использовать `BuffRow` компонент с иконками. Прогресс-бар для коллекции.

## EXP/Levelup: Общая функция

Формула EXP дублировалась в character.ts, battle.ts, mobs.ts. Вынесена в `db/helpers.ts`:

```ts
export function expForLevel(level: number): number {
  return 10 * Math.pow(2, level - 1);
}
export const STAT_POINTS_PER_LEVEL = 5;
export function applyExp(db, userId, expGain, currentExp, currentLevel, currentStatPoints): {
  newExp, newLevel, levelsGained, newStatPoints
}
```

## Header Breadcrumbs

Карта имён в `breadcrumbMap` (Header.tsx). Добавлять новые страницы через `collections: 'Коллекция'` в эту карту — хлебные крошки строятся автоматически.

## Guild Wars

- `joinedAt <= war.declaredAt` для фильтрации участников
- Route ordering: `/guild/my`, `/guild/list`, `/guild/requests` ДО `/guild/:id`
- Guild chat: targetId=-guildId, цвет #2ecc71

## Related Skills

After every deploy, verify server health quickly:

```bash
# Check server is running
ssh root@194.226.142.237 'curl -s http://127.0.0.1:3001/api/time'

# Check PM2 stability (uptime growing, restarts not climbing)
ssh root@194.226.142.237 'pm2 list'

# If ↺ counter is climbing → crash loop:
ssh root@194.226.142.237 'pm2 stop game-server && pm2 start game-server'
```

## PG Table Name Mismatch: `tournament` vs `tournaments`

SQLite code uses `tournaments` (with 's') throughout. PG schema had `tournament`. If queries fail with `relation "tournaments" does not exist`, rename the PG table:

```sql
ALTER TABLE tournament RENAME TO tournaments;
```

And update `schema.ts` to use `tournaments` for future deployments.

## PG `login_logs.username` NOT NULL Crash

Guest registration inserts into `login_logs` without a `username` field: `INSERT INTO login_logs (userId, ip) VALUES (?, ?)`. PG schema had `username TEXT NOT NULL` → server crashes on guest registration.

Fix: `ALTER TABLE login_logs ALTER COLUMN username DROP NOT NULL` and update `schema.ts` to `username TEXT` (nullable).

## System User (id=0)

В таблице `users` создан системный пользователь `id=0, username='system'` для автосообщений (турниры, чат). Миграция: `db.prepare('INSERT OR IGNORE INTO users (id, username, passwordHash, currentHp) VALUES (?, ?, ?, ?)').run(0, 'system', 'system', 100)`.

**Питфолы**:
- Системный пользователь НЕ должен попадать в рейтинг: `WHERE id > 0` в `/api/rating`
- НЕ должен быть выбран противником на арене: `AND id > 0` в `/api/battle` (подбор случайного противника)
- `passwordHash` — NOT NULL без DEFAULT, обязательно включать в INSERT. Без него INSERT OR IGNORE молча проваливается (0 changes).
- В чате отображается как «system». Турнирные уведомления (`senderId=0, targetId=null`) — FOREIGN KEY satisfied.

## WebSocket Broadcast из админских/системных эндпоинтов

Если админский эндпоинт вставляет сообщение в `chat_messages`, он должен отправить broadcast через WebSocket чтобы сообщение появилось сразу у всех онлайн-игроков (без обновления страницы).

**Паттерн**:
1. Экспортировать `broadcast` из `server/src/websocket.ts`:
```ts
export { broadcast };
```
2. В админском роуте импортировать и вызвать после INSERT:
```ts
import { broadcast } from '../websocket';

const info = db.prepare('INSERT INTO chat_messages (...) VALUES (...)').run(...);
const msg = {
    id: info.lastInsertRowid,
    senderId: 0,
    senderName: 'system',
    targetId: null,
    content,
    createdAt: new Date().toISOString(),
};
broadcast('message', { message: msg });
```

Формат `msg` должен совпадать с тем что возвращает обычный эндпоинт чата.

## Server Time (Global Context)

Для единого серверного времени на всём клиенте — `ServerTimeContext` (`client/src/contexts/ServerTimeContext.tsx`):

```tsx
// Провайдер:
// 1. При монтировании: fetch('/api/time') → получает { now: unix_ts }
// 2. Вычисляет offset = serverNow - localNow
// 3. Тикает каждую секунду: now = Date.now()/1000 + offset
// 4. Предоставляет { now } через контекст

export function useServerTime() {
    return useContext(ServerTimeContext);
}
```

Серверный эндпоинт `/api/time` должен быть ДО `authMiddleware` в `setupRoutes.ts`, иначе 401:

```ts
app.get('/api/time', (_req, res) => {
    res.json({ now: Math.floor(Date.now() / 1000) });
});
```

**Использование**:
- Часы в хедере: `new Date(serverNow * 1000).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' })`
- Таймер сброса квестов: `formatTime(Math.max(0, quests.resetAt - now))`
- Любой компонент: `const { now } = useServerTime()`

**Питфол**: `toLocaleTimeString` без `timeZone: 'UTC'` конвертирует в локальный пояс — часы показывают не серверное время. Сервер отдаёт Unix-timestamp (UTC), клиент должен отображать как UTC.

**Питфол**: при переходе с локального `Date.now()` на `useServerTime()` нужно удалить локальный `now` state и его `setInterval`, иначе дубликат переменной.

## UTC Time Formatting (Shared Utility)

Для консистентного отображения времени в хедере, чате и сводке — использовать общие функции из `client/src/utils/time.ts`:

```ts
export function formatGameTime(date: string | number | Date): string {
    const d = typeof date === 'string' && !date.endsWith('Z') && !date.includes('+') && !date.includes('T')
        ? new Date(date + 'Z')
        : new Date(date);
    const h = d.getUTCHours().toString().padStart(2, '0');
    const m = d.getUTCMinutes().toString().padStart(2, '0');
    return `${h}:${m}`;  // "14:10"
}

export function formatGameDateTime(date: string | number | Date): string {
    // Аналогично, возвращает "12.06 14:10"
}
```

**Ключевой момент**: `new Date("2026-06-12 14:10:34")` парсит строку как ЛОКАЛЬНОЕ время если нет 'Z' суффикса. Решение: если строка без 'Z'/'+'/'T' — добавляем 'Z' → `new Date(date + 'Z')`. Это гарантирует что время интерпретируется как UTC.

**Где использовать**:
- Header (часы): `formatGameTime(serverNow * 1000)`
- Chat (MessageList): `formatGameTime(dateStr)`
- History (сводка): `formatGameDateTime(date)`

Все три компонента должны использовать одну и ту же функцию — тогда время везде совпадает. Подробнее: [references/time-formatting.md](references/time-formatting.md).

## GuildTag Component

`client/src/components/GuildTag.tsx`:
```tsx
export default function GuildTag({ guildName, guildId, hideNoGuild }) {
    if (!guildName) return hideNoGuild ? null : <span className=\"text-[0.6rem] text-muted\">[Без гильдии]</span>;
    const short = guildName.length > 10 ? guildName.slice(0, 10) + '…' : guildName;
    return <span onClick={...} className=\"text-[0.6rem] text-[#2ecc71] px-1 cursor-pointer\" title={guildName}>[{short}]</span>;
}
```
- Обрезка длинных названий до 10 символов (полное в `title`) — предотвращает расширение карточек
- Цвет `#2ecc71`, без фона (зелёный фон убран — перегружает вёрстку)
- `hideNoGuild` — для монстров и неперсонажных карточек
- При клике переходит на `/guild/:id`

## Rating: 4-Column Layout

Рейтинг игроков (RatingBlock на главной и RatingPage): 4 колонки с пропорциями 4/4/2/1 (36%/36%/19%/9%):
- Имя (truncate)
- Гильдия (GuildTag)
- Титул (icon + name)
- Очки (elo)

Использовать `style={{ width: '36%' }}` вместо Tailwind `w-4/11`. `items-center` для вертикального выравнивания.
