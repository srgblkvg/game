# Battle Formulas (2026-06)

## Base stat contribution
All chance formulas use `X / (X + 500)` for base stat contribution (was X/(X+50), then X/(X+150), then X/(X+300)).
- Crit: `min(0.8, M/(M+500) + extraCrit/300)`
- Dodge: `max(0, A/(A+500) * (1 - atkM/(atkM+100)) + min(0.5, extraDodge/300))`
- Block: `min(1, D/(D+500) + extraFullBlock/300)`

## Extra stats
All extra stats (crit, dodge, counter, fullBlock) divide by **300** (0.33% per point).
- Was: crit/dodge/counter ÷ 200 (0.5%), fullBlock ÷ 100 (1%)
- Changed: all ÷ 300 (0.33%)

## Damage formula
`rollDamage(S, level)` — mixed distribution:
- 1% chance: damage = level (minimum)
- 98% chance: triangular distribution centered at `level + 0.7*(S-level)` (most common)
- 1% chance: damage = S (maximum)

Replaced old formula: `S > level ? random(level, S) : S`

## currentStats
Now returns `drinks` and `collection` fields:
```typescript
return {
    ...st, hp,
    bonuses: {...},
    extra: {...},
    drinks: drinkBonuses || { s:0, a:0, d:0, m:0 },
    collection: collectionBonus || 0,
};
```

## async pitfall: isCraftItem
`async function isCraftItem()` returns a Promise which is always truthy in boolean checks.
Fix: remove `async` from functions that don't await anything.
Pattern: `function isCraftItem(item: any): boolean { return item?.type === 'material' || item?.type === 'craft_item'; }`

## DB convention
Always use `?` placeholders in SQL (db wrapper converts to $1, $2 via pgParams).
Never use `$1` directly — it breaks `pgLowerIdentifiers` pipeline.
