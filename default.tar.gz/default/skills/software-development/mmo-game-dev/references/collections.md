# Collections System

## Architecture

- **Table `collections`**: userId, itemName, slot, rarity_id — tracks collected items per user
- **Table `collection_sets`**: id, name, description, bonus_percent, sort_order — admin-defined sets
- **Table `collection_set_items`**: set_id, item_name, slot — items belonging to each set

## API

- `GET /api/collections` — returns `{ items, sets }` with per-set progress (collectedCount/totalItems, completed)
- `POST /api/collections/add` — removes item from inventory, adds to collections. Validates uniqueness.
- `GET/POST/PUT/DELETE /api/admin/collection-sets` — CRUD for admins

## Bonus Application

Each collected item gives **+1%** to s, a, d, m, hp (not per-set — per item). 189 items total, max +189%.

Applied in `server/src/routes/character.ts` (lines ~80-89) and in `client/src/utils/stats.ts` (calculateStats). Bonus must be applied in **both** server and client — server for actual stats in battles, client for display.

### Pitfall: Double Bonus

If both server AND client apply the bonus independently AND the client uses server-returned stats as input, the bonus gets doubled. Symptoms: HP showing 102/100 or similar.

**Fix**: Server applies bonus to `stats.*` in character/me response. Client `calculateStats` also applies it. They don't feed into each other — client uses `character.baseStats + equipment` as input, not `character.stats`. So both need to apply it, but they must use the same multiplier.

## All currentStats Calls (server)

Every call to `currentStats()` must include collectionBonus. These were all fixed:

| File | Lines | Status |
|------|-------|--------|
| character.ts | ~78 | ✅ uses applyExp style |
| battle.ts | ~49, ~67, ~78, ~157 | ✅ |
| mobs.ts | ~71 | ✅ |
| tournament.ts | ~121, ~131 | ✅ |
| tavern.ts | ~51, ~84 | ✅ |
| guild.ts | ~867-868 | ✅ |
| arena.ts | ~37, ~102 | ✅ |
| users.ts | ~31 | ✅ |

## All calculateStats Calls (client)

| File | Status |
|------|--------|
| LeftSidebar.tsx | ✅ passes collectionCount |
| ArenaPage.tsx | ✅ |
| BestiaryPage.tsx (×2) | ✅ |

## BuffsBlock

- Shows green dot on collapsed header if inventory has addable items (not in collection, not equipped)
- Shows progress bar + percent for collection completion
- Two useEffect calls: one for indicator (depends on inventory/equipment), one for percent (mount only)
- Navigates to /collections on click

## Performance Notes

- `GET /api/collections` uses a single JOIN instead of N+1 queries per set
- Collection count queries: `SELECT COUNT(*) FROM collections WHERE userId = ?` — indexed via `idx_collections_user`
- In battle.ts, `dCollCnt` is reused instead of querying twice for defender
