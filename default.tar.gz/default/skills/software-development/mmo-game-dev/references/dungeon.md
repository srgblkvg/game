# Dungeon System

## DB
- `dungeon_runs`: one row per user (ON CONFLICT upsert), tracks currentFloor, checkpointFloor, playerHp, playerMaxHp, skills, startedAt, dailyRuns, dailyRunDate
- `skill_pages`: userId + skillId unique, count of pages
- `skill_levels`: userId + skillId unique, level
- Enemy data from `mobs` table: `SELECT name, background, hp, atk FROM mobs`

## Server: Combat Engine
- In-memory `activeRuns: Map<userId, DungeonRun>`
- `TICK_MS = 100` for smooth progress bars
- Auto-attack: `autoTimer += TICK_MS/1000`, fires when `>= 1/attackSpeed`
- Enemy attack: each enemy has `_attackInterval` (random 0.5-2s), fires when `_lastAttack >= interval`
- Rage: +5 per auto-attack (+2 with Battle Cry), +3 on taking damage, decay 0.5/s in combat, 5/s out of combat

## Player Stats
- `buildPlayerStats(user, 'pve')` — SELECT must include `id, level, inventory, equipment, equipment_1/2/3, active_equip_slot, drinkuntil, activedrink`
- Stats use `s, a, d, m` (not str/agi/def/mag)
- HP = `stats.hp` from buildPlayerStats (includes collection + guild bonuses)

## Weapons & Attack Speed
- Speed: `WEAPON_SPEED[rarity] / (1 + weaponStrBonus * 0.005)`, min 0.3
- `equippedWeaponStr` = weapon's `bonuses.s` (not total player STR!)
- Speed values: 0:0.5, 1:0.7, 2:0.85, 3:1.05, 4:1.3, 5:1.55, 6:1.8

## Skills — SINGLE SOURCE OF TRUTH
- Server defines skills in `/dungeon.ts` SKILLS[] array with `icon` field
- Client fetches from `/api/dungeon/skills` — **NEVER hardcode skill lists on client**
- Base skills (unlocked at level 1): Charge (7), Sweep (2), Battle Cry (3) — configurable via `BASE_SKILL_IDS` constant
- Upgrade cost: pages = 10 + level×15, silver = 1000 × 3^level
- Skill switch endpoint: POST `/api/character/switch-equip`, then call `fetchCharacter()` to reload

## Enemies
- Fetched from `mobs` table, cached once (`_mobCache`)
- Scaled by floor: HP × (1 + floor×0.3), boss ×3
- Each enemy gets random `_attackInterval` in `generateEnemyFromMob`
- Enemy avatars: real images from `mobs.background`, fallback to colored letter

## Checkpoints
- Saved at boss floors (5, 10, 15...): saves `floor + 1`
- Client shows checkpoints 1, 6, 11, 16... (floor 1 always available)
- Exit from post-combat room returns to status page (no separate summary screen)

## Client: DungeonPage.tsx
- State polling: 100ms for combat data
- Three views: Status (floor select), Prepare (skills + CharacterCard), Combat
- Post-combat: auto-loot (search corpses with progress bar), show floor loot + total loot
- Progress bars: CSS `transition-all duration-200 ease-linear` for smoothness
- CharacterCard: always pass `equipSets` object (even empty `{}`), use `key={activeSlot}` for re-mount
- Rage display: `Math.round(rage)` — integer only

## Cooldown reset for testing
```bash
ssh root@VPS "sudo -u postgres psql -d game -c \"DELETE FROM dungeon_runs WHERE userId = N\"; pm2 restart game-server"
```

## Common Pitfalls
- `buildPlayerStats` needs `userRow.id` — must include `id` in SELECT
- `generateFloorEnemies` is async — must `await`
- `parseEq(null)` returns `{}` which is truthy — check `Object.keys().length` not truthiness
- Equip slot: `equipment1` in JS (camelRows converts `equipment_1`), `equipment_1` in SQL
- CharacterCard is memo'd — `key={activeSlot}` forces re-mount on switch
- Client must NOT duplicate server data (skills, configs) — fetch from API
