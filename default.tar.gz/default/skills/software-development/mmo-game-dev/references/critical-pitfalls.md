# Critical Pitfalls

## JWT Auth: Missing role/username
When adding new auth methods (VK Bridge, OAuth), the JWT token MUST include `{ userId, role, username }`. The client's `parseUserFromToken` in `AuthContext.tsx` parses these fields. If missing:
- `username: ''` → header shows no name, but renders (user not null)
- `role: undefined` → all route guards `user?.role === 'player'` FAIL silently
- Result: user appears logged in, main page shows, but NO navigation works, NO sidebar/chat, Header renders but empty

The AuthContext `useEffect` on token change re-parses JWT and overwrites any user object set by `loginUser()`. Always include all three fields in every JWT sign call.

## Date Format Mismatch: NOW() vs toISOString()

Postgres `NOW()` produces `2026-06-29 00:39:02.953069+00` (space separator), while JavaScript `new Date().toISOString()` produces `2026-06-29T00:40:59.936Z` (T separator). When filtering by date with string comparison (`createdat >= '...'`), the space vs T difference causes false negatives — the space character (0x20) sorts BEFORE 'T' (0x54) in ASCII.

**Fix:** Always use `new Date().toISOString()` for `createdat` values. Never mix `NOW()` with ISO strings in the same column.

**Affected:** guild_treasury_log deposit insert (was `NOW()`, tax entries used `toISOString()` → "today" filter missed deposits).

## JSX Ternary Brace Loss During Patch

When using `patch` to remove a trailing Card from a long JSX line, the closing `}` of a ternary expression (`condition ? <A/> : <B/>}`) is on the same line and easily dropped. Rolldown gives cryptic error "Unterminated regular expression" near `</Card>`.

**Before patching long JSX lines:** verify the closing `}` count matches. After patching, `grep` for `}</div>` vs `}</div>}` to catch missing braces.

## VK Bridge: access_token IP-bound
`VKWebAppGetAuthToken` returns a token that can only be used from the client's IP. Sending it to the server for validation fails with "access_token was given to another ip address". Use launch parameters (`vk_user_id` + `sign` from URL) instead for server-side auth.

## VK Launch Parameter Signature
Multiple algorithms attempted (MD5, SHA256, HMAC) — none matched VK's signature. Temporarily bypassed. Revisit when VK docs clarify the correct algorithm for game launch parameters.

## PvE Battle Steps Missing `actor` Field — All Animations Play on Mob
In `server/src/routes/mobs.ts`, the PvE battle loop (`/mob/attack`) generates steps WITHOUT the `actor` field. The client's `executeStep` (both in `useBattleLogic.ts` and `BestiaryPage.tsx`) uses `step.actor === 'attacker' ? 'left' : 'right'` to determine which fighter gets the animation. Without `actor`, the condition always resolves to `'right'` (mob side).

**Fix**: Add `actor: 'attacker'` to all steps during player's turn, and `actor: 'defender'` to all steps during mob's turn:
```
// Player attacks
addStep({ type: 'attack', actor: 'attacker', message: 'Вы атакуете!' });
addStep({ type: 'crit', actor: 'attacker', message: 'Крит!' });
// Mob attacks
addStep({ type: 'attack', actor: 'defender', message: '${mob.name} атакует!' });
addStep({ type: 'crit', actor: 'defender', message: 'Крит!' });
```

**Symptoms**: In PvE battles, all animations (attack swing, crit, dodge) appear on the mob. Player's fighter just stands still.

## Shop Daily Purchase Limit
Shop purchases are limited to 10 per player per day. Uses `shop_purchase_log` table with daily count check. Client displays counter «Куплено сегодня: X/10». Add to `server/src/routes/shop.ts`:

```ts
// Check limit before purchase
const todayCount = (await db.one(
    "SELECT COUNT(*) as cnt FROM shop_purchase_log WHERE user_id = ? AND created_at >= CURRENT_DATE",
    [userId]
) as any).cnt;
if (todayCount >= 10) return res.status(400).json({ error: 'Лимит покупок в магазине (10 в сутки)' });

// Log after purchase
db.run('INSERT INTO shop_purchase_log (user_id, item_id) VALUES (?, ?)', [userId, itemId]).catch(() => {});
```

Table: `CREATE TABLE shop_purchase_log (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, item_id INTEGER, created_at TIMESTAMPTZ DEFAULT NOW());`

## PvE: useEffect stopAuto Prevents Loot Notifications

In `BestiaryPage.tsx`, the battle animation auto-play uses an interval timer (`startAuto`/`stopAuto`). The cleanup function `applyPending()` (shows loot via `showAcquire`, updates character) is called only inside `nextStep()` when `next >= steps.length`. However, a `useEffect` watching `currentStep` calls `stopAuto()` when `currentStep >= steps.length - 1` (last step reached):

```tsx
// BAD — stops auto-play early, applyPending() never fires
useEffect(() => {
  if (currentStep >= battleSteps.length - 1 && battleSteps.length > 0) stopAuto();
}, [currentStep, battleSteps.length, stopAuto]);
```

This clears the interval BEFORE `nextStep` gets called for `next = steps.length`, so `applyPending()` never runs. The user sees no loot notifications after watching the full animation. Only skip (`handleSkip`) worked because it calls `applyPending()` explicitly.

**Fix**: call `applyPending()` in the same useEffect:
```tsx
useEffect(() => {
  if (currentStep >= battleSteps.length - 1 && battleSteps.length > 0) {
    stopAuto();
    applyPending();
  }
}, [currentStep, battleSteps.length, stopAuto, applyPending]);
```

`applyPending()` is idempotent (clears refs after first use), so double-call from skip path is safe.

## Battle Functions Are Private — Must Export for Reuse

The battle engine in `server/src/game/battle.ts` defines functions like `dodgeChance`, `critChance`, `critMult`, `blockChance`, `blockReduction`, `counterChance`, `stunChance`, `rollDamage` as module-private (no `export`). They're used internally by `runBattle()` and `runTurn()`. 

When creating a new battle mode (massacre, guild war, etc.) that needs to call these formulas directly, you MUST add `export` to each function used. Otherwise TypeScript reports:

```
Module '"../game/battle"' declares 'dodgeChance' locally, but it is not exported.
```

**Fix**: Add `export` to each battle formula function in `battle.ts`:
```ts
export function dodgeChance(...)
export function critChance(...)
export function critMult(...)
export function blockChance(...)
export function blockReduction(...)
export function counterChance(...)
export function stunChance(...)
export function rollDamage(...)
```

Also, `CharStats` is imported from `battle.ts` but actually defined in `stats.ts`. Import it from the source module:
```ts
import { currentStats, CharStats } from './stats';
// NOT: import { CharStats } from './battle';
```

## Async Battle: Store Full Stats Snapshot as JSON

When building a battle that doesn't run synchronously during the HTTP request (massacre, tournament, guild war), you need stats at battle time but the player's equipment/drinks/guild may have changed since they joined. **Snapshot all stats at join time** into a JSON column:

```sql
ALTER TABLE massacre_participants ADD COLUMN stats_json TEXT DEFAULT '{}';
```

At join time, compute full stats with `buildPlayerStats()` and store:
```ts
const stats = await buildPlayerStats(user, 'arena');
await db.run(
  `INSERT INTO massacre_participants (..., stats_json) VALUES (..., ?)`,
  [JSON.stringify(stats)]
);
```

At battle time, parse and use directly — no recalculation:
```ts
const stats: CharStats = JSON.parse(p.stats_json || '{}');
const atkStats = s.stats;  // use directly, NOT currentStats()
```

This preserves ALL bonuses: equipment, drinks, collection, guild buildings. The stored `stats.s/a/d/m` are the final computed values including everything. Extra stats (dodge/crit/counter/fullBlock) are also in the JSON.

Do NOT pass the snapshot through `currentStats()` again — that would double-apply the base values.

## db.query Breaks JOIN and Boolean WHERE Clauses — Use db.raw

`db.query()` applies `pgLowerIdentifiers()` which runs a regex on the SQL to lowercase camelCase identifiers. This can corrupt JOIN conditions and boolean comparisons:

- `mp.alive = TRUE` can be mangled, returning 0 rows even when data exists
- Complex JOINs with column aliases may produce wrong column names

**Fix**: Use `db.raw()` with `$1`-style placeholders instead of `db.query()` with `?`:
```ts
const rawResult = await db.raw(
    `SELECT mp.*, u.username FROM massacre_participants mp 
     JOIN users u ON mp.user_id = u.id 
     WHERE mp.event_id = $1 AND mp.alive = TRUE`,
    [eventId]
);
const participants = rawResult.rows as any[];
```
NOTE: `db.raw` returns `{ rows }` (PG Result object), NOT an array. Access `.rows`.

## PG CamelCase Converter: Both Keys Preserved, Client Must Pick One

`camelRows()` in `db/index.ts` adds camelCase variants of column names BUT keeps the originals. For a column `participant_count`, the row will have BOTH `participant_count` AND `participant_Count`. The converter capitalizes the matched suffix but keeps the underscore.

**Client must use the snake_case original** — it's always present:
```ts
const pc = data.participant_count ?? 0;  // ✓ works
// NOT: data.participantCount (doesn't exist)
//       data.participant_Count (may exist but fragile)
```

The converter regex `/(hash|hp|id|...|count|...|name)$/i` matches suffixes and capitalizes first letter. `participant_count` → `participant_Count`. `winner_name` → `winner_Name`.

### Adding New Columns: Must Add Explicit `.replace()` Rule

When you add a NEW column to the users table (e.g., `tutorial_completed`), the suffix regex creates an INCORRECT camelCase variant with an underscore: `tutorial_completed` → `tutorial_Completed` (not `tutorialCompleted`). The generic rule `if (cc !== key) row[cc] = row[key]` creates `row.tutorial_Completed`.

If your route code uses `user.tutorialCompleted` (without underscore), it gets `undefined` — the flag is never read.

**Fix**: Add an explicit `.replace()` rule in `db/index.ts` for EVERY new column with an underscore:
```ts
.replace(/^tutorial_completed$/i, 'tutorialCompleted')
```

**Affects**: Any new column added via `ALTER TABLE ... ADD COLUMN`. The suffix list in the regex only handles `completed` by capitalizing the C — it does NOT remove the underscore. You must add a specific rule for each new snake_case column that needs camelCase access in TypeScript.

## HistoryPage Tab Rendering: Missing `tab===` Check Falls Through to Message Renderer

The HistoryPage render has a chained ternary for each tab type. If a new tab is added but no `tab==='<name>'` check is added, it falls through to the DEFAULT renderer (which renders entries as private messages with chat icon, pink text, empty fields).

```tsx
// BAD — no 'massacre' check, falls through to message renderer
tab==='all' ? paginatedData.map(entry => renderEntry(entry)) :
tab==='battles' ? ... :
...
paginatedData.map(m => renderMessageRow(m))  // ← massacre hits this!
```

**Fix**: Always add an explicit `tab==='<name>'` check before the default fallthrough:
```tsx
tab==='messages' ? paginatedData.map(m => renderMessageRow(m)) :
tab==='massacre' ? paginatedData.map(entry => renderEntry(entry)) :
null  // ← explicit null for unknown tabs
```

## DB Delete Without WS Broadcast — Client State Gets Stale

When you `DELETE` rows from the database (e.g., removing auction chat messages when a lot is sold), the **server-side change does NOT automatically propagate to connected clients**. Clients hold message state in React `useState` + `localStorage`, and they only update when they receive a WS message.

**Fix**: Always pair a DB DELETE with a WS broadcast so clients can update their in-memory state:

```ts
// Server: delete + broadcast
await db.run('DELETE FROM chat_messages WHERE item_data LIKE ?', [`%\"lotId\":${lotId}%`]);
broadcast('auction_message_removed', { lotId });

// Client (ChatContext.tsx): listen and filter
case 'auction_message_removed': {
  const lotId = data.lotId;
  if (lotId) {
    setMessages(p => p.filter(m => m.item?.lotId !== lotId));
  }
  break;
}
```

**Real case**: Auction lot was bought out → server deleted chat messages from DB → but client still showed the old messages because no WS event was sent. User saw "сообщение с неактуальным лотом никуда не делось". Added `broadcast('auction_message_removed', { lotId })` after every `DELETE FROM chat_messages` — messages disappear instantly for all online clients.

**Affects**: Any DELETE/UPDATE that should be reflected in real-time across connected clients — chat messages, notifications, auction state, guild events.

## React Notification Data Must Be Stringified — Object Causes Crash

React cannot render objects as children. If `pushNotification` sends `data` as an object `{eventId, participantCount, ...}`, React throws error #31 when the NotificationToast tries to render `{t.data}`.

**Fix**: Stringify the data:
```ts
pushNotification(userId, {
    type: 'battle_result',
    message: 'Резня завершена! ...',
    data: JSON.stringify({ eventId, participantCount, ... }),
});
```

In the client, parse it back:
```tsx
const d = typeof t.data === 'string' ? JSON.parse(t.data) : t.data;
if (d?.path) window.location.href = d.path;
```

## Guild Creation: Two Separate Code Paths — Check BOTH

Guilds can be created through TWO different endpoints:

1. `/api/guild/create` (GuildPage at `/guild`) — creates real guilds in `guilds` table
2. `/api/orders/create` (OrdersPage at `/orders`, since removed) — creates orders/ордены in `orders` table

**Pitfall**: When adding a money check, price change, or validation to guild creation, you MUST check BOTH endpoints. The user may be creating through a page you didn't look at.

**Real case**: User reported "можно создать гильдию с балансом 20". Price was changed from 5000→10000 on `/orders/create` but `/guild/create` had NO money check at all and still showed "1000 серебра" on the button. The GuildPage form was the actual path users take, and it had a completely different (and missing) validation.

**Fix pattern**: When changing any shared feature (guild creation, auction listing, etc.):
1. `grep` for ALL routes/endpoints that handle the feature
2. Check both client pages that render the feature
3. Verify on BOTH paths after deploying

## Guild Tax: Must Be Called in EVERY Income Source — Not Just PvE/Jobs

`collectGuildTax()` in `db/helpers.ts` applies the guild's `taxRate` to income and sends the tax to the treasury. It was originally only called in `mobs.ts` (PvE) and `character.ts` (jobs). **Every new income source must call it**, or the tax silently doesn't apply:

| Source | File | Fixed? |
|--------|------|--------|
| PvE (мобы) | `mobs.ts` | ✓ (was already there) |
| Jobs (работы) | `character.ts` | ✓ (was already there) |
| PvP (арена) | `battle.ts` | ✗ → added `tax_pvp` |
| Quests (квесты) | `quests.ts` | ✗ → added `tax_quest` |
| Tournament prizes | `tournament.ts` | ✗ (uses `addMoney` directly) |
| Auction sales | `auction.ts` | ✗ (direct money update) |
| Casino winnings | `casino.ts` | ✗ (direct money update) |
| Massacre prizes | `massacre.ts` | ✗ (direct money update) |
| Daily salary | `salary.ts` | ✗ (direct money update) |

**Pattern**: `const net = await collectGuildTax(userId, grossIncome, 'tax_<source>');` then use `net` instead of `grossIncome` in the `UPDATE users SET money = money + ?`.

**Also update the response**: the client shows `rewardMoney`/`moneyGained` to the user — it should show the **after-tax** amount, not the gross. Otherwise the user sees "получено 100" but their balance only went up by 50 (with 50% tax).

**Real case**: User set 50% tax, went to PvP battle, got full amount — tax wasn't applied to PvP at all. Then quests also ignored tax. Fix: added `collectGuildTax` to `battle.ts` and `quests.ts`.

## Never Fabricate Game Mechanics — Always Read Actual Code

When writing documentation (Wiki, guides, descriptions), NEVER invent numbers, rarities, room names, prices, or mechanics. Every claim must be verified against actual code:

- **Rarities**: Read `server/src/database/seed.ts` — INSERT_RARITY values (Хлам → Мифический, 7 total, no "Божественный")
- **Tavern rooms**: Read `server/src/routes/tavern.ts` — rooms object (Чулан×3, Койка×10, Аппартаменты×50)
- **Drink duration**: Read the code — `3600` seconds = 1 hour, not 2
- **Craft upgrade**: Read `server/src/routes/craft.ts` — камень + предмет → +1 уровень, not "3 одинаковых → 1"
- **Equipment slots**: Read `client/src/utils/itemUtils.ts` — 10 slots, not 7
- **Guild buildings**: Read `server/src/game/guildBuildings.ts` — +5 per level, not +5%
- **Premium bonus**: Read `server/src/routes/character.ts` — cooldown 150s vs 300s, HP regen ×3 only without active room
- **Order/заказы description**: Read the actual page code — OrdersPage.tsx was a guild listing, not "биржевые заявки"

**User reaction to fabrication**: "откуда ты это взял?", "ты заебал", "с этого всегда надо начинать". The user will catch every fabricated detail.

**Correct workflow for documentation**:
1. Read the actual source files (seed.ts, route handlers, config objects)
2. Extract exact values, names, and mechanics
3. Write documentation from verified facts only
4. Cross-reference with client-side definitions for labels/names

## Deploy After Every Commit — Client AND Server

The user expects changes to be deployed immediately after commit. Not deploying = "а ты деплой не делаешь".

**Correct sequence**:
1. `git add` + `git commit` + `git push`
2. `sshpass rsync` client `dist/` to VPS
3. If server changed: `sshpass rsync` server `dist/` + `pm2 restart game-server`

Bundle the deploy into the same terminal command as commit when possible. Never say "deploy later" — deploy NOW.

`GET /chat/recent` uses `JOIN users u ON m.senderId = u.id`. Auction and system messages have `senderId = 0` (system user), but user id 0 doesn't exist in the `users` table. INNER JOIN silently drops all these rows.

**Symptoms**: Auction lot messages disappear from chat after page reload, even though the lot still exists on the auction page.

**Fix**: Use `LEFT JOIN users u ON m.senderId = u.id` in both `/chat/recent` and `/chat/pm/:userId` queries. `senderName` will be `null` for system messages.

**Client-side crash**: After the LEFT JOIN fix, system messages arrive with `senderName = null`. `truncate()` in `MessageList.tsx` calls `nick.length` on null → crash `Cannot read properties of null (reading 'length')`. Fix both sides:
```tsx
// MessageList.tsx
function truncate(nick: string | null): string {
    if (!nick) return 'Система';
    return nick.length > MAX_NICK_LENGTH ? nick.slice(0, MAX_NICK_LENGTH) + '…' : nick;
}
// Also disable nick click for null senderName
onClick={isOwn || !firstMsg.senderName ? undefined : (e) => onNickClick(e, firstMsg.senderName!, false)}
```

## UI: Hardcoded Dark Backgrounds Break Light Theme

Auction chat cards used `bg-[#2a2010] border border-[#4a3820]` — hardcoded dark amber. In light theme, text colors switch to dark via CSS variables, but the background stays dark → unreadable.

**Fix**: Always use theme-aware CSS variables: `bg-[var(--color-bg-input)] border border-[var(--color-border-light)]`.

**Affected patterns**: Any hardcoded `bg-[#...]` in components that should support both themes. Check `MessageList.tsx`, `ChatPanel.tsx`, and any card with dark background.

## API Data Leak: SELECT * Exposes Internal Columns to Public Endpoints

When using `SELECT g.*` (or any `SELECT *`) in a public API endpoint, every column in the table is returned to all clients — including internal/sensitive data that should only be visible to authorized users.

**Real case**: `/guild/list` and `/guild/:id` used `SELECT g.* FROM guilds g` which returned the `treasury` column. The GuildRatingPage then displayed `Казна: {g.treasury} серебра` — every player could see every guild's treasury balance. Additionally, the column leaked through the API response even when the client didn't display it.

**Fix pattern**:
1. **Server**: Replace `SELECT *` with explicit column lists. Only include columns the endpoint's audience should see:
   ```sql
   -- BEFORE: leaks treasury, taxRate, createdAt
   SELECT g.*, u.username as leaderName FROM guilds g JOIN users u ...
   
   -- AFTER: explicit columns, no sensitive data
   SELECT g.id, g.name, g.description, g.image, g.joinType, g.level, g.exp, g.leaderId, u.username as leaderName FROM guilds g JOIN users u ...
   ```
2. **Client**: Remove any UI that displays leaked data, even after the server is fixed (for defense in depth).
3. **Audit**: Check ALL list/detail endpoints for `SELECT *` on tables with sensitive columns. Guilds had `treasury`, `taxRate` — other tables may have `email`, `password_hash`, `oauthProvider`, etc.

**Affected endpoints fixed**: `/guild/list`, `/guild/:id`. Internal guild data (treasury, tax rate) is now only accessible via `/guild/my` (requires guild membership).

## Image Upload: Always Validate data:image/ Prefix on Server

When accepting image uploads via data URIs (guild emblem, avatar, etc.), the server MUST validate that the data starts with `data:image/`. Client-side `<input type="file" accept="image/*">` can be bypassed with direct API calls (curl/postman).

**Real case**: Guild Fortune had an HTML challenge page (Akamai/Magnific captcha) stored as `data:text/html;base64,...` in the `image` column. Someone pasted a Freepik URL somewhere, the server fetched it, hit bot protection, and saved the challenge HTML instead of an image.

**Fix**: Add server-side prefix check:
```ts
if (image !== '' && !String(image).startsWith('data:image/')) {
    return res.status(400).json({ error: 'Изображение должно быть в формате data:image/...' });
}
```

**Affects**: Any endpoint accepting `image` as a data URI — guild settings, avatar uploads, admin image uploads. Client-side validation via `<input accept="image/*">` is not enough.

## Tournament "Registration Closing" Messages — Check BOTH Chat AND API Warnings

When user says "убрать сообщения о регистрации в турнирах", there are TWO separate mechanisms that produce them:

1. **Chat messages** — `INSERT INTO chat_messages` with tournament text (removed earlier)
2. **API `warnings` field** — The `/tournament` endpoint returns a `warnings` array with tournaments closing within 5 min, displayed in `TournamentBanner.tsx` as orange warning blocks

Removing one doesn't automatically remove the other. After chat messages were removed, the user still saw warnings because the API `warnings` field was still active.

**Fix pattern**:
- Server: Remove `warnings` from `res.json()` in `routes/tournament.ts`
- Client: Remove `warnings` state, `setWarnings` call, and the `.map()` rendering block from `TournamentBanner.tsx`
- Check the API response shape — `warnings` is NOT a `chat_messages` insert, it's a field in the JSON response

**Real case**: User said "эти сообщения снова генерятся хотя вчера убирали их" — chat messages were removed, but API warnings weren't. The fix was in `routes/tournament.ts` (remove `warnings` query) and `TournamentBanner.tsx` (remove display).

## DB Default Change: Always Check Client for Hardcoded Values

When changing a DB column default (e.g., `ALTER TABLE massacre_events ALTER COLUMN entry_fee SET DEFAULT 10`), the server will use the new default for future INSERTs. But the CLIENT may have hardcoded the old value in multiple places:

**Real case**: Changed massacre `entry_fee` from 100→10 in DB. User still saw "Вход — 100" in UI. The MassacrePage had FIVE hardcoded `100`s:
- `character.money - 100` (optimistic balance update after join)
- `formatMoney(100)` in description text
- `character.money < 100` (disabled check on join button)
- `formatMoney(100)` on join button label
- `character.money < 100` (error message show condition)

**Fix pattern**:
1. `grep` the client code for the old value (e.g., `100`)
2. Replace with dynamic `state?.event?.entry_fee || <new_default>` 
3. One of the lines (the active event card) was ALREADY using `state!.event!.entry_fee` — the dynamic value was there but 5 other places weren't updated

**Rule**: After any DB default change, search the entire codebase for the old numeric value. The server will use the new default for new records, but clients often have the old value baked into JSX.

## Don't Recalculate on Client What Server Already Computes

The server already applies `applyHpRegen()` in `/character/me` and returns `currentHp` with regeneration factored in. The client was ALSO computing its own regeneration via `getRegenHp()` — double-counting HP and producing different values in Header, LeftSidebar, and battle pages depending on which time source each used.

**User feedback**: "на сервере есть текущее значение" / "просто тик серверный оставить, и на тике брать текущее значение из сервера"

**Rule**: When server already computes and returns a value, the client should display it as-is. Don't add a second layer of client-side computation. For live updates, use serverTick to distribute the server-computed value.

**Fix**: Remove all client-side `getRegenHp()` calls from components. Add `currentHp`/`lastHpUpdate` to serverTick batch query. Have GameContext compute `regenHp` ONCE centrally (from server-delivered `currentHp` + `lastHpUpdate` + `serverTime`). All components read `regenHp` from GameContext — single source of truth.

## db.run() Always Appends RETURNING id — Don't Add It Yourself

`db.run()` in `db/index.ts` detects INSERT statements and automatically appends `RETURNING id` to the query (line 140). If your SQL already has `RETURNING id`, the resulting query will have it TWICE — a syntax error. The catch block then falls back to a plain INSERT (no RETURNING), returning `lastInsertRowid: 0`.

**Fix**: Remove `RETURNING id` from your INSERT SQL — `db.run()` handles it.

**Also**: `db.run()` returns `{ changes, lastInsertRowid }` — the property is `lastInsertRowid`, NOT `lastID` or `id`. The name comes from `r.rows[0]?.id` (PG result).

```ts
// WRONG — double RETURNING id + wrong property name
const result = await db.run("INSERT INTO t (x) VALUES (?) RETURNING id", [v]);
const gameId = (result as any).lastID || (result as any).id;  // undefined!

// RIGHT — let db.run handle RETURNING
const result = await db.run("INSERT INTO t (x) VALUES (?)", [v]);
const gameId = result.lastInsertRowid;  // actual number
```

## Postgres Table Permissions: GRANT After Creating as postgres

When creating a new table on VPS via `sudo -u postgres psql`, the table is owned by `postgres` user. The game server connects as `game` user, which has NO permissions on the new table by default. All queries will fail with `permission denied`.

**Fix**: Immediately after CREATE TABLE, run:
```sql
GRANT ALL ON <table> TO game;
GRANT ALL ON <table>_id_seq TO game;
```

Use `sudo -u postgres psql game -c "..."` for both CREATE and GRANT.

## useToast() API: showToast, Not .error()

`useToast()` from `ToastContext.tsx` returns `{ showToast }` — a single function with signature `showToast(message: string, type?: 'error'|'success'|'info'|'warning')`. It does NOT return separate `.error()`/.success() methods.

```tsx
// WRONG
const toast = useToast();
toast.error('Сообщение');  // toast.error is not a function

// RIGHT
const { showToast } = useToast();
showToast('Сообщение', 'error');
```

## Character Endpoint: /api/character/me, Not /api/character

The route is `router.get('/character/me', ...)` in `server/src/routes/character.ts`. There is no GET `/character` endpoint. Using `/api/character` returns 404.

```tsx
// WRONG
fetch('/api/character', { headers: getHeaders() })

// RIGHT
fetch('/api/character/me', { headers: getHeaders() })
```

## Tailwind dark: Prefix Does NOT Work — Use CSS Variables

This project uses CSS custom properties for theming, NOT Tailwind's `dark:` variant strategy. The `dark:` prefix requires a `dark` class on the root `<html>` element — this project does NOT set that class. Any `dark:text-white`, `dark:border-*` etc. are silently ignored. The element always gets the base (`text-black`, `border-gray-800` etc.) regardless of which theme the user selected.

**Fix**: Use project CSS variables which switch automatically via the theme:
```tsx
// WRONG — dark: does nothing
className="text-black dark:text-white border-black/30 dark:border-white/30"

// RIGHT — CSS variables switch with theme
className="bg-[var(--color-accent-primary)] text-[var(--color-text-primary)] border-[var(--color-border-light)]"
```

Key variables: `color-bg-primary`, `color-bg-secondary`, `color-bg-input`, `color-text-primary`, `color-text-secondary`, `color-text-muted`, `color-text-accent`, `color-accent-primary`, `color-accent-success`, `color-accent-danger`, `color-accent-info`, `color-accent-warning`, `color-border-light`, `color-border-default`.

## Arena Opponent Selection: /api/arena/opponent, NOT /api/battle

When adding level range, faction bonuses, or any opponent filtering, the arena has its OWN endpoint at `/api/arena/opponent` in `routes/arena.ts`. The battle route (`routes/battle.ts`) handles explicit and random attacks, but users primarily use the **arena page** with difficulty buttons (weak/equal/strong). Level filtering in arena.ts is in TWO places: saved opponent difficulty check AND opponent pool filter. Both use hardcoded ±2. Must update BOTH to use faction-based range.

**Real case**: Agent added level range (±4 for bandits) to battle.ts and rating.ts, but missed arena.ts entirely. User reported "только 6 и 7 попадаются" — the arena still used ±2. Always grep for ALL opponent selection endpoints when adding filters.

## Drop Table: selectedRarity Default 0 = Junk When Sum < 1 (2026-07-25)
Material loot table checks each rarity independently. If `loot_epic + loot_legendary + loot_mythic < 1`, unmatched rolls default to `selectedRarity = 0` (junk). High-end mobs drop junk materials.
**Fix**: Init `selectedRarity = -1`, skip drop when `< 0`.

## Отшельник 2pc Regen: String Pushed But Never Applied
`setBonuses.push('Отшельник: ...')` was in `currentStats()` but `hpRegen.ts` never checked. Fix: add `hermitRegen` flag to CharStats, pass to `applyHpRegen()`, double regenRate. Description corrected to "+100% реген HP (вне боя)".

## Set Items/Artifacts Sellable By Default (2026-07-25)
All items have `sellable = true`. Must disable for sets and artifacts: `UPDATE items SET sellable = false WHERE extra::jsonb ? 'set' OR rarity_id = 7`.

## Collections: Duplicate Keys Across Rarities (2026-07-25)
"Щупальцевые захваты" at rarity 2 and 6. Key `${name}|${slot}|${rarity_id}` needed. `collection_set_items` needs `rarity_id` column for JOIN.

## INSERT Race Condition — Use ON CONFLICT DO NOTHING

When using check-then-insert pattern (`SELECT ... → if no row → INSERT`), two concurrent requests can both see no row and both try INSERT. The second one hits `duplicate key violates unique constraint`.

**Fix**: Add `ON CONFLICT DO NOTHING` to INSERT statements in race-prone paths:
```sql
INSERT INTO player_guild_talents (userId, guildId, talentType, level, progress)
VALUES (?, ?, ?, ?, ?) ON CONFLICT DO NOTHING
```

**Affected paths**: guild talent upgrades (personal + guild), any INSERT that follows a SELECT-exists check. The error log shows `duplicate key value violates unique constraint "player_guild_talents_pkey"` — this is the signature of a check-then-insert race.

## JSONB Field Access: NULL = '' Is Never True — Use COALESCE

In PostgreSQL, `NULL = ''` evaluates to NULL (not true), so `WHERE jsonb->>'field' = ''` silently drops rows where the field is missing or null.

**Fix**: Wrap in COALESCE:
```sql
-- WRONG — misses rows where slot is NULL/missing
AND itemData::jsonb->>'slot' = ?

-- RIGHT
AND COALESCE(itemData::jsonb->>'slot', '') = ?
```

**Real case**: Auction price-history query filtered by `slot`. Craft materials and upgrade stones have no `slot` field → `->>'slot'` returns NULL → 0 rows matched. Chart showed "Недостаточно данных".

## Craft Items: type vs itemType — Check BOTH for Rendering

Inventory items have two fields: `type` (used for stacking/categorization: `craft_item`, `material`, `upgrade`) and `itemType` (used for UI: `upgrade`, `soul_crystal`). For upgrade stones: `type = 'craft_item'` (stacks with other craft items), `itemType = 'upgrade'` (shows as stone, not fragment).

**Fix**: In rendering functions, check BOTH:
```ts
// getItemImage — was only checking type, missed upgrade stones
if (item?.type === 'upgrade' || item?.itemType === 'upgrade') {
    return `/stone/stoneUpgrade_${color}.webp`;
}
```

**Affects**: `getItemImage`, any display logic that distinguishes upgrade stones from materials.

## Stone Rarity Display: rarity_display/rarity_color Can Be Wrong Values, Not Just Null

When stones are dropped, `rarity_display` and `rarity_color` must be JOINed from the `rarities` table. Old code set them to `null`, new code sets them correctly. BUT existing stones in inventories may have WRONG values (e.g. `rarity_id: 2` but `rarity_display: "Хлам"`, `rarity_color: "#888888"`) — not null, so fallback logic doesn't trigger.

**Symptoms**: Руна Изумруда (rarity_id=2=Необычный) shows "Хлам" in tooltip/auction/inventory. `getRarityDisplay()` uses `item.rarity_display || fallback` — but "Хлам" is truthy, so fallback never runs.

**Fix strategy**: 
1. Add `getRarityDisplay(item)` function that falls back to `rarity_id` mapping
2. Fix the SOURCE that writes wrong rarity values to stones (check all code paths that create/modify inventory items: shop, auction returns, stacking, overflow, tutorial gifts, admin panel)
3. Use `getRarityDisplay(item)` instead of `item.rarity_display || 'default'` in all display components (ItemStats, AuctionPage, Inventory)
