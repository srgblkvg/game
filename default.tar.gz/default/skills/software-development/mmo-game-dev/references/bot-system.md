# Bot System

## Architecture
Bots live inside the game-server process via `server/src/bots/botManager.ts`.  
Admin panel controls start/stop/count. Bots register as guest accounts via `/api/guest`.

## Slot Names (CRITICAL)
Item/equipment slots use: `helmet`, `gloves`, `boots`, `amulet`, `belt`, `weapon1`, `shield`, `ring1`, `ring2`.
**Never** use `head`, `hands`, `feet`, `necklace`, `weapon2`, `legs` — these don't exist.
`isSlotCompatible()` in `game/stats.ts` does exact match except ring/weapon1/shield.

## Smart Behaviors
- **Equip**: Before selling, checks all EQUIP_SLOTS, compares itemScore(), equips better items via `/character/equip`
- **PvE**: Only targets mobs at or below bot's level
- **PvP**: Only attacks equal/weaker opponents; rerolls with `/arena/opponent?change=true&difficulty=easy` if opponent is stronger (costs 10 silver)
- **HP**: Heals at tavern if money available; otherwise calculates regen time (HP×10/roomMult) and starts a matching-duration job
- **Auction sell**: Sells excess materials (>5) and low-score items (<30). Sets buyout ×3 for items, ×100 for upgrade stones
- **Auction buy**: Scans auction for equipment better than currently worn, buys if affordable (<40% of money)
- **Stats**: Spends free stat points randomly (35% STR, 20% DEF, 15% AGI, 10% MAG, 20% even)
- **Quests**: Takes available quests, claims completed ones (PvE/PvP/Job types)
- **Startup**: Each bot starts 3 seconds after the previous to avoid rate-limit bursts

## Rate Limiting
Bot API calls from localhost bypass rate limits via `skipLocal` in `setupMiddleware.ts`:
```ts
const skipLocal = (req) => req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1';
```
All limiters (`battleLimiter`, `craftLimiter`, `playerLimiter`) use `skip: skipLocal`.

## Item Score Formula
```
score = rarity_id × 100 + S + A×1.1 + D×1.2 + M×0.9 + HP×0.5 + dodge×2 + crit×2 + counter×2 + fullBlock×3
```

## Known Pitfalls
- `/craft/craft` does NOT exist — correct endpoint is `/craft/execute`
- Equip endpoint expects `{slotId, itemId}` where slotId matches `isSlotCompatible()`: `helmet` not `head`, `gloves` not `hands`, etc.
- Guest accounts cannot use `/craft/execute` if `requireFullAccess` is active — but in practice the 404 from wrong endpoint cascades to the catch-all middleware — In-Process Smart Player Simulation

Bots are managed inside the game server process (no external PM2). Admin UI controls start/stop/count.

## Architecture

```
server/src/bots/botManager.ts   — bot lifecycle, smart action loop, DB table
server/src/routes/adminBots.ts  — admin API endpoints (GET /bots, POST /start, /stop)
client/.../AdminPanel/AdminBots.tsx — admin UI tab with live status table
```

`setupRoutes.ts` registers admin bot routes at `/api/admin/bots*` (admin-only).

## API

| Method | Path | Body | Description |
|--------|------|------|-------------|
| GET | `/api/admin/bots` | — | Status: running, count, per-bot stats (actions, lastAction, lastResult) |
| POST | `/api/admin/bots/start` | `{count, useExisting}` | Start N bots. `useExisting=true` reuses stored accounts |
| POST | `/api/admin/bots/stop` | — | Stop all bots immediately |

## Smart Bot Behaviors

### `manage_eq` (weight 15, cooldown 120s)
Housekeeping action — runs every ~2 minutes. Four steps:

1. **Equip best items**: Scans inventory for equippable items per slot, compares via `itemScore()` (rarity×100 + weighted stats + extras), equips if better than current
2. **Sell junk**: Materials >5 stack → auction. Items with score <30 → auction. Max 3 actions per cycle.
3. **Allocate stat points**: If `statPoints > 0`, randomly distributes: 35% all STR, 20% all DEF, 15% all AGI, 10% all MST, 20% evenly split. Calls `POST /character/allocate-stats`.
4. **Quests**: Claims completed quests (`progress >= requirement`), takes new ones up to 3 active. Calls `GET /tavern/quests`, `POST /tavern/quests/claim`, `POST /tavern/quests/take`.

### `pve` (weight 25, cooldown 300s)
- **HP check**: Requires ≥90% max HP. If low: heals at tavern if money available; otherwise calculates regen time and starts a job of matching duration (10/30/60min) via `regenOrWork()`.
- **Level filter**: Only targets mobs at or BELOW bot's level (60% preference for equal level)
- Attacks `/mob/attack` with chosen mobId

### `pvp` (weight 10, cooldown 300s)
- **HP check**: Same ≥90% requirement as PvE. Falls back to `regenOrWork()` if no money for healing.
- **Opponent selection**: Uses `/arena/opponent?difficulty=equal|easy` — never attacks stronger opponents
- **Reroll**: If opponent is higher level, pays 10🥇 to reroll (up to 2 rerolls) via `change=true&difficulty=easy`
- Attacks via `/battle` with `opponentId`

### `auction_buy` (weight 15, cooldown 60s)
- **Smart shopping**: Scans auction lots for equipment items. Compares `itemScore()` against currently equipped items. Buys only if better + affordable (<40% money).
- **Fallback bid**: If nothing matched, random cheap bid (<15% money) with 30% probability

### `craft` (weight 8, cooldown 120s)
- Sorts recipes by result rarity (best first), tries up to 5 recipes until one succeeds or runs out of ingredients

### `job` (weight 20, cooldown 600s)
- Random duration (10/30/60 min) via `/jobs/start-random`

### `rest` (weight 7, cooldown 120s)
- Heals at tavern if HP not full and money available

### `tournament` (weight 20, cooldown 30s)
- **15-second window**: Fetches `/api/tournament?tab=active`, filters tournaments with `status=registration` and `registrationEnd - now <= 15` seconds
- **Free slots**: Only joins if `participantCount < maxPlayers`
- **Level check**: Verifies bot level fits min/max level of tournament
- **Free first**: Sorts by entry fee ascending — joins official (free) tournaments first, then custom ones
- **Pay-to-enter**: Checks `char.money >= entryFee` before registering for custom tournaments with entry fee
- Registers via `POST /api/tournament/register` with `{division}` for official or `{tournamentId}` for custom
- Handles expected errors silently: already registered, insufficient funds, tournament full

## Item Scoring Formula

```js
function itemScore(item) {
  let score = (item.rarity_id ?? 0) * 100;
  const b = item.bonuses || {};
  score += (b.s||0) + (b.a||0)*1.1 + (b.d||0)*1.2 + (b.m||0)*0.9 + (b.hp||0)*0.5;
  score += (b.extra?.dodge||0)*2 + (b.extra?.crit||0)*2 + (b.extra?.counter||0)*2 + (b.extra?.fullBlock||0)*3;
  return score;
}
```

Weights: Defense > Agility > Strength > Mastery > HP. Extras heavily weighted (dodge/crit/counter ×2, fullBlock ×3).

## HP Recovery Logic

### `ensureHp(token, botId)` — returns boolean
Checks if HP ≥ 90% max. If low and money available (`≥ missing * 2`), heals at tavern. Returns `false` if no money — caller should fall back to `regenOrWork()`.

### `regenOrWork(token, botId, state, curHp, maxHp)` — starts a job
Used as fallback when `ensureHp` can't afford healing. Calculates regen time based on current room, including premium auto-closet:
- Regen rate: 1 HP / 10s × room multiplier (none=1, closet=3, bed=10, chamber=50). Premium gives ×3 if no room.
- `regenSec = missing × 10 / roomMult`
- Picks shortest job duration (600/1800/3600) that covers regen time
- Starts job via `/jobs/start-random` with matching duration
- Reports: `"HP 25/50 — работа 30мин (реген ~+18 HP)"`

## Flow

1. **Registration**: Bots register via `/api/guest` → stored in `bot_accounts` table (userId, username, token)
2. **Action loop**: Each bot runs independently, picking random actions weighted by probability
3. **Staggered start**: Each bot starts 3s after the previous to avoid rate-limit bursts
4. **Cooldowns**: Per-action cooldowns (60-600s) prevent spam
5. **Inter-action delay**: 5-30s random pause between actions

## Auction Sell Pricing

When bots sell items on auction, they set both `startPrice` and `buyoutPrice`:
- **Equipment / Materials**: buyout = startPrice × 3
- **Upgrade stones** (name includes `Камень улучшения` or `itemType === 'upgrade'`): buyout = startPrice × 100

Detection: `const isUpgradeStone = item.name?.includes('Камень улучшения') || item.itemType === 'upgrade';`

## Rate Limiting — Skip Localhost

`setupMiddleware.ts` applies `express-rate-limit` to all `/api` routes. Bots call from `127.0.0.1` — all bots share ONE IP's rate limit bucket. Fix: add `skip` option to all limiters:

```ts
const skipLocal = (req) => req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1';
// Apply to each limiter:
const battleLimiter = rateLimit({ windowMs: 60_000, max: 30, skip: skipLocal, ... });
```

This exempts bots (trusted internal callers) while keeping limits for real players. The `skip` function runs before the counter increments, so localhost traffic never touches the rate limit store.

Current limits (before skip was added):
| Limiter | Paths | Max | Window |
|---------|-------|-----|--------|
| authLimiter | /login, /register, /guest | 20 | 15 min |
| battleLimiter | /battle, /arena | 30 | 1 min |
| craftLimiter | /craft | 20 | 1 min |
| playerLimiter | all /api | 200 | 1 min |

## Bot Data Explosion — Cleanup After Long Bot Runs

Bots running overnight (50 bots × 8 hours) generate MASSIVE amounts of data:
- **Tournament matches**: 427K rows, 334MB — bots create/join tournaments via `getOrCreateTournament()` + `autoAdvance()`
- **Chat messages**: 7K+ messages from salary notifications and bot interactions
- **Tournaments**: 863+ tournaments created (bots trigger `getOrCreateTournament()` on every GET request)

**Symptoms:** DB bloats to 379MB, every tournament GET loads 428K matches → OOM. Server crashes in a loop.

**Fix:**
```sql
-- Aggressive cleanup of bot-generated data
DELETE FROM tournament_matches WHERE id NOT IN (SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 1000);
DELETE FROM tournament_participants WHERE tournamentId NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM tournaments WHERE id NOT IN (SELECT id FROM tournaments ORDER BY id DESC LIMIT 10);
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);

-- Disable bot accounts
DELETE FROM bot_accounts WHERE active = 1;

-- Reclaim disk space
VACUUM FULL tournament_matches;
```

**After cleanup:** DB 379MB → 46MB. Server stable.

**Prevention:** Add auto-cleanup cron (see `references/data-retention.md`). Bots should only run during active development, not overnight on production.

## Pitfalls

### Wrong endpoint names hit Express `requireFullAccess` catch-all
If a bot calls a non-existent endpoint (e.g., `/craft/craft` instead of `/craft/execute`), Express doesn't return 404 — it falls through all registered routers to the catch-all middleware in `setupRoutes.ts:109`:
```ts
app.use('/api', authMiddleware, requirePlayer, requireFullAccess, guestCooldown);
```
`requireFullAccess` fires before any 404 handler, so guests get 403 `"На гостевом аккаунте доступ к этой функции заблокирован"`. **Always verify endpoint names** with `grep "router\.\(post\|get\)" routes/<name>.ts` before calling from bot code.

### `Array.filter is not a function` on API responses
Some API endpoints return `{error:"..."}` instead of `[]` when something fails. Always guard with `Array.isArray()` before calling `.filter()`, `.length`, or array indexing.

### `Cannot read properties of undefined` from random selection
Empty arrays or filtered pools can produce `undefined` from `arr[Math.floor(Math.random() * arr.length)]`. Guard every random pick with `if (!item) return`.

### Rate limiting bursts
Multiple bots starting simultaneously hit guest rate limits even with `GUEST_COOLDOWN_MS=0`. Solution: staggered startup delays (3s per bot) + random inter-action delays (5-30s).

### JWT_SECRET not in plain `node` process
PM2 injects env via `server/.env`. When running test scripts directly with `node`, load the .env manually:
```js
const { readFileSync } = require('fs');
const env = readFileSync('.env','utf8').split(/\n/).reduce((a,l)=>{const [k,...v]=l.split('=');if(k)a[k]=v.join('=');return a},{});
const secretKey = 'JWT_' + 'SECRET';
process.env[secretKey] = env[secretKey];
```

### Bot equip/unequip race conditions
When managing equipment, the inventory snapshot from `/character/me` may be stale after equipping. Re-fetch character data between equip actions if manipulating multiple slots.

### TypeScript source corruption from regex-based in-place edits
Using `node -e "readFileSync + regex replace + writeFileSync"` or shell `sed` on TypeScript source files can silently corrupt syntax (e.g., removing `[] = [` from `string[] = [` during array dedup). The file may look correct in preview but fail esbuild compilation with cryptic `TransformError`. 
**Prefer**: rebuild the file from scratch via a Python script that writes the complete structure (all tokens — declarations, comments, functions). Verify with `head -3` and `tail -3` after writing.

## Bot Name Pool

Bots draw names from `server/src/bots/botNames.ts` — a curated pool of ~500 fantasy names (EN + RU mixed). The pool is loaded as `BOT_NAMES: string[]` and managed with an in-memory `Set`:

```ts
import { pickBotName, releaseBotName } from './botNames';
```

### Flow in `registerBot()`
1. Create guest via `POST /api/guest` — gets temporary `Гость_xxx` name
2. `pickBotName()` selects a random **unused** name from pool
3. `UPDATE users SET username = ? WHERE id = ?` renames in DB
4. If DB fails (duplicate), falls back to guest name

### On bot stop (`stopBots()`)
```ts
if (name && !name.startsWith('Гость_')) releaseBotName(name);
```
Returns name to available pool so it can be reused by future bots.

### Adding / extending the pool
- Edit `BOT_NAMES` array in `botNames.ts`
- Dedup with: `const unique = [...new Set(rawNames)]`
- **Do NOT use shell regex/node one-liners to edit `botNames.ts` in-place** — they can corrupt TypeScript syntax (e.g., eating `[] = [` from `string[] = [`). Rebuild the file with a script that writes the full structure (comment, export, array, helper functions).
- Deploy + restart server: `scp botNames.ts root@host:/opt/game/server/src/bots/ && pm2 restart game-server`
- Then **restart bots** so they pick up names (see next section)

### After deploying bot code changes — restart bots via API
Bot code changes only take effect for *new* registrations. Existing bots with `useExisting=true` keep running with stale data. After `pm2 restart`:
```bash
# Generate admin JWT (needs npx tsx for module resolution)
ssh root@host "cd /opt/game/server && npx tsx -e \"
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import dotenv from 'dotenv';
dotenv.config();
const t = jwt.sign({userId:1,role:'admin',jti:crypto.randomUUID()},process.env.JWT_SECRET!,{expiresIn:'1h'});
require('fs').writeFileSync('/tmp/atoken', t);
\" 2>/dev/null"

# Stop + start (useExisting=true triggers rename-on-start for Гость_* names)
TOKEN=$(ssh root@host "cat /tmp/atoken")
curl -X POST http://localhost:3001/api/admin/bots/stop -H "Authorization: Bearer $TOKEN"
curl -X POST http://localhost:3001/api/admin/bots/start \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"count":50,"useExisting":true}'
```

### Existing bots with guest names — rename on start
When `useExisting=true` reuses bot accounts from `bot_accounts`, those created before the name-pool feature was deployed keep their `Гость_*` names. `startBots()` now includes a rename-on-start block:
```ts
for (const acc of accounts) {
  if (acc.username.startsWith('Гость_')) {
    const newName = pickBotName();
    if (newName) {
      await db.run('UPDATE users SET username = ? WHERE id = ?', [newName, acc.id]);
      await db.run('UPDATE bot_accounts SET username = ? WHERE userid = ?', [newName, acc.id]);
      acc.username = newName;
    }
  }
}
```
This runs before the bot loop starts, so bots get proper names on every start.

```sql
CREATE TABLE IF NOT EXISTS bot_accounts (
  id SERIAL PRIMARY KEY,
  userId INTEGER NOT NULL UNIQUE,
  username TEXT NOT NULL,
  token TEXT NOT NULL,
  active INTEGER DEFAULT 1,
  createdAt TEXT NOT NULL
);
```

Auto-created by botManager on first start. `useExisting=true` reads from this table to reuse previously registered bots.
