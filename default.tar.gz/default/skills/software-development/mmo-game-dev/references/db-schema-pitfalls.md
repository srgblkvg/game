# DB Schema Migrations: Silent Failures

## The Problem: `.catch(() => {})` Hides Migration Errors

Module-level migrations in route files use this pattern:

```typescript
// auction.ts:22-24
db.run(`ALTER TABLE users ADD COLUMN IF NOT EXISTS auction_sales INTEGER DEFAULT 0`).catch(() => {});
db.run(`ALTER TABLE users ADD COLUMN IF NOT EXISTS bank_transfers INTEGER DEFAULT 0`).catch(() => {});
```

If the `game` DB user does **not own** the `users` table, `ALTER TABLE` fails silently. The `.catch(() => {})` swallows the error. No log, no crash — the column simply never exists.

## Postgres User Hierarchy on VPS

| User | Connects as | DDL on `users`? | Use for |
|------|------------|-----------------|---------|
| `game` | `PGPASSWORD=game123 psql -h localhost -U game -d game` | **NO** — not owner | Queries, data access |
| `postgres` | `sudo -u postgres psql -d game` (no password from root) | **YES** — superuser | Schema changes, ALTER TABLE, CREATE INDEX |

## Diagnosis: Did the Column Actually Exist?

```
sudo -u postgres psql -d game -c "SELECT column_name FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'bank_transfers';"
```

Empty result → migration failed silently.

## Fix: Add Column as postgres User

```
sudo -u postgres psql -d game -c "ALTER TABLE users ADD COLUMN IF NOT EXISTS bank_transfers INTEGER DEFAULT 0;"
```

## Real-World Impact: serverTick Dead

When `bank_transfers` was missing, the batched serverTick query (`websocket.ts:242`) failed for ALL users. The `try/catch` wrapped the entire batch — not per-user. Result: no user received balance updates, timers, quests, notifications. Server looked alive but all real-time features dead.

**Symptom:** User reports "timers stuck", "balance not updating", "buttons slow".

**Log pattern:**
```
tick batch err: column u.bank_transfers does not exist
```
Every second, every tick.

## Current Column Dependencies (websocket.ts batched query)

These columns must exist on `users` for serverTick to work:

| Column | Added by | Migration location |
|--------|---------|-------------------|
| `money`, `bank` | Core schema | Initial |
| `auction_sales` | `auction.ts:22` | Module-level, silent catch |
| `bank_transfers` | `auction.ts:24` | Module-level, silent catch |

Any future column added to the batched query must be verified with `sudo -u postgres` — never assume the module-level `.catch(() => {})` worked.

## Prevention

When adding a new DB column:
1. Run the ALTER TABLE via `sudo -u postgres psql` on the VPS
2. Verify with `information_schema.columns` query
3. Only then do the code deploy
