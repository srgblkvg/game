# Dynamic Positioning with ResizeObserver

## Problem

Fixed-position UI elements positioned relative to `#site-header` need to track the header's actual height. Hardcoded pixels break when header content changes (e.g. faction badge added).

## Solution

Use `getBoundingClientRect().bottom` + `ResizeObserver` to dynamically track the element's bottom edge relative to viewport:

```tsx
const [headerHeight, setHeaderHeight] = useState(132);

useEffect(() => {
    const update = () => {
        const el = document.getElementById('site-header');
        const h = el ? el.getBoundingClientRect().bottom : 132;
        const safeArea = parseInt(getComputedStyle(document.documentElement)
            .getPropertyValue('--vk-top-offset')) || 0;
        setHeaderHeight(Math.max(h, 132) + safeArea);
    };
    update();
    const ro = new ResizeObserver(update);
    const el = document.getElementById('site-header');
    if (el) ro.observe(el);
    window.addEventListener('resize', update);
    return () => { ro.disconnect(); window.removeEventListener('resize', update); };
}, []);

// Usage
<button style={{ top: `${headerHeight - 12}px` }} />
```

## Key points

- `getBoundingClientRect().bottom` — exact bottom edge relative to viewport (better than `offsetHeight`)
- `ResizeObserver` — fires on any size change (including font loading, content changes, navigation breadcrumbs)
- Include VK `safe-area-inset-top` offset via CSS variable `--vk-top-offset`
- For VK CSS overrides: remove `!important` top values — let JS handle it dynamically
- Centering a button on the edge: subtract half the button height from `headerHeight`
