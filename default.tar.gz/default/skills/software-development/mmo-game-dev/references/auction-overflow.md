# Auction Overflow Storage

## Purpose
When a buyer wins an auction but their inventory is full (equipment items = inventorySlots), the item goes to `overflow_storage` table instead of the main inventory. This prevents items from being silently lost.

## Key rules
- **Only equipment items take slots**: items with `.slot` field (helmet/gloves/boots/amulet/weapon/shield). Craft items, materials, and upgrade stones don't take slots.
- **Inventory fullness check**: `inventory.filter(i => !!i.slot).length >= maxSlots`, NOT `inventory.length`.
- **Buyout endpoint**: returns `{error: 'Инвентарь заполнен'}` if buyer can't fit the item.
- **Auto-resolution**: when a lot expires with a winner, if winner's inventory is full, item goes to overflow via `addToOverflow()`.

## DB Schema
```sql
CREATE TABLE IF NOT EXISTS overflow_storage (
  id SERIAL PRIMARY KEY,
  userId INTEGER NOT NULL,
  item JSONB NOT NULL,
  auctionLotId INTEGER,
  createdAt INTEGER DEFAULT EXTRACT(EPOCH FROM NOW())::INTEGER
);
CREATE INDEX IF NOT EXISTS idx_overflow_userid ON overflow_storage(userId);
-- CRITICAL: grant access to game user
GRANT ALL ON overflow_storage TO game;
GRANT ALL ON overflow_storage_id_seq TO game;
```

## Server endpoints
- `GET /api/overflow` — list user's overflow items
- `POST /api/overflow/take/:id` — move item to inventory (checks fullness first)

## Helper functions (in overflow.ts)
- `addToOverflow(userId, item, auctionLotId)` — called from auction resolution
- `isInventoryFull(userId)` — checks equipment count vs slots

## Client
`OverflowStorage.tsx` — collapsible panel rendered in `MainBar.tsx` between Inventory and Actions:
- Shows items in a 48px grid
- Tooltip on hover (uses `ItemTooltip`)
- Click to take → calls `/api/overflow/take/:id`
- Drag to inventory area → handled by `onDrop` in MainBar
- Listens for `overflow-taken` custom event to remove items
- Refresh character after taking item to update inventory immediately

## Pitfalls

## Unified return helper (returnItemToInventory)

For ALL auction return paths (cancel, buyout, partial buyout, expired lot), use the unified helper instead of direct `inventory.push`. The helper handles:
- Craft item stacking (same id → increment count)
- Equipment overflow → `addToOverflow()`
- Normal equipment → push to inventory

```ts
async function returnItemToInventory(userId: number, itemData: any) {
    const user = await db.one('SELECT inventory, inventorySlots FROM users WHERE id = ?', [userId]);
    const inventory = JSON.parse(user.inventory || '[]');
    const maxSlots = user.inventorySlots || 10;
    const isCraft = itemData.type === 'craft_item' || itemData.type === 'material';
    
    if (isCraft) {
        const existingIdx = inventory.findIndex((i: any) =>
            (i.type === 'craft_item' || i.type === 'material') && String(i.id) === String(itemData.id));
        if (existingIdx !== -1) {
            inventory[existingIdx].count = (inventory[existingIdx].count || 0) + (itemData.count || 1);
            await db.run('UPDATE users SET inventory = ? WHERE id = ?', [JSON.stringify(inventory), userId]);
            return;
        }
    }
    
    const equipCount = inventory.filter((i: any) => !!i.slot).length;
    if (!isCraft && equipCount >= maxSlots) {
        await addToOverflow(userId, itemData);
    } else {
        inventory.push({ ...itemData, count: itemData.count || 1 });
        await db.run('UPDATE users SET inventory = ? WHERE id = ?', [JSON.stringify(inventory), userId]);
    }
}
```

Applied in: `POST /auction/cancel`, `POST /auction/buyout`, partial buyout, expired lot with/without bid.

## Pitfalls
- **Permissions**: Table created by postgres superuser → game user gets `permission denied`. Always GRANT after CREATE TABLE.
- **PM2 restart bug**: After fixing overflow.ts and recompiling, `pm2 restart` keeps old compiled code. Use `pm2 delete; pm2 start`.
- **`item` before initialization**: When modifying overflow take handler, make sure `item` is parsed from `row.item` BEFORE checking `isGear = !!item.slot`. If the check comes first, it references the uninitialized variable.
- **Silent item loss**: In auction resolution, if inventory push fails silently (caught error), items are lost because lots are still deleted. The resolution code at line 106 (`DELETE FROM auction_lots`) runs after delivery — if delivery crashes, the lot persists. But if delivery succeeds in one branch and fails in another (overflow write), items may be lost.
