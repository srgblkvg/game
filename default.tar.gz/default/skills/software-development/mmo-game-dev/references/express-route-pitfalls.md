# Express Route Ordering Pitfall

## Symptom
- `GET /api/guild/quest` returns 500 with `invalid input syntax for type integer: "NaN"`
- Stack trace points to `guild.ts` line ~236 (the `/guild/:id` handler), NOT the quest handler
- curl to the endpoint shows an HTML error page with the NaN error

## Root Cause
Express matches routes in REGISTRATION ORDER. If `router.get('/guild/:id', ...)` is registered BEFORE `router.get('/guild/quest', ...)`, Express matches `/guild/quest` as `/guild/:id` with `id = "quest"`. Then `parseInt("quest")` = `NaN`, which PG rejects for integer columns.

## Detection
The error message is misleading — it looks like a DB error on the quest handler, but the stack trace shows `guild.ts:236` (the `:id` handler). Check the route registration order in the file.

## Fix Pattern
```typescript
// Option A: Move static route ABOVE parameterized route (preferred)
router.get('/guild/quest', questHandler);
router.get('/guild/:id', guildHandler);

// Option B: Add isNaN guard + next() pass-through
router.get('/guild/:id', async (req, res, next) => {
    const guildId = parseInt(req.params.id);
    if (isNaN(guildId)) return next(); // pass to /guild/quest
    // ... rest of handler
});
```

Don't forget to add `next` to the handler parameters when using Option B.
