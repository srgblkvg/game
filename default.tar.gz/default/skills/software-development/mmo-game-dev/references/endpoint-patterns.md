# Server Endpoint Patterns

## Auction Cancel (возврат предмета + денег)
`POST /api/auction/cancel`
- Verify lot belongs to user (`lot.sellerId !== userId`)
- Return item to inventory (handle stacking for craft items)
- Refund current bidder if any
- Delete lot
- No listing fee refund

```ts
router.post('/auction/cancel', (req, res) => {
  const lot = db.prepare('SELECT * FROM auction_lots WHERE id = ?').get(lotId);
  if (lot.sellerId !== userId) return error;
  // merge item back to inventory
  const existingIdx = inventory.findIndex(i => i.id === itemData.id);
  if (existingIdx !== -1) inventory[existingIdx].count += itemData.count;
  else inventory.push({...itemData});
  // refund bidder
  if (lot.currentBidderId) addMoney(db, lot.currentBidderId, lot.currentBid);
  db.prepare('DELETE FROM auction_lots WHERE id = ?').run(lotId);
});
```

## Disassemble (камень улучшения → материал)
`POST /api/craft/disassemble`
- Find upgrade stone in inventory (`isCraftItem && itemType === 'upgrade'`)
- Find material of same rarity (`type = 'craft'`)
- Replace: decrement/remove stone, add/stack material

```ts
router.post('/craft/disassemble', (req, res) => {
  const stone = inventory.find(i => isCraftItem(i) && i.itemType === 'upgrade');
  const material = db.prepare('SELECT * FROM craft_items WHERE rarity_id = ? AND type = ?').get(rarityId, 'craft');
  // remove stone, add material (with stacking)
});
```

## Feedback (обратная связь)
Table: `feedback_messages (id, userId, username, subject, message, createdAt, read)`
- POST `/api/feedback` — player submits, saves to DB
- GET `/api/admin/feedback?page=&limit=` — admin reads (needs authMiddleware + requireAdmin)
- POST `/api/admin/feedback/read` — mark as read

For admin routes: register under `/api/admin` with `authMiddleware, requireAdmin` middleware chain.
