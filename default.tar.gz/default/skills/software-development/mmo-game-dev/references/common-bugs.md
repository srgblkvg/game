# Common Bug Patterns

Patterns that recur across the codebase. Check these FIRST when debugging unexpected behavior after changes.

## `> 0` truthiness trap (HP/cooldown/money fields)

**Symptom**: Player with 0 HP enters battle and gets full HP back. Cooldown of 0 seconds passes instantly. Player with 0 money bypasses cost checks.

**Root cause**: `field > 0` evaluates to `false` for both `0` (valid) and `null`/`undefined` (unset). Code conflates them.

**Example** (`game/battle.ts:runBattle`):
```js
// BUG: 0 HP → falls through to maxHp
let hpA = (attacker.currentHp != null && attacker.currentHp > 0) ? attacker.currentHp : statsA.hp;

// FIX: separate null check from value check
let hpA = (attacker.currentHp != null) ? attacker.currentHp : statsA.hp;
// Then validate (hpA <= 0) at call site
```

**Audit pattern**: grep for `> 0` in conditions that also have `!= null` or `??`. DB fields that can legitimately be `0`: HP, money, cooldowns, bid amounts, counts.

## Auction item loss on expiry

**Symptom**: When auction lot expires, seller gets money but item vanishes. Winner paid but never receives item. Unsold items disappear instead of returning to seller.

**Root cause**: GET `/auction` handler's expiry cleanup only ran `DELETE FROM auction_lots` — no item transfer logic.

**Fix** (`routes/auction.ts` GET handler):
- Lots with `currentBidderId`: pay seller, transfer item to winner's inventory, record in `auction_history`
- Lots without `currentBidderId`: return item to seller's inventory
- Both: delete lot only AFTER item transferred

## SCP hangs on WSL

**Symptom**: `scp -r` from WSL to VPS hangs indefinitely with no output.

**Workaround**: 
1. Keep SCP calls small — copy individual files rather than `dist/*` wildcards
2. Prefer `rsync` when available
3. If SCP hangs, kill it and verify files already arrived (they often do — the hang is on connection close, not transfer)
4. Test with `diff` between local and remote to confirm deployment succeeded
