# Dynamic Search with Debounce

Pattern for search inputs that filter data on-the-fly without a submit button.

## Client pattern

```tsx
const [search, setSearch] = useState('');

// Debounced auto-search — fires 300ms after user stops typing
useEffect(() => {
  const timer = setTimeout(() => loadData(1, search), 300);
  return () => clearTimeout(timer);
}, [search]);

// Input — no onSubmit, no button, just onChange
<input
  type="text"
  placeholder="Поиск по нику..."
  value={search}
  onChange={e => setSearch(e.target.value)}
  className={inputClass}
/>
```

## Server pattern

```ts
const page = parseInt(req.query.page as string) || 1;
const limit = parseInt(req.query.limit as string) || 10;
const search = (req.query.search as string || '').trim();

let whereClause = 'WHERE guildId = ?';
const params: any[] = [guildId];

if (search) {
  whereClause += ' AND u.username LIKE ?';
  params.push(`%${search}%`);
}

// Count total for pagination
const total = db.prepare(`SELECT COUNT(*) as cnt FROM table l JOIN users u ON l.userId = u.id ${whereClause}`)
  .get(...params).cnt;

// Fetch page
const logs = db.prepare(`SELECT ... FROM table l JOIN users u ... ${whereClause} ORDER BY l.id DESC LIMIT ? OFFSET ?`)
  .all(...params, limit, (page - 1) * limit);

res.json({ data: logs, total, page, totalPages: Math.ceil(total / limit) });
```

## Key points

- Debounce with `useEffect` + `setTimeout/clearTimeout` — prevents API spam on every keystroke
- 300ms is a good balance between responsiveness and server load
- Search resets to page 1 on every query change
- No "Find" button needed — the search is implicit
- LIKE with `%search%` for substring matching (simple, effective for small datasets)
