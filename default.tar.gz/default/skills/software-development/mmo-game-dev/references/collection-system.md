# Collection System

## Overview
Players sacrifice inventory items to a Collection, gaining +1% to S/A/D/M/HP per item.
Two tabs: **Базовая** (upgradeLevel < 7) and **+7** (upgradeLevel ≥ 7).
7 rarity sets × 27 items × 2 tabs = 450 total, max +450% bonus.

## Database

### Tables
- `collections(userId, itemName, slot, rarity_id, upgradelevel, addedAt)` — upgradelevel is the ACTUAL item upgrade level (0-10+), NOT normalized to tab.
- `collection_sets(id, name, description, bonus_percent, sort_order)` — admin-defined sets.
- `collection_set_items(set_id, item_name, slot)` — items belonging to each set.

### Seed Data
7 default sets per tab (Базовая and +7) = 14 sets total.

## API

### GET /api/collections?upgradelevel=0|7
Query by RANGE, not exact match:
- `upgradelevel=0` → `WHERE upgradelevel < 7`
- `upgradelevel=7` → `WHERE upgradelevel >= 7`
The sets JOIN also uses range: `c.upgradelevel >= 7` or `c.upgradelevel < 7`.

### POST /api/collections/add
Body: `{ itemName, slot, itemId, rarityId, upgradeLevel }`.

**Validation (added Aug 2026):**
- Server reads the ACTUAL item's `upgradeLevel` from inventory JSON
- If `targetLevel=0` and `actualUpgrade >= 7` → reject (use +7 tab)
- If `targetLevel=7` and `actualUpgrade < 7` → reject (use Basic tab)
- INSERT uses `actualUpgrade` (item's real level), NOT `targetLevel` from request

**Duplicate check:** uses range query, not exact level:
```sql
SELECT id FROM collections WHERE userId=? AND itemName=? AND slot=? AND rarity_id=? AND upgradelevel >= 7  -- or < 7
```

## Server-Side Bonus
In `character/me`: `SELECT itemName, slot, rarity_id, upgradelevel FROM collections WHERE userId=?` — returns ALL items (both tabs).

## Client-Side

### CollectionsPage
- Fetches only CURRENT tab: `/api/collections?upgradelevel=${activeTab}`
- `collectionKeys` normalized: items from API → key `name|slot|rarity_id|0` (Basic) or `|7` (+7)
- `ownedKeys`: built from FULL inventory, filtered by tab upgradeLevel range
- After adding an item: re-filter `inventoryItems` by tab (was missing — FIXED Aug 2026)
- Green dot on +7 tab: checks `fullInventory` for items with `upgradeLevel >= 7`

### ItemStats (tooltip)
Uses `character.collectedItems` (all items, both tabs). Check by RANGE, not exact match:
- `upgradelevel < 7` → База collected
- `upgradelevel >= 7` → +7 collected
- Shop items have no upgradeLevel (0) — exact match would ALWAYS fail for non-0 collected items → FIXED Aug 2026

### BuffsBlock (Усиления)
Fetches BOTH tabs' collections. Green dot logic (FIXED Aug 2026):
- Item with `upgradeLevel < 7` → check if NOT in Basic collection
- Item with `upgradeLevel >= 7` → check if NOT in +7 collection
- Previously fetched only Basic tab and used exact name|slot match — missed +7 items

## Pitfalls
- **Exact upgradeLevel match in client**: shop items have upgradeLevel=0, DB items have real levels (3,5,8). Always use range checks.
- **inventoryItems not filtered after add**: after `handleConfirm`, `inventoryItems` was set to full inventory without tab filter → showed wrong items as addable.
- **GET by exact level**: `WHERE upgradelevel = 0` misses items stored with upgradelevel=3. Use `< 7` / `>= 7`.
- **Server used targetLevel for INSERT**: stored tab level (0/7) instead of actual item upgradeLevel → fixed to use `actualUpgrade`.
- **Existing check by exact level**: `upgradelevel = targetLevel` missed items in same tab with different level → use range.
