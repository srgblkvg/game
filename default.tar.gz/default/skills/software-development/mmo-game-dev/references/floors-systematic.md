# Bestiary Floors — Systematic Grouping

## Current state (24 June 2026)
Floors are hardcoded in the client as DIFFICULTIES groups. Case-insensitive matching used because
API returns Title Case ("Врата Бездны") vs lowercase in code ("Врата бездны").

## Desired state
Add `difficulty` INTEGER column to `floors` table:
- 0 = Легко, 1 = Нормально, 2 = Сложно, 3 = Ад
- API returns floors with difficulty field
- Client groups by difficulty field, no hardcoding

## Migration needed (postgres superuser required)
```sql
ALTER TABLE floors ADD COLUMN difficulty INTEGER DEFAULT 0;
UPDATE floors SET difficulty = 0 WHERE name IN ('Склеп','Подземелье','Катакомбы','Деревня Пепла');
UPDATE floors SET difficulty = 1 WHERE name IN ('Лес Черепов','Старый Тракт','Ядовитые луга','Первый ярус');
UPDATE floors SET difficulty = 2 WHERE name IN ('Гнилая Топь','Чёрный Монастырь','Башня Плакальщиц','Некрополь Королей');
UPDATE floors SET difficulty = 3 WHERE name IN ('Бездонный Овраг','Врата Бездны');
```

## Client update needed after migration
Replace DIFFICULTIES constant with difficulty from API response.
Remove case-insensitive matching — use exact name from DB.
