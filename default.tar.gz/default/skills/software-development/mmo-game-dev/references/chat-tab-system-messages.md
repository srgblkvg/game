# Chat Tab with System Messages — Reusable Pattern

How to add a new chat tab (like Auction) that shows system-generated messages (lot listings, bids, outbids, buyouts). Reusable for: guild war notifications, tournament results, bank transfers, etc.

## 1. Server: INSERT system message into chat_messages

Use `senderId: 0` (system), `targetId: null` (not private), and `item_data` JSON with a `type` prefix for filtering:

```ts
const data = JSON.stringify({
  type: 'auction_lot', // prefix for client-side filtering: msg.item?.type?.startsWith('auction_')
  lotId: 123,
  itemData: {...},
  startPrice: 100,
  currentBid: null,
  buyoutPrice: 500,
  currentBidderName: null,
  sellerName: 'Player1',
  endsAt: 1783000000,
  createdAt: now,
});

const info = await db.run(
  'INSERT INTO chat_messages (senderId, targetId, content, item_data, senderguild, senderguildid) VALUES (?, NULL, ?, ?, NULL, NULL)',
  [0, '📦 Player1 выставил лот', data]
);
```

## 2. Server: broadcast to all clients

```ts
const msg = {
  id: info.lastInsertRowid,
  senderId: 0,
  senderName: 'Глашатай',  // senderId=0 — все системные сообщения от Глашатай
  targetId: null,
  content: '📦 Player1 выставил лот',
  createdAt: new Date().toISOString(),
  item: { type: 'auction_lot', lotId, itemData, startPrice, ... },
};
broadcast('message', { message: msg });
```

The `broadcast('message', ...)` goes through `events.ts` → `websocket.ts` → all connected clients receive `{ type: 'message', message: msg }`.

## 3. Client: ChatTabs — add tab

```tsx
// ChatTabs.tsx — new prop + tab
<div onClick={onSelectAuction} className={...}>
  🔨 Аукцион
  {unreadAuction > 0 && !auctionChatActive && (
    <span className="w-2 h-2 rounded-full bg-[var(--color-accent-warning)] inline-block" />
  )}
</div>
```

## 4. Client: ChatPanel — state + filtering + unread

```tsx
// State
const [auctionChatActive, setAuctionChatActive] = useState(false);
const [unreadAuction, setUnreadAuction] = useState(0);
const LS_AUCTION = 'chatLastReadAuction';

// Filter displayed messages
const displayedMessages = useMemo(() => messages.filter(msg => {
    if (auctionChatActive) return msg.item?.type?.startsWith('auction_');
    if (privateChatWith === null) return msg.targetId === null && !msg.item?.type?.startsWith('auction_');
    // ... other tabs
}), [messages, auctionChatActive, ...]);

// Unread tracking (add to existing useEffect)
setUnreadAuction(messages.filter(m => m.senderId !== userId && m.item?.type?.startsWith('auction_') && m.id > lastReadAuction).length);

// Mark read
const markRead = (type: 'general' | 'guild' | 'auction' | number) => {
    if (type === 'auction') {
        const filtered = messages.filter(m => m.item?.type?.startsWith('auction_'));
        const maxId = filtered.length > 0 ? Math.max(...filtered.map(m => m.id)) : 0;
        saveLastRead(LS_AUCTION, maxId);
        setUnreadAuction(0);
    }
    // ...
};
```

## 5. Client: MessageList — custom rendering

```tsx
// Inside group.map()
const isAuction = msg.item?.type?.startsWith('auction_');
if (isAuction) {
    const a = msg.item;
    const timeLeft = Math.max(0, (a.endsAt || 0) - Math.floor(Date.now()/1000));
    return (
        <div className="auction-card">
            <span style={{color: getRarityColor(rarity)}} className="cursor-pointer"
                  onMouseEnter={(e) => setTooltipData({item: a.itemData, x: e.clientX, y: e.clientY})}
                  onMouseLeave={() => setTooltipData(null)}>
                [{itemName}]
            </span>
            <div>Старт: {a.startPrice}🥇</div>
            <div>Продавец: {a.sellerName} • {a.currentBidderName ? null : 'Нет покупателя'}</div>
            <div>{formatTime(msg.createdAt)} | ⏳ {hours}ч {mins}м</div>
        </div>
    );
}
```

## 6. Message Cleanup — DELETE + broadcast removal

When the related entity is deleted (lot bought/cancelled/expired):

```ts
// Server: delete from DB
await db.run('DELETE FROM chat_messages WHERE item_data LIKE ?', [`%"lotId":${lotId}%`]);
// Broadcast removal to all clients
broadcast('auction_message_removed', { lotId });
```

```tsx
// Client: listen and filter from state
case 'auction_message_removed': {
    const lotId = data.lotId;
    if (lotId) {
        setMessages(p => p.filter(m => {
            if (!m.item?.lotId) return true;
            return m.item.lotId !== lotId;
        }));
    }
    break;
}
```

## 7. Client: localStorage auto-cleanup on load

Prevent stale messages from localStorage cache:

```tsx
const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
        const c = localStorage.getItem('chat_messages');
        if (!c) return [];
        const parsed = JSON.parse(c);
        // Strip auction messages on load — server sends fresh via WS
        return parsed.filter(m => !m.item?.type?.startsWith('auction_'));
    } catch { return []; }
});
```

## 8. Collapsed panel indicator

Add unread dot on the collapsed chat header:

```tsx
{!isPanelOpen && (
    <>
        {unreadGeneral > 0 && <span className="chat-blink bg-white" />}
        {unreadAuction > 0 && <span className="chat-blink bg-[var(--color-accent-warning)]" />}
        {unreadGuild > 0 && <span className="chat-blink bg-[var(--color-accent-success)]" />}
        {unreadPrivateCount > 0 && <span className="chat-blink bg-[#c084fc]" />}
    </>
)}
```

## Pitfalls

- **Don't forget to exclude auction messages from general chat**: `msg.targetId === null && !msg.item?.type?.startsWith('auction_')` — otherwise auction messages appear in both tabs
- **Don't forget broadcast on cleanup**: deleting from DB is not enough — client has messages in React state + localStorage. Must broadcast removal event
- **localStorage is persistent**: messages loaded from localStorage survive page refresh even after DB rows are gone. Filter them out on init
- **Don't show input on read-only tabs**: auction/notification tabs should hide ChatInput and show a placeholder
- **fetchRecentMessages on tab switch**: add `auctionChatActive` to the useEffect dependency so messages load when switching to the auction tab
- **ChatInput early return**: `if (auctionChatActive) return;` at the top of `handleSend` to prevent sending from read-only tabs
