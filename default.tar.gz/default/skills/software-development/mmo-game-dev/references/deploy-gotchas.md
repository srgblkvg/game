# Deploy Gotchas

## DB path after git reset
The SQLite DB opens `game.db` relative to CWD. PM2 starts in `/opt/game`, so the DB must be at `/opt/game/game.db`. After `git reset --hard`, the repo version may not include the DB file. Copy it:
```bash
cp /opt/game/server/game.db /opt/game/game.db
```

## Uploads wiped by git reset
`git reset --hard` overwrites `server/uploads/` with the repo version (which has no avatars). After any git reset, restore uploads from backup:
```bash
cp -r /opt/game_backup_DATE/server/uploads/* /opt/game/server/uploads/
```

## Fresh PM2 process (crash loop)
If PM2 shows restart count > 100, the process is in a crash loop. PM2 has a restart limit. Delete and re-create:
```bash
pm2 delete game-server
pm2 start "cd /opt/game && npx tsx server/src/index.ts" --name game-server
```

## Nginx 502 after deploy
After PM2 restart, nginx may cache the old upstream state. Reload:
```bash
nginx -s reload
```

## Don't use sed/awk on VPS
sed replacements on VPS files create uncommitted changes that get lost on next `git reset --hard`. Always edit locally, commit, and push.

## Vite chunk hashes change unpredictably — use rsync

After `npx vite build`, **every chunk hash can change**, not just the modified ones.
Selective `scp` of individual files almost always misses something.

**Wrong (causes MIME type errors):**
```bash
scp dist/assets/index-*.js dist/assets/GuildPage-*.js user@vps:/opt/game/client/dist/assets/
```

**Right:**
```bash
rsync -avz -e "ssh -i ~/.ssh/id_ed25519" client/dist/ root@VPS:/opt/game/client/dist/
```

This syncs `index.html`, all JS/CSS chunks, and static assets in one shot.
Always run rsync after every client build before restarting the server.
