# Admin Image Upload Pattern

## Server Endpoint
POST /api/admin/upload-image — accepts { image: "data:image/...;base64,...", folder?: "jobs" }
Saves to /mnt/c/project/game/server/uploads/admin/<folder>/<timestamp>.<ext>
Returns { success: true, url: "/uploads/admin/<folder>/<file>" }

## Gallery Endpoint
GET /api/admin/images?folder=jobs — lists all image files in the folder
Returns string[] of URLs, sorted newest first

## Client Component
<ImageUploader
  currentUrl={item.background || null}
  folder="jobs"
  onUploaded={(url) => setForm({ background: url })}
  label="Фоновое изображение"
/>

Features:
- File input → base64 conversion → POST to server
- Preview thumbnail
- 📁 button opens gallery modal with grid of existing images
- ✕ button to clear/remove image
- 5MB client-side limit check

## Prerequisites
- Express: app.use(express.json({ limit: '5mb' })) in setupMiddleware.ts
- Nginx: client_max_body_size 10m; in site config
- Directory must exist: fs.mkdirSync(dir, { recursive: true })
- Public access: nginx serves /uploads/ directly (already configured)

## DB Patterns
When adding image support to a table:
1. Migration: try { db.exec('ALTER TABLE tablename ADD COLUMN background TEXT'); } catch {}
2. API: include background in SELECT and INSERT/UPDATE
3. Client: ImageUploader component

## Critical Pitfall: undefined overwrites existing value
When a PUT endpoint receives `background: undefined` (because the ImageUploader wasn't touched), `background || null` evaluates to `null`, erasing the existing background. Fix: use dynamic field updates that only SET columns when the field is explicitly provided:

```typescript
// WRONG — overwrites background when not in request body
db.prepare('UPDATE jobs SET name=?, background=? WHERE id=?')
    .run(name, background || null, id);

// RIGHT — only updates fields that are present
const fields: string[] = []; const values: any[] = [];
if (name !== undefined) { fields.push('name=?'); values.push(name); }
if (background !== undefined) { fields.push('background=?'); values.push(background || null); }
db.prepare(`UPDATE jobs SET ${fields.join(',')} WHERE id=?`).run(...values, id);
```
