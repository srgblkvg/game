# Express Route Ordering Pitfall

## Problem
Express matches routes in registration order. `router.get('/guild/:id')` registered **before** `router.get('/guild/quest')` will match `/guild/quest` with `:id = "quest"`. `parseInt("quest")` → `NaN` → PostgreSQL `invalid input syntax for type integer: "NaN"` → 500.

## Fix
Add `next` to the handler params and skip non-numeric IDs:

```typescript
router.get('/guild/:id', async (req, res, next) => {  // add next
    const guildId = parseInt(req.params.id);
    if (isNaN(guildId)) return next();                 // pass to next matching route
    // ... rest of handler
});
```

This lets Express fall through to `/guild/quest` (or any other static route) when `:id` is not a number.

## General rule
- Static routes MUST be registered BEFORE parameterized routes with the same prefix
- OR add `isNaN` + `next()` guards on all `:id` handlers that overlap with static route prefixes
