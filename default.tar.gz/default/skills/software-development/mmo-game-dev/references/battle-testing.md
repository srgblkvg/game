# Battle Testing / Simulation

Run N simulated battles between two players without touching prod.

## Workflow
1. Write a self-contained Node.js script with `runBattle` + `currentStats` copied inline
2. Script connects to prod DB **read-only**, fetches player base stats + equipment + drink bonuses
3. Script runs N battles, collects results, generates HTML report
4. `scp` script → server, `ssh ... node script.js`, `scp` HTML report back
5. Clean up temp files on server

## Script skeleton
```js
const { Pool } = require('pg');
const pool = new Pool({host:'localhost', user:'game', password:'game123', database:'game'});

// === COPY runBattle + currentStats + helpers from server/src/game/battle.ts ===
// (inline them — no TS imports work from plain node)

(async() => {
  // 1. Fetch players
  const users = await pool.query(
    "SELECT id,username,level,bases,basea,based,basem,equipment,activedrink FROM users WHERE username IN ('Player1','Player2')"
  );
  // 2. Build player objects: { id, name, base:{s,a,d,m}, equipment:{}, level, money:0, drinkBonuses, collectionBonus }
  // 3. Run N battles (alternate attacker each round)
  for (let i = 0; i < N; i++) {
    const att = i % 2 === 0 ? p1 : p2;
    const def = i % 2 === 0 ? p2 : p1;
    const r = runBattle(att, def);
    // collect: winnerId, steps[], hA, hD, maxA, maxD, sA, sD
  }
  // 4. Count effects per battle: filter steps where type in (dodge,counter,crit,block,fblock,stun)
  // 5. Generate HTML with collapsible sections, summary stats, HP bars
  require('fs').writeFileSync('/tmp/battle_report.html', html);
})();
```

## HTML report structure
- Summary card: wins/losses per player, base stats, equipment bonuses, extra stats
- Average effects per battle (dodges, counters, crits, blocks, stuns)
- Each battle: collapsible `<div>` with toggle via `classList.toggle('open')`
- Step-by-step log with HP after each hit: `[Attacker: 45/276 | Defender: 200/294]`
- CSS: dark theme (`#1a1a2e` bg, `#cdd6f4` text), colored step types

## Deploy: scp script → run on VPS → scp report back
```bash
scp script.js root@194.226.142.237:/opt/game/server/
ssh root@194.226.142.237 "cd /opt/game/server && node script.js"
scp root@194.226.142.237:/tmp/battle_report.html /home/srg/.hermes/
```

## Pitfalls
- `pg` module only available in `/opt/game/server` (where node_modules are)
- `activedrink` column: JSON with `{bonuses: {s,a,d,m}}` — parse and extract `.bonuses`
- `equipment` column: JSON object keyed by slot — pass directly to `currentStats`
- HP display: attacker/defender swap each battle — derive max HP from `currentStats` output, not from DB
- Script cleanup: `rm` on server after scp-ing report back
