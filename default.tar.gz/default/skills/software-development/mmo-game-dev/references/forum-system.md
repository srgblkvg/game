# Forum System

## DB Tables
```sql
CREATE TABLE forum_threads (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    author_id INTEGER NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    posts_count INTEGER DEFAULT 1,
    is_closed BOOLEAN DEFAULT false
);

CREATE TABLE forum_posts (
    id SERIAL PRIMARY KEY,
    thread_id INTEGER NOT NULL REFERENCES forum_threads(id) ON DELETE CASCADE,
    author_id INTEGER NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    parent_id INTEGER REFERENCES forum_posts(id) ON DELETE SET NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ
);

-- Polls (one per thread)
CREATE TABLE forum_polls (
    id SERIAL PRIMARY KEY,
    thread_id INTEGER NOT NULL UNIQUE REFERENCES forum_threads(id) ON DELETE CASCADE,
    question TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE forum_poll_options (
    id SERIAL PRIMARY KEY,
    poll_id INTEGER NOT NULL REFERENCES forum_polls(id) ON DELETE CASCADE,
    option_text TEXT NOT NULL,
    votes_count INTEGER DEFAULT 0
);

CREATE TABLE forum_poll_votes (
    poll_id INTEGER NOT NULL REFERENCES forum_polls(id) ON DELETE CASCADE,
    option_id INTEGER NOT NULL REFERENCES forum_poll_options(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(poll_id, user_id)
);

-- Always grant permissions and sequence access after creating new tables
GRANT ALL ON forum_polls, forum_poll_options, forum_poll_votes TO game;
GRANT USAGE, SELECT ON SEQUENCE forum_polls_id_seq, forum_poll_options_id_seq TO game;
```

## Client field naming (CRITICAL)
New tables don't go through the camelCase converter properly. Use snake_case in client:
- `post.created_at` (NOT `post.createdAt`)
- `post.updated_at` (NOT `post.updatedAt`)
- `thread.created_at`, `thread.updated_at`, `thread.is_closed`

## Routes
- `GET /api/forum/threads?page=&limit=` — list threads (auth required)
- `GET /api/forum/thread/:id?page=` — single thread with posts + poll (auth required)
- `POST /api/forum/thread` — create thread (optional `poll` body: `{question, options: string[]}`)
- `POST /api/forum/reply` — reply (supports `parentId` for threading)
- `POST /api/forum/poll/vote` — vote in poll (`{threadId, optionId}`), one vote per user
- `PUT /api/forum/thread/:id/close` — close/open (author only)
- `PUT /api/forum/thread/:id` — edit title (author only, blocked when closed)
- `PUT /api/forum/post/:id` — edit post content (author only, blocked when closed thread)
- `GET /api/forum/latest` — public, returns last 3 threads for CastlePage

## Markdown Rendering
Uses `marked` (npm) + `DOMPurify` for safe HTML output. Configured with:
- `breaks: true` — single newline → `<br>`
- `gfm: true` — GitHub Flavored Markdown (tables, task lists)

DOMPurify whitelist: `p, br, strong, em, del, code, pre, h1-h6, ul, ol, li, a, blockquote, table, thead, tbody, tr, th, td, hr, img, span`.

Custom CSS via `<style>` tag with `.forum-content` prefix:
- `blockquote` → blue left border (`var(--color-accent-info)`)
- `code` → bg-input background, small padding
- `pre` → bg-input background, scrollable
- `a` → accent-info color, underline
- `h1-h3` → appropriate font sizes and weights

## Threading
Posts have `parent_id` → replies are nested in a tree. Client builds tree from flat list:
```ts
const buildTree = (flatPosts) => {
    const map = new Map();
    const roots = [];
    for (const p of flatPosts) { p.children = []; map.set(p.id, p); }
    for (const p of flatPosts) {
        if (p.parent_id && map.has(p.parent_id)) map.get(p.parent_id).children.push(p);
        else roots.push(p);
    }
    return roots;
};
```

## First post + last page redirect
- Server always returns `firstPost` separately from `posts[]`
- Posts query excludes first post: `WHERE thread_id = ? AND p.id != ?`
- Client thread page: `?page=last` → fetch page 1 to get totalPages, then fetch actual last page
- First post highlighted with blue left border (`border-l-4 border-l-[var(--color-accent-info)] bg-[var(--color-bg-card)]`)
- Pagination: 9 posts per page + 1 first post = 10 visible

## Author highlighting
- First post of thread: blue left border + card background (NO 📢 badge, NO «Автор» text label)
- Reply target (when clicking «Ответить»): yellow left border (`border-l-[var(--color-accent-warning)]`), NOT on first post

## Closed threads
When `thread.is_closed`:
- Reply form hidden, replaced with 🔒 message
- ALL post actions hidden (reply button, edit ✎ button)
- Edit title ✎ button hidden for thread author
- Only «Открыть» button visible for thread author
- Server blocks: `PUT /forum/post/:id`, `PUT /forum/thread/:id`, `POST /forum/poll/vote` with «Тема закрыта»
- Poll vote buttons disabled (client-side via `thread.is_closed`)

## Polls
- Created with thread via `POST /forum/thread` with `poll: {question, options: string[]}`
- 2-10 options, validated server-side
- One vote per user (UNIQUE constraint on `forum_poll_votes(poll_id, user_id)`)
- Results returned with thread: `{poll: {id, question, options: [{id, option_text, votes_count}]}}`
- Vote response returns updated `{options, totalVotes}`
- Progress bars show percentage per option
- Vote buttons disabled when thread is closed

## MdToolbar component
Reusable at `client/src/components/ui/MdToolbar.tsx`. Props: `{textareaId: string}`.
Standard text symbols: **B** (bold), *I* (italic), ~~S~~ (strikethrough), **H** (heading), " (quote), • (list).
No link or code buttons (user preference — removed).
Works by reading `document.getElementById(textareaId)`, inserting markdown syntax at cursor:
- With selection: wraps selected text
- Without selection: inserts `prefix + placeholder + suffix`, selects placeholder for replacement
- Triggers `input` event on textarea for React state sync
Used in: ForumPage modal, ForumThreadPage reply form, PostCard edit form.

## Full quote on reply
When clicking «Ответить», the entire post content is quoted (was previously truncated to 300 chars — user preference: full quote).

## Quote stripping
When generating reply quote, nested `>` quotes are stripped via `stripQuotes()`:
```ts
function stripQuotes(text: string): string {
    return text.split('\n').filter(line => !line.startsWith('>')).join('\n').trim();
}
```

## Modal sizing
New thread modal: `width="640px"`, textarea `min-h-[200px]`.
Reply form textarea: `min-h-[150px]`.
