# Guild Chat Event Bus

## Architecture
Guild chat uses the `events.ts` EventBus to send messages only to guild members.

### Import
```ts
import { sendToGuild } from "../../events";
```

### Sending
```ts
const msg = { id, senderId, senderName, targetId: -guildId, content, createdAt };
sendToGuild(guildId, { type: 'message', message: msg });
```

`events.ts` → `emit({ type: 'sendToGuild', guildId, payload })` → `websocket.ts` listener → `_sendToGuild(guildId, payload)` iterates online users, checks guild membership, sends only to members.

### What NOT to use
```ts
// WRONG — sends to ALL connected users regardless of guild
broadcast('message', { message: msg });

// WRONG — broken ternary always sends to everyone
members.forEach(m => broadcast('message', { message: msg }, m.userId === userId ? undefined : undefined));
```

The `broadcast()` third param is `exceptUserId` (exclude ONE user), not a target filter. To exclude the sender, pass their userId. To send to specific users, use `sendToUser()`.

### Client filtering
Guild chat messages have `targetId: -guildId` (negative). The client's ChatPanel filters:
```ts
messages.filter(m => m.targetId !== null && m.targetId < 0)
```

Unread badge: `unreadGuild = messages with targetId < 0 && senderId !== userId && id > lastReadGuild`.

### File
- `server/src/routes/guild/guildChat.ts` — POST `/guild/chat`
- `server/src/events.ts` — `sendToGuild()` helper
- `server/src/websocket.ts` — `_sendToGuild()` listener
