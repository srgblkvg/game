# Client API pitfalls для MMO Arena

## useToast: `showToast`, не `.error()` / `.success()`

Хук `useToast()` возвращает `{ showToast }`, а не объект с методами `.error()`, `.success()`.

```tsx
// ❌ Неправильно
const toast = useToast();
toast.error('Сообщение');

// ✅ Правильно
const { showToast } = useToast();
showToast('Сообщение', 'error');
showToast('Сообщение', 'success');
showToast('Сообщение', 'info');
```

## Character endpoint

Эндпоинт для получения данных персонажа: `/api/character/me` (GET). Не `/api/character`.

## Тёмная/светлая тема: CSS-переменные, не Tailwind `dark:`

Проект использует CSS-переменные (`var(--color-text-primary)`, `var(--color-bg-primary)` и т.д.) для темизации. Tailwind-префикс `dark:` НЕ работает — нет класса `dark` на `<html>`.

Для кросс-темных стилей использовать переменные проекта:
```tsx
// ❌ Не работает
className="text-black dark:text-white"

// ✅ Работает
className="text-[var(--color-text-primary)]"
```

## Новые таблицы в PG: GRANT

После создания таблицы через `sudo -u postgres psql` нужно выдать права:
```sql
GRANT ALL ON table_name TO game;
GRANT ALL ON table_name_id_seq TO game;
```
Без этого `INSERT` падает с `permission denied`, хотя `SELECT` может работать.
