# Auction Price History

## Feature
Price history chart on auction lots (buy tab) and sell preparation tab. Chart.js shows 30-day price trend per item.

## Endpoint: GET /api/auction/price-history
Query params: `name`, `slot`, `rarity`, `upgradeLevel`
Returns: `{ points: [{ day, count, avg_price, min_price, max_price }] }`

## Key Details
- Groups by `DATE(createdAt::timestamp)` over last 30 days
- Matches on `itemName`, `itemData::jsonb->>'slot'`, `rarity_id`, `upgradeLevel`
- Uses `COALESCE(..., '')` for slot and `COALESCE(..., 0)` for rarity/upgradeLevel to handle NULL values from materials/runes without these fields

## Item Identity
Items are identified by: `name | slot | rarity_id | upgradeLevel`
- +0, +2, +3 are separate items
- Applied to: auction groups, group filter, similar lots, price history, client group clicks

## Client (AuctionPage.tsx)
- `PriceChart` component: lazy-loads on "📈 История цен" button click
- Uses `react-chartjs-2` with Chart.js core (CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler)
- Shows 3 lines: avg (yellow fill), min (green dashed), max (red dashed)
- Y-axis: compact notation (1.5k, 2.3M)
- X-axis: DD.MM format
- Resets on item change via `itemKey` useEffect

## Pitfalls
- Chart.js adds ~192KB to bundle — only import needed components
- Must handle `p.day` being full ISO timestamp (`2026-07-31T00:00:00.000Z`) — slice first 10 chars before formatting
- `rarity_display` may be null for old stones — use `getRarityDisplay` with fallback to `rarity_id`
