# Battle Stat Calculation Chain

How character stats are computed in PvP combat — full trace from DB to `currentStats()`.

## Data Flow

```
DB users row
  ├── baseS, baseA, baseD, baseM ──→ getBaseStats(user)
  ├── equipment (JSON)           ──→ JSON.parse → Record<slot, GameItem>
  ├── activeDrink, drinkUntil    ──→ getDrinkBonuses(user)
  └── collections COUNT          ──→ collectionBonus (count)

currentStats(base, equipment, drinkBonuses, collectionBonus):
  1. Sum equipment bonuses × (1 + upgradeLevel × 0.1)
  2. Sum equipment extras (crit, dodge, counter, fullBlock)
  3. Add drinkBonuses (if drink not expired)
  4. Add base stats
  5. Multiply by (1 + collectionCount/100)
  6. HP = s + a + d + m
```

## Source Files

| Layer | File | Function |
|-------|------|----------|
| Base stats | `db/helpers.ts` | `getBaseStats()` — reads baseS/A/D/M |
| Drink buffs | `game/drinks.ts` | `getDrinkBonuses()` — checks activeDrink + drinkUntil |
| Equipment | `game/stats.ts:47-62` | Iterates equipment, sums bonuses×upgrade, extras |
| Collection | `game/stats.ts:80-88` | Multiplier 1 + count/100 |
| Final stats | `game/stats.ts:38-103` | `currentStats()` combines all above |

## Where currentStats Is Called

| Context | File | Line | Args | Status |
|---------|------|------|------|--------|
| Character page | `routes/character.ts` | 78 | (base, equip, drinks) — collection applied manually after | OK |
| Battle (actual) | `routes/battle.ts` | 49-50 | (base, equip, drinks, collection) | OK |
| Battle (opponent display) | `routes/battle.ts` | 143 | (base, equip, **drinks**, collection) | Fixed 2026-06-14 |
| Arena opponent | `routes/arena.ts` | 38, 104 | (base, equip, **drinks**, collection) | Fixed 2026-06-14 |
| Equip/unequip | `routes/inventory.ts` | 25,31,70,75 | (base, equip) — HP calc only | OK |
| Tournament | `routes/tournament.ts` | 122 (loadPlayerForBattle) | (base, equip, **drinks**, collection) | Fixed 2026-06-14 |
| Guild war | `routes/guild.ts` | 870-871 | (base, equip, **drinks**, collection) | Fixed 2026-06-14 |

## Fixed Bug: Client Arena HP Missing Collection Bonus

**Found and fixed 2026-06-14.** In arena, the client recalculates the player's max HP locally via `calculateStats()` in `useBattleLogic.ts:73`, but the call omitted `collectionBonus`:

```typescript
// BEFORE (bug):
const pStats = calculateStats(character, (character as any).drinkBonuses);
// AFTER (fix):
const pStats = calculateStats(character, (character as any).drinkBonuses, (character as any).collectionCount || 0);
```

This caused visible discrepancy: character page showed correct HP (from server, with all bonuses), arena HP bar showed lower value (client calculation without collection). The actual battle uses server-side stats — only the arena UI display was wrong.

## Fixed Bug: Opponent Stats Missing Drink Bonuses

**Found and fixed 2026-06-14.** Three places passed `undefined` for opponent drinkBonuses:

1. **Battle response** (`battle.ts:143`): `undefined` → `defenderData.drinkBonuses`
2. **Arena saved opponent** (`arena.ts:38`): `undefined` → `getDrinkBonuses(saved)`
3. **Arena random opponent** (`arena.ts:104`): `undefined` → `getDrinkBonuses(opponent)`

Arena opponent queries updated to include `u.activeDrink, u.drinkUntil` so `getDrinkBonuses()` can resolve them.

## Client-Side calculateStats

`client/src/utils/stats.ts` mirrors the server's `currentStats()` logic. Accepts 3 args: `(char, drinkBonuses?, collectionBonus?)`.

Callers:
| Location | File | Collection passed? |
|----------|------|-------------------|
| Arena loadOpponent | `useBattleLogic.ts:73` | ✅ |
| Bestiary | `BestiaryPage.tsx:261` | ✅ |

## Design Decisions

### currentHp Is NOT Restored Before Battle

In `battle.ts:51`: `let hpA = attacker.currentHp ?? statsA.hp;`

The attacker enters battle with whatever `currentHp` is in the DB — NOT full max HP. This is intentional ("фишка проекта"): players must heal between fights (tavern/rooms/hpRegen). Do NOT change this.

### Opponent Drink Bonuses Are Visible

Arena and battle opponent stats include drink bonuses (`getDrinkBonuses(opponent)`). This was explicitly requested — visible opponent buffs are part of the game design.

To verify stat calculation for a specific user:

1. Get user from DB: `SELECT baseS, baseA, baseD, baseM, equipment, activeDrink, drinkUntil FROM users WHERE id = ?`
2. Count collections: `SELECT COUNT(*) FROM collections WHERE userId = ?`
3. Run through `currentStats()` manually or via node REPL
4. Compare with character page output

## Audit Checklist

When adding a new stat source:
- [ ] Does `currentStats()` receive it as a parameter?
- [ ] Is it passed in ALL call sites (character, battle, arena, inventory, tournament, guild war)?
- [ ] Does the client's `calculateStats()` mirror it?
- [ ] Are DB queries selecting the needed fields?
- [ ] Are arena opponent queries including `activeDrink, drinkUntil`?

## Fixed Bug: Tournament Missing Drink Bonuses

**Found and fixed 2026-06-14.** `loadPlayerForBattle()` in `tournament.ts` did not pass drink bonuses:
- Query missing `activeDrink, drinkUntil` fields
- `currentStats()` called with `undefined` for drinkBonuses
- Return object missing `drinkBonuses` field — `runBattle()` never received them

Fix:
```
// Query: added activeDrink, drinkUntil
// currentStats: undefined → drinkBonuses = getDrinkBonuses(u)
// Return: added drinkBonuses field
```

Tournament uses max HP (`currentHp: stats.hp`) — correct and intentional.

## Fixed Bug: Guild War Missing Drink Bonuses + Simplified Combat

**Found and fixed 2026-06-14.** War attack in `guild.ts:860-871`:
- Attacker/defender queries missing `activeDrink, drinkUntil`
- `currentStats()` called with `undefined` for drinkBonuses
- Used simplified combat loop (s+d only, no extra stats)

Fix: added drink fields to queries, switched to full `runBattle()` call (same as PvP/tournament). Guild war now uses max HP + all bonuses + full extra stats (crit/dodge/block/counter/stun/fullBlock).

## Fixed Bug: PvE Simplified Combat → Full Combat

**Found and fixed 2026-06-14.** `mobs.ts` used simplified combat (dodge+crit only). Rewritten to full PvP mechanics: dodge, crit, block, counter, stun, fullBlock. Player extra stats from equipment fully apply. Mobs have mobExtra = {0,0,0,0} but base formulas use mob stats. Same formulas as battle.ts.

## Deployment Pitfalls: async async and await in map

### async async → ReferenceError in compiled JS

The codebase has `async async (req, res)` on ~197 route handlers. With `tsx` (type-stripping), this is harmless. With `tsc` + `node dist/`, the compiled JS produces:
```js
router.post('/battle', async, async (req, res) => {
//                      ^^^^^ ReferenceError: async is not defined
```
**Fix**: global `sed -i 's/async async (/async (/g'` on all `.ts` files before `npx tsc`.

### await in .map() after PG rollback

PG migration added `await` to all `db.prepare()` calls. After SQLite rollback, some files (tournament.ts, guild.ts) retained `await` inside `.map()` callbacks. SQLite is synchronous — `await` is unnecessary but breaks when compiled by `tsc`:
```js
// tournament.ts:539
matches: matches.map((m: any) => ({
    player1Name: (await database_1.prepare(...).get(...))?.username
    //             ^^^^^ SyntaxError: await is only valid in async functions
}))
```
**Fix**: remove `await` from synchronous SQLite calls inside `.map()` callbacks, OR make callbacks async + wrap in `Promise.all()`. Prefer removing `await` for SQLite.
