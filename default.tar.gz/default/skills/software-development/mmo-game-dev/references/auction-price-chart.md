# Auction Price History Chart

Feature: interactive price history chart on auction lot cards and sell form.

## Backend: GET /auction/price-history

```ts
router.get('/auction/price-history', async (req, res) => {
    const name = req.query.name as string;
    const slot = req.query.slot as string;
    const rarity = parseInt(req.query.rarity as string) || 0;
    const upgLevel = parseInt(req.query.upgradeLevel as string) || 0;
    if (!name) return res.json({ points: [] });

    const rows = await db.query(`
        SELECT
            DATE(createdAt::timestamp) as day,
            COUNT(*) as count,
            AVG(price)::int as avg_price,
            MIN(price) as min_price,
            MAX(price) as max_price
        FROM auction_history
        WHERE itemName = ?
          AND COALESCE(itemData::jsonb->>'slot', '') = ?
          AND COALESCE((itemData::jsonb->>'rarity_id')::int, 0) = ?
          AND COALESCE((itemData::jsonb->>'upgradeLevel')::int, 0) = ?
          AND createdAt::timestamp > NOW() - INTERVAL '30 days'
        GROUP BY DATE(createdAt::timestamp)
        ORDER BY day ASC
    `, [name, slot, rarity, upgLevel]);
    res.json({ points: rows });
});
```

**Critical: COALESCE for slot** — materials and upgrade runes have no `slot` field in `itemData`. `->>'slot'` returns NULL, and `NULL = ''` is never true in SQL. Use `COALESCE(itemData::jsonb->>'slot', '') = ?` so NULL becomes empty string and matches.

**Critical: COALESCE for rarity_id** — same issue. Always wrap in `COALESCE(..., 0)`.

## Frontend: Chart.js Integration

### Dependencies
```bash
npm install chart.js react-chartjs-2
```

Minimal Chart.js registration (tree-shakeable):
```ts
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement,
  LineElement, Tooltip, Filler,
} from 'chart.js';
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);
```

### PriceChart Component Pattern

Key behaviors:
1. **Lazy load** — button triggers fetch, chart renders only after data arrives
2. **Reset on item change** — `useEffect` with `itemKey` resets state to null
3. **Min 2 data points** — chart requires ≥2 days to render

```tsx
function PriceChart({ item }: { item: any }) {
    const [points, setPoints] = useState<any[] | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const itemKey = `${item.name}|${item.slot || ''}|${item.rarity_id ?? 0}`;

    // Reset on item change — critical for sell-form item switching
    useEffect(() => {
        setPoints(null);
        setLoading(false);
        setError('');
    }, [itemKey]);

    const fetchHistory = useCallback(async () => {
        if (points !== null) return; // already loaded
        setLoading(true);
        try {
            const qs = new URLSearchParams({
                name: item.name || '',
                slot: item.slot || '',
                rarity: String(item.rarity_id ?? 0),
            });
            const res = await fetch(`/api/auction/price-history?${qs}`, { headers: getHeaders() });
            const data = await res.json();
            setPoints(data.points || []);
        } catch { setError('...'); }
        finally { setLoading(false); }
    }, [item.name, item.slot, item.rarity_id, points]);

    // State machine: null → show button; loading → spinner; error → message;
    // < 2 points → "not enough data"; ≥ 2 → render chart

    if (!points) return <button onClick={fetchHistory}>📈 История цен</button>;
    if (loading) return <div>Загрузка...</div>;
    if (error) return <div>{error}</div>;
    if (points.length < 2) return <div>Недостаточно данных для графика</div>;

    // Render Line chart...
}
```

### Date Labels

The `day` field from PostgreSQL `DATE()` cast arrives as full ISO timestamp: `2026-07-31T00:00:00.000Z`.

**Fix**: extract date-only part first, then format:
```ts
labels: points.map((p: any) => {
    const d = p.day.slice(0, 10).split('-'); // "2026-07-31" → ["2026","07","31"]
    return `${d[2]}.${d[1]}`; // "31.07"
})
```

Do NOT use `p.day.slice(5)` — breaks on `T00:00:00.000Z` suffix.

### Compact Y-Axis Labels

Use `k`/`M` instead of full `formatMoney` for readability:
```ts
y: {
    ticks: {
        callback: (v: any) =>
            v >= 1_000_000 ? `${(v/1_000_000).toFixed(1)}M` :
            v >= 1000 ? `${(v/1000).toFixed(1)}k` : v
    }
}
```

### Chart Options

Dark theme, 120px height, no x-grid:
```ts
const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${formatMoney(ctx.raw)}` } }
    },
    scales: {
        x: { ticks: { font: { size: 9 }, color: '#888' }, grid: { display: false } },
        y: { ticks: { font: { size: 9 }, color: '#888', callback: (v) => ... }, grid: { color: 'rgba(255,255,255,0.05)' } },
    },
};
```

Three datasets: average (yellow fill), min (green dashed), max (red dashed).

### Placement

- **Buy tab**: after `</Card>` closing div, before `</div>` (lot wrapper)
  ```
  </Card>       ← Card closes
  </div>        ← lot wrapper closes
  ```
  Add `<PriceChart item={item} />` BEFORE `</Card>`:
  ```
  <PriceChart item={item} />
  </Card>
  ```

- **Sell tab**: after `similarStats` block, only when `selectedItem` exists:
  ```tsx
  {selectedItem && <PriceChart item={selectedItem} />}
  ```

### Bundle Size

Chart.js adds ~190KB to the auction page bundle. Acceptable — only loaded when user visits auction.

## UpgradeLevel in Group Key

Items with different `upgradeLevel` are treated as **separate items** across the entire auction system:

**Server (`auction.ts`):**
```ts
// Group key (2 places: grouping + filter)
const key = `${lot.itemData?.name || ''}|${lot.itemData?.slot || ''}|${lot.itemData?.rarity_id ?? ''}|${lot.itemData?.upgradeLevel ?? 0}`;

// Similar lots filter
return d.name === name && ... && (d.upgradeLevel ?? 0) === upgLevel;
```

**Client (`AuctionPage.tsx`):**
```ts
// PriceChart itemKey for reset detection
const itemKey = `${item.name}|${item.slot || ''}|${item.rarity_id ?? 0}|${item.upgradeLevel ?? 0}`;

// Group click handler
const key = `${item.name || ''}|${item.slot || ''}|${item.rarity_id ?? ''}|${item.upgradeLevel ?? 0}`;

// Similar query: add upgradeLevel param
const qs = `...&upgradeLevel=${item.upgradeLevel ?? 0}&sellCount=...`;
```

Group cards show `+N` suffix: `{item.name}{(item.upgradeLevel ?? 0) > 0 && <span> +{item.upgradeLevel}</span>}`

## Lot Limits with Premium

Server check in `POST /auction/sell`:
```ts
const user = await db.one('SELECT money, inventory, premiumUntil FROM users WHERE id = ?', [userId]) as any;
const hasPremium = (user.premiumUntil || 0) > Math.floor(Date.now() / 1000);
const maxLots = hasPremium ? 20 : 10;
if (userLotCount >= maxLots) return res.status(400).json({ error: `Максимум ${maxLots} лотов` });
```

Note: the user query moved BEFORE the listing fee check to avoid duplicate DB calls. Premium check uses `premiumUntil > now` Unix timestamp comparison.

Client: `const maxSlots = character?.premium ? 20 : 10;`
PremiumPage bonus list: `📦 +10 слотов аукциона (всего 20)`
