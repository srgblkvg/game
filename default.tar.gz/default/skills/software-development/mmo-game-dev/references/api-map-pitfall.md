# API Response Mapping Pitfall

## Don't strip DB fields in .map()

When a DB query fetches extra fields (via JOINs), and you `.map()` the results to shape the API response, you MUST include all fields that the client needs. This is a recurring bug pattern.

### Example: Tournament participants

```js
// WRONG — strips guildName and guildId
participants: participants.map((p: any) => ({
    id: p.userId, username: p.username, goldenTicket: p.goldenTicket,
    snapshotStats: p.snapshotStats ? JSON.parse(p.snapshotStats) : null,
})),

// RIGHT — includes all needed fields
participants: participants.map((p: any) => ({
    id: p.userId, username: p.username, goldenTicket: p.goldenTicket,
    guildName: p.guildName, guildId: p.guildId,
    snapshotStats: p.snapshotStats ? JSON.parse(p.snapshotStats) : null,
})),
```

The DB query correctly fetches `g.name as guildName, u.guildId`, but the `.map()` silently drops them. The client then shows "[Без гильдии]" for everyone.

### Rule: audit every `.map()` in API responses

When you see `.map((p: any) => ({ ... }))` in a route handler, verify that ALL fields fetched by the SQL query are included. If the map is only reshaping a few fields, consider using `...p` spread as safety net, then override specific fields:

```js
participants: participants.map((p: any) => ({
    ...p,
    snapshotStats: p.snapshotStats ? JSON.parse(p.snapshotStats) : null,
})),
```

This preserves all DB fields and only transforms what's needed.
