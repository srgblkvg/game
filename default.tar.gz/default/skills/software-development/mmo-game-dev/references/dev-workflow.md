# Vite HMR on WSL

When running on WSL (files on /mnt/c/... NTFS mount), Vite HMR won't detect file changes because NTFS doesn't send inotify events to Linux. Fix: add polling to `client/vite.config.ts`:

```ts
server: {
  watch: {
    usePolling: true,
    interval: 500,
  },
},
```

After changing vite.config.ts, Vite must be restarted (kill PID on 5173, restart).

# Adding a new feature (full-stack pattern)

1. **Schema**: add table in `server/src/database/schema.ts` with `CREATE TABLE IF NOT EXISTS`
2. **API route**: create `server/src/routes/<feature>.ts` with Express Router
3. **Register**: import and `app.use('/api', <feature>Routes)` in `server/src/setupRoutes.ts`
4. **Client page**: create `client/src/pages/<Feature>Page.tsx`
5. **Route**: add lazy import + `<Route>` in `client/src/App.tsx`
6. **Restart server**: kill 3001 PID, `npx tsx src/index.ts` (tsx for live TypeScript, dist is often stale from different branch builds)
7. **Vite picks up changes** automatically with polling enabled

# Local dev server startup

Always use `npx tsx src/index.ts` from `server/` directory — the `dist/` folder from `npm run build` may be stale from a different branch or have TypeScript compilation errors that ts-node/tsx bypasses.

Kill existing processes first:
```bash
ss -tlnp | grep 3001 | grep -oP 'pid=\K\d+' | while read pid; do kill -9 $pid; done
ss -tlnp | grep 5173 | grep -oP 'pid=\K\d+' | while read pid; do kill -9 $pid; done
```

Start both:
```bash
cd /mnt/c/project/game/server && npx tsx src/index.ts &  # background
cd /mnt/c/project/game/client && npx vite --host 0.0.0.0 &  # background
```

In Hermes: use `terminal(background=true, notify_on_complete=false)` for long-lived servers.

# Database seeding

- `server/src/database/schema.ts` creates tables (CREATE TABLE IF NOT EXISTS)
- `server/src/database/migrations.ts` runs migrations on startup
- `server/src/database/seed.ts` populates: rarities, items (189), jobs (20), mobs (30), craft_items (14), craft_recipes (20), upgrade_chances (70)
- Floors and actions_config are NOT in seed — create via admin API
- If copying DB from VPS: `scp root@194.226.142.237:/opt/game/server/game.db /mnt/c/project/game/server/game.db`
- Schema changes require deleting game.db and letting server recreate it (or manual migration)

# Admin API for seeding game data

Login to get token:
```bash
TOKEN=$(curl -s -X POST http://localhost:3001/api/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")
```

Create floors:
```bash
curl -s -X POST http://localhost:3001/api/admin/floors -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"name":"Склеп","background":"/images/floors/crypt.webp","sort_order":1}'
```

Create actions (use section "world" and "castle"):
```bash
curl -s -X POST http://localhost:3001/api/admin/actions -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"section":"world","title":"Бестиарий","subtitle":"Охота на монстров","icon":"game-icons:bestial-fangs","path":"/bestiary","cost":0,"sort_order":1}'
```

Create test user (registration requires email verification — bypass via SQL):
```bash
cd /mnt/c/project/game/server && node -e '
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const db = new Database("game.db");
const pwhash = bcrypt.hashSync("testtest1!", 10);
const now = Math.floor(Date.now()/1000);
db.prepare("INSERT INTO users (username, passwordHash, email, emailVerified, currentHp, lastHpUpdate, level, gender, exp, money, lastLoginAt) VALUES (?,?,?,1,50,?,1,'\''male'\'',0,100,?)").run("test", pwhash, "test@test.com", now, now);
db.close();
'
```
