# Achievements System

## Overview

11 tracks, 5 tiers each (🥉🥈🥇💎👑). Config: `server/src/game/achievements.ts` → `ACHIEVEMENT_TRACKS`.

## Database

```sql
CREATE TABLE user_achievements (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  track TEXT NOT NULL,
  progress INTEGER DEFAULT 0,
  highest_tier INTEGER DEFAULT 0,
  achieved_at JSONB DEFAULT '{}',
  PRIMARY KEY (user_id, track)
);
ALTER TABLE users ADD COLUMN total_income INTEGER DEFAULT 0;
```

## API

- `GET /api/achievements` — all tracks (with progress, tiers, achieved_at)
- `GET /api/achievements/:userId` — public, returns `{ achievements: [...], score: N }`
- `checkAchievement(userId, trackKey, increment?)` → `{ newTier, trackName, tierIcon, tierName } | null`
- `trackIncome(userId, amount)` → updates `total_income` + checks `income` achievement

## Tracking (where to call)

| Track | File | Condition |
|-------|------|-----------|
| pve_wins | mobs.ts | `playerWon` |
| pvp_wins | battle.ts | `attackerWins` AND `!attackerWins` (BOTH sides!) |
| craft | craft.ts | After craft created + both upgrade paths (3 call sites) |
| training | training.ts | After training UPDATE |
| casino | casino.ts | 4 places: start/stand/double/surrender |
| income | mobs.ts, battle.ts | Via `trackIncome(userId, amount)` |
| massacre | massacre.ts | When killing in massacre (`action_type === 'death'`) |
| collection | collections.ts | After INSERT INTO collections |
| auction | auction.ts | 3 points: expired lot, buyout, partial buy (all seller-side) |
| tournament | tournament.ts | Both `finishTournament` AND `finishTournamentTx` (winner only) |
| level | helpers.ts → applyExp | When `gained > 0`, uses `setAchievementProgress` (absolute) |

## setAchievementProgress — для абсолютных значений

Для треков, где progress = текущее значение (не инкремент), используй:
```ts
// helpers.ts → applyExp:
if (gained > 0) {
    import('../routes/achievements').then(m =>
        m.setAchievementProgress(userId, 'level', level)
    ).catch(() => {});
}
```

`setAchievementProgress` делает `SET progress = $3` вместо `progress + $4` и пересчитывает `highest_tier`.

## Backfill

Historical recalculation via SQL with `INSERT ... ON CONFLICT DO UPDATE` + CASE tier recalculation.
**Collection:** read from `collections` table, NOT from inventory JSON.

## UI: AchievementsBlock

`client/src/components/AchievementsBlock.tsx`:
- `<Card className="mt-4 w-full">` — same style as StatAllocation/BuffsBlock
- Collapsed by default, 5 rows + scroll (`max-h-[11.5rem] overflow-y-auto pr-1`)
- Icons: `w-5 text-center flex-shrink-0` (even alignment)
- Numbers: `fmtNum()` — 1000→"1к", 1M→"1М"
- Tooltips via `createPortal` → `document.body` (`fixed z-[100]`) — avoids overflow clipping
- Desktop: `onMouseEnter/Leave`. Mobile: long press 500ms, NO `e.preventDefault()` on touchstart (spams console)
- Profile: score only `🏆 Достижения — N очк.`

## Guild Quest Persistence

Quests were regenerating on every page load. Fix:
1. `ALTER TABLE guilds ADD COLUMN quest_options JSONB DEFAULT '[]'`
2. GET /guild/quest: check `quest_options` → if non-empty, return stored (don't regenerate)
3. If empty → generate 3 options, save to `quest_options`, return
4. POST /guild/quest/take → clear `quest_options = '[]'`
