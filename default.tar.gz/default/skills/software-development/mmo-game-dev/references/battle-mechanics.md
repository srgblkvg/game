# Battle Mechanics

## Formulas (актуальные, 2026-06-16)

### Chances
- **Crit chance:** `min(0.8, M/(M+150) + extraCrit/300)`
- **Dodge chance:** `max(0, A/(A+150) × (1 − atkM/(atkM+100)) + min(0.5, extraDodge/300))`
- **Block chance:** `min(1, D/(D+150) + extraFullBlock/300)`
- **Full block chance:** `extraFullBlock / 300`
- **Counter chance:** ratio-based `(M_def+A_def)/(M_def+A_def+M_atk+D_atk) × 0.5 + extraCounter/300`, capped at 0.5
- **Stun chance:** ratio-based `(S_atk+M_atk)/(S_atk+M_atk+S_def+D_def) × 0.3`

### Damage
- **Base damage:** `S ≤ lvl → dmg = S`; `S > lvl → dmg = lvl + random(0, S−lvl+1)`
- **Crit multiplier:** `1.5 + 0.5 × M/(M+50)` — (50, не 150 — эта формула не менялась)
- **Block reduction:** `min(0.75, 0.5 × D/max(1, S_attacker))`

### Key numbers
- Extra stats (crit/dodge/counter/fullBlock): **0.33% per point** (divisor = 300)
- Base stat contribution: divisor = **150** (was 50) — шансы больше зависят от шмота и коллекций
- Collection bonus: `1 + count/100` (count = rows in `collections` table)

## DB patterns (pg-native)
- Always use `?` placeholders in SQL, NOT `$1` directly. `pgParams()` converts `?` → `$1`, `$2`...
- `pgLowerIdentifiers()` lowercases camelCase identifiers in SQL before execution
- `camelRows()` adds camelCase keys to result rows — suffix list must be kept current

## BattleSim (скрытая страница)
- Route: `/battle-sim` (no link in navigation)
- API: `GET /api/players/search?q=...` — autocomplete, `GET /api/players/:id/loadout` — full stats, `POST /api/battle-sim` — run N battles
- Autocomplete via `ILIKE` on `users.username`
- `currentStats()` now returns `drinks` and `collection` fields (added 2026-06-16)
