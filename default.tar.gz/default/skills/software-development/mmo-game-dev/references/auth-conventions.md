# Auth conventions

## req.userId, not req.user

The auth middleware (`middleware/auth.ts`) sets `req.userId = decoded.userId`, NOT `req.user`.

When writing server routes that need the current user's ID, always use:
```ts
const userId = req.userId;
```

Never use `req.user?.id` — it will always be `undefined` and cause 401 errors.

## Email lowercasing (PG case-sensitive!)

PG `WHERE email = ?` — **регистрозависимо**. Всегда lowercas'и:
```ts
const email = rawEmail.toLowerCase().trim();
```
Применять в: register, verify-email, resend-code, login (если содержит @), register-guest.

## Сравнение кодов подтверждения
```ts
if (String(user.emailCode) !== String(code)) { ... }
```
Явное приведение защищает от PG-драйвера, который может вернуть число.

## Проверка пароля на клиенте
Валидировать до отправки: длина ≥8, цифра, спецсимвол.
Zod-схема на сервере дублирует проверку, но клиент должен давать понятную ошибку сразу.
Текст подсказки: «Минимум 8 символов, цифра и спецсимвол».
