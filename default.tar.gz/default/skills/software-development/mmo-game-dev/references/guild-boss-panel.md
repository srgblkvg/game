# Guild Boss — Cooldown & Right Panel Patterns

## Personal Cooldown After Attack

After a guild boss attack, the right panel (QuestsBlock) must update the cooldown without page reload.

### Server: send personal WS update to attacker

```ts
// After boss attack, broadcast guild update to all members
sendToGuild(user.guildid, { type: 'guild_boss_update', data: { bossHp, bossMaxHp, ... } });

// AND send personal cooldown to just the attacker
const remainingCd = Math.max(0, BOSS_COOLDOWN - (now - (member.lastbossattackat || 0)));
sendToUser(userId, { type: 'guild_boss_update', data: { cooldownRemaining: remainingCd, bossHp, bossMaxHp } });
```

`sendToGuild` goes to all guild members, `sendToUser` goes to one user. Both use `type: 'guild_boss_update'` — the client listens for this event in ChatContext.

### Client: QuestsBlock listens for `guildBossUpdate`

```ts
window.addEventListener('guildBossUpdate', handler);
// handler: setBossCd(d.cooldownRemaining || 0);
```

### Navigation on cooldown

Right panel boss section should ALWAYS navigate to boss tab, even on cooldown:
```tsx
// BEFORE (bug): onClick={() => bossCd <= 0 && navigate('/guild?tab=4')}
// AFTER (fix): onClick={() => navigate('/guild?tab=4')}
```

## RightSidebar Positioning

Button and panel are `position: fixed` with hardcoded `top` values. When header height changes (e.g. adding faction badge), update:

- Button: `top-[135px]` (was 115px)
- Panel: `top-[140px]` + `h-[calc(100vh-140px-40px)]` (was 120px)

These values should match `header height + some padding`.
