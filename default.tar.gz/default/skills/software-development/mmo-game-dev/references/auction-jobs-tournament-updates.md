# Auction & Jobs Updates (2026-06-21)

## Auction Sort — Items User Hasn't Bid On First
When sorting by price (bid), use `CASE WHEN` to put items where the user hasn't placed a bid at the top:
```sql
ORDER BY CASE WHEN l.currentBidderId = ${userId} THEN 1 ELSE 0 END, 
  COALESCE(l.currentBid, l.startPrice) ASC
```
Items where user has NOT bid → sort value 0 → appear first.
Items where user HAS bid → sort value 1 → appear after.

## Job Reward Scaling with Level
Reward range: `random(rewardMin, rewardMax × level)`
```ts
let reward = Math.floor(Math.random() * (job.rewardMax * (user.level || 1) - job.rewardMin + 1)) + job.rewardMin;
const scaledMax = job.rewardMax * (user.level || 1);
```

Stored in activeJob JSON with `rewardMax: scaledMax`.

## Premium Bonus Display
- Server calculates `premiumBonus` at job start
- Server sends `premiumBonus` in response: `res.json({ ..., premiumBonus, ... })`
- Client MUST include `premiumBonus: result.premiumBonus || 0` in setCharacter activeJob
- `reward` already INCLUDES premium bonus; `premiumBonus` is just for display
- Without this, premium bonus appears with delay (from serverTick)

## Auto-cancel Empty Tournaments
In `autoAdvance()`, when registration ends:
```ts
const pCount = (await db.one('SELECT COUNT(*) as cnt FROM tournament_participants WHERE tournamentId = ?', [tournamentId]) as any).cnt;
if (pCount < 2) {
  await db.run('UPDATE tournaments SET status = ?, completedAt = ? WHERE id = ?', ['cancelled', now, tournamentId]);
  return;
}
```
