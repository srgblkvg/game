# Battle HP & Notification Patterns

## HP/0 Bug — PvE Death → PvP Full Heal

**Root cause**: `game/battle.ts` `runBattle()` had:
```js
let hpA = (attacker.currentHp != null && attacker.currentHp > 0) ? attacker.currentHp : statsA.hp;
```
When `currentHp === 0` (dead after PvE), `> 0` is false → falls back to `statsA.hp` (max HP).
Dead player enters PvP at full health.

**Fix**: Remove `> 0` check:
```js
let hpA = (attacker.currentHp != null) ? attacker.currentHp : statsA.hp;
```
Now 0 HP stays 0. Added validation in `routes/battle.ts`: if HP ≤ 0, return 400.

**Affected files**:
- `server/src/game/battle.ts` — both `hpA` and `hpD` lines
- `server/src/routes/battle.ts` — early validation before battle

## Red Dot on Summary — Only When Attacked

**Context**: `Header.tsx` shows a red dot on the History ("Сводка") button for new battles.
Previously it lit up for ANY new battle (attack or defend).

**Fix**: Filter battles to only those where user is defender:
```js
const newDefeats = battles.filter((b: any) => b.defenderId === user.id);
```

When the user attacks someone, the summary dot should NOT light up — only when they were attacked.

**File**: `client/src/components/Header.tsx` — `checkForNewBattles()`

## Auction Cancel Restriction

Cannot remove a lot from auction if any bid has been placed:
```js
if (lot.currentBidderId) return res.status(400).json({ error: 'Нельзя снять лот, на который уже сделана ставка' });
```

Previously allowed cancellation with active bids, which refunded the bidder's money
and returned the item to seller — exploitable.

**File**: `server/src/routes/auction.ts` — `/auction/cancel`
