# Frontend UI Patterns

## Theming
Project uses CSS custom properties, NOT Tailwind `dark:` prefix (`dark:` does NOT work here).
Key variables: `--color-text-primary`, `--color-bg-primary`, `--color-bg-secondary`, `--color-bg-input`,
`--color-accent-primary`, `--color-accent-danger`, `--color-accent-success`, `--color-accent-info`,
`--color-accent-warning`, `--color-border-light`, `--color-border-default`, `--color-text-accent`, `--color-text-muted`, `--color-text-secondary`.
Use as: `className="text-[var(--color-text-primary)]"` etc. Never hardcode Tailwind color names for theme-aware elements.

## Toast notifications
`useToast` returns `{ showToast }`. Signature: `showToast(message: string, type?: 'error'|'success'|'info'|'warning')`.
Do NOT call `toast.error(...)` — the hook returns `{ showToast }`, not `toast`.
Import: `import { useToast } from '../contexts/ToastContext';`

## Character endpoint
Use `GET /api/character/me` (NOT `/api/character` — returns 404).

## Game buttons
- Primary actions: `variant="danger"` (red), `size="md"`
- Secondary actions: `variant="secondary"`, `size="sm"`
- Layout: buttons on the right, inline with inputs (flex gap-2 items-end)

## Chat Panel Behavior
Chat is at `client/src/components/chat/ChatPanel.tsx`. Key rules:
- **Collapse triggers**: only navigation (`location.pathname` change) and RightSidebar opening (via `window.dispatchEvent(new CustomEvent('closeChatPanel'))`)
- **Do NOT** collapse on click/scroll/touch outside panel — this was the old aggressive behavior that frustrated users
- **Overlay**: `fixed inset-0 z-[999] bg-black/40` — provides visual darkening but NO `onClick` handler (chat closes only via header toggle, nav, or RightSidebar)
- RightSidebar sends `closeChatPanel` on open: `if (!open) window.dispatchEvent(new CustomEvent('closeChatPanel'))`
- Chat listens: `window.addEventListener('closeChatPanel', handler)`

## Replace browser dialogs with custom popups
Never use `confirm()` or `alert()` — they look foreign and break mobile UX.

### Confirm popup pattern (see GuildPage.tsx)
```tsx
const [confirmPopup, setConfirmPopup] = useState<{ message: string; onConfirm: () => void } | null>(null);

// Usage: instead of if (!confirm('...')) return;
setConfirmPopup({
    message: 'Покинуть гильдию?',
    onConfirm: async () => {
        setConfirmPopup(null);
        // ... action
    }
});

// Render:
{confirmPopup && (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center">
        <div className="absolute inset-0 bg-black/50" onClick={() => setConfirmPopup(null)} />
        <div className="relative bg-[var(--color-bg-card)] border border-[var(--color-border-default)] rounded-xl p-6 max-w-sm w-full mx-4 shadow-2xl">
            <p className="text-sm mb-4">{confirmPopup.message}</p>
            <div className="flex gap-2 justify-end">
                <Button variant="secondary" size="xs" onClick={() => setConfirmPopup(null)}>Отмена</Button>
                <Button variant="danger" size="xs" onClick={confirmPopup.onConfirm}>Подтвердить</Button>
            </div>
        </div>
    </div>
)}
```

### Animated progress popup pattern (see CraftPage/CraftPopup.tsx)
For actions with delayed result (craft, upgrade):
- `useRef` for `onDone` to avoid useEffect re-triggering
- `done` guard flag to prevent duplicate timeouts
- Three-phase: `fill` → `result` → `done` (returns null)
- Progress bar fills ~2s; success to 100%, fail to 45%
- Result shown 1.5s then auto-dismisses
- On success, acquire popup fires AFTER popup closes (via onDone callback)

## Server-side guild war restrictions
`server/src/routes/guild.ts` — `POST /guild/leave` checks `isGuildAtWar(member.guildId)` and returns 400 if guild is in pending/active war.
