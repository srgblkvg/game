# Покер на костях (Dice Game)

Добавлен 2026-07-23.

## Файлы
- Сервер: `server/src/routes/dice.ts`
- Клиент: `client/src/components/DiceGame.tsx` (переиспользуемый, без шапки)
- Клиент: `client/src/pages/DicePage.tsx` (отдельная страница-обёртка)
- БД: таблица `dice_games`

## Механика
- Ставка 10 сер., 5 кубиков, до 2 перебросов
- Игрок выбирает какие кубики оставить (клик), остальные перебрасываются
- Комбинации: Покер ×50, Каре ×20, Фулл-хаус ×10, Стрит ×7, Сет ×4, Две пары ×2, Пара ×1

## Интеграция
- CasinoPage: таб 🎲 Кости с `<DiceGame onBalanceChange={loadBalance} />`
- Статистика: общая с блэкджеком через `casino_games_played/won/lost`
- Навигация: `actions_config` запись с section='casino', path='/dice'

## DB
```sql
CREATE TABLE dice_games (
  id SERIAL PRIMARY KEY, user_id INT, entry_fee INT DEFAULT 10,
  dice TEXT DEFAULT '[]', rerolls INT DEFAULT 0, combo TEXT,
  payout INT DEFAULT 0, status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```
⚠️ После CREATE TABLE: `GRANT ALL ON dice_games TO game; GRANT ALL ON SEQUENCE dice_games_id_seq TO game;`

## Попадавшие баги
1. **Permission denied** — таблица создана от `postgres`, сервер ходит под `game` → нужен GRANT
2. **RETURNING id дубликат** — `db.run()` сам добавляет `RETURNING id` к INSERT'ам, в запросе писать не надо
3. **lastInsertRowid, не lastID** — `db.run()` возвращает `{ lastInsertRowid }`, не `{ lastID }`
4. **toast.error → showToast** — `useToast()` возвращает `{ showToast }`, вызов: `showToast(msg, 'error')`
5. **fetch('/api/character') → 404** — правильный URL: `/api/character/me`
