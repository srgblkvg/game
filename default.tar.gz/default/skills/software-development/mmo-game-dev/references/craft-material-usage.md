# CraftPage: materialUsage sync pitfalls

## displayInventory derived state

CraftPage uses a `useMemo`-derived `displayInventory` that filters `character.inventory` by:
1. `slotIds` — IDs of non-craft items currently in craft slots (excluded from display)
2. `materialUsage` — for craft items, remaining = `item.count - (materialUsage[item.id] || 0)`

```ts
const displayInventory = useMemo(() => {
    const slotIds = new Set(craftSlots.filter(s => s !== null && !isCraftItem(s)).map(s => s.id));
    return character.inventory
        .filter(item => !slotIds.has(item.id))
        .map(item => {
            if (isCraftItem(item)) {
                const used = materialUsage[item.id] || 0;
                const remaining = item.count - used;
                return remaining > 0 ? { ...item, count: remaining } : null;
            }
            return item;
        })
        .filter(Boolean);
}, [character.inventory, craftSlots, materialUsage]);
```

## Rule: ALL craft item paths must uniformly track materialUsage

Every path that adds/removes a craft item to/from `craftSlots` MUST increment/decrement `materialUsage`:

| Action | materialUsage | craftSlots |
|--------|--------------|------------|
| Add material to slot | `+1` | `{...item, count:1}` |
| Remove material from slot | `-1` | `null` |
| Add upgrade stone to slot | `+1` | `{...item, count:1}` |
| Remove upgrade stone from slot | `-1` | `null` |
| Add equipment to slot | (n/a) | `item` |
| Remove equipment from slot | (n/a) | `null` |

## Bug: upgrade stones excluded from materialUsage tracking

**Original code** had guards like `if (item.itemType !== 'upgrade')` on materialUsage operations:

```tsx
// handleSlotClick — БЫЛО
if (isCraftItem(item)) {
    if (item.itemType !== 'upgrade') {  // ← БАГ! Камни не decrement
        setMaterialUsage(prev => { ... n[item.id]-- ... });
    }
}

// handleDropOnSlot — БЫЛО
if (isCraftItem(item) && item.itemType !== 'upgrade') {  // ← БАГ! Камни не трекаются
    setMaterialUsage(prev => ({ ...prev, [item.id]: (prev[item.id] || 0) + 1 }));
    setCraftSlots(prev => { ... n[index] = { ...item, count: 1 } ... });
} else {
    setCraftSlots(prev => { ... n[index] = item ... });  // ← Весь стак!
}
```

**Symptoms:**
1. Removing upgrade stone from slot → stone disappears from inventory (remaining = count - 1 = 0)
2. Dragging stack of stones → entire stack goes to one slot (no `count: 1` wrapping)

**Fix:** Remove all `itemType !== 'upgrade'` guards. ALL `isCraftItem(item)` paths uniformly track `materialUsage` and use `{ ...item, count: 1 }`.

## Drag-drop: count:1 for all craft items

```tsx
// handleDropOnSlot — СТАЛО
if (isCraftItem(item)) {
    const used = materialUsage[item.id] || 0;
    if (used >= getOriginalCraftItemCount(item.id)) return;
    setMaterialUsage(prev => ({ ...prev, [item.id]: (prev[item.id] || 0) + 1 }));
    setCraftSlots(prev => { ... n[index] = { ...item, count: 1 } ... });
} else {
    setCraftSlots(prev => { ... n[index] = item ... });  // equipment only
}
```
