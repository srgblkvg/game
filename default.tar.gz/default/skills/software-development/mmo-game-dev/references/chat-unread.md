# Chat Unread Notifications — lastReadId localStorage Pattern

## Problem

After page refresh, chat notification indicators blink for messages the user already saw — because the client doesn't persist which messages have been read.

## Solution: `lastReadId` in localStorage

Store the ID of the last read message per chat type:

```ts
const LS_GENERAL = 'chatLastReadGeneral';
const LS_GUILD = 'chatLastReadGuild';
const lsPrivate = (uid: number) => `chatLastReadPrivate_${uid}`;

const getLastRead = (key: string): number => parseInt(localStorage.getItem(key) || '0') || 0;
const saveLastRead = (key: string, id: number) => { if (id > getLastRead(key)) localStorage.setItem(key, String(id)); };
```

## Computing unread counts

ALWAYS recompute from scratch on every `messages` change — discard the initial/incremental split approach:

```tsx
useEffect(() => {
    if (messages.length === 0) return;
    const lastReadGeneral = getLastRead(LS_GENERAL);
    const lastReadGuild = getLastRead(LS_GUILD);
    setUnreadGeneral(messages.filter(m => m.senderId !== userId && m.targetId === null && m.id > lastReadGeneral).length);
    setUnreadGuild(messages.filter(m => m.senderId !== userId && m.targetId !== null && m.targetId < 0 && m.id > lastReadGuild).length);
    const priv = new Map<number, number>();
    for (const m of messages) {
        if (m.senderId === userId) continue;
        if (m.targetId !== null && m.targetId > 0 && m.targetId === userId) {
            const lastRead = getLastRead(lsPrivate(m.senderId));
            if (m.id > lastRead) priv.set(m.senderId, (priv.get(m.senderId) || 0) + 1);
        }
    }
    setUnreadPrivate(priv);
}, [messages, userId]);
```

O(n) where n ≤ 300 messages. Simple, correct, survives page refresh.

## Marking as read

When user opens a tab or closes the chat panel, update lastReadId:

```tsx
const markRead = useCallback((type: 'general' | 'guild' | number) => {
    const filtered = type === 'general'
        ? messages.filter(m => m.targetId === null)
        : type === 'guild'
            ? messages.filter(m => m.targetId !== null && m.targetId < 0)
            : messages.filter(m => (m.senderId === userId && m.targetId === type) || (m.senderId === type && m.targetId === userId));
    const maxId = filtered.length > 0 ? Math.max(...filtered.map(m => m.id)) : 0;
    if (type === 'general') { saveLastRead(LS_GENERAL, maxId); setUnreadGeneral(0); }
    else if (type === 'guild') { saveLastRead(LS_GUILD, maxId); setUnreadGuild(0); }
    else { saveLastRead(lsPrivate(type), maxId); setUnreadPrivate(p => { const n = new Map(p); n.delete(type); return n; }); }
}, [messages, userId]);

// When panel closes
useEffect(() => {
    if (!isPanelOpen && messages.length > 0) {
        if (guildChatActive) markRead('guild');
        else if (privateChatWith !== null) markRead(privateChatWith);
        else markRead('general');
    }
}, [isPanelOpen]);
```

## Pitfalls

- **Initial/incremental split approach is buggy**: the initialScanDone ref, the isPanelOpen reset logic, and the incremental last-message check had timing issues that caused false unread counts after page refresh. Full recompute is simpler and reliable.
- **Don't sink into the initial+incremental trap again**: the ref mechanism, the conditional scan-once logic, the `messages.length` dependency that only checks the last message — all of this was replaced with a single `useEffect` dependency on `[messages, userId]` that recomputes everything.
