# Battle Speed & Premium Skip

## Default speed

All battles (PvP and PvE) run at **x2 speed always**. The x1/x2 toggle button has been removed.

- `useBattleLogic.ts`: `useState(2)` for speed, `useRef(2)` for speedRef
- `BestiaryPage.tsx`: `useState(2)` for speed, `useRef(2)` for speedRef

## Premium-only skip

The "Пропустить" button is only visible when the player has active premium:

```tsx
{(character as any)?.premium?.until > serverTime && (
  <Button variant="secondary" size="sm" onClick={handleSkip}>Пропустить</Button>
)}
```

This check is done in both:
- `ArenaPage.tsx` (PvP) — uses `Math.floor(Date.now()/1000)`
- `BestiaryPage.tsx` (PvE) — uses `serverTime` from `useServerTime()` hook

## Premium field

Premium on character object: `character.premium?.until` — a Unix timestamp (seconds). Premium is active when this is in the future.
