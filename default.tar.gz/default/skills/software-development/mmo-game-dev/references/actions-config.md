# actions_config Pitfall

Every action card on the main page (Мир / Площадь) comes from the `actions_config` table. If a new action is added to the client code but the row is missing from the DB, the card simply won't appear — no error, no 404, just silence.

## Must-do after adding a new action

```sql
-- Local
PGPASSWORD=game123 psql -h localhost -U game -d game -c "
INSERT INTO actions_config (section, title, subtitle, icon, path, cost, sort_order)
SELECT 'world', 'Название', 'Подзаголовок', 'game-icons:icon-name', '/path', 100, 8
WHERE NOT EXISTS (SELECT 1 FROM actions_config WHERE path = '/path');
"

-- Production
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"
INSERT INTO actions_config (section, title, subtitle, icon, path, cost, sort_order)
SELECT 'world', 'Название', 'Подзаголовок', 'game-icons:icon-name', '/path', 100, 8
WHERE NOT EXISTS (SELECT 1 FROM actions_config WHERE path = '/path');
\""
```

## Verify

```bash
curl -s https://mmoarena.ru/api/actions | python3 -c "import sys,json; [print(c['title'],c['path']) for c in json.load(sys.stdin)]"
```

## Card layout rule

Cards in the same grid MUST be the same height. No extra lines. Patterns that add height:
- Extra `<p>` for price — put price on button text instead
- Long subtitle wrapping — keep under ~20 chars
- Counter badges — put inline in subtitle, not as separate row
