# Collections, Sets & Battle — New Patterns (2026-07-25)

## Collection System

### Key format: name + slot + rarity_id
- `collection_set_items` table has `rarity_id` column
- Collections key: `${itemName}|${slot}|${rarity_id}`
- Server JOIN: `c.userId = ? AND c.itemName = si.item_name AND c.slot = si.slot AND c.rarity_id = si.rarity_id`
- Without rarity_id in key, duplicate name+slot items (e.g. "Щупальцевые захваты" rarity 2 and 6) cause collection conflicts

### Completed set bonuses
- Each fully collected set gives bonus_percent (1-5%) added to total collection bonus
- Query in `buildPlayerStats()` and `character.ts`:
```sql
SELECT COALESCE(SUM(cs.bonus_percent), 0) as total
FROM collection_sets cs WHERE cs.id IN (
  SELECT si.set_id FROM collection_set_items si
  LEFT JOIN collections c ON c.userId=? AND c.itemName=si.item_name AND c.slot=si.slot AND c.rarity_id=si.rarity_id
  GROUP BY si.set_id HAVING COUNT(*)=COUNT(c.id)
)
```
- Total bonus = itemCount + sum(completedSetBonuses)
- Applied via `scaleKeep(st, 1 + total/100)`

### Collection sets structure
- 7 rarity sets (Хлам 1%, Обычные 1%, Необычные 2%, Редкие 2%, Эпические 3%, Легендарные 4%, Мифические 5%)
- 8 set armor sets (Берсерк/Буревестник/Гладиатор/Дуэлянт/Жнец/Крушитель/Отшельник/Страж) — 5% each
- 1 artifact set — 5%
- Total: 225 items (189 base + 32 set + 4 artifact)

## Sets & Artifacts

### Set items (rarity_id=6)
- **ONLY drop from Ад floors** (Врата Бездны, Огненные чертоги, Тронный зал, Ледяная бездна, Престол падших)
- **sellable=false** — not buyable from shop
- Excluded from random_item craft (craft.ts: `AND (i.extra IS NULL OR i.extra::text NOT LIKE '%"set"%')`)
- Set bonuses in `currentStats()`: hermitRegen, rageDmg, blockPen, vampirism, execute, counterOnHit, alwaysFirst, poisonOnHit, luckBoost

### Artifact items (rarity_id=7)
- **Craft only** — 4 recipes, category "Артефакты", result_type='item'
- Recipes: 3× rare resource + 2× Слеза вечности, 20000💰, 60% chance
- **NOT in shop** (sellable=false)
- Requires rarity 7 in `rarities` table: 'Артефакт', '#ff4444'

### Отшельник 2pc fix
- Set bonus was "+10% реген HP" (wrong) → "+100% реген HP (вне боя)" (correct)
- Was just a string in setBonuses, now actually applied via `hpRegen.ts`: `if (user.hermitRegen) regenRate *= 2`
- Added `hermitRegen?: boolean` to CharStats interface

## Battle Engine Unification

### PvE (mobs.ts)
- Uses `runBattle()` from battle.ts (replaced simplified loop)
- Mob wrapped as defender with: id=-(mob.id), base from mob.atk/agi/def/mst, equipment={}
- Import: `import { runBattle } from '../game/battle'`

### Massacre (massacre.ts)
- Uses `runTurn()` from battle.ts (replaced runTurnLocal)
- `runTurn` and `TurnContext` exported from battle.ts
- Import: `import { runTurn, TurnContext } from './battle'`
- Steps collected via local array: `const steps: BattleStep[] = []; const result = runTurn(ctx, step => steps.push(step));`

### Poison DoT
- Changed from instant damage to DoT over 3 turns
- Tracks `poisonOnA/poisonOnD: { damage, turnsLeft }` in runBattle
- Applied at start of each turn via `applyPoison()` helper
- Resilience reduces turns: `Math.max(1, Math.round(3 * (1 - resiliencePct/100)))`
- Resilience description: "-30% длительность яда / -30% шанс быть оглушенным"

## Drop System

### Normalization fix
- Loot table chances don't always sum to 1 → `selectedRarity` defaulted to 0 (junk)
- Fix: `selectedRarity = -1`, skip material drop if no match (`if (selectedRarity >= 0)`)

### Drop chance reduction
- Legendary/mythic loot_chances reduced ~3× in DB
- Item drop table (getItemDropTable) also reduced ~3×
- Legendary: 2-7%, Mythic: 2-5% depending on mob level

## Deploy Checklist
1. `cd /mnt/c/project/game/server && npx tsc`
2. `npx vite build` (client, use background mode)
3. `SSHPASS='...' sshpass -e rsync -avz dist/ root@...:/opt/game/server/dist/`
4. `SSHPASS='...' sshpass -e rsync -avz --delete client/dist/ root@...:/opt/game/client/dist/`
5. `ssh root@... "pm2 restart game-server"`
6. `git add -A && git commit -m "..." && git push`
7. User must Ctrl+Shift+R to clear client cache (nginx sets immutable 1y cache on assets)
