# buildPlayerStats — Single Source of Truth for Stats

## DO
- Use `buildPlayerStats(userRow, context)` in ALL routes that need character stats
- Pass `stats: buildPlayerStats(...)` to `runBattle()` — it accepts optional `stats?: CharStats`
- Context: `'pve' | 'arena' | 'tournament' | 'war_attack' | 'war_defense'`

## DO NOT
- NEVER call `currentStats(base, equip, drinks, coll, guild)` manually in routes
- NEVER import `getDrinkBonuses`, `getGuildBonus`, `getBaseStats`, `enrichEquipment` into routes
- NEVER compute `JSON.parse(x.equipment || '{}')` manually — use `parseEquipment(eq)`

## Server
```typescript
// server/src/db/helpers.ts
export async function buildPlayerStats(userRow, context): Promise<CharStats>
export function parseEquipment(eq?: string | null): Record<string, any>
```

## Client
- Client NEVER computes stats itself. Always use `character.stats` from server.
- Client `sumStats` removed from CharacterCard — uses `stats.hp` directly.
- `calculateStats()` is dead code — only used in `utils/stats.ts` internally.

## Migration
Old pattern:
```typescript
const base = getBaseStats(user);
const equip = JSON.parse(user.equipment || '{}');
const { enriched } = await enrichEquipment(equip);
const drinks = getDrinkBonuses(user);
const guild = await getGuildBonus(userId, 'arena');
const stats = currentStats(base, enriched, drinks, user.collectionCount, guild);
```

New pattern:
```typescript
const stats = await buildPlayerStats(user, 'arena');
```
