# Admin Panel Patterns

## Pagination: 10 Items Per Page (Client-Side)

For admin list views with fixed datasets (items, mobs, collections, users, bots):

```tsx
const LIMIT = 10;
const [page, setPage] = useState(1);
const totalPages = Math.ceil(allItems.length / LIMIT);
const pagedItems = allItems.slice((page - 1) * LIMIT, page * LIMIT);

// In table: {pagedItems.map(...)}

// Pagination controls:
{totalPages > 1 && (
  <div className="flex items-center justify-center gap-2 mt-3">
    <Button size="md" disabled={page <= 1} onClick={() => setPage(page - 1)}>←</Button>
    <span className="text-xs text-[var(--color-text-muted)]">{page}/{totalPages}</span>
    <Button size="md" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>→</Button>
  </div>
)}
```

For server-side pagination (battles, feedback): change `LIMIT` constant from 20 to 10.

## Image Thumbnails in Table Lists

Add a narrow image column (`w-10`) at the start of each table row:

```tsx
<th className="text-left p-1.5 w-10"></th>
// ...
<td className="p-1.5">
  {item.image && <img src={item.image} alt="" className="w-8 h-8 object-contain rounded" />}
</td>
```

For avatars: `w-6 h-6 rounded-full object-cover`.

## Compact Action Blocks (4-Column Grid)

Admin action blocks (timers, money, premium, jobs) in one Card with grid:

```tsx
<Card className="mt-4">
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
    <div>
      <h3 className="font-bold text-sm mb-1">Title</h3>
      <label className="text-[0.6rem] text-[var(--color-text-muted)]">Label</label>
      <input ... className={inputClass} />
      <Button ...>Action</Button>
    </div>
    {/* 3 more blocks */}
  </div>
</Card>
```

## Auto-Fill User ID on Row Click

When clicking a user row, fill all admin action ID inputs:

```tsx
const selectUser = (u: any) => {
    const id = String(u.id);
    setTimerUserId(id);
    setMoneyUserId(id);
    setFinishJobUserId(id);
    setPremiumUserId(id);
    setBanUserId(u.id);
};

// Row:
<tr onClick={() => selectUser(u)} className="cursor-pointer hover:bg-[var(--color-bg-hover)]">
```
