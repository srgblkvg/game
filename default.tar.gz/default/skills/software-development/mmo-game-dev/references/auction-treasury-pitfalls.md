# Auction & Treasury DB Column Pitfalls

## Auction: No `status` column — use `endsat` (integer Unix timestamp)

**Table**: `auction_lots` has NO `status` column. Active lots = `endsat > NOW_UNIX`.

**Pitfall chain** (3 iterations to fix):
1. ❌ `WHERE status = 'active'` → column doesn't exist
2. ❌ `WHERE endsat > NOW()` → `integer > timestamp with time zone` type error  
3. ❌ `const now = Math.floor(Date.now()/1000)` → redeclared `now` (same scope already has one)
4. ✅ `WHERE endsat > ?` with `Math.floor(Date.now()/1000)` inline

**Working pattern**:
```typescript
const userLotCount = (await db.one(
  'SELECT COUNT(*) as cnt FROM auction_lots WHERE sellerId = ? AND endsat > ?',
  [userId, Math.floor(Date.now() / 1000)]
) as any).cnt;
```

## Treasury: `createdat` is TEXT, not timestamp

**Pitfall chain**:
1. ❌ `datetime(${unix}, 'unixepoch')` → SQLite syntax, PG doesn't have it
2. ❌ `to_timestamp(${unix})` → PG expects timestamp, column is text
3. ✅ Compare as ISO strings: `createdat >= '${d.toISOString()}'`

**Working pattern**:
```typescript
const d = new Date(); d.setHours(0,0,0,0);
const filter = `AND l.createdat >= '${d.toISOString()}'`;
```

## Guild Buildings: return ALL types, not just built ones

`getGuildBuildings()` must iterate ALL `BUILDINGS` config entries, not just rows in `guild_buildings` table. Non-built buildings get `level: 0` and `canBuild` based on guild level + treasury.

**Working pattern**:
```typescript
const built: Record<string,number> = {};
for (const r of rows) built[r.buildingtype] = r.level;
return Object.entries(BUILDINGS).map(([type, cfg]) => ({
    level: built[type] || 0,
    cost: getBuildingCost((built[type] || 0) + 1),
    reqLevel: getBuildingReqLevel((built[type] || 0) + 1),
    canBuild: guild.level >= reqLevel && guild.treasury >= cost,
    ...cfg,
}));
```
