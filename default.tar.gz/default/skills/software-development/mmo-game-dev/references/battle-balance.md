# Battle Balance Changes — June 2026

## HP Formula
HP = S + A + M (defense excluded — defense gives block chance, not HP).

Old: `sumStats` used PRIMARY_STATS (S+A+D+M).
New: `sumStats` returns `(s.s||0)+(s.a||0)+(s.m||0)`.

Server: `server/src/game/stats.ts` — `sumStats()` function.
Client: `client/src/utils/stats.ts` — `sumStats()` function (must match server).

## Block Cap
Block chance capped at 75% (was 100%).

```typescript
// server/src/game/battle.ts
function blockChance(defStats: CharStats): number {
  return Math.min(0.75, ...); // was Math.min(1, ...)
}
```

## Extra Stats — Soft Cap
All extra stats (crit, dodge, counter, fullBlock) now use diminishing returns:
`extraValue / (extraValue + 300)` instead of `extraValue / 300`.

At 100 extra: 25% (was 33%)
At 300 extra: 50% (was 100%)
At 600 extra: 67% (was 200%)

Files: `server/src/game/battle.ts` — all chance functions.
