# Guild Buildings System

## Overview
Guild buildings provide stat bonuses in specific combat contexts. Managed via DB, exposed through API, integrated into combat calculations.

## Building Types

| Key | Name | Bonus/Level | Applies To |
|-----|------|-------------|------------|
| `training_ground` | Тренировочная площадка | +5% S/A/D/M | Arena, Tournaments |
| `scout_hq` | Штаб разведки | +5% S/A/D/M | PvE (mob hunting) |
| `siege_camp` | Осадный лагерь | +5% S/A/D/M | Guild War attack |
| `walls` | Стены | +5% S/A/D/M | Guild War defense |

## Cost Formula
`cost = 100000 * 2^(targetLevel - 1)`
- Level 1: 100,000 silver
- Level 2: 200,000 silver
- Level 3: 400,000 silver

Guild level requirement: `targetLevel` (e.g., level 2 requires guild level 2).

## Files
```
server/src/game/guildBuildings.ts   — constants, getBuildingCost, getGuildBonus(userId, context)
server/src/routes/guildBuildings.ts — GET /guild/:id/buildings, POST upgrade
client/GuildPage.tsx                — "Сооружения" collapsible block with upgrade buttons
```

## API (updated June 2026)
- `GET /api/guild/my` — returns ALL 4 building types inside `guild.buildings[]` with: type, icon, label, desc, level, bonus, nextBonus, cost, reqLevel, canBuild
- `POST /api/guild/buildings/build` — body `{buildingType}`, requires leader rank, deducts from treasury. Creates or upgrades.

## Server files (updated)
```
server/src/game/guildBuildings.ts    — BUILDINGS config, getBuildingCost, getBuildingReqLevel, getGuildBonus, getGuildBuildings, buildBuilding
server/src/routes/guild/guildCore.ts — includes buildings in guild/my response, build endpoint
client/src/pages/GuildPage.tsx        — "Постройки" tab with all 4 types, cost/requirements, build button
```

## Client display
Each building card shows: icon + name + level, description, next level cost and req, build/upgrade button.

## Combat Integration
`getGuildBonus(userId, context)` queries guild_buildings table, sums levels × 5% for buildings matching the context. Called in:
- `battle.ts` — `getGuildBonus(attacker.id, 'arena')` + `getGuildBonus(defender.id, 'arena')`
- `mobs.ts` — `getGuildBonus(userId, 'pve')`
- `tournament.ts` — `getGuildBonus(u.id, 'tournament')`
- `guild.ts` (war) — `getGuildBonus(attacker.id, 'war_attack')` + `getGuildBonus(defender.id, 'war_defense')`
- `arena.ts` (opponent display) — `getGuildBonus(opponent.id, 'arena')` for display consistency
- `battleSim.ts` — `getGuildBonus(id, context)` for both players; context is user-selectable (arena/tournament/war_attack/war_defense — PvP only, no pve) via API param

## Stats Integration
`currentStats()` accepts optional `guildBonus` parameter (5th arg). Applied as multiplier after collection bonus:
```ts
if (guildBonus && guildBonus > 0) {
    const mult = 1 + guildBonus / 100;
    st = { s: Math.round(st.s * mult), a: Math.round(st.a * mult), ... };
}
```

## Permission
Only guild **leader** (not officer by default) can upgrade. Officers CAN upgrade if the leader grants them `can_buildings` permission via `/guild/officer-permissions`.

**⚠️ Питфол:** Функция `buildBuilding()` в `game/guildBuildings.ts` изначально проверяла только `member.rank !== 'leader'`. Офицеры с `can_buildings=true` не проходили. Фикс (2026-07-23): проверка `member.rank !== 'leader' && !(member.rank === 'officer' && member.can_buildings)`.

**⚠️ Питфол:** Клиентский API `/guild/buildings/build` маршрутизируется в `guildCore.ts` (не `guildBuildings.ts`). Не создавать дубликаты роутов.

**⚠️ Питфол:** Сервер возвращает `canUpgrade`, клиент читает `b.canBuild` — имена полей должны совпадать.

## DB Table
```sql
CREATE TABLE IF NOT EXISTS guild_buildings (
    id SERIAL PRIMARY KEY,
    guildId INTEGER NOT NULL,
    buildingType TEXT NOT NULL,
    level INTEGER DEFAULT 0,
    UNIQUE(guildId, buildingType)
);
```
Auto-created by `guildBuildings.ts` route on first access.

## Client UI Pattern
- Collapsible Card with ▶/▼ toggle
- Each building row: icon + name + description + current bonus % + level
- Leader sees upgrade button with cost; others see placeholder text
- **Always show cost + next bonus** — even when can't upgrade.
  - If can upgrade: button `↑ {cost}💰`
  - If can't: two-line display:
    - Line 1: reason (`Только лидер`, `Нужен ур. гильдии 3 (сейчас 2)`, `Нужно 200,000, в казне 50,000`)
    - Line 2: `Стоимость: {cost}💰 → +{nextBonus}%`
- `canUpgrade` determined server-side (checks guild level + treasury) and returned in API

**UX rule:** The player must see WHAT they need to upgrade, not just THAT they can't. Cost and next bonus are always visible.

## Character Card Display
The `StatsOverlay` shows each building's bonus individually with its context label:
```
🏟️ Арена/Турниры       +5%
🔭 Охота               +5%
⚔️ Атака в ГВ          +5%
🏰 Защита в ГВ          +5%
```

**Data flow:**
1. Server `character.ts` returns `buildings: [{type, icon, label, level, bonus}]` — one entry per building with bonus > 0
2. `LeftSidebar` passes `buildings: character.buildings` to CharacterCard
3. `CharacterCard` extracts `buildingsList = char.buildings` and passes to StatsOverlay
4. `StatsOverlay` renders each entry as a table row with icon + label + bonus%

The server also returns `guildBonus` (sum of all bonuses) for backward compatibility. The `buildings` array is preferred for display as it shows context labels.

**ShowFlip trigger:** The flip button appears when `hasBonuses || hasExtra || buildings.length > 0`. This ensures the button shows even without equipment bonuses — just having collection or guild buildings is enough.

## Premium HP Regen (related)
Premium auto-grants closet room (×3 regen):
- **Server**: `applyHpRegen()` checks `premiumUntil > now` → sets regenRate=3 if no better room active
- **Client**: `LeftSidebar` creates `effectiveRoom` from `character.premium?.until` → `{type:'closet', until}` if premium active and no other room
- Both callers must pass `premiumUntil`: `character.ts` includes it in the user object, `battle.ts` includes `u.premiumUntil` in DB queries

## Guild Ranking Sort
Guild list sorted by: `ORDER BY g.level DESC, g.exp DESC` (was `g.treasury DESC, g.level DESC`). In `routes/guild.ts` GET `/guild/list`.

## Pitfalls
- **Mismatched file deployment**: `guildBuildings.ts` exists in both `game/` and `routes/`. The game file has constants + `getGuildBonus`, the route file has Express handlers. Deploy to correct directories:
  ```bash
  # CORRECT — каждому файлу своя директория
  scp server/src/game/guildBuildings.ts   root@host:/opt/game/server/src/game/
  scp server/src/routes/guildBuildings.ts root@host:/opt/game/server/src/routes/
  ```
  Error: `TypeError: Cannot convert undefined or null to object` = BUILDINGS is undefined because the route file was deployed to the game directory. Error: `getGuildBonus is not a function` = game file was overwritten by route file.
- **Arena display mismatch**: Must call `getGuildBonus()` in arena opponent display (not just in battle calculation) so stats shown before attacking match the actual battle stats.
- **Stats only in combat context**: Guild bonuses apply ONLY in their declared context. The character's general stats display (`/character/me`) returns `buildings` array + `guildBonus` as informational only — NOT applied to `stats.s/a/d/m/hp`. Applying them to general stats was reverted because it inflated HP everywhere.
- **StatsOverlay prop mapping**: `calculateStats()` returns `equipmentBonuses` and `extraStats` (not `bonuses` and `extra`). When the character comes from LeftSidebar (via calculateStats), use `char.equipmentBonuses`/`char.extraStats`. When from the server API directly (arena opponent), use `stats.bonuses`/`stats.extra`. Always fall back with `||` chain.
- **tournament.ts loadPlayerForBattle — guildBonus loaded but NOT applied to currentStats**: `guildBonus` is fetched on line 132 but `currentStats()` on line 120 is called WITHOUT it. This means:
  - Tournament bracket display shows stats without training ground bonus
  - HP for tournament battle is set to `stats.hp` (without guild bonus) — `runBattle` sees `currentHp != null` and uses the lower value instead of recomputing with guild bonus
  - **Fix**: call `currentStats(base, enriched, drinkBonuses, collCnt, guildBonus)` and move `guildBonus` fetch before that line.
- **battle.ts opponent display — guildBonus omitted from currentStats**: Line 160 passes `defenderData.collectionBonus` but NOT `defenderData.guildBonus` (which IS loaded on line 88). Fixed by adding the 5th arg.
- **Client-side calculateStats() ignores guild bonus entirely**: `client/src/utils/stats.ts` computes stats as `(base + equipment + drinks) * collection_multiplier` — no guild bonus parameter. This means LeftSidebar, BestiaryPage CharacterCard, and all other client-rendered stat displays never include guild building bonuses. Only server-rendered stat payloads (arena opponent via `arena.ts:107`, battle logs) include them. If guild building bonuses need to appear in these client displays, `calculateStats()` needs a `guildBonus` parameter and the callers must pass it.
- **Client deploy caching**: Nginx serves static files without cache headers for non-upload assets. Browsers cache index.html heuristically. Hard-refresh (Ctrl+Shift+R) is needed after deploy. Old chunks persist in `/opt/game/client/dist/assets/` until `rm -rf` before deploy.
