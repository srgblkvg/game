# Auction Expiry — Item Transfer

## Bug Found
When auction lots expired:
- Lots WITH bids: seller got money, but ITEM WAS DELETED (not transferred to winner)
- Lots WITHOUT bids: ITEM WAS DELETED (not returned to seller)

Both cases caused permanent item loss.

## Fix (GET /api/auction)
```ts
// Expired WITH bids — transfer item to winner
for (const lot of expired) {
  // ... pay seller ...
  // Transfer item to winner's inventory
  const winner = await db.one('SELECT inventory FROM users WHERE id = ?', [lot.currentBidderId]);
  if (winner) {
    const inv = JSON.parse(winner.inventory || '[]');
    // stack with existing craft items, or push new
    inv.push(itemData);
    await db.run('UPDATE users SET inventory = ? WHERE id = ?', [JSON.stringify(inv), lot.currentBidderId]);
    // Record in auction_history
  }
}

// Expired WITHOUT bids — return item to seller
for (const lot of unsold) {
  const seller = await db.one('SELECT inventory FROM users WHERE id = ?', [lot.sellerId]);
  // ... return item to seller's inventory ...
}
```

## Cancel Protection
Added check to prevent canceling lots with active bids:
```ts
if (lot.currentBidderId) return res.status(400).json({ error: 'Нельзя снять лот, на который уже сделана ставка' });
```

## Money Flow Verification
- When outbid: money IS returned to previous bidder (in `/auction/bid`)
- When auction expires and you're winner: money stays deducted (correct — you bought the item)
- Item now properly transferred to winner's inventory
