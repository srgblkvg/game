# Client Frontend Patterns

## Vite HMR on WSL

WSL uses NTFS which doesn't support inotify — Vite won't detect file changes.

**Fix:** Add polling to `vite.config.ts`:
```ts
server: {
  watch: {
    usePolling: true,
    interval: 500,
  },
}
```

Restart Vite after adding this. Without it, every file change requires a manual browser refresh.

## Tooltips

**ALWAYS use the existing `ItemTooltip` component** (`client/src/components/ItemTooltip.tsx`). Never write custom tooltips.

- Props: `item={object} position={{ x, y }}`
- Uses `createPortal` to `document.body` — bypasses CSS containing blocks
- Auto-adjusts position to stay within viewport

## Long Press (Mobile)

Use `useLongPress` hook (`client/src/hooks/useLongPress.ts`):
```ts
const longPress = useLongPress(
  onLongPress,  // fired after delay
  onClick,      // fired on short tap (optional)
  500           // delay ms (default)
);
// Spread: {...longPress} adds onTouchStart/End/Move
```

For collection slots:
- Mobile: long press = tooltip, short tap = add to collection
- Desktop: hover = tooltip, click = add to collection
- Block context menu: `onContextMenu={(e) => e.preventDefault()}`
- Block text selection: `className="... select-none"`
- Detect touch device: `'ontouchstart' in window` — skip onMouseEnter on mobile

## Modals

Stack modals by condition:
```tsx
{selectedItem && !showConfirm && (<div>selection modal</div>)}
{showConfirm && selectedItem && (<div>confirmation modal</div>)}
```
Click backdrop to close: `onClick={() => setState(null)}` on overlay, `onClick={e => e.stopPropagation()}` on modal content.

### Confirm popup (replaces browser `confirm()`)

Never use `if (!confirm('...')) return` — it breaks mobile UX and theming. Use a state-driven popup:

```tsx
const [confirmPopup, setConfirmPopup] = useState<{ message: string; onConfirm: () => void } | null>(null);

// Usage:
const handleLeave = () => {
    setConfirmPopup({
        message: 'Покинуть гильдию?',
        onConfirm: async () => {
            setConfirmPopup(null);
            // ... action
        }
    });
};

// Render:
{confirmPopup && (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center">
        <div className="absolute inset-0 bg-black/50" onClick={() => setConfirmPopup(null)} />
        <div className="relative bg-[var(--color-bg-card)] border border-[var(--color-border-default)] rounded-xl p-6 max-w-sm w-full mx-4 shadow-2xl">
            <p className="text-sm mb-4">{confirmPopup.message}</p>
            <div className="flex gap-2 justify-end">
                <Button variant="secondary" size="xs" onClick={() => setConfirmPopup(null)}>Отмена</Button>
                <Button variant="danger" size="xs" onClick={confirmPopup.onConfirm}>Подтвердить</Button>
            </div>
        </div>
    </div>
)}
```

Pattern used in GuildPage (leave guild, kick member). `onConfirm` is async so API calls + state updates work inside.

### Chat overlay (visual block without auto-close)

For the chat panel, use a backdrop overlay that provides visual darkening but does NOT close on click:

```tsx
{isPanelOpen && (
    <div className="fixed inset-0 z-[999] bg-black/40" />
)}
```

Note: NO `onClick` handler. Chat closes only via:
- Page navigation (`useLocation` + `useEffect` on `location.pathname`)
- RightSidebar opening (`window.dispatchEvent(new CustomEvent('closeChatPanel'))`)
- Header toggle button

The overlay sits below the panel (`z-[999]` vs panel `z-[1000]`) and naturally blocks interaction with page content behind it — the darkening makes it visually obvious.
