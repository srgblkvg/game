# Discuss Before Coding

User strongly prefers discussion/design before implementation for large features.

**Signal**: if user asks for a new feature (e.g., "делаем одиночный данж"), DO NOT start immediately coding. Ask clarifying questions first:
- Combat mechanics
- UI structure
- Rewards
- Limits/cooldowns
- Progression

**Real case**: started coding dungeon without asking for specs → user: "стой. ты уже все придумал?" → had to redesign from scratch.

**Also applies to**:
- New game mechanics
- UI redesigns
- Balance changes
- Feature integrations from other projects
