# CSS Pitfalls in the MMO Game

## backdrop-filter creates containing block for position:fixed

`backdrop-blur` (and any `backdrop-filter` or `transform` on an ancestor) creates a new CSS containing block. All `position: fixed` descendants position relative to THAT element, not the viewport.

**Symptom**: Tooltips, modals, or dropdowns appear in wrong position — offset by the parent's position. On mobile (full-screen panel) the offset is small; on desktop (small panel at bottom) it's huge.

**Fix**: Use `createPortal(children, document.body)` to render the fixed element directly into `<body>`. This completely bypasses any ancestor's containing block. Always use portal for tooltips that need viewport-relative positioning.

**Specific case**: ChatPanel has `backdrop-blur-[12px]` which broke ItemTooltip positioning. Fixed by changing ItemTooltip to use `createPortal(tooltip, document.body)`.

**Checklist when adding backdrop-blur/transform to a container**:
- Any `position: fixed` descendants need portal rendering
- Tooltips inside the container need portal
- Modals rendered inside the container need portal (or move them out)

## overflow-hidden clips absolute-positioned headers

When positioning a header absolutely on a border (e.g., `absolute -top-3`), do NOT use `overflow-hidden` on the container — it clips the positioned element. Remove `overflow-hidden` or change to `overflow-visible`.

## Inline style for background images with Tailwind

For dynamic background images (from DB), use inline `style={{ backgroundImage: ... }}` rather than trying to use Tailwind `bg-[url(...)]` which only works with static paths.

## background-attachment:fixed + mobile overscroll = white stripe

**Symptom**: On mobile browsers (especially Yandex Browser), scrolling to the bottom of the page reveals a white stripe/bar. The body background doesn't extend into the overscroll area.

**Root cause**: `background-attachment: fixed` on `body` pins the background to the viewport. When overscrolling (pulling past content end), the area beyond the `body` shows the `html` element's background color — which defaults to white.

**Fix**: Set `background-color` on `html` to match the body's gradient start color, so overscroll shows the same color instead of white:

```css
/* Dark theme */
html {
  background-color: #0a0a1e; /* matches gradient start */
}

/* Light theme */
[data-theme="light"] html {
  background-color: #f5f0e8; /* matches gradient start */
}
```

This provides a backdrop behind the fixed body background, eliminating the white gap during overscroll without removing `background-attachment: fixed` (which is needed for the starfield effect).

**Where**: `client/src/styles/theme.css` — `html` rule and `[data-theme="light"] html`
