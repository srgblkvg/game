# Admin Panel Click-to-Fill Pattern

Clicking a row in an admin list fills related action inputs with the row's IDs. Used in AdminUsers and AdminChat.

## AdminUsers: click row → fill all ID inputs

```tsx
// Selection function
const selectUser = (u: any) => {
  const id = String(u.id);
  setTimerUserId(id);
  setMoneyUserId(id);
  setFinishJobUserId(id);
  setPremiumUserId(id);
  setBanUserId(u.id);
};

// Row onClick
<tr key={u.id}
    className="... cursor-pointer hover:bg-[var(--color-bg-hover)] ..."
    onClick={() => selectUser(u)}
>
```

This fills: timer reset input, money input, job finish input, premium input, and ban target.

## AdminChat: click message → fill ban + delete inputs

```tsx
// Row onClick
<tr key={m.id}
    className="... cursor-pointer hover:bg-[var(--color-bg-hover)]"
    onClick={() => {
      setBanUserId(String(m.senderId));   // fill ban input
      setDeleteId(String(m.id));           // fill delete input
    }}
    title="Клик: заполнить ID отправителя и ID сообщения"
>
```

This fills: chat ban user ID and message delete ID in one click.

## Pitfalls

- Must convert IDs to strings for string-state inputs (`String(id)`)
- Hover and cursor-pointer classes make rows clearly interactive
- `title` attribute provides a tooltip explaining what clicking does
