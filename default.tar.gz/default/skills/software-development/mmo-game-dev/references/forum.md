# Forum Development Patterns

## Architecture
- **Server**: `server/src/routes/forum.ts` — Express router
- **Client**: `client/src/pages/ForumPage.tsx` (thread list + create), `client/src/pages/ForumThreadPage.tsx` (thread + posts)
- **DB Tables**: `forum_threads`, `forum_posts`, `forum_polls`, `forum_poll_options`, `forum_poll_votes`

## Markdown Rendering
- Use `marked` + `DOMPurify` for safe MD→HTML conversion
- Inject scoped CSS via `<style>` tag in component for blockquote, code, table, heading styles
- DOMPurify whitelist: `p, br, strong, em, del, code, pre, h1-h6, ul, ol, li, a, blockquote, table, thead, tbody, tr, th, td, hr, img, span`
- Allowed attrs: `href, src, alt, title, class, target`

### Blockquote styling
```css
.forum-content blockquote {
    border-left: 2px solid var(--color-accent-info);
    padding: 0.4rem 0.75rem;
    margin: 0.25rem 0;
    font-size: 0.8rem;
    color: var(--color-text-muted);
    opacity: 0.85;
    background: var(--color-bg-input);
    border-radius: 0 4px 4px 0;
}
```

## MD Toolbar (MdToolbar component)
- Located at `client/src/components/ui/MdToolbar.tsx`
- Inserts MD syntax (B/I/S/H/quote/list) at cursor position
- Uses native `HTMLTextAreaElement.value` setter to avoid React cursor reset

### Critical: Cursor position on VK/controlled inputs
React controlled textareas (`value={state}`) reset cursor to end after every DOM mutation.
To preserve cursor position when inserting MD tags:
1. Use `Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set` to set value natively
2. Dispatch `input` event for React state sync
3. Store desired selection in module-level Map via `setMdSelection()`
4. Restore selection in `useEffect` with `requestAnimationFrame`

## Reply/Quote Logic
- Click "Ответить" → fill reply textarea with `> username:\n> each line\n\n`
- Strip nested `>` lines from quoted message (only quote new text, not previous quotes)
- Quote EVERY line with `> ` prefix (`.map(l => '> ' + l)`)
- Do NOT truncate quote length (was 300 chars, now full message)

## Poll System
- Created with thread: optional `{ question, options: string[] }` in POST body
- Displayed between title and first post in thread page
- Vote: POST `/api/forum/poll/vote` — one vote per user (UNIQUE constraint)
- Closed threads block voting (both client and server)

## Author Highlighting
- First post (thread author): `border-l-4 border-l-[var(--color-accent-info)]` + `bg-[var(--color-bg-card)]`
- NO icon badge (📢 removed), NO "Автор" label
- Reply target highlight: `border-l-4 border-l-[var(--color-accent-warning)]`

## Closed Thread Behavior
- Hide reply form, edit buttons, reply buttons on all posts
- Only author sees Open/Close toggle button
- Server blocks: PUT post, PUT thread title, POST poll vote with "Тема закрыта"
- Poll voting disabled with `disabled={pollVoting || thread.is_closed}`

## Thread Actions (author only)
- Edit title: ✎ button next to title (hidden when closed)
- Close/Open: toggle button
- Edit post: ✎ button per message (hidden when closed, only own posts)

## Reply Click → Focus Pattern
Use `useEffect([replyParentId, replyText])` with `setTimeout(100ms)` for scroll+focus.
Direct ref manipulation in onClick doesn't work reliably due to React render timing.
