# DB Migration Patterns for MMO Game

## Critical Rules

1. **ALL migrations in `migrations.ts` run on EVERY server start.** There is no migration versioning. Every migration MUST be idempotent.

2. **For ALTER TABLE ADD COLUMN**: Use `try { db.exec(...) } catch {}` — if column already exists, silently skip.

3. **For table restructuring**: Check if the change is already applied before executing. Use `PRAGMA table_info` to inspect current schema.

4. **NEVER drop and recreate a table with FOREIGN KEY constraints** — it will break FK references from other tables. Use in-place UPDATE instead.

## Patterns

### Adding a Column (idempotent)
```ts
try { db.exec('ALTER TABLE tournaments ADD COLUMN completedAt DATETIME'); } catch {}
```

### Converting Column Type (in-place, no FK breakage)
```ts
const colInfo = db.prepare("PRAGMA table_info(tournaments)").all();
const createdAtCol = colInfo.find(c => c.name === 'createdAt');
if (createdAtCol && createdAtCol.type === 'INTEGER') {
    const oldData = db.prepare('SELECT id, createdAt FROM tournaments').all();
    const update = db.prepare('UPDATE tournaments SET createdAt=? WHERE id=?');
    for (const t of oldData) {
        if (typeof t.createdAt === 'number' && t.createdAt > 1000000000) {
            const s = new Date(t.createdAt * 1000).toISOString().replace('T', ' ').slice(0, 19);
            update.run(s, t.id);
        }
    }
}
```

### Restructuring without FK (for non-referenced tables)
```ts
const hasRarityCol = db.prepare("PRAGMA table_info(upgrade_chances)").all()
    .some(c => c.name === 'rarity_id');
if (!hasRarityCol) {
    db.exec('DROP TABLE IF EXISTS upgrade_chances_new');
    db.exec(`CREATE TABLE upgrade_chances_new (...)`);
    // copy data, drop old, rename new
}
```

### Seed Data Fill
```ts
// Instead of: if (count === 0) insert
// Use: if (count < expectedTotal) delete + re-insert
const count = db.prepare('SELECT COUNT(*) as cnt FROM upgrade_chances').get().cnt;
if (count < 70) {
    db.exec('DELETE FROM upgrade_chances');
    // re-seed all 70 rows
}
```

## Real-World Pitfalls

1. **`datetime()` is SQL, not JavaScript** — writing `String(t.createdAt || datetime('now'))` in a Node.js migration fails because `datetime` is undefined in JavaScript. Use `new Date().toISOString()` instead.

2. **Upgrade_chances migration was destructive** — the original migration dropped and recreated the table every start, wiping rarity_id data. Fixed by checking `PRAGMA table_info` first.

3. **Tournament createdAt migration** — the initial approach dropped/recreated the table, breaking FOREIGN KEY constraints from `tournament_participants` and `tournament_matches`. Fixed by switching to in-place UPDATE.

4. **Shell escaping for direct VPS queries** — when running queries via `ssh ... node -e`, single quotes inside the command need double-escaping. Prefer writing scripts to files and scp-ing them.
