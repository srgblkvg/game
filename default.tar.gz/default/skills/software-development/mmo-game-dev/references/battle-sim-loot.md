# Battle Sim & Mob Loot (pg-native, June 2026)

## Battle Simulator page
Route: `/battle-sim` — not in nav, direct URL only. Available to players and admins.

### Server endpoints
- `GET /players/search?q=...` — autocomplete (ILIKE, min 2 chars)
- `GET /players/:id/loadout` — full player data with stats
- `POST /battle-sim {id1, id2, battles}` — runs N battles, returns JSON with steps, effects, win counts

Files: `server/src/routes/battleSim.ts`

### Frontend
`client/src/pages/BattleSimPage.tsx`:
- Autocomplete inputs with dropdown suggestions
- Stats comparison: base/equip/drinks/collection → total, with S/A/D/M/HP
- Damage range: min-med-max (from rollDamage formula)
- Chance display: crit%, block%, dodge%, fullBlock% (using battle formulas)
- Collapsible battle logs with turn dividers (before each `attack` step)
- Attack step background tint: attacker yellow, defender pink

### Formulas displayed (must match battle.ts)
```typescript
const cC = (m, ec) => Math.min(0.8, m/(m+500) + ec/300);
const dC = (a, ed) => Math.max(0, Math.min(0.95, a/(a+500) + ed/300));
const bC = (d, fb) => Math.min(1, d/(d+500) + fb/300);
const fB = (fb) => Math.min(1, fb/300);
const dmgRange = (S, level) => ({ min: level, med: Math.round(level+0.7*(S-level)), max: S });
```

## Mob loot system
Per battle: max 1 material + 1 stone + 1 item.

### Materials: 35% chance
Rarity from mob's `loot_*` columns (fractions summing to ~1.0).

### Junk stone: 5% independent chance
Added to `lootImages` with `rarity: -1` (special flag).

### Random items: per-rarity chances from `getItemDropTable(level)`
Item drop chances (×10 from initial values):
| Level | Rarities |
|-------|----------|
| 1-10 | 20% junk, 5% common |
| 11-25 | 20% junk, 15% common, 5% uncommon |
| 26-45 | 20% junk, 20% common, 15% uncommon, 5% rare |
| 46-65 | 20% common, 20% uncommon, 15% rare, 5% epic |
| 66-85 | 20% uncommon, 20% rare, 15% epic, 5% legendary |
| 86-100 | 20% rare, 20% epic, 20% legendary, 5% mythic |
| 100+ | 20% epic, 20% legendary, 15% mythic |

Each rarity rolled independently, first success wins (max 1 item per battle).

### Bestiary display
Floor cards show:
- Materials: item icons with % (from `lootImages`)
- Stone: junk stone icon with 5%
- Items: colored squares with `?` character + %, by rarity color

Implementation: `server/src/routes/mobs.ts`, `client/src/pages/BestiaryPage.tsx`
