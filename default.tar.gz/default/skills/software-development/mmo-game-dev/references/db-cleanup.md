# Database Cleanup (7-day retention)

## cleanup.ts
```typescript
import { db } from './db/index';

export async function cleanupOldData() {
  const weekAgo = Math.floor(Date.now() / 1000) - 7 * 24 * 3600;
  const weekAgoISO = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
  
  // Tournament matches (via completed tournaments)
  await db.run(`DELETE FROM tournament_matches WHERE tournamentId IN (SELECT id FROM tournaments WHERE status = 'completed' AND completedAt < ?)`, [weekAgo]);
  await db.run(`DELETE FROM tournament_participants WHERE tournamentId IN (SELECT id FROM tournaments WHERE status = 'completed' AND completedAt < ?)`, [weekAgo]);
  await db.run(`DELETE FROM tournaments WHERE status = 'completed' AND completedAt < ?`, [weekAgo]);
  
  // Chat messages
  await db.run(`DELETE FROM chat_messages WHERE createdAt < ?`, [weekAgoISO]);
  
  // Battles
  await db.run(`DELETE FROM battles WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM pve_battles WHERE createdAt < ?`, [weekAgo]);
  
  // Auction history
  await db.run(`DELETE FROM auction_history WHERE createdAt < ?`, [weekAgo]);
  
  // Quest & job history
  await db.run(`DELETE FROM quest_history WHERE createdAt < ?`, [weekAgo]);
  await db.run(`DELETE FROM job_history WHERE endTime < ?`, [weekAgo]);
}
```

## Integration in index.ts
```typescript
import { cleanupOldData } from './cleanup';
setTimeout(() => { cleanupOldData().catch(() => {}); }, 60000); // run 1 min after startup
setInterval(() => { cleanupOldData().catch(() => {}); }, 24 * 3600 * 1000); // daily
```

## Manual emergency cleanup after bots
```sql
-- Keep only 1000 recent tournament matches
DELETE FROM tournament_matches WHERE id NOT IN (SELECT id FROM tournament_matches ORDER BY id DESC LIMIT 1000);
-- Keep only 500 chat messages
DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 500);
-- Reclaim disk
VACUUM FULL tournament_matches;
```
Result: 379MB → 46MB after 427K matches deleted.
