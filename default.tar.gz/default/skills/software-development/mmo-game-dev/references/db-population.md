# DB Population

Tables that auto-seed via `runSeed()`: rarities, items, jobs, craft_items, craft_recipes, upgrade_chances, mobs, stat_names, craft_recipe_categories.

Tables that need manual population (via admin API or SQL):
- **floors** — POST `/api/admin/floors` with `{name, background, sort_order}`
- **actions_config** — POST `/api/admin/actions` with `{section, title, subtitle, icon, bg_image, path, cost, sort_order}`

## actions_config sections

⚠️ **CRITICAL**: Client code in `Actions.tsx` filters by `section`:
- `'world'` → секция "МИР" (main page top)
- `'castle'` → секция "Площадь" (main page bottom)

Do NOT use `'town'` — it won't render. The section name `castle` is hardcoded in `client/src/components/Actions.tsx:44`.

## Admin API

Get token: `POST /api/login` with admin credentials.
All admin endpoints require `Authorization: Bearer <token>` header.

### Floors
```
POST /api/admin/floors
{"name": "Склеп", "background": "/images/floors/crypt.webp", "sort_order": 1}
```

### Actions
```
POST /api/admin/actions
{"section": "world", "title": "Бестиарий", "subtitle": "Охота на монстров", "icon": "game-icons:bestial-fangs", "path": "/bestiary", "cost": 0, "sort_order": 1}
```

## Creating users without SMTP

Registration requires email verification (SMTP). For local dev, create users directly in SQLite with `emailVerified=1`:

```js
const bcrypt = require('bcryptjs');
const pwhash = bcrypt.hashSync('password', 10);
const now = Math.floor(Date.now()/1000);
db.prepare("INSERT INTO users (username, passwordHash, email, emailVerified, currentHp, lastHpUpdate, level, gender, exp, money, lastLoginAt) VALUES (?,?,?,1,50,?,1,'male',0,100,?)").run('username', pwhash, 'email@test.com', now, now);
```

If user already exists from failed registration, just set `emailVerified=1`:
```sql
UPDATE users SET emailVerified=1 WHERE username='test';
```
