# Chart.js Integration

## Setup
```bash
cd client && npm install chart.js react-chartjs-2
```

## Client component pattern
```tsx
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler,
} from 'chart.js';
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);
```

## Component with lazy fetch + item-change reset
```tsx
function PriceChart({ item }: { item: any }) {
  const [points, setPoints] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const itemKey = `${item.name}|${item.slot || ''}|${item.rarity_id ?? 0}`;

  // Critical: reset state when item changes, otherwise stale chart stays
  useEffect(() => {
    setPoints(null);
    setLoading(false);
    setError('');
  }, [itemKey]);

  // Lazy fetch on button click, cached after first load
  const fetchHistory = useCallback(async () => {
    if (points !== null) return; // already loaded
    ...
  }, [item.name, item.slot, item.rarity_id, points]);

  if (!points) return <button onClick={fetchHistory}>📈 История цен</button>;
  if (points.length < 2) return <div>Недостаточно данных</div>;

  return <Line data={chartData} options={options} />;
}
```

## Common pitfalls

### 1. Stale chart on item switch
The `fetchHistory` callback checks `if (points !== null) return` — once data is loaded for one item, switching to another item won't refetch. **Fix**: `useEffect` that resets `points`/`loading`/`error` when `itemKey` changes.

### 2. Date format from PostgreSQL DATE()
`DATE(createdAt::timestamp)` returns a full ISO timestamp string (`2026-08-07T00:00:00.000Z`), not just `2026-08-07`. Use `p.day.slice(0, 10)` before splitting.

### 3. Compact Y-axis labels (k/M)
Replace full `formatMoney()` on chart axis — too long for chart ticks. Use:
```tsx
callback: (v: any) => v >= 1_000_000 ? `${(v/1_000_000).toFixed(1)}M`
  : v >= 1000 ? `${(v/1000).toFixed(1)}k` : v
```

### 4. SQL NULL handling for JSONB fields
When filtering `itemData::jsonb->>'slot'` and items may not have a `slot` field, use COALESCE:
```sql
AND COALESCE(itemData::jsonb->>'slot', '') = ?  -- not itemData::jsonb->>'slot' = ?
```
Without COALESCE, `NULL = ''` is not true in SQL — materials/runes without slot silently excluded.

### 5. Build check: `tsc -b` vs `tsc --noEmit`
The client `tsconfig.json` has `"files": []` with project references. Running `npx tsc --noEmit` compiles NOTHING (always passes). Always use `npm run build` (which runs `tsc -b`) to catch real errors. The app tsconfig (`tsconfig.app.json`) has `noUnusedLocals`, `noUnusedParameters`, and `verbatimModuleSyntax` that catch issues `tsc --noEmit` misses.
