# Admin Panel Pagination Pattern

Standard pattern for adding client-side pagination (10 items per page) to any admin list view.

## Core pattern

```tsx
// 1. Add state
const [page, setPage] = useState(1);
const LIMIT = 10;

// 2. Calculate totals and slice
const totalPages = Math.ceil(items.length / LIMIT);
const paged = items.slice((page - 1) * LIMIT, page * LIMIT);

// 3. Use paged instead of items in map
{paged.map(item => <tr key={item.id}>...</tr>)}

// 4. Add pagination controls at bottom
{totalPages > 1 && (
  <div className="flex justify-center gap-2 mt-2">
    <Button size="md" disabled={page <= 1} onClick={() => setPage(page - 1)}>←</Button>
    <span className="text-xs text-[var(--color-text-muted)]">{page}/{totalPages}</span>
    <Button size="md" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>→</Button>
  </div>
)}
```

## Adding image thumbnails

For lists that have image columns (items, mobs, actions, jobs):

```tsx
// Header: add empty column
<th className="text-left p-1 w-10"></th>

// Row: show image if available
<td className="p-1">
  {item.image && <img src={item.image} alt="" className="w-8 h-8 object-cover rounded" />}
</td>
```

Image field names vary: `item.image` (items), `item.background` (mobs/jobs), `item.bg_image` (actions).

## Sorting before pagination

When data needs sorting (e.g. mobs by location), sort the array BEFORE slicing:

```tsx
const sorted = [...items].sort((a, b) => (a.location || '').localeCompare(b.location || ''));
const totalPages = Math.ceil(sorted.length / LIMIT);
const paged = sorted.slice((page - 1) * LIMIT, page * LIMIT);
```

## Files using this pattern

- `AdminItems.tsx` — items with images, 10/page
- `AdminUsers.tsx` — users with avatars, 10/page
- `AdminGame.tsx` — actions (images), mobs (sorted by location, images), floors (images)
- `AdminBots.tsx` — bots, 10/page
- `AdminCollections.tsx` — collection sets, 10/page
- `AdminTournaments.tsx` — tournaments, 10/page
- `AdminChat.tsx` — chat messages, 10/page
- `AdminJobs.tsx` — jobs with images, 10/page

## Pitfalls

- `useCrud` hook does NOT have built-in pagination — add page state manually
- When using `replace_all` in patch, make sure onChange handlers also get updated (digit filtering for VK)
- Pagination must reset to page 1 when search/filter changes (not currently implemented — for large datasets, consider adding)
