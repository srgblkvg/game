# Express Route Ordering (CRITICAL)

Express matches routes in file-order. A parameterized route defined BEFORE a specific route will swallow it.

## Real case
`router.get('/guild/:id', ...)` at line 234, `router.get('/guild/quest', ...)` at line 1016.
Request `GET /guild/quest` → Express matches `/guild/:id` first → `req.params.id = "quest"`.
`parseInt("quest")` → `NaN` → `SELECT ... WHERE g.id = NaN` → PG `invalid input syntax for type integer: "NaN"` → 500.

## Fix pattern
```typescript
router.get('/guild/:id', async (req, res, next) => {  // ADD next param
    const guildId = parseInt(req.params.id);
    if (isNaN(guildId)) return next();                 // pass to next matching route
    // ... rest of handler
});
```

## Audit command
```bash
# Find parameterized GET routes that could swallow specific routes
grep -n "router\.get.*\/:.*, async" server/src/routes/*.ts
```

All parameterized GET routes MUST have the `isNaN` + `next()` guard.

## Don't do
- Reordering routes (fragile, easy to break again)
- Renaming routes to avoid collision (API contract changes)
