# Auction Chat — Backend Query Fix (2026-07-02)

## Problem

Auction chat messages (`senderId=0`, system messages) disappeared from chat after adding new lots. Two root causes:

### 1. INNER JOIN drops system messages

`/api/chat/recent` used `JOIN users u ON m.senderId = u.id`. Auction messages have `senderId=0` — no matching user row → silently excluded.

**Fix:** `LEFT JOIN users u ON m.senderId = u.id` — returns `NULL` for `senderName` instead of dropping the row.

### 2. Auction messages compete with regular chat for LIMIT 20

Even with LEFT JOIN, auction messages older than the 20 most recent regular messages are excluded.

**Fix:** Redesigned query — auction messages for ACTIVE lots are always returned, not counted toward the limit:

```sql
SELECT m.*, u.username as senderName,
       CASE WHEN al.id IS NOT NULL THEN 1 ELSE 0 END as is_active_auction
FROM chat_messages m
LEFT JOIN users u ON m.senderId = u.id
LEFT JOIN auction_lots al ON al.id = (m.item_data::jsonb->>'lotId')::int
WHERE (al.id IS NOT NULL)  -- active auction messages — ALL of them
   OR ((m.targetId IS NULL OR m.senderId = ? OR m.targetId = ?) AND m.id IN (
     SELECT id FROM chat_messages
     WHERE item_data IS NULL AND (targetId IS NULL OR senderId = ? OR targetId = ?)
     ORDER BY createdAt DESC LIMIT ?
   ))  -- regular messages — last N
ORDER BY m.createdAt ASC
```

Key details:
- `(m.item_data::jsonb->>'lotId')::int` — PostgreSQL JSON extraction (NOT SQLite `json_extract`)
- `al.id IS NOT NULL` — only messages for currently active lots (sold/expired lots have their chat_messages rows deleted)
- Regular messages still use the subquery with LIMIT
- Results merged and sorted chronologically

**Pitfall: `item_data::jsonb` fails on NULL.** Regular chat messages have `item_data = NULL`. The LEFT JOIN condition `(m.item_data::jsonb->>'lotId')::int` crashes with NULL input. **Must guard with `m.item_data IS NOT NULL` before the cast:**

```sql
LEFT JOIN auction_lots al ON m.item_data IS NOT NULL AND al.id = (m.item_data::jsonb->>'lotId')::int
```

## Files

- `server/src/routes/chat.ts` — `/chat/recent` endpoint
- `server/src/routes/auction.ts` — lot creation/deletion, chat message insertion/cleanup

## Client Crash: truncate(null)

After LEFT JOIN, system auction messages have `senderName = NULL` (no user with id=0). Client-side `truncate()` in `MessageList.tsx` called `nick.length` on null → `Cannot read properties of null (reading 'length')` → entire render crashes.

**Fix in `client/src/components/chat/MessageList.tsx`:**
```typescript
function truncate(nick: string | null): string {
    if (!nick) return 'Глашатай';
    return nick.length > MAX_NICK_LENGTH ? nick.slice(0, MAX_NICK_LENGTH) + '…' : nick;
}
```

Also disable nick-click for system messages: `onClick={isOwn || !firstMsg.senderName ? undefined : ...}`
