# Notification pitfalls

## React error #31: Objects as React children

**Symptom:** `Minified React error #31; visit https://react.dev/errors/31?args[]=object%20with%20keys%20%7B...%7D`

**Cause:** `pushNotification()` accepts `data?: any` in `NotificationData`, but the `NotificationToast` renders `{t.data}` directly as a React child. If `data` is an object (not a string), React throws error #31.

**Fix:** Always pass `data` as a JSON string:
```ts
pushNotification(userId, {
    type: 'battle_result',
    message: '...',
    data: JSON.stringify({ eventId, path: '/history?tab=massacre' }),
});
```

On the client side, parse it before use:
```tsx
// In NotificationToast onClick
const d = typeof t.data === 'string' ? JSON.parse(t.data) : t.data;
if (d?.path) window.location.href = d.path;
```

## Click-to-navigate pattern

To make a notification clickable (navigating to a page):
1. Server: include `path` in `data` (as JSON string)
2. Client: `NotificationToast` onClick parses `data`, uses `window.location.href = d.path`

Works for any notification type. Use absolute paths like `/history?tab=massacre` or `/massacre?eventId=3`.

## Empty notification display

If the notification toast shows raw JSON or empty text, check:
1. Is `data` a string, not an object? (see above)
2. Is `t.message` populated? (template literals with backticks work fine in Node.js)
3. Is the client cache stale? Ctrl+Shift+R
