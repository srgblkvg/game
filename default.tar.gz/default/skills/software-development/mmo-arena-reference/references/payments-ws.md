# Payment Status via WebSocket

Сервер получает колбэк от VK (`POST /api/vk/payments`) или YooKassa (`POST /api/yukassa/webhook`). При успешной оплате — шлёт WS-бродкаст:

```typescript
// routes/vkPayments.ts и routes/yukassa.ts
import { sendToUser } from '../events';

sendToUser(character.id, { type: 'paymentStatus', status: 'success', platform: 'vk', until: newUntil });
```

## Клиент: ChatContext → CustomEvent → PremiumPage

```typescript
// contexts/ChatContext.tsx — в WS onmessage (switch data.type)
case 'paymentStatus': {
  window.dispatchEvent(new CustomEvent('paymentStatus', { detail: data }));
  break;
}

// pages/PremiumPage.tsx — слушаем событие
useEffect(() => {
    const handler = (e: Event) => {
        const data = (e as CustomEvent).detail;
        if (data?.status === 'success') {
            setPaymentMsg('✅ Оплата прошла! Премиум активирован.');
            setTimeout(() => setPaymentMsg(''), 5000);
        }
    };
    window.addEventListener('paymentStatus', handler);
    return () => window.removeEventListener('paymentStatus', handler);
}, []);
```

## YooKassa: таймаут 2 мин

Если пользователь открыл URL оплаты но не заплатил — колбэк не придёт. Добавлен таймаут:

```typescript
const t = setTimeout(() => {
    setPaymentMsg(prev => prev === 'Ожидайте...' ? '❌ Оплата не завершена' : prev);
}, 120000);
// При успехе через WS — снимаем таймер
window.addEventListener('paymentStatus', () => clearTimeout(t), { once: true });
```

## VK: cancelled

`VKWebAppShowOrderBox` возвращает `{ status: 'cancelled' }` при закрытии диалога — сразу показываем ошибку.

## VK: статус через API

Добавлен `GET /api/vk/payments/latest` — возвращает последний статус платежа текущего юзера (`vk_payments` таблица). Можно использовать для поллинга если WS недоступен.
