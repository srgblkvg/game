# Treasury History API (updated June 23)

## Endpoint: `GET /api/guild/treasury/history?period=today|week|month|all`

Response:
```json
{
  "treasury": 5000,
  "contributions": [
    { "userid": 31, "username": "Ждуля", "total": 1000, "count": 3 },
    { "userid": 42, "username": "Player2", "total": 500, "count": 1 }
  ],
  "period": "week"
}
```

- `period=today` — since midnight UTC
- `period=week` — last 7 days
- `period=month` — last 30 days
- `period=all` — no date filter

**Note**: `createdat` is TEXT column, uses ISO string comparison. Not `to_timestamp()` or `datetime()`.

## Guild/mybresponse includes buildings
`GET /api/guild/my` now returns `buildings` array:
```json
{
  "buildings": [
    { "type": "training_ground", "icon": "🏟️", "label": "Тренировочная площадка", "level": 2, "bonus": 4 }
  ]
}
```

## Auction pagination
- `GET /api/auction?page=1&limit=6` — 6 lots per page (was 12)
- Response: `{ lots, totalCount, totalPages, page }`
