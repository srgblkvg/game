# Balance Changes — June 23, 2026

## HP Formula: S+A+M (was S+A+D+M)

`sumStats` in `game/stats.ts`:
```typescript
// Было: PRIMARY_STATS.reduce((sum, k) => sum + (s[k] || 0), 0);  // S+A+D+M
// Стало:
export function sumStats(s: StatRecord): number {
  return (s.s || 0) + (s.a || 0) + (s.m || 0);  // S+A+M
}
```

Причина: танки получали двойное преимущество — защита давала и блок, и HP.
Теперь защита даёт только блок. HP = сила + ловкость + мастерство.

Затронуто: `currentStats()`, `runBattle()`, `buildPlayerStats()` — автоматически через `sumStats()`.
Клиентский `sumStats` в `utils/stats.ts` ТОЖЕ изменён.

## Block cap: 100% → 75%

`battle.ts:blockChance()`:
```typescript
return Math.min(0.75, sv(defStats, F.block) / (sv(defStats, F.block) + 500) + extraBlock / (extraBlock + 300));
```

## Extra stats soft cap: x/300 → x/(x+300)

Все extra-статы (dodge, crit, fullBlock, counter) теперь с диминишингом — асимптота к 1.0.
При 100 → 25% (было 33%), при 300 → 50% (было 100%).

Формулы: `dodgeChance`, `critChance`, `blockChance`, `counterChance`, `fullBlockChance`.

## Premium HP regen fix

`applyHpRegen()` ожидает `premiumUntil`, но вызывающие роуты НЕ передавали его.
Исправлено в `character.ts` и `battle.ts` — добавлено `premiumUntil: user.premiumUntil`.

## Base stat influence reduced ×1.5 (July 6, 2026)

Влияние основных статов на крит/уклон/блок/контрудар уменьшено делением на 1.5.
Экстра-статы с бижутерии теперь весомее относительно базы.

`battle.ts` — все 4 формулы:
```typescript
// crit:   m/(m+500)/1.5 + extraCrit/(extraCrit+300)      кап 80%
// dodge:  a/(a+500)*(1−m_врага/(m_врага+100))/1.5 + extra/(extra+300)  кап 50%
// block:  d/(d+500)/1.5 + extraBlock/(extraBlock+300)    кап 75%
// counter: (m+a)/(m+a+m_врага+d_врага)*0.5/1.5 + extra/(extra+300)     кап 50%
```

### Client display: real % via soft cap

`StatsOverlay.tsx` — экстра-статы теперь показывают реальный процент через `x/(x+300)`:
```typescript
const pct = Math.round((v / (v + 300)) * 100);
```
Было: показывало сырое значение как `+50%`. Стало: `+14%` (50/350).
