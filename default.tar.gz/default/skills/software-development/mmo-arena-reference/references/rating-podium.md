# Rating Page — Top 3 Podium

## Component: Top3Podium.tsx

Пьедестал с топ-3 игроками над таблицей рейтинга.

### Visual specs
- **Colors (solid, no gradient):** gold #daa520, silver #708090, bronze #8b4513
- **Heights:** 80px / 55px / 35px
- **Layout:** 2nd (left), 1st (center), 3rd (right)
- **Bottom line:** wrapper div with maxWidth: 470, line width 100% inside
- **Medals:** 1st 🏆, 2nd 🥈, 3rd 🥉
- **Avatar:** rounded-full, medal-colored border + glow, place badge (bottom-right)
- **Info:** username (medal color), level, ELO (no 🏅), guild tag
- **Click:** navigate to /profile/{id}

### API changes
- `GET /rating` accepts `skip` param — offset skips first N players
- Client passes `skip=3` to start table at 4th place
- `totalPages = Math.max(1, Math.ceil((total - 3) / LIMIT))`
- Row numbering: `i + 1 + (page-1) * LIMIT + 3`

### Rating page order
1. Back button
2. Title
3. "Как зарабатывается рейтинг" (collapsible Card)
4. Top3Podium
5. Search + rank filter
6. Table (starting from 4th place)
