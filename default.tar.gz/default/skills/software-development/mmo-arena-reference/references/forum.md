# Форум

## Таблицы

```sql
CREATE TABLE forum_threads (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    author_id INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    posts_count INTEGER DEFAULT 1,
    is_closed BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE forum_posts (
    id SERIAL PRIMARY KEY,
    thread_id INTEGER NOT NULL REFERENCES forum_threads(id) ON DELETE CASCADE,
    author_id INTEGER NOT NULL REFERENCES users(id),
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    parent_id INTEGER REFERENCES forum_posts(id) ON DELETE SET NULL
);

-- Голосования (2026-07-11)
CREATE TABLE forum_polls (
    id SERIAL PRIMARY KEY,
    thread_id INTEGER NOT NULL REFERENCES forum_threads(id) ON DELETE CASCADE,
    question TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(thread_id)
);
CREATE TABLE forum_poll_options (
    id SERIAL PRIMARY KEY,
    poll_id INTEGER NOT NULL REFERENCES forum_polls(id) ON DELETE CASCADE,
    option_text TEXT NOT NULL,
    votes_count INTEGER DEFAULT 0
);
CREATE TABLE forum_poll_votes (
    poll_id INTEGER NOT NULL REFERENCES forum_polls(id) ON DELETE CASCADE,
    option_id INTEGER NOT NULL REFERENCES forum_poll_options(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(poll_id, user_id)
);

CREATE INDEX idx_forum_threads_updated ON forum_threads(updated_at DESC);
CREATE INDEX idx_forum_posts_thread ON forum_posts(thread_id, created_at);
```

**Права:** `GRANT ALL ON forum_threads, forum_posts, forum_polls, forum_poll_options, forum_poll_votes TO game; GRANT USAGE, SELECT ON SEQUENCE forum_threads_id_seq, forum_posts_id_seq, forum_polls_id_seq, forum_poll_options_id_seq TO game;`

## API

| Метод | Путь | Назначение | Авторизация |
|---|---|---|---|
| GET | `/api/forum/latest` | Последние 3 темы (для Замка) | Публичный (в setupRoutes.ts) |
| GET | `/api/forum/threads` | Список тем с пагинацией (10 на стр) | Требуется (игрок) |
| GET | `/api/forum/thread/:id` | Тема: firstPost + posts (9 на стр) + poll | Требуется (игрок) |
| POST | `/api/forum/thread` | Создать тему (+ опрос: `{poll: {question, options[]}}`) | Требуется (игрок) |
| POST | `/api/forum/reply` | Ответить (body: threadId, content, parentId?), блокируется если is_closed | Требуется (игрок) |
| POST | `/api/forum/poll/vote` | Голосование (body: threadId, optionId). Один голос на юзера | Требуется (игрок) |
| PUT | `/api/forum/thread/:id` | Редактировать название темы (только автор) | Требуется (игрок) |
| PUT | `/api/forum/thread/:id/close` | Закрыть/открыть тему (только автор, body: { closed }) | Требуется (игрок) |
| PUT | `/api/forum/post/:id` | Редактировать сообщение (только автор, body: { content }) | Требуется (игрок) |

**Важно:** `/api/forum/latest` — публичный эндпоинт, добавлен напрямую в `setupRoutes.ts` (не через forumRoutes), чтобы обойти authMiddleware.

## Markdown-рендеринг (2026-07-11)

Клиент использует `marked` + `DOMPurify` для рендеринга сообщений:
- `**жирный**`, `*курсив*`, `~~зачёркнутый~~`, `` `код` ``
- Заголовки `# ## ###`, списки `- * 1.`, цитаты `>`, ссылки `[текст](url)`, таблицы
- GFM включён (`breaks: true, gfm: true`)

**CSS-стили для форума** (`FORUM_STYLES` в `ForumThreadPage.tsx`):
- `blockquote`: синяя левая полоса (`border-left: 2px solid var(--color-accent-info)`)
- `h1-h3`: размеры и отступы
- `code`: фон `var(--color-bg-input)`, скруглённые углы
- `pre code`: без фона
- `a`: цвет `var(--color-accent-info)`, подчёркивание
- `table`: границы коллапса, th с фоном `var(--color-bg-input)`

**При замене рендерера всегда добавлять CSS для blockquote** — юзер заметит пропажу синей полосы у цитат.

## Голосования (2026-07-11)

- Создание: в модалке «Новая тема» — чекбокс «Добавить голосование», вопрос + 2–10 вариантов
- Отображение: Card с синей левой полосой, прогресс-бары, кнопки-варианты
- Ограничения: один голос на пользователя (UNIQUE poll_id, user_id)
- Ответ API голосования: `{ success, options: [{id, option_text, votes_count}], totalVotes }`

## Подсветка сообщений

- **Первое сообщение (автор темы):** синяя левая рамка `border-l-4 border-l-[var(--color-accent-info)]`, фон карточки `bg-[var(--color-bg-card)]`. Иконка 📢 и ярлык «Автор» УБРАНЫ (2026-07-11).
- **Сообщение-цель ответа:** жёлтая левая рамка `border-l-4 border-l-[var(--color-accent-warning)]` (когда replyParentId совпадает с post.id). Проп `replyTargetId` пробрасывается через всё дерево PostCard.
- **Кнопка редактирования:** Button ✎ вместо текстовой ссылки, рядом с «Ответить», только для автора сообщения.

## Питфолы

### camelCase конвертер не работает для forum полей
DB-колонки `created_at`, `updated_at`, `is_closed` конвертируются в `created_At`, `updated_At`, `is_Closed` (не `createdAt`). В клиенте использовать **snake_case**: `post.created_at`, `thread.updated_at`, `thread.is_closed`.

### Пагинация: 9+1 на странице
Первый пост (firstPost) всегда закреплён сверху, не участвует в пагинации. Общий лимит = 9.
- **totalPages**: `Math.max(1, Math.ceil((total - 1) / 9))`
- **offset**: `(page - 1) * 9` — обычная формула (НЕ `(page-2)*limit+1`)

### Переход на последнюю страницу при открытии
Клиент загружает `?page=1` чтобы узнать totalPages, затем сразу `?page=lastPg`. НЕ устанавливать посты из первого запроса (будет мигание).

### user.id (не user.userId)
AuthContext.User имеет поле `id`, не `userId`. Проверка авторства: `user.id === thread.author_id`.

### Древовидные ответы
`parent_id` — ссылка на родительское сообщение. Клиент строит дерево через `buildTree()`. Ответ с `parentId` устанавливает parent_id.

### Цитирование при ответе — каждая строка с `>`, без вложенных цитат

При клике «Ответить» ВСЕ строки сообщения (кроме вложенных цитат) должны получить префикс `> `. Сообщение цитируется **полностью**, без обрезки.

```tsx
// ✅ Правильно
const lines = post.content.split('\n');
const ownLines = lines.filter((l: string) => !l.startsWith('>')); // пропускаем вложенные цитаты
const quoted = ownLines.map((l: string) => `> ${l}`).join('\n');
onReply(`> ${post.author_name}:\n${quoted}\n\n`, post.id);

// ❌ Неправильно — только первая строка с >, остальные как свой текст
const cleaned = stripQuotes(post.content);
onReply(`> ${post.author_name}:\n> ${cleaned}\n\n`, post.id);
```

**Симптом:** Markdown-форматирование (заголовки, списки) отображается как текст автора ответа, а не как цитата.

### Блокировка действий в закрытой теме (КЛИЕНТ + СЕРВЕР)

При `is_closed = true`:
- **Клиент:** скрыты кнопки «Ответить» и ✎ на всех постах (`isClosed` проп), ✎ на названии темы, кнопки голосования задизейблены (`disabled={pollVoting || thread.is_closed}`)
- **Сервер:** PUT `/forum/post/:id` и PUT `/forum/thread/:id` проверяют `is_closed` через JOIN, возвращают 403 «Тема закрыта»
- **Сервер:** POST `/forum/poll/vote` проверяет `is_closed` в `forum_threads`
- Только кнопка «Открыть/Закрыть» доступна автору

### MdToolbar — стандартные символы, не игровые иконки

Компонент `client/src/components/ui/MdToolbar.tsx`. Кнопки: **B** (жирный), *I* (курсив), ~~S~~ (зачёркнутый), **H** (заголовок), " (цитата), • (список). Вставка через `document.getElementById(textareaId)` + манипуляция `selectionStart/End`.

**НЕ использовать `game-icons:*`** — юзер требует общепринятые обозначения. Код (`<>`) и ссылка (🔗) убраны по требованию.

### Модалка новой темы — width="640px"

`<Modal ... width="640px">` + `min-h-[200px]` на textarea. Не использовать дефолтную узкую модалку.

### Blockquote CSS — обязателен при смене рендерера

Если замена `renderContent` на `marked` или другой рендерер — сразу добавлять CSS для `blockquote` (синяя полоса, фон, скругление). Юзер замечает пропажу мгновенно.

### useEffect для скролла при ответе

Фокус и скролл к форме ответа делать через `useEffect([replyParentId, replyText])` с `setTimeout(100ms)`, а не напрямую в обработчике клика. Иначе после отправки/отмены первого ответа повторный клик «Ответить» не срабатывает — ref ещё не привязан.

### FK + удаление пользователя
`forum_threads.author_id` и `forum_posts.author_id` → FK на `users(id)` с `ON DELETE SET NULL`. Все JOIN users — LEFT JOIN + COALESCE.
