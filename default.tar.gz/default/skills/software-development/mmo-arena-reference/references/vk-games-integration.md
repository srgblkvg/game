# VK Games — Интеграция платформы

## Обязательные компоненты

### VK Bridge SDK
- Скрипт в `client/index.html`:
  ```html
  <script src="https://unpkg.com/@vkontakte/vk-bridge/dist/browser.min.js"></script>
  ```
- Инициализация в `client/src/main.tsx`:
  ```ts
  if (window.vkBridge) {
    window.vkBridge.send('VKWebAppInit').catch(() => {});
    document.documentElement.classList.add('vk-iframe');
  }
  ```
- Декларация типа (в main.tsx):
  ```ts
  declare global {
    interface Window {
      vkBridge?: { send: (method: string, params?: Record<string, unknown>) => Promise<unknown> };
    }
  }
  ```

## Скроллбар в iframe

### Проблема
VK iframe (911×700 десктоп) имеет `scrolling="no"`. При `min-height: 100vh` body растягивается под контент → переполнения нет → скролл не появляется. `VKWebAppResizeWindow` ломает `vh`-зависимые элементы → бесконечные циклы ресайза.

### Решение
Только внутри VK (класс `vk-iframe`, добавляется JS когда `window.vkBridge` есть):

```css
html.vk-iframe,
html.vk-iframe body {
  height: 100vh;
  height: 100dvh;
  overflow-y: auto;
  overflow-x: hidden;
}
```

**Ключевое:** `height` (фиксированная) вместо `min-height` (растягивается под контент). На основном сайте класс не добавляется — не затрагивает.

### Антипаттерны (НЕ ДЕЛАТЬ)
- `VKWebAppResizeWindow` с любыми параметрами — вызывает циклы
- 9999px-трюк (выставить огромную высоту, замерить) — 100vh=9999 → scrollHeight=9999 → бесполезно
- ResizeObserver на body/#root — создаёт feedback loop
- `overflow-y: auto` на `min-height: 100vh` — overflow никогда не срабатывает, body растёт под контент
- `min-h-screen` на страницах — меняется с высотой iframe при ресайзе

## Авторизация через VK Bridge

**Актуальный метод (июнь 2026):** Чтение параметров запуска из URL iframe. VK автоматически добавляет `vk_user_id`, `sign`, `vk_app_id` и другие параметры в URL. Этот метод НЕ требует вызова VK API с сервера и не привязан к IP.

### Клиент: VkLoginPage (`/vk-login`)
- Отдельная страница, URL указывается в настройках размещения VK
- Авто-вход: при загрузке читает `vk_user_id` и `sign` из `window.location.search`
- Отправляет на сервер: `{ vkUserId, sign, vkAppId, launchParams }`
- После успеха: `loginUser(data.user, data.token)` → Navigate to `/`
- Поддержка `?nologin=1` для ручного входа (тестирование)
- **НЕ использовать** `window.location.href` — теряет VK-параметры запуска

### Сервер: POST /api/auth/vk-bridge
1. Парсит launchParams, проверяет подпись (временно отключена)
2. Ищет пользователя: `WHERE oauthProvider = 'vk' AND oauthId = ?` (VK user_id)
3. Если пользователь существует:
   - Проверяет что персонаж не удалён (`level > 0 AND currentHp > 0`)
   - Если удалён → удаляет запись и создаёт новую
   - Если жив → обновляет lastLoginAt, возвращает JWT
4. Если нет → создаёт с `oauthProvider='vk'`, `oauthId=VK_ID`, +1 день премиума
5. JWT **ОБЯЗАН** содержать `username` и `role` (см. питфолы)

### Роутинг
```tsx
// App.tsx — отдельный маршрут, всегда рендерит VkLoginPage
<Route path="/vk-login" element={<VkLoginPage />} />
// VkLoginPage сам редиректит когда user?.role есть
if (user?.role || done) return <Navigate to="/" />;
```

### Питфолы авторизации VK
- **`parseUserFromToken` возвращает `username: ''`.** JWT должен содержать поле `username`, иначе после перезагрузки имя пропадает. Сервер: ВСЕГДА включать `username` в `jwt.sign()`.
- **`role` должен быть в JWT.** Без него `user?.role` undefined → все роуты редиректят на /login.
- **`window.location.href` теряет VK-параметры.** VK добавляет params в URL iframe. При редиректе они пропадают → doLogin падает с «Нет параметров запуска».
- **`localStorage.removeItem('token')` в doLogin ломает цепочку.** При перезагрузке новый токен удаляется до того как компоненты его используют.
- **`VKWebAppGetAuthToken` НЕ подходит для серверной авторизации.** Токен привязан к IP клиента, сервер с другим IP получит `access_token was given to another ip address`.
- **Использовать параметры запуска VK, НЕ OAuth-редирект.** В iframe редиректы неудобны, URL-параметры уже содержат всё нужное.

## Авто-вход после удаления персонажа

При удалении персонажа запись в `users` остаётся (с oauthProvider='vk'). При следующем входе:
1. Сервер находит существующего по oauthId
2. Проверяет `level < 1 OR currentHp < 1` → персонаж удалён
3. Удаляет старую запись: `DELETE FROM users WHERE id = ?`
4. Создаёт нового пользователя с чистым персонажем
5. Возвращает новый JWT

## Платёжная система VK

### Сервер
- Роут: `/api/vk/payments` (публичный, ДО auth middleware в setupRoutes)
- Файл: `server/src/routes/vkPayments.ts`
- Колбэк URL в настройках VK: `https://mmoarena.ru/api/vk/payments`
- Обрабатывает: `get_item`, `get_item_test`, `order_status_change`, `order_status_change_test`
- При chargeable: продлевает premiumUntil, пишет лог в vk_payments
- Поиск игрока: `WHERE oauthProvider = 'vk' AND oauthId = ?` (VK user_id)

### Клиент
- PremiumPage: `isVK = !!window.vkBridge`
- VK: `vkBridge.send('VKWebAppShowOrderBox', { type: 'item', item: 'premium_7d' | 'premium_30d' })`
- Сайт: YooMoney (без изменений)

### Подпись колбэков
- Алгоритм: `MD5(sorted_params_without_sig + VK_APP_SECRET)`
- VK_APP_SECRET = Защищённый ключ (из «Разработка → Ключи доступа»)
- Если не сходится — временно отключить: `function verifySignature() { return true; }`

## Платёж: частые ошибки

| Симптом | Причина |
|---|---|
| «Ожидание информации о товаре» висит | Сервер не отвечает / не тот URL |
| `[object Object]` в alert | `JSON.stringify(err)` вместо `String(err)` |
| Invalid signature | Не тот ключ или алгоритм |
| «Character not found» | Игрок не вошёл через VK (нет oauthProvider='vk') |
| Платёж прошёл, премиум не начислен | Нет обработчика `order_status_change_test` |

### Ключи VK
Три типа в «Разработка → Ключи доступа»:
- **Защищённый ключ** — проверка подписи колбэков, env `VK_APP_SECRET`
- **Сервисный ключ доступа** — API-запросы с сервера, env `VK_CLIENT_SECRET`
- **Клиентский ключ** — фронтенд-библиотеки

**Питфол:** ключи цензурятся/обрезаются при передаче через терминал. Использовать base64:
```bash
echo -n 'VK_APP_SECRET=*** | base64  # локально
ssh host "echo 'BASE64_STRING' | base64 -d >> .env"  # на сервер
```

### Цены в голосах
- 1 голос ≈ 7₽
- 7 дней: 14 голосов (≈99₽)
- 30 дней: 42 голоса (≈299₽)

### Премиум при регистрации
- Все новые пользователи (VK, OAuth, email): **1 день** (86400 сек)
- Файлы: `vkBridgeAuth.ts`, `oauth.ts`, `account.ts`
- Менять во всех трёх файлах одновременно

## Запуск игры
- URL: `https://vk.com/app<id>` (например `app54652146`)
- НЕ из панели управления dev.vk.com
- Ошибки `getRootRef` / `stats.vk-portal.net 403` — баги платформы VK, не игры
- Состояние → «Включено», Режим разработки → включить для тестов
