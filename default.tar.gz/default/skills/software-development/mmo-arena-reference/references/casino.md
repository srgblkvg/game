# Игорный дом — Казино (Блэкджек)

## Добавлена: 2026-07-10

## Структура

- **БД:** `casino_games` — одна таблица для всех игр (game_type = 'blackjack', позже покер и т.д.)
- **Сервер:** `server/src/routes/casino.ts` — все эндпоинты казино
- **Клиент:** `client/src/pages/CasinoPage.tsx` — страница с табами (вкладка на игру)
- **Карточка:** `actions_config`, section='castle', path='/casino', sort_order=7

## Таблица casino_games

```sql
CREATE TABLE casino_games (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  game_type TEXT NOT NULL DEFAULT 'blackjack',
  bet INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'playing',
  player_cards TEXT NOT NULL DEFAULT '[]',
  dealer_cards TEXT NOT NULL DEFAULT '[]',
  deck TEXT NOT NULL DEFAULT '[]',
  player_score INTEGER DEFAULT 0,
  dealer_score INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  finished_at TIMESTAMPTZ
);
```

**Питфол:** таблица создана через `sudo -u postgres psql` → юзер `game` не имеет прав. Фикс:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c 'GRANT ALL ON casino_games TO game; GRANT ALL ON SEQUENCE casino_games_id_seq TO game;'"
```
Симптом: `permission denied for table casino_games` в pm2 logs.

## API эндпоинты

| Метод | Путь | Описание |
|-------|------|----------|
| GET | /api/casino/active | Активная игра (скрывает 2-ю карту дилера) |
| POST | /api/casino/blackjack/start | Начать {bet}. Списание, сдача |
| POST | /api/casino/blackjack/hit | Взять карту. Bust -> dealer_won |
| POST | /api/casino/blackjack/stand | Дилер до 17, подсчёт |
| POST | /api/casino/blackjack/double | Удвоение (только на 2 картах) |
| POST | /api/casino/blackjack/surrender | Сдаться, возврат 50% |

## Правила

- 6 колод (312 карт), Fisher-Yates шаффл при каждой игре
- Дилер до 17 (hard 17)
- Блэкджек 3:2, обоюдный -> push (возврат ставки)
- Double: +1 карта, ставка x2
- Surrender: 50% возврат (`Math.floor(bet / 2)`), только первые 2 карты

## Реализация

- Все операции в `db.tx()` с `FOR UPDATE` для изоляции
- Деньги: списание при старте, начисление при исходе
- Карты: JSON-массивы строк `"ранг+масть"` (AH, 10D, KS)
- Масти: H/♥, D/♦, C/♣, S/♠
- TypeScript: `deck[0]!` non-null assertion после проверки `deck.length > 0`

## Подключение

1. `setupRoutes.ts`: `import casinoRoutes` + `app.use('/api', casinoRoutes)` (в блоке после `authMiddleware, requirePlayer, guestCooldown`)
2. `App.tsx`: `lazy(() => import('./pages/CasinoPage'))` + `<Route path="/casino">`

## Клиент: CasinoPage

Страница следует стандартному паттерну страниц проекта:
```tsx
<div className="max-w-2xl mx-auto px-4 py-4">
    <BackButton />                              {/* mb-3 встроен */}
    {actionCard && <PageHeader ... />}           {/* mb-4 встроен, загрузка через /api/actions */}
    <p className="text-xs ... rounded p-2 mb-3"> {/* описание */}
        ...
    </p>
    <div className="flex gap-2 mb-4">           {/* табы */}
        ...
    </div>
    {/* контент вкладки */}
</div>
```

Инпут ставки — VK-совместимый как везде в проекте:
```tsx
const isVK = typeof document !== 'undefined' && document.documentElement.classList.contains('vk-iframe');
const inputType = isVK ? 'text' : 'number';
import { inputClass } from '../utils/formStyles';

<input
    type={inputType}
    inputMode={isVK ? "none" : undefined}
    data-vk-num={isVK ? "true" : undefined}
    autoComplete="off"
    value={bet}
    onChange={e => { const v = e.target.value.replace(/\D/g, ''); setBet(v); }}
    className={inputClass}
/>
```

## Стилизация карт и статусов

Карты: ВСЕГДА `bg-white border border-gray-300` — белый фон как у настоящих игральных карт, читаемо в любой теме.
Масти: красные `text-red-600` (♥ ♦), чёрные `text-gray-900` (♣ ♠).

Статусы игры: НЕ использовать хардкод-цвета (`text-green-400 bg-green-900/30`). Только CSS-переменные:
```tsx
game.status === 'player_won'  ? 'text-[var(--color-accent-success)]'   // победа
game.status === 'dealer_won'  ? 'text-[var(--color-accent-danger)]'    // проигрыш
game.status === 'surrender'   ? 'text-[var(--color-accent-warning)]'   // сдался
                               : 'text-[var(--color-text-muted)]'       // ничья
```
Фон статуса: `bg-[var(--color-bg-input)]` — адаптируется под светлую/тёмную тему.

## Добавление новой игры

1. Новый `game_type` (колонка уже есть)
2. Эндпоинты в `casino.ts` (`/casino/<game>/...`)
3. Вкладка в `CasinoPage.tsx`
4. Обновить subtitle в `actions_config`
