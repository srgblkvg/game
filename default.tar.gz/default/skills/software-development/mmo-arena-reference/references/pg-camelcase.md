# PG camelCase converter quirks

The db/index.ts camelCase converter transforms PG column names to camelCase for client consumption.
However, it only uppercases the FIRST letter of the MATCHED suffix, leaving underscores intact.

## CRITICAL: Converter ADDS camelCase but KEEPS original

**The converter does NOT delete the original key.** It ADD-sets `row[cc] = row[key]` (line 105 of db/index.ts). Both variants exist on the row object.

This means for a column `participant_count`, BOTH `row["participant_count"]` (original) AND `row["participant_Count"]` (camelCase) exist. When in doubt, **always use the original snake_case key** — it is always present and never transformed.

**This was the root cause of a 10-iteration debugging session for massacre history entries.** The client tried `data.participantCount` → undefined, then `data.participant_Count` → ALSO undefined (the actual key has lowercase `c` in the middle). The fix: just use `data.participant_count`.

## Problem

For columns like `created_at`, `updated_at`, the regex on line 60:
```ts
key.replace(/(hash|hp|id|...|at|...)$/i, m => m.charAt(0).toUpperCase() + m.slice(1))
```

Produces: `created_At`, `updated_At` (NOT `createdAt`, `updatedAt`).

The underscore is NOT removed. So client code MUST use `post.created_at`, NOT `post.createdAt`.

## Fix pattern

When adding NEW tables with `_at`, `_id`, `_count` columns, ALWAYS use the snake_case field names in client code:

```ts
// CORRECT — matches actual PG column name, always present
post.created_at
post.updated_at
thread.posts_count

// WRONG — camelCase converter produces created_At, not createdAt
post.createdAt
post.updatedAt
thread.postsCount
```

## Known working fields (from existing users table)
The converter has special cases for known fields like `attacktime` → `AttackTime`, but for new tables you must use snake_case.
