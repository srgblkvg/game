# Tutorial Overlay — пошаговый гайд для новых игроков

## Компоненты

- `client/src/components/TutorialOverlay.tsx` — компонент затенения и подсветки
- `client/src/data/tutorialSteps.ts` — массив шагов туториала (27 шагов)
- `client/src/components/StatAllocation.tsx` — слушатель `tutorial-expand-stats` для авторазворачивания
- `client/src/components/BuffsBlock.tsx` — слушатель `tutorial-expand-buffs`, атрибуты `data-tutorial-buff` на BuffRow
- Интеграция: `client/src/pages/HomePage.tsx`

## Как работает

1. **Триггер:** новый игрок (`character.totalBattles === 0`) + `character.tutorialCompleted !== 1`
2. Флаг хранится в БД: колонка `tutorial_completed INTEGER DEFAULT 0` в таблице `users`
3. После загрузки HomePage и отрисовки DOM (задержка 500ms) показывается TutorialOverlay
4. Оверлей затемняет экран (rgba 0,0,0,0.75), оставляя «окно» вокруг целевого элемента
5. Целевой элемент подсвечивается жёлтой рамкой с box-shadow свечением
6. Карточка-подсказка позиционируется рядом с элементом
7. Кнопки: «Далее» (Enter) — следующий шаг, «Пропустить» (Esc) — закрыть
8. При завершении: `POST /api/character/tutorial-done` → `UPDATE users SET tutorial_completed = 1`

## Серверная часть

- **Колонка:** `ALTER TABLE users ADD COLUMN IF NOT EXISTS tutorial_completed INTEGER DEFAULT 0`
- **Эндпоинт:** `POST /api/character/tutorial-done` (в `server/src/routes/character.ts`)
- **Ответ character/me:** поле `tutorialCompleted: user.tutorialCompleted || 0`
- **camelRows:** суффикс `completed` добавлен в регекс (строка 60 `db/index.ts`) для авто-конвертации `tutorial_completed` → `tutorialCompleted`
- **Миграция на проде:** `sudo -u postgres psql -d game -c "ALTER TABLE users ADD COLUMN IF NOT EXISTS tutorial_completed INTEGER DEFAULT 0;"`

## Техника затенения

Используются четыре фиксированных div'а (top/right/bottom/left) вокруг целевого элемента,
оставляющие «окно» с отступом PADDING=8px. Работает надёжнее чем clip-path и box-shadow трюки.

## Позиционирование подсказки

Функция `calcTooltipPosition()`:
- Проверяет доступное пространство со всех 4 сторон
- Пробует желаемую позицию, при недостатке места — фолбэк на сторону с максимумом пространства
- Крайний фолбэк: центрирование на экране
- **Десктоп:** gap=24px, tooltipH=280px. Позиция: bottom/top/left/right/center с приоритетом желаемой.
- **Мобильный режим** (viewport < 480px): tooltip ВСЕГДА сверху (top = headerH + 8), ширина `calc(100vw - 24px)`, центрирование через `left: 50%; transform: translateX(-50%)`
- Подсвеченный элемент на мобильном скроллится **под** tooltip: `top >= headerH + tooltipEstH + 16`

## Скролл с учётом sticky-шапки и tooltip (мобильные)

**Питфол:** `scrollIntoView` работает даже при `overflow: hidden` на body. `window.scrollBy` — НЕТ (если overflow hidden). Но `scrollIntoView` не учитывает sticky-шапку — элемент уходит под неё.

**Текущий фикс (проверенный):**
```js
// Временно включаем скролл
document.body.style.overflow = '';
if (mobile) {
    // Скроллим чтобы элемент оказался ниже tooltip
    const scrollTarget = window.scrollY + rect.top - topClearance;
    window.scrollTo({ top: scrollTarget, behavior: 'instant' });
} else {
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    window.scrollBy({ top: -(headerH + 16), behavior: 'instant' });
}
document.body.style.overflow = 'hidden';
```

**Питфолы которые НЕ работают:**
- `document.documentElement.scrollTop -= headerH` при `overflow: hidden` — не скроллит
- `window.scrollBy({ top: delta })` при `overflow: hidden` — не скроллит
- `element.scrollIntoView({ block: 'start' })` — не учитывает sticky-шапку

**Ключевое:** `overflow: ''` (восстановить дефолт) → скролл → `overflow: 'hidden'` обратно. Это единственный способ заставить скролл работать гарантированно.

## data-tutorial атрибуты

Каждый целевой элемент должен иметь атрибут `data-tutorial="<key>"`:

| Компонент | Атрибут | Файл |
|-----------|---------|------|
| Header (шапка) | `id="site-header"` (CSS id) | Header.tsx |
| CharacterCard | `data-tutorial="character-card"` | CharacterCard.tsx |
| StatAllocation | `data-tutorial="stat-allocation"` | StatAllocation.tsx |
| Статы (строки) | `data-tutorial-stat="s"/"a"/"d"/"m"` | StatAllocation.tsx |
| BuffsBlock | `data-tutorial="buffs-block"` | BuffsBlock.tsx |
| BuffRow (комната) | `data-tutorial-buff="room"` | BuffsBlock.tsx |
| BuffRow (напиток) | `data-tutorial-buff="drink"` | BuffsBlock.tsx |
| BuffRow (премиум) | `data-tutorial-buff="premium"` | BuffsBlock.tsx |
| Коллекция | `data-tutorial-buff="collection"` | BuffsBlock.tsx |
| Inventory | `data-tutorial="inventory"` | Inventory.tsx |
| Actions | `data-tutorial="actions"` | Actions.tsx |
| RightSidebar toggle | `data-tutorial="right-sidebar"` | RightSidebar.tsx |
| ChatPanel | `data-tutorial="chat-panel"` | ChatPanel.tsx |

Также для карточек действий используются ID: `#action-card-Арена`, `#action-card-Охота`, `#action-card-Банк`, `#action-card-Магазин`, `#action-card-Ремесло`, `#action-card-Работы`, `#action-card-Гильдия`, `#action-card-Аукцион`, `#action-card-Резня`, `#action-card-Трактир`, `#action-card-Замок`.

## Шаги туториала (27 шагов)

Интерфейс `TutorialStep`:
```typescript
interface TutorialStep {
  targetSelector: string;    // CSS-селектор
  title: string;             // заголовок шага
  description: string;       // текст подсказки
  tooltipPosition?: 'top' | 'bottom' | 'left' | 'right' | 'center';
  action?: string;           // кастомное событие перед показом (dispatchEvent)
}
```

Порядок: Шапка → Персонаж → Характеристики (авторазворот) → Сила → Ловкость → Защита → Мастерство → Усиления (авторазворот) → Комната → Напиток → Премиум → Коллекция → Инвентарь → Действия (обзор) → Арена → Охота → Банк → Магазин → Ремесло → Работы → Гильдия → Аукцион → Резня → Трактир → Замок → Боевой журнал → Чат.

Все 11 карточек действий покрыты отдельными шагами (world + castle секции из `actions_config`).
Все 4 элемента усилений покрыты отдельными шагами после разворота блока.

## Кастомные события для взаимодействия компонентов

`action` в шаге вызывает `window.dispatchEvent(new CustomEvent(step.action))`.

- `tutorial-expand-stats` — StatAllocation слушает и делает `setCollapsed(false)`, разворачивая блок перед показом шага характеристик
- `tutorial-expand-buffs` — BuffsBlock слушает и делает `setCollapsed(false)`, разворачивая блок перед показом шага усилений
- При добавлении новых событий: компонент-слушатель добавляет `window.addEventListener` в `useEffect`

## Добавление новых шагов

1. Добавить `data-tutorial="<key>"` на целевой элемент в компоненте (или использовать существующий id/атрибут)
2. Добавить объект шага в массив `tutorialSteps` в `client/src/data/tutorialSteps.ts`
3. Если нужно действие перед шагом — добавить `action: 'event-name'` и слушатель в целевом компоненте
4. Порядок шагов = порядок в массиве

## Питфолы

- **Элемент не в DOM:** если `document.querySelector(targetSelector)` возвращает null — шаг автоматически пропускается
- **z-index:** оверлей 100, рамка 101, подсказка 102. Чат имеет z-index 1000 — оверлей ниже чата. Для шага «Чат» рамка всё равно рисуется корректно
- **Блокировка скролла:** `document.body.style.overflow = 'hidden'` на время туториала, восстанавливается при размонтировании. Для скролла временно сбрасывается в `''`, затем восстанавливается
- **Sticky-шапка:** `scrollIntoView({ block: 'center' })` центрирует элемент без учёта sticky-шапки. Нужна ручная корректировка `scrollBy(-headerH - 16)` после скролла. Скролл работает только при `overflow: ''`
- **Мобильные (ВАЖНО):** tooltip всегда вверху (под шапкой), элемент скроллится под него. Это гарантирует что tooltip и элемент не перекрываются. Tooltip компактный: maxHeight 35vh, padding 12px, уменьшенные шрифты
- **StatAllocation/BuffsBlock:** должны быть развёрнуты перед показом шагов. События `tutorial-expand-stats` / `tutorial-expand-buffs` делают это автоматически
- **Карточки действий:** загружаются асинхронно из API `/api/actions`. Если карточки ещё не загружены к моменту шага — он будет пропущен. Задержка 500ms перед стартом туториала даёт время на загрузку
- **Список карточек на проде:** получить через `SELECT title, section, path FROM actions_config ORDER BY sort_order`. Сверять с шагами при изменении состава карточек
- **dataTutorial в BuffRow:** BuffRow принимает опциональный проп `dataTutorial?: string`, который применяется как `data-tutorial-buff={dataTutorial}` на div
