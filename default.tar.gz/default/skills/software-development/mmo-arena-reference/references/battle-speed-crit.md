# Battle Speed & Crit Animation Fix

## Speed
- All battles run at x2 by default (useBattleLogic.ts, BestiaryPage.tsx)
- x1/x2 toggle buttons removed from both PvP and PvE
- Skip button always visible (disabled without premium, overlay div catches clicks → tooltip)

## Crit Animation — z-index conflict fix

**Problem:** Crit animation not visible because `attacking` setTimeout (600ms) clears z-index after crit step sets it to 30.

**Root cause:** The attack step's `setTimeout(() => { card.style.zIndex = '' }, 600)` fires ~250ms into the crit animation, resetting z-index to empty string.

**Fix in BestiaryPage executeStep (PvE):**
```tsx
const atkTimeoutRef = useRef<number | null>(null);

// Attack step — track timeout
if (step.type === 'attack') {
    if (card) card.style.zIndex = '20';
    frame?.classList.add('attacking');
    if (atkTimeoutRef.current) clearTimeout(atkTimeoutRef.current);
    atkTimeoutRef.current = window.setTimeout(() => {
        frame?.classList.remove('attacking');
        if (card) card.style.zIndex = '';
    }, 600);
}

// Crit step — clear attack timeout, remove attacking class
if (step.type === 'crit') {
    if (atkTimeoutRef.current) { clearTimeout(atkTimeoutRef.current); atkTimeoutRef.current = null; }
    frame?.classList.remove('attacking');
    frame?.classList.add('critting');
    if (card) card.style.zIndex = '30';
    setTimeout(() => {
        frame?.classList.remove('critting');
        frame!.style.filter = '';
        frame!.style.outline = '';
        if (card) card.style.zIndex = '';
    }, 800);
}
```

**useBattleLogic.ts (PvP)** already clears attacking before critting, just bumped z-index to 30.

**CSS animation** — crit is more dramatic than regular attack:
- Bigger rotation: 30° (vs 10° for attack)
- More travel: 70px (vs 30px)
- Bigger scale: 1.35 (vs no scale for attack)
- Red glow: `filter: brightness(1.6) drop-shadow(0 0 20px #e74c3c)` + outline
