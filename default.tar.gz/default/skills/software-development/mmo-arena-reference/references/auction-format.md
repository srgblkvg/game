# Аукцион — формат API и фильтры

## Ответ сервера
Сервер ДОЛЖЕН возвращать `{ lots: [...], totalCount, totalPages, page }`.
Клиент читает `data.lots`. Если вернуть просто массив `[...]` — клиент не видит лоты.

## Фильтры статов
Клиент шлёт: `minStr`, `minAgi`, `minDef`, `minMag`.
Сервер мапит в статы: `s`, `a`, `d`, `m`.

## Слоты
База использует: `weapon1`, `shield`, `helmet`, `chest`, `gloves`, `boots`, `ring`, `amulet`, `belt`.
Клиентские категории фильтрации: `weapon` (=weapon1), `shield`, `chest`, `helmet`, `gloves`, `boots`, `ring`, `amulet`, `belt`, `material`, `upgrade`.
Группы: `armor` = helmet+chest+gloves+boots, `accessory` = amulet+ring+belt.

## Пагинация
12 лотов на страницу. Сервер режет `{ lots: paged, totalCount, totalPages, page }`.

## Истечение лотов (expiry flow)

Обработка просроченных лотов происходит в `GET /auction` (при каждом запросе списка).

### Лоты со ставками (currentBidderId NOT NULL)
1. Продавец получает деньги (currentBid - 10% комиссия), +auctionTrades
2. **Покупатель получает предмет в инвентарь** (с учётом стакинга материалов)
3. Запись в `auction_history`
4. Уведомления: продавцу `auction_sold`, покупателю `system`, бейдж `auction_sales`
5. Лот удаляется

### Лоты без ставок (currentBidderId IS NULL)
1. **Предмет возвращается в инвентарь продавца** (с учётом стакинга)
2. Уведомление продавцу `system`
3. Лот удаляется

ВАЖНО: expiry обрабатывается лениво при заходе на аукцион. Нет фонового scheduler'а.
