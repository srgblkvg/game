# Pattern: Real-time updates via WebSocket events

## Flow
```
Server route → broadcast('eventName', data)  // events.ts
  → WebSocket sends to all clients
  → ChatContext.tsx: switch(data.type) → window.dispatchEvent(new CustomEvent('...'))
  → Component: window.addEventListener('...', () => refetch())
```

## Server side

```typescript
import { broadcast, sendToGuild } from '../events';

// After creating/updating data, broadcast:
broadcast('tournamentCreated', { tournamentId: id, name });
sendToGuild(guildId, { type: 'guildExp', exp: newExp, level: newLevel });
```

- `broadcast()` — всем подключённым клиентам
- `sendToGuild(guildId, data)` — только членам гильдии
- `markDirty(userId)` — конкретному пользователю

## Client side (ChatContext)

```typescript
// In ChatContext.tsx ws.onmessage switch:
case 'tournamentCreated': {
  window.dispatchEvent(new CustomEvent('tournamentUpdated'));
  break;
}
case 'guildExp': {
  window.dispatchEvent(new CustomEvent('guildExpUpdated', { detail: data }));
  break;
}
```

## Client side (component)

```typescript
// In component useEffect:
const handler = () => load(); // refetch data
window.addEventListener('tournamentUpdated', handler);
return () => window.removeEventListener('tournamentUpdated', handler);
```

## Existing events
- `'auctionChanged'` — аукцион обновился (dispatchEvent)
- `'guildQuestProgress'` — прогресс квеста гильдии (detail: questData)
- `'tournamentUpdated'` — список турниров изменился
- `'serverTick'` — тик сервера (каждую секунду, detail: time)
- `'massacreTick'` — состояние резни (detail: { id, status, timeLeft, participant_count })

## ServerTick: добавление новой фичи

Паттерн для добавления данных в serverTick (на примере резни):

**Сервер** (`websocket.ts`):
1. Один запрос на тик (ДО цикла по пользователям), не N запросов:
```typescript
const data = await db.one(`SELECT ... FROM table WHERE ...`, []);
```
2. Добавить в payload каждого пользователя:
```typescript
if (data) payload.massacre = { id, status, timeLeft, participant_count };
```

**Клиент** (`ChatContext.tsx`):
3. Добавить dispatch в switch:
```typescript
if (data.massacre) {
  window.dispatchEvent(new CustomEvent('massacreTick', { detail: data.massacre }));
}
```

**Клиент** (компонент):
4. Слушать событие:
```typescript
const handler = (e: Event) => {
  const d = (e as CustomEvent).detail;
  setCount(d.participant_count);
  setTimeLeft(d.timeLeft);
};
window.addEventListener('massacreTick', handler);
return () => window.removeEventListener('massacreTick', handler);
```

**Принцип:** один запрос к БД на тик (не на каждого пользователя), данные кешируются в переменной, рассылаются всем. Клиент НЕ поллит HTTP — все обновления через WS.
