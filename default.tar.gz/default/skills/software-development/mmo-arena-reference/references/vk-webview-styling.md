# VK WebView styling constraints

## No opacity / alpha transparency

**VK WebView does NOT support CSS opacity or alpha transparency** (Tailwind's `/10`, `/20`, `/30` modifiers, or `rgba()` with alpha < 1). These render incorrectly or not at all.

**Fix:** Use solid colors instead:
```tsx
// WRONG — doesn't work in VK WebView
className="bg-[var(--color-accent-warning)]/10 text-[var(--color-accent-warning)]"

// CORRECT — solid colors
className="bg-[#3d2e00] text-[#f0c040] border border-[#5a4200]"
```

Pick appropriate hex values for:
- Dark theme backgrounds (dark saturations)
- Light text on dark backgrounds
- Borders slightly lighter than background

## Yellow text on yellow background

In light theme, yellow text (`#f1c40f`) on yellow transparent background becomes invisible. Always use high contrast combinations:
- Light backgrounds → dark text
- Dark backgrounds → light text

## WebP images

WebP format IS supported in VK WebView. No need to convert to PNG/JPEG.
