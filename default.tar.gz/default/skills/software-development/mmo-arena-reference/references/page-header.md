# PageHeader — заголовок страницы с фоном из карточки действия

## Компонент

`client/src/components/ui/PageHeader.tsx`

Props: `title`, `icon` (iconify string), `bgImage` (URL или null)

Рендерит заголовок в стиле карточек Actions: тёмный `bg-secondary` фон, иконка + заголовок в одну строку слева снизу, с фоновым изображением как `<img>` (не CSS `background-image` — VK WebView не грузит).

Текст: `text-[var(--color-text-primary)]` — работает в обеих темах.

Сбрасывает скролл при монтировании (снимает `position: fixed` с body, скроллит `documentElement` и `body` через `requestAnimationFrame`).

## Паттерн использования

**ВАЖНО: PageHeader внутри контентного контейнера, НЕ снаружи.** Иначе ширина не совпадает с контентом.

```tsx
import PageHeader from '../components/ui/PageHeader';
import { getHeaders } from '../api/helpers';

// В компоненте:
const [actionCard, setActionCard] = useState<any>(null);
useEffect(() => {
  fetch('/api/actions', { headers: getHeaders() })
    .then(r => r.json())
    .then((cards: any[]) => {
      const c = cards.find((x: any) => x.path === '/auction');
      // Для Арены (нет path): x.title === 'Арена'
      if (c) setActionCard(c);
    }).catch(() => {});
}, []);

// В JSX — ВНУТРИ контентного контейнера:
return (
  <div className="px-4 py-4 max-w-4xl mx-auto">
    <BackButton />
    {actionCard && <PageHeader title="Аукцион" icon={actionCard.icon} bgImage={actionCard.bg_image} />}
    ...контент страницы...
  </div>
);
```

## Страницы

Все 11 страниц из карточек Actions: Bestiary (Охота), Arena, Jobs, Shop, Bank, Craft, Auction, Tavern, Guild, Castle, Massacre.

Для Арены (нет `path` в `actions_config`): искать по `x.title === 'Арена'`.

## Удаление старых заголовков

При добавлении PageHeader ОБЯЗАТЕЛЬНО удалять старые h1/h2. Симптом дублирования: два заголовка на странице. Старые заголовки различаются на каждой странице — удалять вручную, не sed'ом.

## БД

Изображения: `actions_config.bg_image` → `/uploads/admin/actions/*.webp`. Nginx CORS уже настроен.
