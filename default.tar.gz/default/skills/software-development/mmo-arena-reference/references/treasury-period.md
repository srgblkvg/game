# Treasury History Periods

## API
```
GET /api/guild/treasury/history?period=today|week|month|all
```

Response:
```json
{
  "treasury": 15000,
  "contributions": [
    {"userid": 31, "username": "Ждуля", "total": 5000, "count": 3},
    {"userid": 42, "username": "Player2", "total": 3000, "count": 1}
  ],
  "period": "week"
}
```

## PG Column Type Pitfall
`guild_treasury_log.createdat` is **TEXT**, not TIMESTAMP.
Do NOT use `to_timestamp()` — use ISO date string comparison:

```typescript
// ✅ CORRECT
const d = new Date(); d.setHours(0,0,0,0);
dateFilter = `AND l.createdat >= '${d.toISOString()}'`;

// ❌ WRONG — SQLite syntax, fails on PG
dateFilter = `AND l.createdat >= datetime(${startOfDay}, 'unixepoch')`;

// ❌ WRONG — type mismatch: text >= timestamp
dateFilter = `AND l.createdat >= to_timestamp(${startOfDay})`;
```

## Client Auto-Load Pattern
Treasury must auto-load when switching to the tab:

```tsx
const [tab, setTab] = useState(0);
const [treasuryPeriod, setTreasuryPeriod] = useState('week');

useEffect(() => {
  if (tab === 2) loadTreasury(treasuryPeriod);
}, [tab]);
```

Without this, the history tab shows empty until the user explicitly clicks a period button.

## Filter System Users
System users (id=0) create entries in `guild_treasury_log`. Filter them:
```sql
WHERE l.guildid = $1 AND l.userid > 0
```

## Client Display
Period selector buttons: Сегодня/Неделя/Месяц/Всё.
Contributions shown as: `{username} ({count} раз)  +{total}`.
