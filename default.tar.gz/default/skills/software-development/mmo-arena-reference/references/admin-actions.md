# Action Cards (actions_config)

Карточки действий на главной странице (Охота, Арена, Магазин, Аукцион, etc.) управляются через таблицу `actions_config` в БД.

## Структура

```sql
SELECT id, section, title, sort_order FROM actions_config ORDER BY section, sort_order;
```

- `section`: `'world'` (🌍 МИР) или `'castle'` (🏰 Площадь)
- `sort_order`: порядок внутри секции (1, 2, 3...)

## Изменение порядка

Просто поменять `sort_order` местами:

```sql
UPDATE actions_config SET sort_order = CASE
  WHEN title = 'Аукцион' THEN 1
  WHEN title = 'Магазин' THEN 4
END WHERE title IN ('Аукцион', 'Магазин');
```

## Продакшен

На VPS через SSH + postgres:

```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c 'UPDATE actions_config SET ...'"
```

Изменение мгновенное — перезапуск сервера не нужен.

## Full-width карточка (Замок)

Карточка с `title = 'Замок'` рендерится особым образом в `Actions.tsx`:
- `col-span-full` в гриде (на всю ширину)
- Горизонтальный лейаут: текст слева, кнопка «Перейти» справа
- Определяется по `card.title === 'Замок'` в CardGrid

Для добавления новой full-width карточки — добавить условие в CardGrid аналогично замку.\n