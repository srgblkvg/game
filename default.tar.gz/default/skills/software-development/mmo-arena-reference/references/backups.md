# Бекапы продакшена

## Что бекапится (каждый час)

Скрипт `/opt/game/backup-uploads.sh`:
- `uploads/` → tar.gz в `/opt/game/backups/uploads/uploads-YYYYMMDD-HHMM.tgz`
- `.env` → копия в `/opt/game/backups/env/.env-YYYYMMDD-HHMM`

Хранится 72 копии (3 дня), старые автоматически удаляются.

## Установка

```bash
ssh root@194.226.142.237 'cat > /opt/game/backup-uploads.sh << '"'"'EOF'"'"'
#!/bin/bash
D=/opt/game/backups
mkdir -p $D/uploads $D/env
tar czf "$D/uploads/uploads-$(date +%Y%m%d-%H%M).tgz" -C /opt/game/server uploads
cp /opt/game/server/.env "$D/env/.env-$(date +%Y%m%d-%H%M)"
ls -t $D/uploads/*.tgz 2>/dev/null | tail -n +73 | xargs -r rm
ls -t $D/env/.env-* 2>/dev/null | tail -n +73 | xargs -r rm
EOF
chmod +x /opt/game/backup-uploads.sh
(crontab -l 2>/dev/null | grep -v backup-uploads; echo "0 * * * * /opt/game/backup-uploads.sh") | crontab -
/opt/game/backup-uploads.sh
```

## Проверка

```bash
ssh root@194.226.142.237 "crontab -l | grep backup; ls -la /opt/game/backups/uploads/ | tail -3; ls -la /opt/game/backups/env/ | tail -3"
```

## Восстановление uploads

```bash
ssh root@194.226.142.237 "cd /opt/game/server && tar xzf /opt/game/backups/uploads/<нужный-файл>.tgz"
```

## Восстановление .env

```bash
ssh root@194.226.142.237 "cp /opt/game/backups/env/.env-<дата> /opt/game/server/.env && pm2 restart game-server"
```

## Занимаемое место

~6.4MB на копию (uploads) + ~500B (.env). При 72 копиях: ~460MB максимум.
