# VK WebView Android Keyboard Fix — Custom Keyboard Works

> **iOS keyboard fix:** see `vk-games` skill → `references/vk-ios-keyboard-fix.md` — `scrollBy` after `focusin` triggers iOS viewport shift. Fix: skip centering on iOS.

## Problem
В VK WebView на Android при фокусе на текстовый input страница уезжает вверх, оставляя пустое пространство над клавиатурой. ~74% экрана под клавиатуру.

## Root Cause
Android System WebView при `windowSoftInputMode` сжимает viewport, но body сохраняет старую высоту. Поведение контролируется на уровне ОС/активности, не из JavaScript.

## What Was Tried (ALL FAILED)

### Viewport + CSS approach (2026-07-02, совет от другого разработчика)
- `interactive-widget=resizes-content` — не работает в VK WebView
- `100dvh` вместо `100vh` — body.offsetHeight остаётся 1681px
- `position: static` вместо `fixed` у хедера — не влияет
- Результат: **не помогло**, откачено обратно на `2fa65b7`

### JS visualViewport approach
- `visualViewport.offsetTop` = 0 (WebView не скроллится на уровне ОС)
- JS `body.style.height = visualViewport.height` — body сжимается (1681→224), но визуально сдвиг остаётся
- rAF-луп + `body.style.height` + clamp scrollTop — не предотвращает сдвиг
- `vkKeyboardFix.ts` создан и удалён в `2fa65b7`

### VK Bridge API
- `VKWebAppResizeWindow` — не имеет эффекта
- `VKWebAppUpdateInsets` — события не приходят
- VK Bridge 3.0.2: методов управления клавиатурой нет

### CSS positioning
- `position: fixed` + `transform: translateY` — не помогает
- `overflow: hidden` на body — не помогает
- `scrollIntoView` — не помогает

## Current State (2026-07-02)
После отката в `2fa65b7`:
- Кастомная клавиатура `VkKeyboard.tsx` — **АКТИВНА**
- `vkInputMode.ts` (MutationObserver `inputmode="none"`) — **АКТИВЕН**
- viewport — обычный `width=device-width, initial-scale=1.0` (без interactive-widget)
- CSS — `height: 100vh` + `height: 100dvh`, `position: fixed` хедера
- `vkKeyboardFix.ts` — **УДАЛЁН**

## The Only Working Workaround
Кастомная клавиатура: `inputmode="none"` на всех инпутах → нативная клавиатура не вызывается → нет сдвига WebView.
Реализация: `client/src/components/VkKeyboard.tsx` + `client/src/utils/vkInputMode.ts`.

## When to Delete Custom Keyboard
Только после того как VK исправит `windowSoftInputMode` на своей стороне
ИЛИ официально задокументирует другой способ управления WebView-клавиатурой.

## Files to Clean Up When VK Fixes This
- `client/src/components/VkKeyboard.tsx`
- `client/src/utils/vkInputMode.ts`
- Импорты/вызовы в `main.tsx` и `App.tsx` (помечены TODO)
- CSS `.vk-keyboard` правила в `theme.css`
