# Добавление нового стата — пошаговый рецепт

Пример: добавляем стат «Удача» (ключ `luck`).

## 1. Сервер — реестры (`game/stats.ts`)

```typescript
// PRIMARY_STATS — добавить ключ
export const PRIMARY_STATS = ['s', 'a', 'd', 'm', 'luck'] as const;

// StatRecord — добавить поле
export type StatRecord = { s: number; a: number; d: number; m: number; luck: number };

// EXTRA_STATS — если нужно (опционально)
```

## 2. Сервер — хелперы обновятся автоматически

`sumStats()`, `addStats()`, `scaleStats()` итерируют `PRIMARY_STATS` → новый стат учтён.

## 3. Сервер — боевые механики (если стат влияет на бой)

```typescript
// game/stats.ts — конфиг F
const F = {
  // Добавить luck в нужные механики:
  crit: ['m', 'luck'],   // крит теперь зависит от магии + удачи
  dodgeDef: 'a',
  // ...
} as const;
```

Формулы в `battle.ts` используют `sv(stats, F.crit)` → автоматом суммируют оба стата.

## 4. Сервер — БД

```sql
ALTER TABLE users ADD COLUMN baseLuck INTEGER DEFAULT 5;
```

## 5. Сервер — helpers.ts

```typescript
// db/helpers.ts — getBaseStats()
export function getBaseStats(user: any): StatRecord {
  return { s: user.baseS ?? 5, a: user.baseA ?? 5, d: user.baseD ?? 5, m: user.baseM ?? 5, luck: user.baseLuck ?? 5 };
}

// USER_BATTLE_FIELDS — добавить u.baseLuck
export const USER_BATTLE_FIELDS = `
  ..., u.baseLuck
`;
```

## 6. Сервер — напитки (опционально)

```typescript
// game/drinks.ts — если есть напиток на удачу
lucky_potion: { s: 0, a: 0, d: 0, m: 0, luck: 10 },
```

## 7. Клиент — реестр и лейблы (`utils/stats.ts`)

```typescript
export const PRIMARY_STATS = ['s', 'a', 'd', 'm', 'luck'] as const;
export const STAT_LABELS: Record<string, string> = {
  s: 'Сила', a: 'Ловкость', d: 'Защита', m: 'Мастерство',
  luck: 'Удача',
};
```

## 8. Клиент — Character interface (`GameContext.tsx`)

```typescript
// stats — не трогать, сервер сам пришлёт
// baseStats — добавить luck
```

## 9. Клиент — UI обновится автоматически

`StatsOverlay.tsx`: `PRIMARY_STATS.map(k => [STAT_LABELS[k], stats[k]])` → удача появляется.
`ItemStats.tsx`: `Object.entries(item.bonuses)` → бонусы удачи на шмоте показываются.

## 10. Компиляция + деплой

```bash
cd server && npx tsc && rsync ... && ssh ... pm2 restart
cd client && npx vite build && rsync ...
```

## Файлы, которые НЕ требуют правок

- `battle.ts` — формулы используют `F` и `sv()`, новый стат в конфиге → учтён
- `currentStats()` — итерирует PRIMARY_STATS
- Клиентские компоненты (StatsOverlay, ItemStats, CharacterCard) — итеративные
- Роуты — используют `getBaseStats()` который вернёт новый стат
