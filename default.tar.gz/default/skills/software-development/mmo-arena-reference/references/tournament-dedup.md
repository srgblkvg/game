# Tournament Dedup Fix (2026-07-03)
# Tournament Dedup Fixes

## Fix #1: Order (2026-07-03)

`GET /tournament` called `getOrCreateTournament()` BEFORE `autoAdvance()`:
1. getOrCreate → creates new
2. autoAdvance → advances old
3. Division has 2 active tournaments

**Fix:** `autoAdvance` FIRST, then `getOrCreateTournament`.

## Fix #2: Race condition in getOrCreateTournament (2026-07-11)

`getOrCreateTournament()` had a non-atomic check-then-insert:
```typescript
const recheck = await db.one(...);  // check
if (recheck) continue;
await db.run('INSERT ...');         // insert
```
Two concurrent calls pass the check simultaneously → duplicate INSERT.

**Fix:** wrap in `db.tx` with `SELECT ... FOR UPDATE`:
```typescript
await db.tx(async (client) => {
    const recheck = (await client.query(
        `SELECT id FROM tournaments WHERE division = $1 AND status IN ('registration', 'in_progress') AND type = 'official' FOR UPDATE`,
        [div.name]
    )).rows[0];
    if (recheck) return; // locked — already exists
    await client.query('INSERT INTO tournaments (...) VALUES (...)');
});
```

**Pattern:** any create-if-not-exists with concurrent callers → transaction + `FOR UPDATE`.
