# Guild Split Script

## Location
`/mnt/c/project/game/server/split_guild.js` — Node.js скрипт для разделения `guild.ts` на модули.

## Usage
```bash
# 1. Убедиться что оригинальный guild.ts не перезаписан (через git)
cd /mnt/c/project/game/server
git show HEAD:server/src/routes/guild.ts > /tmp/guild_orig.ts
scp /tmp/guild_orig.ts root@194.226.142.237:/opt/game/server/src/routes/guild.ts

# 2. Скопировать скрипт и запустить
scp split_guild.js root@194.226.142.237:/opt/game/server/
ssh root@194.226.142.237 'cd /opt/game/server && node split_guild.js'

# 3. Слить результат обратно
rsync -avz root@194.226.142.237:/opt/game/server/src/routes/guild/ /mnt/c/project/game/server/src/routes/guild/
rsync root@194.226.142.237:/opt/game/server/src/routes/guild.ts /mnt/c/project/game/server/src/routes/guild.ts

# 4. Починить импорты (isGuildAtWar, updateGuildQuestProgress, export)
# Затем:
npx tsc --noEmit
```

## Почему Node.js а не sed
- `sed -n` через ssh heredoc ломает кавычки и пробелы
- Python `execute_code` с `read_file` обрезает файлы при limit
- Node.js `fs.readFileSync` + `lines.slice(s-1, e)` — надёжно

## Результат (2026-06-23, 4-я попытка)
```
src/routes/guild/
├── guildCore.ts      205 строк  (create, my, list, settings, view/:id, leave)
├── guildMembers.ts   255 строк  (requests, invites, join, request, invite, accept, kick, role)
├── guildChat.ts       62 строки  (чат)
├── guildTreasury.ts   91 строка  (депозит, история, налог)
├── guildWar.ts       420 строк  (войны + isGuildAtWar)
├── guildQuests.ts    172 строки  (квесты + updateGuildQuestProgress)
```
Новый `guild.ts` — 19 строк. 0 ошибок компиляции.

## Почему FAILED на tournament.ts и mobs.ts

Оригинальные файлы имеют **разбалансированные скобки** (69 `{` vs 68 `}` в guild до правки). Скобки сбалансированы в контексте всего файла, но при извлечении отдельных секций баланс теряется. Файлы, где скобки сбалансированы пословно (guild после фикса `async function...: Promise<any>`), сплитятся нормально.

**Перед сплитом:** проверить баланс скобок скриптом `check_braces.js` (исключая строки/комментарии/шаблонные литералы). Если depth ≠ 0 — файл НЕ сплитится без правки кода.

## Что НЕ работает
- `cat << 'SCRIPT' | ssh ...` — bash ломает спецсимволы
- `sed -i '...'` через ssh — нестабильно с большими файлами
- `write_file` + `scp` — write_file портит `Bearer ` и другие строки
- `patch replace_all: true` с неоднозначным контекстом — ломает файл в разных местах по-разному
- Попытки сплитить файл с несбалансированными скобками — ведут к `TS1005: '}' expected`
