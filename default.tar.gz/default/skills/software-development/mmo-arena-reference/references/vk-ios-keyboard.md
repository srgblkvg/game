# VK WebView — iOS Keyboard Fix

## Problem
На iOS `inputmode="none"` блокирует нативную клавиатуру НО при `scrollBy` после `focusin` iOS всё равно резервирует viewport под клавиатуру — экран сдвигается вверх на пол-экрана.

## Root cause
Программный скролл (`window.scrollBy`) после фокуса инпута триггерит iOS WebView на показ клавиатурного viewport.

## Fix
В `VkKeyboard.tsx` onFocus handler — центрирование инпута только для Android:

```ts
const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
if (!isIOS) {
  requestAnimationFrame(() => {
    // scrollBy центрирования
  });
}
```

Android продолжает центрироваться. iOS не скроллится → viewport не сдвигается.

## Что НЕ работает
- `readonly` на инпутах — ломает React controlled inputs (value стирается)
- `blur()` после focus — не юзерфрендли (нет курсора)
- `inputmode="none"` — работает на Android, на iOS не полностью
