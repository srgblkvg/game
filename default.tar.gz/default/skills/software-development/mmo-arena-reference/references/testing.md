# Тестирование серверных статов и API без клиента

## Паттерн

Из-за бага `write_file` (ломает `Bearer ` в HTTP-заголовках) тестовые скрипты пишутся так:

1. `write_file` локально → `scp` на VPS → `ssh root@... node /opt/game/server/test-*.js`

**НЕ использовать:**
- `ssh ... node -e "..."` — bash ломает `Bearer ` (откусывает пробел)
- `ssh ... "cat > file << 'EOF' ... EOF"` — heredoc ломает кавычки и `${}`

## Проверка статов пользователя

```bash
scp test-stats.js root@194.226.142.237:/opt/game/server/
ssh root@194.226.142.237 'cd /opt/game/server && node test-stats.js'
```

test-stats.js:
```javascript
require("dotenv").config();
const stats = require("./dist/game/stats");
const db = require("./dist/db/index").db;
const helpers = require("./dist/db/helpers");
const drinks = require("./dist/game/drinks");
const gb = require("./dist/game/guildBuildings");

(async () => {
  const u = await db.one("SELECT * FROM users WHERE id = 31");
  const base = helpers.getBaseStats(u);
  const eq = JSON.parse(u.equipment || "{}");
  const dr = drinks.getDrinkBonuses(u);
  const r = await db.one("SELECT COUNT(*) as cnt FROM collections WHERE userId = 31");
  const bn = await gb.getGuildBonus(31, "arena");
  const st = stats.currentStats(base, eq, dr, r.cnt, bn);
  console.log("S=" + st.s + " A=" + st.a + " D=" + st.d + " M=" + st.m + " HP=" + st.hp);
  
  // Сравнение формул
  const oldBlock = st.d/(st.d+500);
  const newBlock = stats.sv(st, stats.F.block)/(stats.sv(st, stats.F.block)+500);
  console.log("Block match:", oldBlock === newBlock);
})();
```

## Проверка API ответа

```javascript
require("dotenv").config();
const jwt = require("jsonwebtoken");
const http = require("http");
const token = jwt.sign({ userId: 31, username: "test", role: "player" }, process.env.JWT_SECRET);

http.get({
  hostname: "localhost", port: 3001,
  path: "/api/character/me",
  headers: { Authorization: *** " + token }
}, res => {
  let d = "";
  res.on("data", c => d += c);
  res.on("end", () => {
    const j = JSON.parse(d);
    console.log("stats.s:", j.stats.s, "guildBonus:", j.guildBonus, "collectionCount:", j.collectionCount);
  });
});
```

## Проверка всех контекстов гильд-бонуса

```javascript
for (const ctx of ["arena", "pve", "tournament", "war_attack", "war_defense"]) {
  const bn = await gb.getGuildBonus(31, ctx);
  const st = stats.currentStats(base, eq, dr, r.cnt, bn);
  console.log(ctx + ": gb=" + bn + "% S=" + st.s + " HP=" + st.hp);
}
```

## Проверка аукциона

```bash
ssh root@194.226.142.237 'cd /opt/game/server && node -e "
require(\"dotenv\").config();
const db=require(\"./dist/db/index\").db;
(async()=>{
  const now=Math.floor(Date.now()/1000);
  const cnt=await db.one(\"SELECT COUNT(*) as cnt FROM auction_lots WHERE endsAt > ?\",[now]);
  console.log(\"Active lots:\",cnt.cnt);
})();
"'
```

Одноразовые скрипты класть в `/opt/game/server/test-*.js` и удалять после.
