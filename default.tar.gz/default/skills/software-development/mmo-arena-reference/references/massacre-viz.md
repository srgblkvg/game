# Massacre Battle Visualization

Визуализация боя резни — анимированное воспроизведение по логу ходов.

## Компонент: MassacrePage.tsx

### Состояния визуализации
- `vizMode`: переключение текст/визуализация
- `vizStep`: текущий шаг (-1 = до начала)
- `vizPlaying`: автопроигрывание
- `vizSpeed`: скорость (1x/2x/4x)

### HP-трекер
Строится через `hpMap` (useRef):
1. Инициализация: для каждого участника max HP из `p.hp_max`, начальное HP = max
2. Проход по всем строкам лога
3. При damage > 0: уменьшаем HP цели
4. При death: отмечаем `dead = true`
5. На КАЖДОМ шагу записываем текущее HP ВСЕХ участников в history

**Питфол:** история должна содержать записи для КАЖДОГО участника на КАЖДОМ шагу, иначе getHpAtStep падает за границы массива и показывает 0.

### getHpAtStep
```ts
const idx = Math.min(Math.max(0, vizStep + 1), h.history.length - 1);
```
`+1` потому что history[0] — начальное HP, history[1] — после первого хода.

### Цветовая схема
- 🟦 синий — атакующий (`ring-[var(--color-accent-info)]`)
- 🟥 красный — цель атаки (`ring-red-500`)
- 🟨 жёлтый — свой персонаж (`ring-[var(--color-accent-warning)]`)
- HP-бар: зелёный (>50%), жёлтый (25-50%), красный (<25%)
- Мёртвый: `opacity-40 grayscale`

### Легенда
Только атакующий, цель и свой персонаж:
- 🟦 — атакующий
- 🟥 — цель атаки
- 🟨 — ваш персонаж

HP-проценты и ☠ в легенду НЕ включать.

### Управление
- ▶ Play / ⏸ Pause
- ⏮ ⏭ шаг назад/вперёд
- Select: 1x/2x/4x
- Range-ползунок для прокрутки

### Кнопка переключения
```tsx
<Button variant="secondary" size="sm" onClick={() => setVizMode(!vizMode)}>
    {vizMode ? 'Текстовый лог' : 'Визуализация боя'}
</Button>
```

## Сервер: hp_max в ответе лога
`/massacre/log/:eventId` должен возвращать `hp_max` для каждого участника:
```ts
participants: participants.map(p => ({
    id: p.user_id, name: p.username, level: p.level, alive: p.alive,
    hp_max: p.hp_max, hp_current: p.hp_current
})),
```
