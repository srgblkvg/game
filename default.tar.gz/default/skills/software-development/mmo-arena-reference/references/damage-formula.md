# Damage Formula (актуально после 2026-07-06)

## rollDamage (battle.ts)

```
damage = level + factor × (S − level)
```

Где `S = stats.s` (только сила). **Было:** `sumStats(stats)` — сумма S+A+D+M.

**Распределение фактора:**
- 1% — мин урон = `level`
- 1% — макс урон = `S`
- 98% — треугольное `(random+random)/2`:
  - 70% случаев: фактор 0...0.7
  - 30% случаев: фактор 0.7...1.0

**Средний урон:** `level + 0.5 × (S − level)`

## Крит-множитель

```
critMult = 1.5 + 0.5 × (m / (m + 50))
```

Где `m` = мастерство.

## Блок (снижение урона)

```
blockReduction = min(0.75, 0.5 × d_защитника / s_атакующего)
```

## Все бои

| Бой | Функция урона |
|---|---|
| PvP/Арена/Турнир/ГВ | `runBattle()` → `rollDamage()` |
| Резня | `game/massacre.ts` → `rollDamage()` |
| PvE | `routes/mobs.ts` — свой код: `level + random × (s − level)` |
