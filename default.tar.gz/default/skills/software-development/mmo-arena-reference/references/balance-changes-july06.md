# Balance Changes — July 6, 2026

## Урон: только от силы (S)

**Было:** `rollDamage()` использовал `sumStats(stats)` — сумма всех четырёх статов (S+A+D+M).
**Стало:** `stats.s` — только сила.

```
// battle.ts: rollDamage()
- const S = sumStats(stats);
+ const S = stats.s;
```

Формула: `level + random_factor × (сила − level)`.
Убран неиспользуемый импорт `sumStats` из battle.ts.

## Влияние основных статов на крит/уклон/блок/контрудар уменьшено в 1.5

Все четыре формулы в `battle.ts` поделены на 1.5:

- **critChance:** `m/(m+500)/1.5 + extra_crit/(extra_crit+300)` (кап 80%)
- **dodgeChance:** `a/(a+500)*(1−m_врага/(m_врага+100))/1.5 + extra_dodge/(extra_dodge+300)` (кап 50%)
- **blockChance:** `d/(d+500)/1.5 + fullBlock/(fullBlock+300)` (кап 75%)
- **counterChance:** `(m+a)/(m+a+m_врага+d_врага)*0.5/1.5 + extra_counter/(extra_counter+300)` (кап 50%)

## PvE (mobs.ts) — единые формулы с PvP

**Было:** хардкод-формулы в mobs.ts:
```
dodgeChance = agility / (agility + 50)    // давал 87% при a=339
critChance = mst / (mst + 50)             // давал 75% при m=148
critMult = 1.5 + 0.5 * (mst / (mst + 50))
```

**Стало:** импорт из `game/battle.ts`:
```
import { dodgeChance, critChance, critMult } from '../game/battle';
```

Вызовы: `dodgeChance(mobStats, userStats)`, `critChance(userStats)`, `critMult(userStats)`.
Моб получает честные статы: `S=atk, A=agi, D=def, M=mst`.

## Экстра-статы в UI — реальный процент

StatsOverlay.tsx: сырые значения → `x/(x+300)`:
```
const pct = Math.round((v / (v + 300)) * 100);
```

## Проверка всех типов боёв

| Бой | Файл | Функции |
|---|---|---|
| PvP | routes/battle.ts | runBattle() |
| Арена | routes/battle.ts (POST /battle) | runBattle() |
| Турнир | routes/tournament.ts | runBattle() |
| ГВ | routes/guild/guildWar.ts | runBattle() |
| Резня | game/massacre.ts | dodgeChance/critChance/... |
| PvE | routes/mobs.ts | ✅ исправлен, общие функции |

Все через `game/battle.ts`.

## Статы: терминология

- s = Сила
- a = Ловкость
- d = Защита
- m = Мастерство (НЕ магия)
