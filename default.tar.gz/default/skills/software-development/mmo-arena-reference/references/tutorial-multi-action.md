# TutorialOverlay — Multi-Action Support (2026-07-03)

The tutorial step `action` field now supports comma-separated event names for dispatching multiple CustomEvents at once.

## Problem

Tutorial steps often need to collapse the previous section AND expand the next section simultaneously:
- After Mastery → collapse stats + expand buffs
- After Collection → collapse buffs + expand inventory
- After Inventory → collapse inventory

The original single-action design forced separate steps for each action, creating extra "сворачиваем" steps that the user had to click through.

## Solution

In `TutorialOverlay.tsx`, changed the dispatch logic:

```ts
// Before: single event
window.dispatchEvent(new CustomEvent(step.action));

// After: multiple events, comma-separated
step.action.split(',').forEach(a => {
  window.dispatchEvent(new CustomEvent(a.trim()));
});
```

## Usage in tutorialSteps.ts

```ts
// Step 8: when showing Buffs, collapse stats AND expand buffs
{
  targetSelector: '[data-tutorial="buffs-block"]',
  title: 'Усиления',
  action: 'tutorial-collapse-stats, tutorial-expand-buffs',
}

// Step 12: when showing Collection's Next, collapse buffs AND expand inventory
{
  targetSelector: '[data-tutorial-buff="collection"]',
  title: 'Коллекция',
  action: 'tutorial-collapse-buffs, tutorial-expand-inventory',
}
```

## Related Events

| Event | Listener Location |
|---|---|
| `tutorial-expand-stats` | `StatAllocation.tsx` |
| `tutorial-collapse-stats` | `StatAllocation.tsx` |
| `tutorial-expand-buffs` | `BuffsBlock.tsx` |
| `tutorial-collapse-buffs` | `BuffsBlock.tsx` |
| `tutorial-expand-inventory` | `Inventory.tsx` |
| `tutorial-collapse-inventory` | `Inventory.tsx` |
| `tutorial-tab-world` | `Actions.tsx` |
| `tutorial-tab-castle` | `Actions.tsx` |
