# Турниры: дивизионы и фонд из казны (2026-06-29)

## 10 дивизионов с перекрывающимися уровнями

| # | Название | Tier | Уровни | Иконка | Доля от 50% казны |
|---|----------|------|--------|--------|--------------------|
| 1 | Медный | 1 | 1-5 | 🥉 | 1/55 ≈ 0.91% |
| 2 | Бронзовый | 2 | 3-7 | 🥉 | 2/55 ≈ 1.82% |
| 3 | Железный | 3 | 5-9 | 🥈 | 3/55 ≈ 2.73% |
| 4 | Стальной | 4 | 7-11 | 🥈 | 4/55 ≈ 3.64% |
| 5 | Серебряный | 5 | 9-13 | 🥈 | 5/55 ≈ 4.55% |
| 6 | Золотой | 6 | 11-15 | 🥇 | 6/55 ≈ 5.45% |
| 7 | Платиновый | 7 | 13-17 | 🥇 | 7/55 ≈ 6.36% |
| 8 | Мифриловый | 8 | 15-19 | 🥇 | 8/55 ≈ 7.27% |
| 9 | Адамантиновый | 9 | 17-21 | 👑 | 9/55 ≈ 8.18% |
| 10 | Орихалковый | 10 | 19-999 | 💎 | 10/55 ≈ 9.09% |

## Призовой фонд

Фонд = 50% казны замка (`castle_treasury.amount`), распределяется по tier/55:

```typescript
const TIERS_TOTAL = 55; // 1+2+3+4+5+6+7+8+9+10

async function calcDivisionPool(tier: number): Promise<number> {
    const { getTreasury } = await import('../game/treasury');
    const treasury = await getTreasury();
    const half = Math.floor(treasury * 0.5);
    return Math.floor(half * tier / TIERS_TOTAL);
}
```

## Регистрация и кулдаун

- Окно регистрации: **1 час** (`REGISTRATION_WINDOW = 60 * 60`)
- Кулдаун между турнирами одного дивизиона: **4 часа** (`14400 * 1000` ms)
- Максимум игроков: 8 (`MAX_PLAYERS = 8`)

## Файлы

- **Сервер:** `server/src/routes/tournament.ts` — divisions, calcDivisionPool, getOrCreateTournament
- **Клиент (страница):** `client/src/pages/TournamentPage.tsx` — divisionLabels, divisionIcons, divisionBorderClasses, divisionTextClasses (все 10)
- **Клиент (сводка):** `client/src/pages/HistoryPage.tsx` — divisionLabels (все 10)
- **Клиент (панель):** `client/src/components/TournamentBanner.tsx` — DIVISION_LABELS, DIVISION_ICONS, DIVISION_LEVELS (все 10)

## Питфол: TournamentBanner (правая панель)

TournamentBanner.tsx имеет собственные `DIVISION_LABELS`, `DIVISION_ICONS`, `DIVISION_LEVELS`. При добавлении новых дивизионов нужно обновить их ВСЕ, иначе:

- `tournamentLabel()` возвращает английское `division` имя
- `tournamentIcon()` падает в `'🏆'` fallback
- `canJoin()` всегда false → турниры не показываются в панели
