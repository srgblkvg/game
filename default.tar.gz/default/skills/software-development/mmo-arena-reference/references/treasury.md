# Казна замка (Castle Treasury)

## Таблицы

```sql
CREATE TABLE castle_treasury (
    id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    amount INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
INSERT INTO castle_treasury (id, amount) VALUES (1, 0) ON CONFLICT DO NOTHING;

CREATE TABLE treasury_log (
    id SERIAL PRIMARY KEY,
    amount INTEGER NOT NULL,
    source TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

**Права:** после создания через `sudo -u postgres` — `GRANT ALL ON castle_treasury TO game; GRANT ALL ON treasury_log TO game; GRANT USAGE, SELECT ON SEQUENCE treasury_log_id_seq TO game;`

## Сервер

Файл `server/src/game/treasury.ts`:
- `initTreasury()` / `initTreasuryLog()` — создание таблиц
- `addToTreasury(amount, source)` — пополнение (fire-and-forget, .catch(() => {}))
- `getTreasury()` — текущая сумма

API: `GET /api/treasury` → `{ "amount": 12345 }` (публичный, без авторизации)

## Сборы (где вызывается addToTreasury)

| Источник | Сумма | Файл |
|---|---|---|
| Банк — депозит | 2% комиссия | `routes/bank.ts` |
| Банк — перевод | 2% комиссия | `routes/bank.ts` |
| Магазин | 100% цены предмета | `routes/shop.ts` |
| Аукцион — листинг | 5% от стартовой цены | `routes/auction.ts` |
| Аукцион — продажа | 10% от цены сделки | `routes/auction.ts` |
| Крафт — рецепт | `recipe.money_cost` | `routes/craft.ts` |
| Крафт — улучшение | `actualCost` (money_cost/4) | `routes/craft.ts` |

## Клиент

- **Карточка Замок** (`Actions.tsx`): `fetch('/api/treasury')` → показывает `Казна: {formatMoney(treasury)} 🥇` всегда (даже при 0)
- **Страница Замка** (`CastlePage.tsx`): крупный блок с суммой и описанием «Сборы с банка, магазина, аукциона и ремесла»
