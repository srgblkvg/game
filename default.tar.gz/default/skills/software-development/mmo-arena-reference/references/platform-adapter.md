# Platform Adapter

Архитектура для поддержки нескольких платформ (VK, OK, Yandex Games, standalone browser) из одной сборки.

```
src/platforms/
  types.ts       — PlatformAdapter interface
  browser.ts     — BrowserAdapter (дефолт)
  vk.ts          — VkAdapter (детект по vk_user_id)
  adapter.ts     — getPlatformAdapter(): фабрика
```

## Использование в main.tsx

```typescript
import { getPlatformAdapter } from './platforms/adapter';

const platform = getPlatformAdapter();
platform.init();

// Применяем платформо-специфичные настройки
if (platform.bodyClass) {
  document.documentElement.classList.add(platform.bodyClass);
}
const vp = document.querySelector('meta[name="viewport"]');
if (vp) vp.setAttribute('content', platform.viewportMeta);
if (!platform.allowSystemKeyboard) {
  initVkInputMode();
}
```

## Интерфейс PlatformAdapter

```typescript
interface PlatformAdapter {
    readonly id: PlatformId;           // 'browser' | 'vk' | 'ok' | 'yandex'
    readonly name: string;
    init(): Promise<void>;
    get hasCustomKeyboard(): boolean;
    get hasScrollLock(): boolean;
    get bodyClass(): string;
    get viewportMeta(): string;
    get allowSystemKeyboard(): boolean;
}
```

## VK: isVK флаг при перезагрузке фрейма

После перезагрузки фрейма `vk_user_id` может отсутствовать в URL. Фикс: проверять `sessionStorage`:

```typescript
const params = new URLSearchParams(window.location.search);
const vid = params.get('vk_user_id');
const wasVk = sessionStorage.getItem('isVkIframe') === '1';

const isVk = !!(vid || wasVk);
localStorage.setItem('isVK', isVk ? '1' : '0');
```

## Добавление новой платформы

1. Создать класс в `platforms/ok.ts` / `platforms/yandex.ts`
2. Добавить детект в `adapter.ts` → `getPlatformAdapter()`
3. Всё. Клиентский код не меняется.
