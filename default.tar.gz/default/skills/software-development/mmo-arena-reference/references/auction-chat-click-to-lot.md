# Auction: click lot in chat → open on AuctionPage

## Problem
Auction chat messages show lots but clicking them does nothing. User wants to click the lot card in chat and immediately see it on the AuctionPage.

## Solution
Two-part: MessageList navigates with `?lot=<id>` param, AuctionPage reads param and highlights/scrolls to the lot via `useEffect` + `document.getElementById`.

### 1. MessageList.tsx — make auction card clickable
```tsx
<div
    className={`... cursor-pointer hover:border-[var(--color-accent-warning)]`}
    onClick={() => a.lotId && navigate(`/auction?lot=${a.lotId}`)}
>
```

### 2. AuctionPage.tsx — handle lot param
```tsx
import { useSearchParams } from 'react-router-dom';

const [searchParams, setSearchParams] = useSearchParams();
const highlightLotId = searchParams.get('lot');

// Auto-switch to buy tab
useEffect(() => {
    if (highlightLotId) setTab('buy');
}, [highlightLotId]);

// Scroll after lots are loaded (not before!)
useEffect(() => {
    if (!highlightLotId || lots.length === 0) return;
    const el = document.getElementById(`auction-lot-${highlightLotId}`);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const t = setTimeout(() => {
            const p = new URLSearchParams(searchParams);
            p.delete('lot');
            setSearchParams(p, { replace: true });
        }, 2000);
        return () => clearTimeout(t);
    }
}, [lots, highlightLotId]);

// In lot rendering: id on wrapper div, ring-2 on Card
<div key={lot.id} id={`auction-lot-${lot.id}`}>
    <Card className={`mb-3 ${String(lot.id) === highlightLotId ? 'ring-2 ring-[var(--color-accent-warning)]' : ''}`}>
        ...
    </Card>
</div>
```

### Pitfalls

1. **Card component doesn't accept `ref`.** Don't put ref on Card — wrap in a plain div with `id` attribute, access via `document.getElementById` in useEffect.

2. **Scroll before data loads.** Don't scroll in the render cycle (ref callback) — lots haven't been fetched yet. Use useEffect that depends on `[lots, highlightLotId]` to wait for data.

3. **useEffect with `[]` deps misses race.** Don't use `[]` as deps for the scroll effect — `lots` might not be loaded yet. Depend on `[lots, highlightLotId]`.

4. **Лот на другой странице.** Клиент всегда грузит page=1, но лот может быть на page=3 — `scrollIntoView` не найдёт элемент. **Решение (2026-07-06):** сервер принимает `highlightLot=X`, находит лот в отфильтрованном списке, вычисляет `targetPage = floor(idx/limit) + 1`, возвращает `{ page: targetPage }`. Клиент передаёт `highlightLot` при page=1, применяет `data.page` из ответа.

```typescript
// server/routes/auction.ts — перед пагинацией:
const highlightLot = parseInt(req.query.highlightLot) || 0;
if (highlightLot && page === 1) {
    const idx = filtered.findIndex(l => l.id === highlightLot);
    if (idx !== -1) {
        const targetPage = Math.floor(idx / limit) + 1;
        if (targetPage !== 1) {
            const paged = filtered.slice((targetPage-1)*limit, targetPage*limit);
            return res.json({ lots: paged, ..., page: targetPage });
        }
    }
}

// client/AuctionPage.tsx — в load():
if (highlightLotId && p === 1) qs.set('highlightLot', highlightLotId);
```
