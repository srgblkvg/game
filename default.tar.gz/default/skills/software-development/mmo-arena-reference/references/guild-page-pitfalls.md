# GuildPage JSX Editing Rules

## DO NOT PATCH — WRITE FILE
GuildPage.tsx has deeply nested JSX (tabs + conditionals + maps + sub-components).
Any `patch()` call on the render section causes cascading JSX structure errors.

**RULE:** When GuildPage needs changes, rewrite the entire file with `write_file()`.

**History of failures:**
- 6+ patch attempts on GuildPage → 6+ rollbacks via `git checkout`
- Cause: `patch()` replaces text but JSX closing tags get orphaned
- Same file rewritten via `write_file()` compiles on first try

## Safe Edit Patterns for Other Files
For files <200 lines with simple structure:
- `sed -i 's/old/new/'` — single-line replacements (imports)
- `patch()` with unique context — OK for handlers/state

## Buildings Data Flow
- Server: `getGuildBuildings(userId)` returns `[{type, icon, label, level, bonus}]`
- API: `/guild/my` → `{ guild: {...}, buildings: [...] }` — **buildings at TOP level, not inside guild**
- Client: `setGuild({...data.guild, buildings: data.buildings})` — merge into guild object

## Tab Indices
After 2026-06-23 rewrite:
- 0: Обзор (quest, war)
- 1: Постройки (buildings list)
- 2: Казна (deposit/tax/history)
- 3: Участники (invite, requests, members)
