# Аукцион — вкладка в чате

## Архитектура

Аукционные сообщения идут через общую таблицу `chat_messages` и фильтруются на клиенте по `item_data.type`.

**Сервер:**
- `senderId: 0` (система), `targetId: NULL` (не приватное)
- `item_data` — JSON с полем `type: 'auction_lot' | 'auction_bid' | 'auction_buyout'`
- Broadcast через EventBus: `broadcast('message', { message: msg })` → WS → клиент

**Клиент:**
- ChatContext получает `{ type: 'message', message: {...} }` через WS, добавляет в общий массив `messages`
- ChatPanel фильтрует: `msg.item?.type?.startsWith('auction_')` → вкладка Аукцион
- Общий чат ИСКЛЮЧАЕТ аукционные сообщения: `msg.targetId === null && !msg.item?.type?.startsWith('auction_')`
- ChatTabs: вкладка 🔨 Аукцион между Общим и Гильдией

## Формат item_data

### auction_lot (новый лот)
```json
{
  "type": "auction_lot",
  "lotId": 123,
  "itemData": { "name": "Меч", "rarity_id": 3, ... },
  "startPrice": 100,
  "currentBid": null,
  "buyoutPrice": 500,
  "currentBidderName": null,
  "sellerName": "Player1",
  "endsAt": 1783000000
}
```

### auction_bid (перебивка ставки)
```json
{
  "type": "auction_bid",
  "lotId": 123,
  "itemData": { ... },
  "startPrice": 100,
  "currentBid": 150,
  "buyoutPrice": 500,
  "currentBidderName": "Player2",
  "previousBidderName": "Player1",
  "sellerName": "Seller",
  "endsAt": 1783000000
}
```

### auction_buyout (выкуп)
```json
{
  "type": "auction_buyout",
  "lotId": 123,
  "itemData": { ... },
  "price": 500,
  "buyerName": "Player2"
}
```

## Очистка неактуальных сообщений

При удалении лота (выкуп, отмена, частичная покупка, истечение) — удаляются ВСЕ связанные сообщения:
```typescript
await db.run('DELETE FROM chat_messages WHERE item_data LIKE ?', [`%"lotId":${lotId}%`]);
```

Добавлено после КАЖДОГО `DELETE FROM auction_lots` во всех обработчиках:
- `POST /auction/buyout`
- `POST /auction/cancel`
- `POST /auction/buy-partial` (при remainingCount <= 0)
- `GET /auction` (expiry — оба случая: sold и unsold)

## Индикаторы непрочитанных

- **Вкладка:** жёлтая точка `bg-[var(--color-accent-warning)]` в ChatTabs
- **Свёрнутый чат:** жёлтая `chat-blink` точка в хедере ChatPanel
- **LS-ключ:** `chatLastReadAuction`
- **Пересчёт:** `messages.filter(m => m.item?.type?.startsWith('auction_') && m.id > lastReadAuction)`

## Рендер в MessageList

Аукционные карточки рендерятся отдельным блоком ДО обычных item-link и text-bubble:
- Фон: `bg-[#2a2010]`, бордер: `#4a3820`
- Название предмета с тултипом (как shift+click)
- Старт/текущая ставка, выкуп, лидер, продавец
- ⏳ Оставшееся время (красный если < 1ч)
- Инпут скрыт, вместо него ссылка на `/auction`
