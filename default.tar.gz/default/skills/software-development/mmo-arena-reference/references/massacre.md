# Резня (Massacre) — массовые PvP бои

## Обзор

Хаотичный массовый PvP-бой. Карточка в разделе 🌍 МИР со счётчиком участников. Сбор 30 минут, затем сервер автоматически проводит бой. Вход — 100 сер., приз победителю: +10 XP + весь сбор.

## БД

Три таблицы (созданы локально и на проде):

```sql
massacre_events       -- id, status, entry_fee, gathering_end, turn_order, created_at
massacre_participants -- event_id, user_id, level, base_s/a/d/m, hp_current, hp_max, stunned, alive, stats_json, joined_at
massacre_turns        -- event_id, turn_number, actor_id/name, target_id/name, action_type, damage, message, created_at
```

**Миграция:** `stats_json` добавлена позже через ALTER:
```sql
ALTER TABLE massacre_participants ADD COLUMN IF NOT EXISTS stats_json TEXT DEFAULT '{}';
```

**Права:** после создания таблиц на проде — `GRANT ALL ON <таблица> TO game; GRANT USAGE, SELECT ON SEQUENCE <seq> TO game;`

## Серверные маршруты (`routes/massacre.ts`)

- `GET /api/massacre/state` — текущее событие, счётчик, таймер, участие игрока, **`lastEvent`** (последний завершённый бой). Если нет активного gathering — создаёт новое.
- `POST /api/massacre/join` — списывает 100 сер., сохраняет полный снимок статов (`stats_json`), взнос → казна замка.
- `GET /api/massacre/log/:eventId` — ходы боя с флагом `isMyTurn`.

## История боёв (`routes/log.ts`)

- `GET /api/log/massacre-battles` — список завершённых резнь для игрока. Возвращает: `id, participant_count, turn_count, winner_id, winner_name, participated`.

## ServerTick — реалтайм-обновления

Резня добавлена в `websocket.ts` serverTick (каждую секунду):
- Один запрос `SELECT ... FROM massacre_events WHERE status IN ('gathering','in_progress')` на тик
- Поле `massacre: { id, status, timeLeft, participant_count }` в payload для всех онлайн-игроков
- Клиент слушает `window.addEventListener('massacreTick', ...)` — таймер и счётчик обновляются мгновенно, без polling

## Снимок статов (`stats_json`)

**Ключевой паттерн:** при вступлении `buildPlayerStats(user, 'arena')` вычисляет ВСЕ бонусы (экипировка, напитки, коллекции, гильдия) и сохраняет как JSON. В бою статы НЕ пересчитываются — используется `JSON.parse(p.stats_json)` напрямую.

Это гарантирует что бонусы заморожены на момент вступления и не меняются во время боя.

## Боевая логика (`game/massacre.ts`)

- Участники сортируются по `base_a` DESC (ловкость)
- Каждый ход: выбрать случайную живую цель (!= себя)
- Один вызов `runTurnLocal()` — полная копия `runTurn()` из `battle.ts`
- Оглушение: цель пропускает следующий ход (тип `stunned_skip`), оглушивший НЕ получает доп. ход
- Бой до последнего выжившего
- После боя: `pushNotification` всем участникам с типом `battle_result`

**Экспорт боевых функций:** для использования `dodgeChance`, `critChance`, `blockChance` и др. извне `battle.ts` они отмечены `export`.

## Scheduler (`schedulers/massacre.ts`)

- Каждые 10 сек проверяет `gathering_end <= now`
- Переводит статус в `in_progress` и запускает `runMassacreBattle()`
- При старте сервера создаёт первое событие если нет активного
- Если участников < 2 — отменяет и возвращает взнос

## Клиент: карточка в Actions.tsx

- Счётчик и таймер обновляются через **serverTick WebSocket** (`massacreTick` event), первичная загрузка через HTTP
- Карточка рендерится отдельным блоком (как arena, castle)
- **Заголовок по центру** (как остальные карточки)
- **Подзаголовок:** «Хаотичный PvP» (короткий, не из БД) + счётчик при >0: `· {count}`
- **Кнопка:** `{цена} · {таймер}` — цена и таймер на одной строке, без отдельной строки цены
- Без таймера кнопка показывает только цену

## Клиент: MassacrePage (`/massacre`)

- Принимает `?eventId=` — загружает лог конкретного боя (используется из сводки)
- Всегда показывает лог последнего завершённого боя (`lastEvent` из state API)
- Три состояния:
  1. **Сбор (gathering):** таймер обратного отсчёта, кнопка «Вступить», статус участия
  2. **Бой идёт (in_progress/starting):** заглушка «Бой в процессе»
  3. **Завершён (finished):** подробный лог — участники сверху (свои выделены), ходы с иконками, свои ходы на жёлтом фоне
- Таймер и статус обновляются через **serverTick** (`massacreTick` event)
- При получении `status: 'finished'` через serverTick — мгновенно грузит лог через `fetchLog`

## Сводка (HistoryPage)

- Вкладка «Резня» в `/history` — список завершённых боёв
- Запись: иконка топора, число участников, победитель/поражение, число ходов
- Клик → `/massacre?eventId=X` с полным пошаговым логом
- Данные: `GET /api/log/massacre-battles`

### Питфол: raw API objects vs allEntries mapping

`renderEntry()` проверяет `type` поля для выбора рендера. `allEntries` оборачивает сырые данные API в `{ type: 'massacre', ... }`. Для вкладки «Резня» НЕЛЬЗЯ отдавать сырой `massacreBattles` — нужно либо фильтровать `allEntries.filter(e => e.type === 'massacre')`, либо делать отдельный `massacreEntries` с тем же mapping'ом что и в `allEntries`. Иначе `renderEntry` не найдёт `type` и отрендерит пустой `return null`.

**Правило:** вкладка таба должна либо фильтровать `allEntries`, либо использовать отдельную переменную с ТЕМ ЖЕ mapping'ом (`{ type, ts, data }`).

## Уведомления

- После боя всем участникам шлётся `pushNotification` с `type: 'battle_result'`
- **❗ data ДОЛЖНА быть JSON-строкой:** `JSON.stringify({...})` — объект вызывает React error #31 («Objects are not valid as React child»), потому что `NotificationToast` рендерит `{t.data}` как текстовый элемент.
- `data.path = '/history?tab=massacre'` — клик по уведомлению → переход в сводку
- `NotificationToast` проверяет `data.path` и делает `window.location.href` при клике, парся JSON если data — строка.

## Хлебные крошки

`Header.tsx` → `breadcrumbMap`: `massacre: 'Резня'`.

## Питфолы

### WebView: не использовать прозрачность (opacity)

VK WebView не поддерживает CSS opacity/прозрачность корректно. Все цвета должны быть сплошными (без `/10`, `/20`, `/30` суффиксов в Tailwind). Для выделения своих ходов в логе используются твёрдые цвета:
- Фон: `#3d2e00` (тёмно-жёлтый), рамка: `#5a4200`, текст: `#f0c040`
- Фон лога: `bg-[var(--color-bg-secondary)]` (без `/90`)

### React error #31: объект в data уведомления

`pushNotification` принимает `data: any`, но `NotificationToast` рендерит `{t.data}` как React child. Если `data` — объект → краш. Всегда передавать `JSON.stringify({...})`. Клиентский `NotificationToast` парсит JSON при извлечении `path`.

## Действие в БД

```sql
INSERT INTO actions_config (section, title, subtitle, icon, path, cost, sort_order)
VALUES ('world', 'Резня', 'Массовый хаотичный PvP-бой', 'game-icons:battered-axe', '/massacre', 100, 8);
```

Добавляется локально и на проде. После этого карточка появляется в API `/api/actions`.
