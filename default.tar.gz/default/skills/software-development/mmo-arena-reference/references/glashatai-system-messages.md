# Глашатай — системные сообщения и user id=0

## Проблема

Системные сообщения (senderId=0) показывали senderName='system' вместо 'Глашатай' при загрузке с сервера, хотя в реальном времени (WebSocket) приходили правильно.

## Причина

1. В таблице `users` есть запись `id=0, username='system'` (создана при инициализации БД)
2. Запрос `SELECT m.*, u.username as senderName FROM chat_messages m LEFT JOIN users u ON m.senderId = u.id` находил `u.id=0` → `u.username='system'`
3. `COALESCE(u.username, 'Глашатай')` видел НЕ NULL → возвращал 'system'
4. `m.*` мог также включать колонку `sendername` если бы она была в таблице, что перекрыло бы алиас из JOIN

## Фикс

Использовать `CASE WHEN m.senderId = 0 THEN 'Глашатай' ELSE u.username END` вместо `COALESCE`.

И не использовать `m.*` в запросах с JOIN — перечислять колонки явно.

## Затронутые файлы

- `server/src/routes/chat.ts` — `chat/recent` и `chat/private/:userId`
- `server/src/routes/auction.ts` — аукционные сообщения (senderName уже 'Глашатай' при INSERT)
- `server/src/routes/adminChat.ts` — админские системные сообщения
- `server/src/routes/guild/guildMembers.ts` — приглашения в гильдию
- `server/src/routes/guild/guildWar.ts` — объявления войны
- `client/src/components/chat/MessageList.tsx` — `truncate(null)` → 'Глашатай'

## Проверка

```sql
SELECT id, username FROM users WHERE id = 0;
-- Должен быть: 0 | system (это нормально, не удалять)
```
