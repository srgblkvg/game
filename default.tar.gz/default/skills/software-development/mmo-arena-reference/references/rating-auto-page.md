# Rating Page — Auto-Navigate to Player's Page

## Solution: `myPage` in rating response (server-side)

The `/api/rating` endpoint now includes `myPage` — the page number where the current user appears (considering active search/filter params).

### Server: `server/src/routes/rating.ts`

```typescript
// Include user's own page for auto-navigation
let myPage = 1;
if (req.userId) {
    const userRow = await db.one('SELECT elo FROM users WHERE id = ?', [req.userId]) as any;
    if (userRow) {
        const elo = userRow.elo || 1000;
        const pos = (await db.one(
            `SELECT COUNT(*) as cnt FROM users u ${whereClause} AND (u.elo > ? OR (u.elo = ? AND u.id < ?))`,
            [...params, elo, elo, req.userId]
        ) as any).cnt + 1;
        myPage = Math.ceil(pos / limit);
    }
}
res.json({ users: result, total, myPage });
```

### Client: `client/src/pages/RatingPage.tsx`

```tsx
const initialLoadDone = useRef(false);

// Initial load: jump to user's page
useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
        try {
            const data = await fetchRating(1, LIMIT, search, minElo);
            if (cancelled) return;
            setPlayers(data.users);
            setTotalPages(Math.ceil(data.total / LIMIT));
            if (data.myPage && data.myPage !== 1) {
                setPage(data.myPage);  // triggers re-render → second effect fires
            }
            initialLoadDone.current = true;
        } catch {
            if (!cancelled) initialLoadDone.current = true;
        }
    })();
    return () => { cancelled = true; };
}, [user]);

// Subsequent loads: pagination, search, filter
useEffect(() => {
    if (!initialLoadDone.current) return;
    fetchRating(page, LIMIT, search, minElo).then(data => {
        setPlayers(data.users);
        setTotalPages(Math.ceil(data.total / LIMIT));
    }).catch(console.error);
}, [page, search, minElo]);
```

### `fetchRating` return type: `client/src/api/character.ts`

```typescript
export async function fetchRating(...) {
    // ...
    const data = await res.json();
    return { users: data.users, total: data.total, myPage: data.myPage || 1 };
}
```

### Key design decisions

1. **No separate `/my-position` endpoint.** Position calculation is inside the rating query using the SAME `whereClause` (search + minElo filter). This means `myPage` is correct even when filters are active.

2. **`setPage(data.myPage)` triggers re-render.** The second effect (with `[page, search, minElo]` deps) fires automatically, loading the correct page data.

3. **useRef for initialLoadDone.** Prevents the second effect from running before initial load completes. Unlike useState, it doesn't cause extra renders.

4. **Search debounce only resets page on actual change.** `prevSearchRef` tracks the previous search value — `setPage(1)` only fires when search actually changes, not on mount.

### Pitfalls

- **Don't use `useState` for `initialPageSet`.** If `/my-position` fails, the `.catch` sets `initialPageSet = true` without calling `setPage()` → second effect fires with `page=1` → user never navigates. Use `useRef` and `setPage(startPage)` unconditionally.

- **`useRef` changes don't trigger re-renders.** The `initialLoadDone` ref alone won't make the second effect run. You MUST call `setPage()` (a state update) to trigger the re-render.

- **Search debounce on mount.** Without the `prevSearchRef` guard, the 300ms debounce fires even on initial render with empty input, calling `setPage(1)` and overriding the player's page.

### Failed evolution (lessons learned)

The feature went through 4 iterations before working:

1. **useState + separate /my-position** — search debounce overwrote `setPage(1)` on mount
2. **useRef + search guard** — `useRef.current = true` didn't trigger re-render, second effect never ran
3. **async/await + useRef** — same useRef problem
4. **Server-side myPage + setPage()** — ✅ working. `setPage(myPage)` triggers state change → re-render → second effect fires.
