---
name: mmo-arena-reference
description: "Quick reference for MMO Arena project — paths, deploy, DB, common pitfalls."
version: 2.2.0
---

# MMO Arena — Quick Reference

## Paths
- **Server:** `/opt/game/server/` (VPS), локально `/mnt/c/project/game/`
- **Client:** `/opt/game/client/dist/` (nginx, VPS), локально `/mnt/c/project/game/client/`
- **IDEAS:** `/mnt/c/project/game/IDEAS.md`

## Tech Stack
- **Backend:** Node.js + Express + WebSocket + **PostgreSQL** (PG native branch)
- **Frontend:** React + Vite
- **VPS:** 194.226.142.237, root

## Database — PostgreSQL (NOT SQLite)
- `game_prod.db` на VPS — **СТАРЫЙ АРТЕФАКТ от SQLite**, не трогать
- Реальная БД: PostgreSQL, localhost:5432, база `game`, юзер `game`
- Все колонки **lowercase** (PG фолдит в lowercase)
- camelCase конвертер: `camelRows()` в `db/index.ts` добавляет camelCase-ключи к строкам. **НЕ отказываться от него** — код везде полагается на `row.sellerId`, `row.currentBid` и т.д. Паттерн-защита: `row.guildid || row.guildId`.
- DB pool: max 5

### Питфол camelRows: AS-алиасы с camelCase — буква после префикса НЕ капитализируется

`pgLowerIdentifiers` опускает ВСЕ незакавыченные идентификаторы, включая AS-алиасы. Затем `camelRows` обрабатывает полученный lowercase-ключ суффикс-регексом. **Проблема:** для алиасов вида `u.id as leaderUserId`:

1. `pgLowerIdentifiers` → `leaderuserid`
2. `camelRows`: матчит суффикс `id` → `leaderuserId` (строчная `u` в `userId`)

Клиентский код `g.leaderUserId` (заглавная `U`) → `undefined` → `/profile/undefined`.

**Симптом:** клик по лидеру гильдии в рейтинге/списке → профиль с «undefined».

**Фикс:** всегда проверять ТОЧНОЕ имя camelCase-ключа, которое производит `camelRows`. Для `leaderuserid` это `leaderuserId` (не `leaderUserId`). Либо: использовать оригинальный lowercase-ключ `g.leaderuserid` (всегда работает, т.к. camelRows сохраняет оригинальные ключи).

**Где проявлялось:** `GuildRatingPage.tsx` — `g.leaderUserId` → исправлено на `g.leaderuserId` (2026-07-10).

### Питфол camelRows: колонки с вложенным camelCase

`camelRows()` работает через суффикс-регекс: находит известный суффикс в конце ключа и капитализирует его первую букву. **Проблема:** для имён вроде `currentbidderid` регекс матчит `id` (не `bid`), давая `currentbidderId` вместо правильного `currentBidderId`. Колонка становится недоступна как `row.currentBidderId` → undefined → null в INSERT → constraint violation.

**Симптомы:** `null value in column "buyerid" violates not-null constraint` при INSERT в `auction_history`, хотя WHERE фильтрует `currentBidderId IS NOT NULL`.

**Фикс:** добавить явное правило в цепочку `.replace()` в `camelRows()` (файл `db/index.ts`, после `.replace(/^toaccount$/i, 'toAccount')`):
```typescript
.replace(/^currentbidderid$/i, 'currentBidderId')
```

### Питфол camelRows: ключи с ПОДЧЁРКИВАНИЕМ

**camelRows НЕ удаляет подчёркивания.** Для колонок с `_count`, `_id`, `_name`, `_at`:
- `participant_count` → добавляет ключ `participant_Count` (НЕ `participantCount`)
- `winner_id` → `winner_Id`
- `winner_name` → `winner_Name`  
- `created_at` → `created_At`

**ОРИГИНАЛЬНЫЕ snake_case ключи СОХРАНЯЮТСЯ.** `row.participant_count` и `row.participant_Count` оба валидны.

**Правило:** для новых таблиц использовать ОРИГИНАЛЬНЫЕ snake_case имена (`data.participant_count`, `data.created_at`) — они всегда работают. НЕ гадать какой camelCase-вариант получился.

**Какие суффиксы матчатся:** `count`, `id`, `name`, `at`, `time`, `data`, `type`, `level`, `slots`, `bonus`, `amount`, `price`, `cost`, `won`, `lost`, `gained`, `battles`, `money`, `created`, `completed`, `updated`, `xp`, `end`, `start`, `score`, `number`, `players`, `stats`, `place`, `text`, `chat`, `from`, `guild`, `role`, `first`, `last`, `url`, `path`, `size`, `width`, `height`, `color`, `slot`, `icon`, `round`, `log`, `code`, др. (полный список: `db/index.ts` строка 60).

## Сервер: SELECT users — через USER_FIELDS

`db/helpers.ts` экспортирует константы для боевых запросов:
```typescript
USER_BATTLE_FIELDS        // PvP бой (все поля + elo + сезоны)
USER_BATTLE_FIELDS_GUILD  // то же + guildName
USER_ARENA_FIELDS_GUILD   // арена (arenaOpponentId + gender + avatar)
```
Использование:
```typescript
const attacker = await db.one(`SELECT ${USER_BATTLE_FIELDS_GUILD} FROM users u LEFT JOIN guilds g ON u.guildId = g.id WHERE u.id = ?`, [userId]);
```
Добавить поле в users → добавить в USER_BATTLE_FIELDS → ВСЕ боевые запросы автоматом.

## Сервер: buildPlayerStats() — единый сбор статов

`db/helpers.ts`:
```typescript
export async function buildPlayerStats(userRow: any, context: BattleContext): Promise<CharStats>
```

Собирает `base + equip + drinks + coll + guild` → `currentStats()`.
**Все** роуты должны использовать её вместо ручного копипаста.
Добавить бонус → править только `buildPlayerStats`.
```bash
# Локально: compile + sync
cd /mnt/c/project/game/server && npx tsc
rsync -avz --delete dist/ root@194.226.142.237:/opt/game/server/dist/

# На VPS:
cd /opt/game/server
pm2 delete game-server
pm2 start dist/index.js --name game-server --node-args="--max-old-space-size=512" --max-memory-restart 900M
# --max-memory-restart ДОЛЖЕН быть ДО -- (это флаг PM2, не node.js)
```

## Production Health Check

При вопросе «что с сервером» — проверить по порядку:

```bash
# 1. PM2 статус
ssh root@194.226.142.237 "pm2 list"

# 2. Nginx
ssh root@194.226.142.237 "systemctl status nginx --no-pager -l | head -20"

# 3. Домен (HTTPS, не IP — сертификат на домен)
curl -s -o /dev/null -w "HTTP %{http_code}" http://mmoarena.ru
curl -s -o /dev/null -w "HTTPS %{http_code}" https://mmoarena.ru

# 4. Логи ошибок (последние 30 строк)
ssh root@194.226.142.237 "pm2 logs game-server --err --lines 30 --nostream"

# 5. Сравнить продакшн-код с локальным (при ошибках в конкретном файле)
ssh root@194.226.142.237 "head -70 /opt/game/server/src/routes/файл.ts"
```

**Питфол:** `curl https://194.226.142.237` даёт HTTP 000 — SSL-сертификат выпущен на `mmoarena.ru`, не на IP. Всегда проверять по домену.

### Коммит после каждого деплоя

После любой правки кода + деплоя ОБЯЗАТЕЛЕН коммит и пуш. Порядок: изменить код → собрать → задеплоить → проверить → `git add && git commit && git push`. Без этого изменения теряются, пользователь теряет доверие к процессу («ты перестал работать с гитом»).

### Stale compiled JS на VPS — проверять при расхождении ошибок

Если ошибка в логах ссылается на строку/логику, которой нет в локальном TypeScript-исходнике — значит скомпилированный JS на VPS УСТАРЕЛ и не соответствует текущим `.ts` файлам. Симптом: `vkPayments.ts:50:23 Cannot read properties of undefined (reading 'notification_type')` — но в актуальном `.ts` на этой строке `logger.warn(...)`. Причина: после `npx tsc` не был сделан `rsync dist/` или `pm2 restart` не перезагрузил модули.

**Фикс:** пересобрать (`npx tsc`), задеплоить (`rsync dist/`), и сделать `pm2 restart` (или `pm2 delete && pm2 start` если кеш модулей).

### DB schema drift (CREATE TABLE IF NOT EXISTS ≠ ALTER)

`CREATE TABLE IF NOT EXISTS` в коде **не обновляет** существующую таблицу. Если колонка была создана с `NOT NULL`, а позже код изменился на nullable — ограничение остаётся. Симптом: `null value in column "X" violates not-null constraint`, хотя код определяет колонку без NOT NULL.

**Фикс:** ручной ALTER на VPS:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c 'ALTER TABLE auction_history ALTER COLUMN buyerid DROP NOT NULL;'"
```

**Проверка схемы:**
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c '\\d имя_таблицы'"
```

**БД:** PostgreSQL, база `game`, схема `public`. Подключение через `sudo -u postgres psql -d game`.

### Питфол: новые таблицы — GRANT для юзера `game`

`CREATE TABLE` через `sudo -u postgres psql` создаёт таблицу от имени `postgres`. Юзер `game` (которым ходит сервер) **не получает прав автоматически**. Результат: 500 ошибка `permission denied for table ...`.

**Фикс:** после создания таблицы сразу выдать права:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c 'GRANT ALL ON имя_таблицы TO game; GRANT ALL ON SEQUENCE имя_таблицы_id_seq TO game;'"
```

**Симптом:** `permission denied for table casino_games` в pm2 logs, хотя `\d` показывает таблицу.

## Deploy (через sshpass — парольный доступ)

Сервер: 194.226.142.237, root. **Пароль:** `re8XyUoMH2PD6UCn`.

**Если ключ не работает** (WSL, новая машина) — использовать sshpass:
```bash
SSHPASS='re8XyUoMH2PD6UCn' sshpass -e ssh -o StrictHostKeyChecking=no root@194.226.142.237 "..."
SSHPASS='re8XyUoMH2PD6UCn' sshpass -e rsync -avz ... root@194.226.142.237:/opt/game/...
```

**⚠️ НИКОГДА не использовать `rsync --delete` для серверного dist/ — удаляет `.env` и `node_modules` на VPS!**

### Сервер
```bash
cd /mnt/c/project/game/server && npx tsc
SSHPASS='re8XyUoMH2PD6UCn' sshpass -e rsync -avz dist/ root@194.226.142.237:/opt/game/server/dist/
SSHPASS='re8XyUoMH2PD6UCn' sshpass -e ssh root@194.226.142.237 "cd /opt/game/server && npm install --omit=dev && pm2 restart game-server"
```

### Клиент
```bash
cd /mnt/c/project/game/client && npm run build
SSHPASS='re8XyUoMH2PD6UCn' sshpass -e rsync -avz --delete dist/ root@194.226.142.237:/opt/game/client/dist/
```

**Бекапы:** uploads и .env бекапятся каждый час в `/opt/game/backups/`. Подробнее: `references/backups.md`.

**🔴 Питфол:** nginx root = `/opt/game/client/dist/` (см. `grep root /etc/nginx/sites-enabled/mmoarena`). Не путать с `/var/www/mmoarena/` — это старый путь, туда nginx НЕ смотрит. Перед деплоем всегда проверять: `ssh root@194.226.142.237 "grep 'root ' /etc/nginx/sites-enabled/mmoarena"`.

### Nginx: приоритет location и конфликт с регексом

Конфиг: `/etc/nginx/sites-enabled/mmoarena` на VPS.

**Питфол:** `location ~* \.(webp|png|jpg)$` (regex) перехватывает ВСЕ картинки, включая те что должны идти через `location /uploads/` (alias). Регекс-блоки имеют приоритет над префиксными (без `^~`).

**Фикс:** `location ^~ /uploads/` — модификатор `^~` даёт префиксному блоку приоритет над регексами.

**Структура блоков (в порядке):**
- `location ^~ /uploads/` — alias на `/opt/game/server/uploads/`, кеш 7д
- `location /assets/` — alias на dist/assets, кеш 1г
- `location ~* \.(webp|png|jpg|svg|woff2|ttf)$` — картинки предметов + шрифты, кеш 1г (НЕ трогает /uploads/)
- `location /api/` — proxy_pass :3001, no-cache
- `location /ws` — proxy_pass :3001 (WebSocket)
- `location /` — try_files /index.html (SPA fallback)

**Проверка:** `curl -sI -H "Host: mmoarena.ru" https://localhost/uploads/avatars/31.jpg -k` (с HTTPS и Host, не голый http://localhost).

## Чат: сохранение гильдии отправителя в БД

Таблица `chat_messages` имеет колонки `"senderGuild"` TEXT и `"senderGuildId"` INTEGER. При ВСЕХ INSERT'ах сообщений от реальных игроков (НЕ системных senderId=0) нужно включать эти поля:

```typescript
await db.run(
  'INSERT INTO chat_messages (senderId, targetId, content, "senderGuild", "senderGuildId") VALUES (?, ?, ?, ?, ?)',
  [userId, targetId, content, user.guildName || null, user.guildId || null]
);
```

Файлы с INSERT'ами: `websocket.ts` (public/private/itemLink/w-command), `routes/chat.ts` (send endpoint).

`m.*` в SELECT-запросах автоматом подхватывает колонки. Клиент уже читает `senderGuild`/`senderGuildId` из объектов сообщений.

**Симптом при ошибке:** после отправки сообщения тег гильдии виден (WS broadcast), после перезагрузки — исчезает (БД-история без гильдии).

### Питфол: camelCase-колонки и PG-конвертер

PG-конвертер `pgLowerIdentifiers()` в `db/index.ts` опускает ВСЕ незаэкранированные camelCase-слова в SQL до lowercase. То есть `senderGuild` в тексте SQL превращается в `senderguild`, а колонка в БД создана как `"senderGuild"` (с кавычками, mixed-case).

**Создание колонки (DDL):** всегда использовать double-quotes:
```sql
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS "senderGuild" TEXT;
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS "senderGuildId" INTEGER;
```

**Вставка (DML):** в TypeScript-строке SQL использовать double-quotes ВНУТРИ single-quoted строки:
```typescript
'INSERT INTO chat_messages (senderId, targetId, content, "senderGuild", "senderGuildId") VALUES ...'
//                               ^            ^
//                               без кавычек  с кавычками!
```

**Правило:** ЛЮБОЙ camelCase-идентификатор, который НЕ должен быть опущен PG-конвертером, ОБЯЗАН быть заэкранирован двойными кавычками в SQL-строке. snake_case идентификаторы опускать не нужно — они и так lowercase.

**Симптом при ошибке:** `WS msg err: column "senderguild" of relation "chat_messages" does not exist`.

## Аукцион (формат API)
См. `references/auction-format.md`. Ключевое: ответ `{ lots: [...], ... }`, не массив. Expiry flow: лоты со ставками → предмет покупателю, без ставок → возврат продавцу.

## Аукцион — вкладка в чате
См. `references/auction-chat.md`. Системные сообщения через `chat_messages` с `item_data.type: 'auction_*'`, фильтрация на клиенте, автоочистка при удалении лотов.

## Аукцион — бэкенд чата (фикс выпадения сообщений)
См. `references/auction-chat-backend.md`. `/chat/recent`: LEFT JOIN users (senderId=0), LEFT JOIN auction_lots по lotId из JSON, аукционные сообщения не считаются в LIMIT 20 обычных. **Питфол:** truncate(null) крашит клиент — см. фикс в референсе.

## Рейтинг — авто-переход на страницу игрока
См. `references/rating-auto-page.md`. Последовательная цепочка `/my-position` → `fetchRating(myPage)`, без гонки эффектов. useRef для initialLoadDone вместо useState.

## Аукцион — клик по лоту в чате → открытие на странице
См. `references/auction-chat-click-to-lot.md`. Клик по карточке лота в чате переходит на `/auction?lot=<id>`, лот подсвечивается `ring-2` и скроллится в центр.

## Туториал для новых игроков
См. `references/tutorial-overlay.md` и `references/tutorial-multi-action.md`. Пошаговый гайд с затенением экрана и подсветкой интерфейса через `data-tutorial` атрибуты. 28 шагов, триггер: флаг `tutorial_completed` в БД. Кастомные события для авторазворачивания блоков. **Multi-action:** поле `action` поддерживает несколько событий через запятую (`'collapse-stats, expand-buffs'`) — коллапс предыдущей секции + раскрытие следующей в одном шаге. На мобильных tooltip всегда сверху.

## Action Cards (главная страница)
См. `references/admin-actions.md`. Карточки действий управляются через таблицу `actions_config` в БД (section + sort_order). Для смены порядка — поменять `sort_order` местами. Изменение мгновенное, перезапуск не нужен.

## Резня — массовые PvP бои
См. `references/massacre.md` (БД, маршруты, боевая логика, scheduler) и `references/massacre-viz.md` (визуализация боя).

### Full-width карточка (Замок)

Карточка «Замок» рендерится особым образом в `Actions.tsx`: `col-span-full`, горизонтальный лейаут (текст слева, кнопка «Перейти» справа). Определяется по `card.title === 'Замок'` в CardGrid.

**Турниры на карточке Замка:** при наличии активных турниров (`/api/tournament?tab=active&type=official`) карточка показывает:
- Если турнир в регистрации и игрок не записан: кнопка «Записаться» (POST `/api/tournament/register`). Обработчик в CardGrid, `setRegisterMsg?.('Записаны!')` (опциональный вызов — проп может быть undefined).
- Если записан: «✓ Вы записаны»
- Название дивизиона (🏆 bronze/silver/etc.)
- **Если нет активных:** таймер до следующего **подходящего по уровню** турнира. Данные берутся из `upcomingOfficial` в ответе `/api/tournament?tab=active` (сервер уже считает `registrationOpensAt` для каждого дивизиона). Клиент фильтрует по `userLevel`, берёт ближайший, показывает `⏳ Следующий турнир: 🥉 Бронза через ЧЧ:ММ:СС`. Состояние: `nextTournamentSec` (секунды), `nextTournamentLabel` (название дивизиона). `setInterval(1000)` декрементит таймер, при 0 — сбрасывает и перезапрашивает API.

Данные пробрасываются через `tournamentInfo`/`myRegistration`/`registerMsg`/`nextTournamentSec`/`nextTournamentLabel` пропсы в CardGrid.

### Actions: табы Мир/Площадь

Вкладки `🌍 Мир` / `🏰 Площадь` под карточкой Замка, по центру. Стейт `activeTab` ('world'|'castle'), по умолчанию 'world'. Карточки `hero`-секции (Замок) рендерятся всегда над табами. Активная вкладка: `bg-[var(--color-accent-info)] text-white`, неактивная: `bg-[var(--color-bg-input)] text-[var(--color-text-muted)]`. `cursor-pointer`.

### Инвентарь — индикатор заполнения

Тонкая полоса вверху блока (вне `p-4`, внутри `overflow-hidden`):
- Зелёная (<80%), жёлтая (≥80%), красная (100%)
- Счётчик `(N/M)` меняет цвет синхронно
- Видна в свёрнутом и развёрнутом состоянии

```tsx
const fillRatio = inventory.length / Math.max(1, maxSlots);
const fillPct = Math.round(fillRatio * 100);
const fillColor = fillRatio >= 1 ? 'bg-danger' : fillRatio >= 0.8 ? 'bg-warning' : 'bg-success';
const counterColor = fillRatio >= 1 ? 'text-danger' : fillRatio >= 0.8 ? 'text-warning' : '';

<div className="...overflow-hidden">
  <div className={`h-1 ${fillColor} transition-all`} style={{ width: `${fillPct}%` }} />
  <div className="p-4">
    <h3>Инвентарь <span className={counterColor}>({length}/{maxSlots})</span></h3>
  </div>
</div>
```

### Массовая загрузка изображений (админка)

Компонент `BulkImageUploader` (`client/src/components/BulkImageUploader.tsx`) — принимает `items: { id, name, imagePath }[]` и позволяет загрузить файлы под существующими путями из БД (без переименования). Используется в админке на вкладках: этажи, действия, мобы (AdminGame), работы (AdminJobs), предметы (AdminItems), ресурсы (AdminCraft).

Серверный эндпоинт: `POST /api/admin/upload-bulk` — принимает `{ images: [{ targetPath, dataUrl }] }`, сохраняет файлы по указанным путям.

## Описания страниц — единый стиль
Все страницы используют паттерн из Трактира для описания:
```tsx
<p className="text-xs text-[var(--color-text-muted)] bg-[var(--color-bg-secondary)] rounded p-2 mb-3">
    Краткое описание механик страницы.
</p>
```
Располагается сразу под заголовком `<h1>`/`<h2>`, перед табами/контентом. НЕ использовать `text-sm text-center` — это другой стиль.

## Магазин — текущая механика
Магазин продаёт **только базовые предметы экипировки для первых шагов**. Раньше были случайные предметы с качеством по уровню — эта механика удалена. В описании магазина упоминать «нельзя надеть два одинаковых кольца».

### Истечение лотов (обработка в GET /auction)
При каждом запросе GET /auction обрабатываются просроченные лоты (`endsAt <= now`):
- **Лоты со ставками** (currentBidderId IS NOT NULL): продавец получает деньги (цена − 10% комиссия), покупатель получает предмет в инвентарь (с учётом стакинга для craft_item/material). Пишется запись в `auction_history`. Шлются уведомления: продавцу `auction_sold` + бейдж `auction_sales`, покупателю `system`.
- **Лоты без ставок** (currentBidderId IS NULL): предмет возвращается в инвентарь продавца (со стакингом). Продавцу уведомление `system`.

### Питфолы аукциона
- **Не забывать отдавать предмет покупателю при истечении.** Деньги уже списаны при ставке, предмет должен уйти победителю. Без этого покупатель теряет деньги, а предмет исчезает.
- **Возвращать непроданные лоты продавцу.** Иначе предмет теряется безвозвратно.
- **Переполнение инвентаря:** при снятии лота, выкупе или возврате — если инвентарь заполнен, предмет уходит в `overflow_storage`. Хелпер `returnItemToInventory()` в `routes/auction.ts` проверяет заполненность (только equipment-слоты, craft-материалы всегда в инвентарь) и направляет в overflow. Применён во всех ПЯТИ точках: cancel, buyout, buy-partial, expired lots с обеими ветками (с победителем и без). Реализация: `routes/overflow.ts` — `addToOverflow(userId, item, auctionLotId?)`, таблица `overflow_storage`. Клиент: `OverflowStorage.tsx` показывает склад с возможностью забрать предмет.

## Гильдия — сплит через Node.js (работает)

Файл: `routes/guild.ts`, 30 обработчиков. Успешно разделён на 6 модулей через Node.js-скрипт:

```
src/routes/guild/
├── guildCore.ts      205 строк  (create, my, list, settings, view/:id, leave)
├── guildMembers.ts   255 строк  (requests, invites, join, request, invite, accept, kick, role)
├── guildChat.ts       62 строки  (чат)
├── guildTreasury.ts   91 строка  (депозит, история, налог)
├── guildWar.ts       420 строк  (войны + isGuildAtWar)
├── guildQuests.ts    172 строки  (квесты + updateGuildQuestProgress)
```

Новый `guild.ts` — 19 строк, только импортирует модули.

**Рабочий способ сплита:** Node.js-скрипт (`split_guild.js`) на VPS, который читает строки через `fs.readFileSync`, делает `lines.slice(s-1, e)` по известным диапазонам строк, и пишет под-файлы с `fs.writeFileSync`. Подробности: `references/guild-split.md`.

**Что НЕ работает:** `sed -n` через heredoc/ssh (ломает кавычки), Python `execute_code` (читает файл некорректно с `limit`).

**Обязательное условие для сплита:** скобки в исходном файле ДОЛЖНЫ быть сбалансированы. Перед сплитом:
```bash
node references/check_braces.js <путь-к-файлу>
```
Файлы с разбалансировкой (tournament.ts — 72{ vs 70}, mobs.ts — аналогично) НЕ поддаются сплиту без предварительной правки скобок. Guild.ts был сбалансирован → сплит удался с 4-й попытки.

## Гильдия: разрешения офицеров (2026-07-06)

Колонки `guild_members`: `can_quests`, `can_buildings`, `can_war` (BOOLEAN DEFAULT false).
API: `POST /guild/officer-permissions` — лидер устанавливает (`{ officerId, permission, value }`).

**⚠️ Питфол API:** `value` обязателен при массовом сохранении! Без `value` API флипает текущее значение → три вызова подряд переключают все три разрешения независимо от чекбоксов. Всегда передавать `{ officerId, permission, value: true/false }`.

**⚠️ Питфол `/guild/my`:** должен возвращать `gm.can_quests, gm.can_buildings, gm.can_war` в SELECT участников. Без этих колонок клиент не видит выданные разрешения (иконки не рендерятся, попап открывается с пустыми чекбоксами). ВАЖНО: и `/guild/my` И `/guild/:id` должны включать эти колонки.
- **Квесты:** `guildQuests.ts` — take и claim разрешены лидеру И офицеру с `can_quests`
- **Постройки:** `guildBuildings.ts` — build разрешён лидеру И офицеру с `can_buildings`
- **Война:** `guildWar.ts` — declare и respond разрешены лидеру И офицеру с `can_war`

## Гильдия: передача лидерства

- При удалении аккаунта (`account/delete`): лидерство → офицеру с max `lastLoginAt`, если нет офицеров → игроку с max `lastLoginAt`
- Авто-передача: шедулер `inactiveLeader.ts` каждый час проверяет `lastLoginAt < now - 3д`. Найден → передача лидерства активному офицеру/игроку, бывший лидер → офицер

### Питфол: SELECT g.* утекает приватные колонки через API

`SELECT g.*` в публичных эндпоинтах (`/guild/list`, `/guild/:id`) возвращает ВСЕ колонки таблицы `guilds`, включая `treasury` (казна гильдии). Казна видна всем игрокам через API и UI.

**Фикс:** заменить `SELECT g.*` на явный перечень колонок без `treasury`:
```typescript
// /guild/list — только публичные колонки
SELECT g.id, g.name, g.description, g.image, g.joinType, g.level, g.exp, g.leaderId, ...
// /guild/:id — то же самое
SELECT g.id, g.name, g.description, g.image, g.joinType, g.level, g.exp, g.leaderId, ...
```

**Правило:** для ЛЮБОГО публичного API использовать явный список колонок, не `SELECT *`. При добавлении приватной колонки в таблицу — проверять все SELECT этой таблицы.

**Клиент:** убрать отображение `g.treasury` из `GuildRatingPage.tsx`. Казна видна только на странице управления СВОЕЙ гильдией (`GuildPage`, вкладка «💰 Казна» и в шапке-обзоре).

## Гильдия: налог (collectGuildTax)

См. `references/guild-tax.md`. Налог должен вызываться во ВСЕХ точках дохода (PvE, PvP, квесты, работы). При жалобе «налог не работает» — проверить все источники дохода, не только PvE.

## Гильдия: создание (10000 серебра, без уровня)

**Два пути создания** (проверять ОБА при изменениях):
1. `/guild/create` (`guildCore.ts`) — создание со страницы `/guild`
2. ~~`/orders/create` (`orders.ts`)~~ — УДАЛЁН 2026-07-02, как и `/orders` полностью

**Проверка:** `money < 10000` → ошибка. Списание: `money = money - 10000`. Требование 5 уровня УБРАНО.
**Клиент (GuildPage):** кнопка «Создать (10000 серебра)».
**Вики:** `10000💰` без упоминания уровня.

**Питфол:** при жалобе «не работает проверка денег» — проверить ВСЕ эндпоинты создания. Гильдию можно было создать через `/guild/create` вообще без проверки, пока `/orders/create` имел проверку. Баг жил месяц.

## Гильдия — квесты

Файл: `routes/guild/guildQuests.ts`, 185 строк. 3 эндпоинта + `updateGuildQuestProgress()`.

### API контракт

**GET /guild/quest** — получить квесты:
- Если есть активный квест → `{ activeQuest: {...}, options: null }`
- Если нет активного → `{ activeQuest: null, options: [{ questType, difficulty, requirement, rewardXp, typeName, description, difficultyLabel }, ...] }` (3 варианта)
- Если не в гильдии → `{ activeQuest: null, options: null }`

**POST /guild/quest/take** — лидер берёт квест:
- Body: `{ questType, difficulty, requirement, rewardXp }` — все 4 обязательны
- Только лидер может брать/забирать квесты

**POST /guild/quest/claim** — лидер забирает награду:
- Проверяет `quest.progress >= quest.requirement`
- Начисляет XP гильдии, проверяет level-up

### Питфолы квестов гильдии
- **Клиент читает `d.options`, НЕ `d.available`.** Сервер возвращает поле `options`, опечатка в клиенте → опции никогда не показываются.
- **take body: `questType`, НЕ `type`.** Сервер проверяет `if (!questType || ...)` — если клиент шлёт `{ type: ... }`, сервер отвергает «Выберите задание».
- **take body: обязателен `rewardXp`.** Сервер проверяет все 4 поля.
- **Только лидер может управлять квестами.** Рядовые участники видят прогресс, но кнопки «Взять»/«Забрать» скрыты.

## Архитектура (после рефакторинга 2026-06-23)

### Структура сервера

```
server/src/
├── index.ts              # точка входа (30 строк, только setup)
├── events.ts             # EventBus — шина между роутами и WebSocket
├── websocket.ts          # WebSocket (connection, chat, serverTick, heartbeat)
├── setupRoutes.ts        # регистрация всех маршрутов
├── setupMiddleware.ts    # middleware
├── db/
│   ├── index.ts          # PostgreSQL pool + query/run/one/tx
│   └── helpers.ts        # USER_*_FIELDS, buildPlayerStats(), getBaseStats, enrichEquipment, applyExp
├── game/
│   ├── stats.ts          # PRIMARY_STATS, StatRecord, CharStats, currentStats(), F, sv()
│   ├── battle.ts         # runBattle(), runTurn(), формулы через F+sv()
│   ├── drinks.ts         # DRINK_BONUSES, getDrinkBonuses()
│   ├── guildBuildings.ts # BUILDINGS, getGuildBonus(), getGuildBuildings()
│   ├── hpRegen.ts        # регенерация HP
│   └── rating.ts         # calcElo, рейтинги
├── schedulers/\n│   ├── salary.ts         # жалование: 10 + pvewins каждый час (всем игрокам)\n│   ├── tournaments.ts    # создание/продвижение турниров\n│   ├── cleanup.ts        # очистка старых данных (>7 дней)
  └── massacre.ts       # резня — проверка сбора и запуск боя
└── routes/
    ├── battle.ts         # PvP бой
    ├── arena.ts          # арена (подбор соперника)
    ├── massacre.ts       # резня (массовые PvP бои)
    ├── mobs.ts           # PvE бой
    ├── tournament.ts     # турниры
    ├── auction.ts        # аукцион (фильтры: weapon/shield/ring/armor/stats)
    ├── character.ts      # /character/me — главный эндпоинт персонажа
    ├── guild/              # гильдия (разбита на 6 модулей)
    │   ├── guildCore.ts     # create, my, list, settings, view/:id, leave
    │   ├── guildMembers.ts  # requests, invites, join, kick, role
    │   ├── guildChat.ts     # чат гильдии
    │   ├── guildTreasury.ts # депозит, история, налог
    │   ├── guildWar.ts      # войны + isGuildAtWar
    │   └── guildQuests.ts   # квесты + updateGuildQuestProgress
    ├── guild.ts             # 19 строк — импортирует guild/ модули
    ├── vkBridgeAuth.ts      # VK авто-вход по параметрам запуска (HMAC-SHA256 подпись)
    ├── vkPayments.ts        # VK Payments колбэк (get_item + order_status_change)
    └── vkLeaderboard.ts     # отправка уровней в VK (secure.addAppEvent)
```

### EventBus (`src/events.ts`)
Шина событий между роутами и WebSocket. Роуты НЕ импортируют из `websocket.ts` — только из `events.ts`.

```typescript
// В роуте:
import { markDirty, pushNotification, broadcast } from '../events';
markDirty(userId, 'quests');
pushNotification(userId, { type: 'system', message: '...' });
broadcast('auctionChanged', {});
```

WebSocket подписывается на события в `setupWebSocket()`. При добавлении новой фичи:
- Если нужно уведомить клиента через WS → emit в `events.ts`
- `websocket.ts` править НЕ надо

### Schedulers (`src/schedulers/`)
Фоновые процессы вынесены из `index.ts`:
- `salary.ts` — жалование за PvE (каждый час)
- `tournaments.ts` — создание/продвижение турниров (каждые 5 мин)
- `cleanup.ts` — очистка старых данных (раз в 24ч)

Добавление нового scheduler'а: создать файл в `schedulers/`, вызвать `start*()` из `index.ts`.

## Stats Architecture (после рефакторинга 2026-06-23)

### Balance Changes (June 23, 2026)
См. `references/balance-changes-june23.md`. Ключевое:
- HP = S+A+M (не S+A+D+M)
- Block cap: 75% (не 100%)
- Extra stats: soft cap x/(x+300) вместо x/300
- Premium HP regen: `premiumUntil` передаётся в `applyHpRegen`

### Login Overhaul (June 23, 2026)
См. `references/login-overhaul-june23.md`. Ключевое:
- `/login`: никнейм → игра (без пароля)
- `/login-classic`: email+пароль (без гостевого входа)
- Регистрация: только email+пароль, ник сохраняется
- Премиум: +3 дня за email-регистрацию или OAuth
- `/rules` и `/privacy` — правовые документы

### Система статов — параметрическая
Статы больше не хардкодятся как `{s, a, d, m}` в 15 файлах. Единый реестр:

```typescript
// ЕДИНСТВЕННОЕ место перечисления статов:
export const PRIMARY_STATS = ['s', 'a', 'd', 'm'] as const;
export type StatRecord = { s: number; a: number; d: number; m: number };
```

### Хелперы (вместо ручного счёта)
- `sumStats(s: StatRecord): number` — сумма статов = HP
- `addStats(a, b): StatRecord` — сложение двух StatRecord
- `scaleStats(s, mult): StatRecord` — масштабирование на множитель

### Где лежат
- **Сервер:** `game/stats.ts` — PRIMARY_STATS, StatRecord, CharStats, currentStats(), хелперы
- **Клиент:** `utils/stats.ts` — PRIMARY_STATS, STAT_LABELS (русские названия), дубли хелперов
- **Бой:** `game/battle.ts` — формулы принимают CharStats (не голые числа). Ходы симметричны через `runTurn()`
- **Бонусы:** `game/drinks.ts` — DRINK_BONUSES: `Record<string, StatRecord>`
- **UI:** `StatsOverlay.tsx` итерирует `PRIMARY_STATS.map(...)`, `ItemStats.tsx` итерирует `Object.entries(bonuses)`

### Боевые формулы (актуальные, после баланса 2026-07-06)

**Статы:** s=Сила, a=Ловкость, d=Защита, m=Мастерство. HP = S+A+M.

Базовое влияние основных статов уменьшено в 1.5 раза (`/ 1.5`). Экстра-статы через soft cap `x/(x+300)`, капы: crit 80%, dodge 50%, block 75%, counter 50%.

```typescript
// game/battle.ts — ЕДИНСТВЕННЫЕ формулы крита/уклонения/блока/контрудара
blockChance   = d / (d + 500) / 1.5 + extraBlock / (extraBlock + 300)
blockReduce   = min(0.75, 0.9 × (def_d / atk_s))  // сколько % урона режется при блоке (коэфф 0.9, 2026-07-11)
crit    = m / (m + 500) / 1.5 + extraCrit / (extraCrit + 300)
dodge   = a / (a + 500) * (1 - m_врага / (m_врага + 250)) / 1.5 + extraDodge / (extraDodge + 300)
counter = (m+a) / ((m+a) + (m_врага+d_врага)) * 0.5 / 1.5 + extraCounter / (extraCounter + 300)
```

Формула урона: `level + factor × (S − level)`, где S = сила. Подробнее: `references/damage-formula.md`.

### 🔴 Питфол: PvE бой — хардкод формул в mobs.ts

**ВСЕГДА использовать общие функции из `game/battle.ts`** — `dodgeChance()`, `critChance()`, `critMult()`. PvE (`routes/mobs.ts`) ДОЛЖЕН импортировать их, а не писать свои.

**Симптом:** в бою с мобом дикое количество уклонений/критов. Мобы с M=0 уклоняются в 50%+ случаев. Причина: хардкод `agility / (agility + 50)` вместо общей формулы.

**Фикс (2026-07-06):** заменить локальные функции в `mobs.ts` на импорт из `battle.ts`:
```typescript
import { dodgeChance, critChance, critMult } from '../game/battle';
// ...
dodgeChance(mobStats, userStats)  // моб уклоняется (defender=mob)
dodgeChance(userStats, mobStats)  // игрок уклоняется (defender=player)
critChance(userStats)             // крит игрока
critChance(mobStats)              // крит моба
```

### Экстра-статы в UI — реальный процент

`StatsOverlay.tsx` показывает экстра-статы (крит/уклон/контр/блок) через soft cap: `Math.round(v / (v + 300) * 100)`. Не показывать сырые значения как проценты — это вводит в заблуждение (сырое 50 ≠ 50% шанс).

Формулы в `battle.ts` НЕ ссылаются на статы по имени. Вместо `stats.m` / `stats.d` используется конфиг `F` + хелпер `sv()`:

```typescript
// ЕДИНСТВЕННОЕ место правки при добавлении стата в механику:
const F = {
  dodgeDef:   'a',           // уклонение защиты от ловкости
  dodgePen:   'm',           // штраф уклонения от мастерства атакующего
  crit:       'm',           // крит от мастерства
  block:      'd',           // блок от защиты
  damage:     's',           // урон от силы
  counterDef: ['m', 'a'],    // контратака защиты: мастерство + ловкость
  counterTgt: ['m', 'd'],    // контратака цели: мастерство + защита
  stunAtk:    ['s', 'm'],    // оглушение атакующего: сила + мастерство
  stunDef:    ['s', 'd'],    // сопротивление оглушению: сила + защита
} as const;

function sv(stats: CharStats, key: any): number { ... }
```

Добавить «удачу» в крит: `F.crit = ['m', 'luck']` — формула автоматом суммирует оба стата.

### Имена слотов (актуальные из БД)

Предметы в БД используют слоты: `weapon1, shield, helmet, chest, gloves, boots, amulet, ring, belt`.
- Кольца: **`ring`** (НЕ ring1/ring2)
- Оружие: **`weapon1`**
- Щит: **`shield`**

Аукционный серверный фильтр: weapon → `slot === 'weapon1'`, shield → `slot === 'shield'`, ring → `slot === 'ring'`.
Клиентский SLOT_KEYWORDS в `AuctionPage.tsx` мапит русские названия на эти ключи.

### Character interface (`GameContext.tsx`)
Поле `guildBonus?: number` — сервер возвращает его в `/character/me`.
Поле `buildings?: { type, icon, label, level, bonus }[]` — список сооружений гильдии (загружается через `getGuildBuildings()` в `character.ts`).
Поле `stats` расширено: `{ s, a, d, m, hp, bonuses, extra, drinks, collection }`.
Поле `collectedItems?: { itemName: string; slot: string }[]` — загружается вместе с персонажем в `/character/me`.

### Защита от рендера без статов
Все страницы с CharacterCard ДОЛЖНЫ проверять `character?.stats` перед рендером:
```tsx
if (!character?.stats) return <div>Загрузка...</div>;
```
Добавлено в ArenaPage 2026-06-23. Без этого в первую секунду показываются нулевые статы → путаница.

## Где применяется гильд-бонус

### Сервер — `currentStats()` ОБЯЗАН получать гильд-бонус 5-м аргументом:
- ✅ `routes/character.ts` `/character/me` — статы игрока
- ✅ `routes/battle.ts` — PvP бой (атакующий + защитник)
- ✅ `routes/arena.ts` — подбор соперника
- ✅ `routes/mobs.ts` — PvE бой
- ✅ `routes/battleSim.ts` — симулятор
- ✅ `routes/tavern.ts` — таверна (HP для отдыха)
- ✅ `routes/users.ts` — профиль другого игрока
- ✅ `routes/tournament.ts` — турниры

## Клиент: CharacterCard — через toCharCardData()

```typescript
import { toCharCardData } from '../utils/character';
// Хелпер собирает CharacterCardData из Character
// ЕДИНСТВЕННОЕ место правки при добавлении поля в CharacterCard
char={toCharCardData(character, { currentHp: hpLeft, maxHp: maxHpLeft })}
```
Файлы: LeftSidebar, ArenaPage, BestiaryPage — используют toCharCardData.
Больше НИГДЕ не собирать char вручную.

Клиент **не вычисляет** статы сам. Всегда используется `character.stats` с сервера.
Сервер `/character/me` возвращает полные статы со ВСЕМИ бонусами (экипировка, напитки, коллекция, гильдия).

```typescript
// ❌ НЕ ДЕЛАТЬ: локальный пересчёт
const stats = calculateStats(character, ...);
const stats = getCharStats(character);

// ✅ ДЕЛАТЬ: брать с сервера
const stats = character.stats;
```

Поля в `character.stats`: `{ s, a, d, m, hp, bonuses, extra, drinks, collection }`
Отдельно в `/character/me`: `baseStats`, `drinkBonuses`, `collectionCount`, `guildBonus`, `collectedItems[]`, `buildings[]`

Добавление нового бонуса: ТОЛЬКО на сервере в `currentStats()` → автоматически доходит до клиента.

## Гильд-бонус — проверка

Все 5 контекстов протестированы на Ждуле (userId=31, guildId=5): training_ground lv1 → arena+tournament 5%, scout_hq lv1 → pve 5%, siege_camp lv1 → war_attack 5%, walls lv1 → war_defense 5%.
Сервер: S=258 с гильдией / S=246 без. `/character/me` → `stats.s=258, guildBonus=5`.
Если клиент показывает другие цифры — Ctrl+Shift+R, проверить DevTools → Console.

## VK Games — интеграция платформы

Полная документация: `references/vk-games-integration.md`. Ключевое:
- **VK Bridge SDK обязателен:** скрипт в `index.html` + `VKWebAppInit` в `main.tsx`
- Игра грузится в iframe на `vk.com/app<id>`, НЕ в панели управления dev.vk.com
- Ошибки `getRootRef` / `stats.vk-portal.net 403` — баги платформы VK, не игры
- **Скроллбар:** `height: 100vh` (не `min-height`) + `overflow-y: auto` + класс `vk-iframe`
- **Авторизация:** параметры запуска из URL (`vk_user_id`, `sign`) → `/api/auth/vk-bridge`
- **Авто-вход:** отдельная страница `/vk-login`, редирект через `<Navigate>` (не `window.location`)
- **Платежи:** `VKWebAppShowOrderBox` + серверный колбэк `/api/vk/payments`
- **Бейджи гильдии:** клик по карточке должен вызывать onGuildClick (сохраняет guildBadgeSeen)
- **Премиум новым:** 1 день всем (vkBridgeAuth.ts, oauth.ts, account.ts)

### VK WebView image loading

**Проблема:** в VK WebView (iframe на vk.com) картинки могут не грузиться. Основные причины:
1. Файлы `uploads/` не задеплоены на VPS → 404
2. Nginx не отдаёт CORS заголовки → блокировка кросс-ориджин запросов
3. `<base>` тег может сломать пути в VK iframe — лучше НЕ использовать

**Проверенный фикс:**
1. Задеплоить `uploads/`: `rsync -avz uploads/ root@194.226.142.237:/opt/game/server/uploads/`
2. Добавить CORS для статики в nginx:
```nginx
add_header Access-Control-Allow-Origin "*";
```
В блоках: `location ^~ /uploads/`, `location /assets/`, `location ~* \.(webp|png|jpg|svg)$`

**НЕ помогло:** `<base href>` и `<meta referrer>` — либо не влияют, либо ломают пути в VK iframe. WebP формат НЕ является проблемой — VK WebView его поддерживает.

VK WebView не поддерживает `@layer`, `@property`, `translate:`, `oklch()`, `backdrop-filter`.
Все исправления — в кастомном Vite плагине (`vite.config.ts` → `stripCssForVkWebView`):
- Разворачивает `@layer`, вырезает `@property`, заменяет `translate:` → `transform:`
- `oklch()` → hex, хардкод-opacity → `var()`
- CSS инлайнится в `<style>` (без внешних файлов)
- `.vk-iframe` оверрайды в `theme.css` для: fixed header, solid-фоны, скролл-лок

При изменении `vite.config.ts` — проверять баланс скобок после билда:
```bash
python3 -c "import re; c=open('dist/index.html').read(); m=re.search(r'<style>(.*?)</style>',c,re.DOTALL); css=m.group(1); print(f'{css.count(\"{\")}/{css.count(\"}\")}')"
```
Должно быть равное количество.
- **CSS в VK WebView:** Tailwind v4 `@layer`/`@property`/`translate:` не работают в VK WebView. Решение: кастомный плагин в `vite.config.ts` (см. skill `vk-games`, `references/vk-css-inline.md`)

## Турниры: дивизионы и фонд из казны (2026-06-29)\n\nСм. `references/tournament-divisions.md`.\n\n10 перекрывающихся дивизионов с русскими названиями. Призовой фонд = 50% казны × tier/55 (где tier 1-10). Кулдаун 4ч, регистрация 1ч. Файлы: `server/routes/tournament.ts` (divisions, calcDivisionPool), `client/pages/TournamentPage.tsx` (divisionLabels/Icons/BorderClasses/TextClasses), `client/pages/HistoryPage.tsx` (divisionLabels для сводки).\n\n## Рефакторинг-паттерны (2026-06-23)

### Статы: PRIMARY_STATS + StatRecord
ЕДИНСТВЕННОЕ место: `game/stats.ts` → `PRIMARY_STATS = ['s','a','d','m']`.
Добавить стат: PRIMARY_STATS + StatRecord + STAT_LABELS (клиент).

### Боевые механики: конфиг F + sv()
ЕДИНСТВЕННОЕ место: `game/stats.ts` → `F = { dodgeDef:'a', crit:'m', block:'d', ... }`.
Формулы: `sv(stats, F.crit)` вместо `stats.m`. Добавить стат → изменить F.

### SELECT-запросы: USER_BATTLE_FIELDS
ЕДИНСТВЕННОЕ место: `db/helpers.ts` → `USER_BATTLE_FIELDS = '...'`.
Запросы: `` SELECT ${USER_BATTLE_FIELDS} FROM users u WHERE ... ``.
Поле в users → ТОЛЬКО в USER_BATTLE_FIELDS.

### Сервер: buildPlayerStats(userRow, context)
ЕДИНСТВЕННОЕ место сборки статов: `await buildPlayerStats(user, 'arena')`.
Заменяет копипаст `getBaseStats + JSON.parse + getDrinkBonuses + COUNT collections + getGuildBonus + currentStats`.

### Клиент: toCharCardData(character, overrides?) (utils/character.ts)
ЕДИНСТВЕННОЕ место сборки CharacterCardData из Character:
```typescript
char={toCharCardData(character, { currentHp: hpLeft, maxHp: maxHpLeft })}
```
Все страницы (Arena, Bestiary, LeftSidebar) используют ТОЛЬКО эту функцию.

### Клиент: НИКОГДА не вычислять статы локально
`calculateStats()` / `getCharStats()` — удалены. Всегда `character.stats` с сервера.
`/character/me` возвращает полные статы со ВСЕМИ бонусами.

### Отладка статов: тестировать НАПРЯМУЮ на VPS
При багах со статами НЕ гадать по клиенту. Тестировать API напрямую:
```bash
# Написать тестовый скрипт локально (write_file), scp на VPS, запустить
scp test.js root@194.226.142.237:/opt/game/server/
ssh root@194.226.142.237 'cd /opt/game/server && node test.js'
```
Проверять: `/character/me` (статы игрока), `/api/arena/opponent` (соперник), прямой вызов `currentStats()`.
Клиентский кеш (Ctrl+Shift+R) — ПОСЛЕДНЕЕ что проверять, не первое.

### Client-server API mismatch — см. `references/api-debugging.md`
Рецидивирующий баг: клиент читает не те поля из ответа сервера. При «данные не показываются» — сначала сверить имена полей.

## Уведомления пользователю — ToastContext (не alert!)

**Все `alert()` в проекте заменены на кастомные тосты** (2026-07-10). Использовать `useToast()` из `contexts/ToastContext.tsx`:

```tsx
import { useToast } from '../contexts/ToastContext';
const { showToast } = useToast();
showToast('Сообщение');                    // error (красный, по умолчанию)
showToast('Успех!', 'success');           // зелёный
showToast('Внимание', 'warning');         // жёлтый
showToast('Информация', 'info');          // синий
```

Тосты: фиксированные по центру сверху, авто-скрытие 4 сек, макс. 5 одновременно. Контекст обёрнут в `ToastProvider` в `App.tsx`.

**НИКОГДА не использовать `alert()`** — только `showToast()`.

## 🎨 UI: антипаттерны (AI-штамповка)

**`border-l-4 border-l-[color]` + `bg-[color]/5`** — шаблонный AI-паттерн для блоков-советов/выделений. Юзер явно отверг: «надо что то новое придумать, что бы отличаться». Заменять на уникальный дизайн (медальон с иконкой по центру верхней границы, угловой ярлык, огненный градиент — что угодно кроме левого бордера).

То же касается `border-l-2 border-l-[var(--color-accent-warning)]` для поста автора на форуме — заменён на медальон с 📢.

**Правило:** если тянет добавить левый цветной бордер — остановиться и придумать что-то не из стандартного AI-набора.

### Медальон (бейдж по центру верхней границы)

Утверждённый юзером паттерн для выделения блоков. Иконка в круглом контейнере, выезжает за верхнюю границу карточки:
```tsx
<Card className="border border-[#f59e0b]/30 relative mt-3">
    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[var(--color-bg-secondary)] border border-[#f59e0b]/30 rounded-full w-7 h-7 flex items-center justify-center text-sm shadow-[0_0_6px_rgba(245,158,11,0.3)]">
        💡
    </div>
    <div className="flex items-start gap-3 mt-1">
        {/* содержимое */}
    </div>
</Card>
```
Используется: WikiPage (💡 совет), ForumThreadPage (📢 пост автора). `mt-3` на Card + `mt-1` на контенте чтобы не пересекалось с текстом.

### Размеры кнопок — mobile-first

Юзер требует удобные кнопки на мобильных. **Минимальный размер: `sm`** (px-2 py-1), **основные действия: `md`** (px-3 py-1.5 text-sm). Размер `xs` (px-1.5 py-0.5) слишком мелкий для пальца — **никогда не использовать** для интерактивных кнопок на основных страницах.

Размеры Button:
- `xs`: px-1.5 py-0.5 — **НЕ ИСПОЛЬЗОВАТЬ** для интерактивных кнопок (слишком мелко для пальца)
- `sm`: px-2 py-1 — минимум для тапов (табы, фильтры, второстепенные действия)
- `md`: px-3 py-1.5 text-sm — **основные действия** (карточки Actions, кнопки покупки/ставки, «Перейти»)

При глобальной замене: `sed -i 's/size="xs"/size="sm"/g'` по pages/ и components/.
Для Actions карточек: вручную `size="sm"` → `size="md"` (6 кнопок в Actions.tsx).

### Карточки Actions — единая высота

Все карточки (включая Резню и Арену) имеют одинаковую структуру для консистентной высоты:
```tsx
<h3>title</h3>
<p>subtitle</p>
<p className="text-[0.65rem] text-[var(--color-text-muted)] h-4 leading-4">{cost > 0 ? `${card.path === '/massacre' ? 'Вход' : 'Цена'}: ${formatMoney(cost)}` : ''}</p>
<div className="mt-auto">
  <Button ...>{btnText}</Button>
</div>
```
Цена всегда в отдельной строке с фиксированной высотой `h-4 leading-4` (16px). Если `cost === 0` — пустая строка (высота сохраняется). У Резни: «Вход: 5000» вместо «Цена:», кнопка показывает таймер или «В бой» (без цены в кнопке). Арена: `cost = 0` в БД (цена не показывается).

**Шрифты для мобильных:** заголовок `text-sm` (14px), описание `text-xs` (12px), цена `text-[0.65rem]` (~10.4px). Кнопки `size="md"`.

### Чат: вкладки без иконок

Вкладки чата (ChatTabs.tsx) — только текст, без emoji-иконок. «Аукцион» вместо «🔨 Аукцион», название гильдии без «🏚️». Цветовая дифференциация через CSS-переменные (`text-[var(--color-accent-warning)]` для аукциона, `text-[var(--color-accent-success)]` для гильдии).

### Чат: тематические карточки — НЕ хардкодить фон

Аукцион-карточки в чате (MessageList.tsx) ДОЛЖНЫ использовать theme-aware CSS-переменные для фона, а не хардкод-цвета. `bg-[#2a2010]` → `bg-[var(--color-bg-input)]`. Иначе в светлой теме тёмный фон + тёмный текст = нечитаемо.

### Системные сообщения — senderName: 'Глашатай'

ВСЕ сообщения с `senderId = 0` должны иметь `senderName: 'Глашатай'` (не 'system', не 'Аукцион').

**КРИТИЧЕСКИЙ БАГ (2026-07-03): таблица `users` содержит запись `id=0, username='system'`!** `LEFT JOIN users u ON m.senderId = u.id` находит её. `COALESCE(u.username, 'Глашатай')` видит `'system'` (НЕ NULL!) → возвращает `'system'`. **Решение:** `CASE WHEN m.senderId = 0 THEN 'Глашатай' ELSE u.username END` в SQL.

Файлы: `routes/chat.ts` (оба эндпоинта — явный список колонок + CASE WHEN), `routes/auction.ts` (3 места), `routes/adminChat.ts`, `routes/guild/guildMembers.ts`, `routes/guild/guildWar.ts`. Клиент: `MessageList.tsx` — `truncate(null)` → `'Глашатай'`.

### Инвентарь — сворачивание и localStorage

Клик по заголовку → сворачивание/разворачивание (стрелки `▶`/`▼`). Состояние (`invCollapsed`, `invSort`) в localStorage. Проп `collapsible={false}` отключает (Крафт). `max-w-2xl mx-auto` как у Actions. Грид слотов `overflow-hidden` на широких экранах.

### Scroll lock — правильный паттерн

Нельзя просто ставить `overflow: hidden` — страница прыгает наверх, хедер пропадает. Правильно: `position: fixed; top: -scrollYpx` с сохранением/восстановлением скролла. Применено в `RightSidebar.tsx` и `ChatPanel.tsx`.

### Чат: drag-to-resize → onClick конфликт

Заголовок чата и драг-хендл, и кнопка сворачивания (onClick). После drag срабатывает onClick → панель закрывается. Фикс: `dragMovedRef`, в onClick `if (!dragMovedRef.current)`. Сброс ref в `onEnd` через `setTimeout(0)`.

### Аукцион: клик по лоту из чата → подсветка

Переход на `/auction?lot=<id>`. Перед `scrollIntoView` снимать scroll-lock с body (`position/overflow/top/width = ''`). Подсветка: `!border-2 !border-[#f59e0b] shadow-[0_0_10px_rgba(245,158,11,0.6)]` (border+shadow с хардкод-цветами — `ring` не работает в VK WebView).

### React: useRef не триггерит ререндер

`useRef.current = value` меняет значение молча, без перерисовки. Если после асинхронной загрузки нужно чтобы сработал другой `useEffect` — использовать `useState` + `setState`. `useRef` подходит только для значений, не влияющих на рендер (таймеры, флаги отмены, предыдущие значения для сравнения).

**Пример бага:** в RatingPage `initialLoadDone.current = true` не вызывал ререндер → второй эффект (зависящий от флага) не срабатывал → данные не грузились. После нескольких неудачных попыток с `useRef` перешли на `useState` + серверный `myPage` в ответе рейтинга.

**Фикс:** либо `useState` + `setState`, либо перенести всю логику в один эффект с async/await (рейтинг так и сделан).

### Навигация: SPA-ссылки через navigate(), не <a href>

Ссылки на ВСЕ внутренние страницы должны использовать React Router `navigate()` или `<Link>` вместо `<a href="...">`. `<a>` вызывает полную перезагрузку страницы. Единственное исключение: внешние ссылки на другие домены (VK, соцсети).

**🔴 Питфол VK iframe:** `<a href>` на внутренние страницы (правила, privacy, wiki) в VK iframe вызывает полную перезагрузку → теряются VK-параметры запуска (`vk_user_id`, `sign`) → `isVkLaunch=false`. При возврате назад (`navigate(-1)`) происходит ещё одна перезагрузка, и если JWT не успевает загрузиться из localStorage на первом рендере — срабатывает `<Navigate to="/login">`. Правила и privacy — НЕ статические страницы, это React-компоненты внутри SPA.

**Симптом:** после просмотра `/rules` или `/privacy` пользователь попадает на страницу авторизации. Воспроизводится только в VK iframe.

**Где проявлялось:** HomePage.tsx (приветственный блок для новых игроков) — `2026-07-18`, исправлено на `navigate()`.

## 🔴 Документация/вики: НИКОГДА не выдумывать

**⚠️ ЗАГРУЗИТЬ ЭТОТ SKILL ПЕРЕД ЛЮБОЙ РАБОТОЙ С ВИКИ/ГАЙДАМИ/ДОКУМЕНТАЦИЕЙ ИГРЫ.**

При написании игровой документации (WikiPage, гайды, описания механик) **запрещено писать что-либо по памяти или догадкам**. Каждый факт должен быть подтверждён чтением исходного кода:

- **Редкости/предметы:** `server/src/database/seed.ts` — точный список и имена (7 редкостей: Хлам→Мифический, Божественной НЕТ)
- **Механики боя:** `server/src/game/battle.ts`, `server/src/game/stats.ts`
- **Трактир/комнаты/напитки:** `server/src/routes/tavern.ts` — названия, цены, длительность (1 час, не 2)
- **Крафт/улучшения:** `server/src/routes/craft.ts` — камень+предмет, не «3 одинаковых→1»
- **Квесты:** `server/src/game/questData.ts` — типы, сложности, множители
- **Гильдии/постройки:** `server/src/game/guildBuildings.ts`
- **Страницы/роуты:** `client/src/App.tsx` — полный список; содержимое читать в `client/src/pages/` (НЕ гадать по имени файла — OrdersPage это гильдии, не «биржевые заявки»)
- **Extra-статы:** читать seed.ts — на амулетах/кольцах/поясах И щитах (fullBlock)

**Антипаттерн:** «наверное там 7 слотов», «кажется напитки на 2 часа», «вроде есть Божественная редкость», «OrdersPage — это биржевые заявки». Симптом: юзер орёт «откуда ты это взял?».

**Правильный workflow для Wiki:**
1. Прочитать `App.tsx` — все роуты
2. Для каждой страницы: прочитать её код, понять что она делает
3. Для цифр: прочитать соответствующий серверный роут или seed
4. Только потом писать текст
5. Ссылки на Wiki из других страниц — через `navigate('/wiki')` (React Router), не `<a href="/wiki">` (перезагрузка)

### Auth JWT pitfalls
- **`parseUserFromToken` возвращает `username: ''`.** JWT payload должен содержать `username`, иначе после перезагрузки localStorage имя юзера теряется.
- **`role` обязателен в JWT.** Без `payload.role` → `user.role = undefined` → все роуты с `user?.role === 'player'` редиректят на /login.
- **loginUser → token → useEffect → parseUserFromToken перезаписывает user.** Если `loginUser` установил юзера с правильным именем, а JWT не содержит `username`, useEffect перезатрёт пустым.

## Трактир: комнаты и напитки

См. `references/tavern-drinks.md`. Ключевое:
- **Комнаты:** Чулан (rate 3), Койка (rate 10), Аппартаменты (rate 50). Стоимость: 1ч/8ч.
- **Напитки** разделены по категориям: Сила (s), Ловкость (a), Защита (d), Мастерство (m), Универсальные (все статы). Сервер возвращает `category` в каждом напитке.
- **Сворачиваемые секции:** используются символы `▶` (свёрнуто) и `▼` (развёрнуто) — единый паттерн для всех раскрывающихся блоков (BuffsBlock, OverflowStorage, TavernPage). По умолчанию секции свёрнуты.
- **Описания вкладок:** каждая вкладка (лечение/комнаты/напитки/задания) имеет блок-описание. При добавлении `<p>` внутрь `<>...</>` не забыть `</>` перед закрывающей `}` — иначе rolldown падает с `Unexpected token`, а `tsc --noEmit` молчит.
- **Рекламное лечение (VK):** `POST /tavern/heal-ad` — полное бесплатное лечение за просмотр rewarded-рекламы (`VKWebAppShowNativeAds`, `ad_format: 'reward'`). Кулдаун 30 мин, колонка `adhealat` в users. Кнопка «▶️ За рекламу — бесплатно» только в VK (`html.vk-iframe`), с таймером обратного отсчёта.

## Квесты: множители наград

Файлы: `server/src/game/questData.ts` (константы), `server/src/routes/quests.ts` (расчёт).

Множители разделены на опыт и серебро (`rewardXpMult` / `rewardMoneyMult`):
```typescript
export const DIFFICULTIES = {
    easy:   { rewardXpMult: 1,  rewardMoneyMult: 1,  ... },
    medium: { rewardXpMult: 2,  rewardMoneyMult: 5,  ... },
    hard:   { rewardXpMult: 3,  rewardMoneyMult: 10, ... },
};
```

Используются в двух местах `quests.ts` (генерация нового квеста + замена после сдачи):
```typescript
Math.round(rw.xp * d.rewardXpMult), Math.round(rw.money * d.rewardMoneyMult)
```

При изменении наград — менять только `questData.ts`. Награда записывается в БД при взятии квеста, уже активные квесты сохраняют старые значения.

### React double-fetch на mount (useEffect + debounce)

Когда на странице есть оба:
- `useEffect(() => load(), [user])` — загрузка при монтировании
- `useEffect(() => { /* debounce → load() */ }, [filters...])` — перезагрузка при смене фильтров

— при первом рендере фильтры имеют начальные значения (совпадающие с дефолтными стейтами), и оба эффекта срабатывают: первый сразу, второй через debounce-задержку. Результат: двойной fetch.

**Фикс:** `useRef(true)` как флаг первого рендера, пропускать debounce-эффект на первом проходе:
```tsx
const initialRender = useRef(true);
useEffect(() => {
    if (initialRender.current) { initialRender.current = false; return; }
    // debounce + load
}, [filters]);
```

Проверено на AuctionPage (строка 157). Применимо к любой странице с фильтрами + авто-загрузкой.

### tsc -b блокирует билд молча

`package.json` build script: `"build": "tsc -b && vite build"`. Если `tsc -b` падает (любая TS-ошибка, включая TS6133 unused vars/imports), `vite build` НЕ запускается. Симптом: dist не обновляется, пользователь видит старую версию. Перед деплоем всегда проверять `npx tsc -b` отдельно.

### Турниры: дубликаты — порядок autoAdvance/getOrCreate

В `GET /tournament`: `getOrCreateTournament()` создаёт новый турнир, потом `autoAdvance` продвигает старый → в дивизионе два активных. **Правильный порядок:** сначала `autoAdvance()`, потом `getOrCreateTournament()` — новые создаются только в освободившихся дивизионах.

### Отображение времени — локальный пояс браузера

Сервер всегда UTC, клиент конвертирует. `fmtSafeDate()` — `toLocaleString('ru-RU')` без `timeZone:'UTC'`. `formatGameTime/formatGameDateTime` — `getHours()` вместо `getUTCHours()`.

### Vite/rolldown: ошибки сборки со срезанным выводом

Rolldown использует unicode-рамки для вывода ошибок. В терминале `process.wait()` или `head` обрезает их, показывая только фрейм без текста ошибки. **Всегда перенаправлять stderr в файл:**

```bash
npx vite build > /tmp/vite_out.txt 2> /tmp/vite_err.txt
# затем читать файлы
```

Симптом: `✗ Build failed in 1.13s` + пустой вывод с unicode-символами рисования рамки. `tsc --noEmit` при этом молчит — ошибка в JSX-синтаксисе, не в типах.

### Vite CSS плагин: `fixColorMix` — УДАЛЁН (ломал прозрачность всем)

Функция `fixColorMix` в `vite.config.ts` заменяла `color-mix(in srgb, var(--color-bg-primary) 60%, transparent)` на `var(--color-bg-primary)` — убирая opacity из всех панелей (чат, RightSidebar) для ВСЕХ пользователей, не только VK. Удалена из пайплайна. VK WebView обрабатывается через CSS-оверрайды в `theme.css` (под `html.vk-iframe`). **НЕ добавлять обратно.**

### Гильдия: бейджик (заявки + приглашения)

В `websocket.ts` serverTick считает бейджик как `requests + invites` из `guild_invites WHERE status = 'pending'`. **Старые приглашения не протухают автоматически** — показываются в бейджике вечно.

**Фиксы:**
1. Фильтр в запросе бейджика: `AND createdat > ?` (14 дней)
2. Автоочистка в `cleanup.ts`: `DELETE FROM guild_invites WHERE status = 'pending' AND createdat < ?` (7 дней, вместе с турнирами/чатом/боями/аукционом/квестами)
3. Ручная чистка при обнаружении: `DELETE FROM guild_invites WHERE status = 'pending' AND createdat < 'YYYY-MM-DD'`

### Хардкод на клиенте — антипаттерн (single source of truth)

Игровые параметры (кулдаун, лимиты, цены) НЕ должны дублироваться на клиенте. Сервер — единственный источник истины. Клиент получает готовые значения через API.

**Пример:** кулдаун арены был захардкожен в ТРЁХ местах:
- `server/routes/battle.ts` — `hasPremium ? 150 : 300`
- `server/routes/character.ts` — `attackCooldownSec: ... ? 150 : 300`
- `client/pages/HomePage.tsx` — `const cd = isPremium ? 150 : 300`

При смене на 300/600 два места обновились, клиент — нет → таймер показывал старое время.

**Фикс:**
1. Сервер вычисляет `attackCooldownSec`/`pveCooldownSec` в `/character/me` и отдаёт готовыми
2. Клиент читает `character.attackCooldownSec` без собственных расчётов
3. Единственное место правки при изменении — `character.ts` (и `battle.ts` для серверной проверки)

**Проверка при изменении параметра:** `grep -r "параметр" server/src/ client/src/` — найти ВСЕ вхождения, включая клиентские хардкоды.

### Казна гильдии: единый формат дат

Ручной депозит (`guildTreasury.ts`) использовал `NOW()` → формат `2026-06-29 00:39:02+00` (с пробелом). Налог (`helpers.ts`) использовал `new Date().toISOString()` → формат `2026-06-29T00:40:59Z` (с T).

Фильтр `period=today` в истории делает строковое сравнение: `createdat >= '2026-06-29T00:00:00Z'`. Пробел (0x20) < T (0x54) в ASCII → депозит НЕ проходит фильтр.

**Фикс:** все INSERT в `guild_treasury_log` должны использовать `new Date().toISOString()`, не `NOW()`.

### CardGrid badge handlers
- **onGuildClick/onBankClick НЕ вызываются при клике.** В `Actions.tsx` CardGrid onClick обрабатывает только `onAuctionClick`. Для гильдии и банка нужно явно добавить `if (card.title === 'Гильдия/Банк' && onXClick) onXClick()`.

### write_file ЛОМАЕТ `Bearer ` (пробел после Bearer)
Писать тестовые скрипты через scp, не через write_file.

### patch с replace_all ЛОМАЕТ файл при разных контекстах
Никогда не использовать `replace_all: true` если заменяемый паттерн встречается в разных контекстах
(например `currentStats(...)` с разными аргументами). Всегда использовать уникальную строку контекста.
Если замена должна произойти в нескольких местах с одинаковым паттерном — ОК.
Пример поломки: battleSim.ts — replace_all заменил `currentStats(base, equipment, drinkBonuses, collectionBonus, guildBonus)`
в loadout-хендлере И в battle-sim хендлере на строчку с `buildPlayerStats(user, ...)`, которая невалидна во втором контексте.

### require('../websocket') из поддиректорий — БАГ
При сплите файлов в поддиректории (`routes/guild/`) статические импорты обновляются на `../../`, 
но динамические `require()` остаются со старыми путями. Пример: `guildChat.ts` делал 
`require('../websocket')` из `routes/guild/` → путь вёл в `routes/websocket` (не существует).
Решение: заменить на статический импорт или исправить путь на `../../`. 
Статические импорты `broadcast`, `sendToGuild` уже есть в `events.ts` — require избыточен.

### execute_code + read_file с limit ОБРЕЗАЕТ файл
Читать весь файл (без limit) или использовать patch.

### node -e через ssh — НЕ для сложных скриптов
bash ломает кавычки, пробелы и спецсимволы.

## Real-time обновления через WebSocket (см. references/ws-events-pattern.md)

Паттерн: сервер `broadcast()` → ChatContext `window.dispatchEvent(CustomEvent)` → компонент `addEventListener`.
Турниры и гильдия используют этот паттерн с 2026-06-23.

**ServerTick — добавление новой фичи:** добавить поле в payload внутри `websocket.ts` tick-цикла, клиент слушает через `window.addEventListener`. Пример: резня (`massacreTick`), аукцион (`auctionBadge`).

**Паттерн serverTick-фичи (код):**
```typescript
// 1. В websocket.ts tick-цикле: один запрос на тик, кешировать результат
let massacreState: any = null;
try {
  const mev = await db.one(`SELECT id, status, ... FROM massacre_events WHERE status IN ('gathering','in_progress') LIMIT 1`, []);
  if (mev) massacreState = { id: mev.id, status: mev.status, timeLeft: ..., participant_count: mev.participant_count };
} catch {}

// 2. Включить в payload каждого юзера
if (massacreState) payload.massacre = massacreState;

// 3. Клиент: dispatch из ChatContext (добавить в switch(data.type) → case 'serverTick')
if (data.massacre) window.dispatchEvent(new CustomEvent('massacreTick', { detail: data.massacre }));

// 4. Компонент: подписаться на событие
window.addEventListener('massacreTick', handler);
```
**Важно:** запрос ДОЛЖЕН быть один на тик для ВСЕХ юзеров (перед циклом `for userIds`), НЕ внутри цикла. Иначе N запросов каждую секунду.

**Уведомление с навигацией:** `pushNotification` → `data.path = '/history?tab=X'` → `NotificationToast` делает `window.location.href = data.path` при клике. Паттерн для любых уведомлений, требующих перехода.

**Питфолы уведомлений:** см. `references/notifications-pitfalls.md`. data ДОЛЖЕН быть строкой (JSON.stringify), иначе React error #31.

## VK WebView: клавиатура на Android (НЕИСПРАВИМО из JS)

См. `references/vk-keyboard-fix.md`. Ключевое: после 18+ попыток (CSS, viewport, JS, VK Bridge) проблема не решается из JavaScript. Единственный рабочий обход — кастомная клавиатура (`VkKeyboard.tsx` + `inputmode="none"`). Viewport-фикс (`interactive-widget=resizes-content`, `100dvh`, убрать `position:fixed`) НЕ РАБОТАЕТ в VK WebView — откачен в `2fa65b7`.

### VK WebView: iOS — клавиатурный viewport при скролле

См. `references/vk-ios-keyboard.md`. `scrollBy` после `focusin` триггерит viewport под нативную клавиатуру. Фикс: центрирование инпута только на Android. `readonly` НЕ использовать — ломает React controlled inputs.

## Рейтинг: пьедестал Топ-3

См. `references/rating-podium.md`. Компонент `Top3Podium`, тёмные сплошные цвета (золото #daa520, серебро #708090, бронза #8b4513), высоты 80/55/35. Таблица с 4 места — `skip=3` в API.

## VK WebView: стилизация без прозрачности

**Запрещено использовать CSS opacity/альфа-каналы** (Tailwind `/10`, `/20`, `rgba()`). Заменять на сплошные цвета. Подробнее: `references/vk-webview-styling.md`.

## Гильдия: страница с вкладками

GuildPage переписана 2026-06-23: 4 вкладки (Обзор/Постройки/Казна/Участники).
Размер: 31.70→21.96 kB (-31%).
Постройки берутся из `data.buildings` (верхний уровень API), клиент сливает: `setGuild({...data.guild, buildings: data.buildings})`.
При расширении гильдии — добавлять секции в существующие вкладки или создавать под-компоненты в `components/guild/`.

**ВАЖНО:** GuildPage (>300 строк в новом виде) НЕЛЬЗЯ править через patch — JSX-вложенность ломается.
Любое изменение — переписывать файл с нуля через write_file. Проверено: 6+ попыток patching'а → 6+ поломок.
Подробнее: `references/guild-page-pitfalls.md`.

**Иконки рангов:** 👑 лидер, 🛡️ офицер, ⚔️ участник.
**Кнопки:** «Повысить»/«Разжаловать» и «Исключить» (текст, не иконки).
**Смена типа:** лидер может менять joinType через settings API (селектор в шапке).
**Приглашения:** во вкладке Участники, не в Обзоре.

## Банк: страница и описание

Файл: `client/src/pages/BankPage.tsx`. Структура:
- Баннер-описание под заголовком (`bg-secondary rounded p-2`) — единый паттерн с трактиром
- Вкладки: «История операций», «Пополнить/Снять», «Переводы»
- Правила (комиссии, PvP-защита) вынесены в баннер, не дублируются во вкладках

Табы `deposit` и `transfer` содержат по два Card: форма + история. При редактировании — следить за закрытием `</>` фрагментов после удаления Card.

## Казна гильдии: периоды (today/week/month/all)

`/api/guild/treasury/history?period=week` — возвращает `{ contributions: [{userid, username, total, count}], treasury }`.

## Казна замка (Castle Treasury)

См. `references/treasury.md`. Собирает комиссии со всех операций (банк 2%, магазин 100%, аукцион 5-10%, крафт).

## Бой: скорость и премиум-пропуск

Бои всегда на скорости x2, кнопки x1/x2 убраны. Крит-анимация усилена (z-index 30, снятие attacking перед critting). См. `references/battle-speed-crit.md`.

### Кнопка «Пропустить» — всегда видна, disabled + overlay tooltip

Кнопка **всегда рендерится** с пропом `disabled={!hasPremium}`. Без премиума кнопка серая (disabled), но **поверх неё кладётся прозрачный div** (`absolute inset-0`), который ловит клик и показывает **tooltip** «Доступно с Премиум». С премиумом — `onClick={handleSkip}`.

**Почему overlay:** disabled-кнопки НЕ фаерят onClick. Прозрачный div поверх ловит клики.

```tsx
const hasPremium = Number((character as any)?.premium?.until || 0) > Math.floor(Date.now()/1000);
const [showPremiumHint, setShowPremiumHint] = useState(false);

useEffect(() => {
  if (!showPremiumHint) return;
  const handler = () => setShowPremiumHint(false);
  document.addEventListener('click', handler);
  return () => document.removeEventListener('click', handler);
}, [showPremiumHint]);

<div className="relative">
  <Button variant="secondary" size="md" disabled={!hasPremium}
    onClick={hasPremium ? handleSkip : undefined}>Пропустить</Button>
  {!hasPremium && (
    <div className="absolute inset-0 cursor-pointer"
      onClick={e => { e.stopPropagation(); setShowPremiumHint(true); }} />
  )}
  {showPremiumHint && (
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-3 py-1
      text-xs text-[var(--color-accent-gold)] bg-[var(--color-bg-secondary)]
      border border-[var(--color-border-default)] rounded whitespace-nowrap shadow-lg z-50">
      Доступно с Премиум
    </div>
  )}
</div>
```

В BestiaryPage: `serverTime || Math.floor(Date.now()/1000)`. Применено в ArenaPage, BestiaryPage.

### HP bar: кнопка «+» для лечения в таверне

HealthBar (`CharacterCard/HealthBar.tsx`) — проп `showHealButton={true}` по умолчанию. При `currentHp < maxHp` показывает `+` справа на баре, клик → `navigate('/tavern?tab=heal')`. В боях передаётся `showHealButton={false}` через CharacterCard.

```tsx
// HealthBar.tsx — на баре:
<div className="...relative">
  <div style={{width:`${pct}%`}} ... />
  {showHealButton && currentHp < maxHp && (
    <div className="absolute top-0 right-0 h-full flex items-center justify-center
      cursor-pointer hover:text-[var(--color-accent-success)] text-[var(--color-text-muted)]
      px-1 text-xs font-bold select-none"
      onClick={e => { e.stopPropagation(); navigate('/tavern?tab=heal'); }}
      title="Лечение в трактире">+</div>
  )}
</div>
```

Проп пробрасывается: HealthBar ← CharacterCard (`showHealButton?: boolean`) ← страницы.

### PlayerBadge — переиспользуемый компонент (аватар+ник+HP)

`client/src/components/PlayerBadge.tsx` — кликабельный блок: аватарка 24×24 + ник [уровень] + HP-бар. Курсор pointer, при клике → `navigate('/')`. Используется в Header. Принимает пропсы: `avatar`, `username`, `level`, `gender`, `currentHp`, `maxHp`, `hpPct`.

### CharacterCard: клик по нику → профиль

Проп `profileId?: number` на CharacterCard. Если передан — никнейм становится кликабельным (`cursor-pointer`, hover-подсветка), переход на `/profile/{profileId}`. Передаётся из LeftSidebar: `profileId={character.id}`. В боях (ArenaPage, BestiaryPage) не передаётся — ник не кликабелен. Требует `import { useNavigate } from 'react-router-dom'` в CharacterCard.

### LeftSidebar — фиксированная ширина на десктопе

`LeftSidebar` использует `sm:w-[240px]` (не `sm:w-auto`). Это предотвращает растягивание контейнера при длинном тексте в `BuffsBlock` (напр. «Комната: Аппартаменты ×50»). Ширина 240px = CharacterCard 200px + margins 20px×2.

### BuffsBlock: BuffRow — двухстрочный лейаут

При длинных названиях деталь (напр. «Аппартаменты ×50») переносится на вторую строку целиком (`whitespace-nowrap`), а время всегда остаётся в одну строку справа (`ml-auto`). Структура:

```tsx
<div className="flex gap-2">
  <Icon className="flex-shrink-0 mt-0.5" />
  <div className="flex-1 min-w-0">
    <div className="flex items-baseline gap-1">
      <span>Комната:</span>
      <span className="ml-auto whitespace-nowrap">45 мин</span>
    </div>
    <div className="whitespace-nowrap">Аппартаменты ×50</div>
  </div>
</div>
```

Без детали — только первая строка.

### Гильдия: скрыть кнопку Вступить/Подать заявку

В `GuildViewPage.tsx` условие рендера кнопки: `{!isMember && !myGuild && (...)}`. Если игрок уже состоит в ЛЮБОЙ гильдии (`myGuild` не null), кнопки «Вступить»/«Подать заявку» скрываются для всех других гильдий.

### GuildViewPage: loaded state для предотвращения мелькания кнопки

`myGuild` загружается асинхронно с сервера. Пока он `null`, кнопка «Вступить» мелькает на полсекунды. Фикс: добавить `const [loaded, setLoaded] = useState(false)`, установить в `true` после завершения загрузки, и проверять `{loaded && !isMember && !myGuild && (...)}`.

**Паттерн `loaded` — универсальный:** для любого асинхронного флага, влияющего на видимость UI. Без `loaded` контент виден во время загрузки → мелькание. Применять везде где асинхронные данные управляют условным рендером.

### Admin panel: selectUser() — авто-заполнение ID при клике

При клике на строку игрока в AdminUsers его ID автоматом заполняется во все поля ввода (таймеры, деньги, работа, бан, премиум):

```typescript
const selectUser = (u: any) => {
    const id = String(u.id);
    setTimerUserId(id); setMoneyUserId(id); setFinishJobUserId(id);
    setPremiumUserId(id); setBanUserId(u.id);
};
```
Строки: `cursor-pointer`, `hover:bg-[var(--color-bg-hover)]`, `onClick={() => selectUser(u)}`.

### formatLastLogin: PG TIMESTAMPTZ → Date объект

PG-драйвер возвращает TIMESTAMPTZ колонки как `Date` объекты. Нужно обрабатывать `value instanceof Date` ДО `typeof value === 'number'`, иначе Date проходит как number (NaN) или строка.

### Admin panel: пагинация 10 + картинки в списках

Все списки в админке — 10 элементов на страницу. Паттерн:
```typescript
const [page, setPage] = useState(1);
const LIMIT = 10;
const totalPages = Math.ceil(items.length / LIMIT);
const pagedItems = items.slice((page - 1) * LIMIT, page * LIMIT);
```
Где есть изображения — показывать `<img>` в первом столбце таблицы (32×32 или 24×24). Применено: AdminItems, AdminUsers, AdminGame (mobs/actions/floors), AdminBots, AdminCollections. Battles/Feedback — серверный limit 10.

### HistoryPage: toMs() helper для смешанных timestamp

Сервер возвращает timestamp в разных форматах (INTEGER секунды, TIMESTAMPTZ строка). Хелпер для правильной конвертации в миллисекунды:
```typescript
const toMs = (v: any) => typeof v === 'number' ? v * 1000 : v ? new Date(v).getTime() : 0;
```
Использовать для entry mapping (`ts: toMs(...)`) и display time (`fmt(toMs(...))`). massacre: `gathering_end` (INTEGER сек) или `created_at` (строка). tournament: `completedAt` (строка) или `createdAt` (INTEGER сек). Без toMs сортировка ломается (строка * 1000 = NaN).

### BackButton — единый компонент

`client/src/components/BackButton.tsx` — кнопка `← Назад` (текстовая стрелка, без иконки). Используется на всех страницах единообразно. Второй вариант: `client/src/components/ui/BackButton.tsx` с пропом `to` для явного пути.

### VK хедер — единый для всех, без лишних отступов

Хедер использует ОДИНАКОВУЮ структуру без `isVK`-условий. VK-специфика только в CSS:

```css
html.vk-iframe { --vk-top-offset: env(safe-area-inset-top, 0px); }
html.vk-iframe #site-header {
  position: fixed !important; top: 0 !important; /* без padding-top */
}
html.vk-iframe #root { padding-top: calc(120px + var(--vk-top-offset)) !important; }
html.vk-iframe #right-sidebar-toggle { top: calc(115px + var(--vk-top-offset)) !important; }
html.vk-iframe #right-sidebar-panel {
  top: calc(120px + var(--vk-top-offset)) !important;
  height: calc(100vh - 120px - 40px - var(--vk-top-offset)) !important;
}
```

**НЕ добавлять `padding-top: 54px` на хедер** — создаёт пустую строку в VK. `--vk-top-offset` только для реального device inset (челка iPhone), не для VK-кнопок.

### VK кастомная клавиатура

- **Скрытие:** `▼ Скрыть` справа сверху, только она скрывает (тап вне — нет)
- **Enter:** на INPUT скрывает клавиатуру, на TEXTAREA — перенос строки
- **Центровка инпута:** при фокусе скролл чтобы инпут был по центру между хедером и клавиатурой/чатом

### AdminChat: клик по сообщению → ID в инпуты

При клике на строку сообщения в AdminChat её `senderId` заполняется в поле блокировки, а `messageId` — в поле удаления:
```typescript
onClick={() => { setBanUserId(String(m.senderId)); setDeleteId(String(m.id)); }}
```

### Admin panel: подписи над инпутами

Мелкие серые label над полями ввода в админке для ясности:
```tsx
<label className="text-[0.6rem] text-[var(--color-text-muted)]">ID игрока</label>
<input ... className={inputClass} />
```

### AdminGame mobs: сортировка по локации

Мобы в админке сортируются по полю `location`:
```typescript
const sorted = [...mobs].sort((a,b) => (a.location||'').localeCompare(b.location||''));
const mpItems = sorted.slice((page - 1) * LIMIT, page * LIMIT);
```

### formatLastLogin: обработка всех форматов (включая числовые строки)

PG-драйвер может возвращать TIMESTAMPTZ как строки/Date/числа. Нужно обрабатывать все варианты в порядке приоритета:
1. **Числовая строка** (`"1783235808"`) — `Number(value)`, если > `1000000000` → ×1000 → Date. Диагностика: `PGPASSWORD=... psql -c "SELECT pg_typeof(lastLoginAt) FROM users LIMIT 1"` → если `text` — база хранит Unix-секунды как текст.
2. **Date объект** — `value.getTime()` (PG-драйвер по умолчанию)
3. **ISO-строка** — `new Date(value)`

### VK кастомная клавиатура

- **Скрытие:** `▼ Скрыть` справа сверху, только она скрывает (тап вне — нет)
- **Enter:** на INPUT скрывает клавиатуру, на TEXTAREA — перенос строки
- **Центровка инпута:** при фокусе скролл чтобы инпут был по центру между хедером и клавиатурой/чатом

### Питфол: PvE шаги боя без поля `actor`

Клиентская анимация крита/атаки/уклонения в PvE (`BestiaryPage`) копирует логику PvP (`useBattleLogic`) — сторона анимации определяется через `step.actor === 'attacker' ? 'left' : 'right'`. Но серверный PvE бой (`routes/mobs.ts`) генерировал шаги БЕЗ поля `actor`. Результат: `step.actor === undefined` → все анимации на правой стороне (моб).

**Фикс:** в `routes/mobs.ts` добавить `actor` во ВСЕ шаги:
- Ход игрока: `actor: 'attacker'` (атака, крит, урон, уклон моба — `actor: 'defender'`)
- Ход моба: `actor: 'defender'` (атака, крит, урон, уклон игрока — `actor: 'attacker'`)

При добавлении новых механик в PvE бой — всегда добавлять `actor` в шаги.

### Питфол: camelRows и новые таблицы

При создании новых таблиц с колонками `created_at`/`updated_at` (snake_case), `camelRows()` преобразует их в `created_At`/`updated_At` (не `createdAt`/`updatedAt`). Клиентский код должен использовать оригинальные snake_case имена (`post.created_at`, `t.created_at`) для новых таблиц, пока конвертер не научится правильно обрабатывать `_at`/`_id` суффиксы.

Подвержены: `forum_threads`, `forum_posts`, любые новые таблицы с `_at`/`_id` колонками.

## Форум

См. `references/forum.md`. Темы, сообщения, ответы с цитированием, блок в Замке с последними 3 темами.

## Игорный дом / Казино

См. `references/casino.md`. Блэкджек и будущие азартные игры. Таблица `casino_games`, сервер `routes/casino.ts`, клиент `CasinoPage.tsx` с табами. Карточка в actions_config: section='castle', path='/casino'.

### Карточные игры — стилизация

Карты всегда с белым фоном (`bg-white`) и тёмным текстом — как настоящие игральные карты, читаемы в любой теме. Масти: красные `text-red-600`, чёрные `text-gray-900`. Статусы игры — через CSS-переменные (`--color-accent-success/danger/warning`) с фоном `--color-bg-input` для совместимости со светлой/тёмной темой. НЕ использовать хардкод-цвета типа `text-green-400 bg-green-900/30`.

## Радио-плеер (AudioPlayer)

Компонент `client/src/components/AudioPlayer.tsx` — браузерный `<audio>` для Icecast-потоков.
Используется в Header (верхний ряд, справа от часов).

**Паттерн:**
- `<audio>` элемент создаётся через `new Audio()` в useEffect, хранится в useRef
- Громкость: `audio.volume` + `<input type="range">`, сохраняется в `localStorage('radioVolume')`
- Ошибки: `audio.addEventListener('error', ...)` — показывать индикатор ошибки
- Поток: Icecast URL напрямую (без прокси), браузер сам обрабатывает

```tsx
const STREAM_URL = 'http://mediaserv73.live-streams.nl:18058/stream';
const [playing, setPlaying] = useState(false);
const [volume, setVolume] = useState(() => parseFloat(localStorage.getItem('radioVolume') || '0.5'));
const audioRef = useRef<HTMLAudioElement | null>(null);

useEffect(() => {
    const audio = new Audio();
    audio.preload = 'none';
    audio.volume = volume;
    audioRef.current = audio;
    return () => audio.pause();
}, []);

const togglePlay = () => {
    if (playing) { audioRef.current?.pause(); setPlaying(false); }
    else {
        audioRef.current!.src = STREAM_URL;
        audioRef.current!.play().catch(() => setError(true));
        setPlaying(true);
    }
};
```

## Профиль — статистика казино/резни/аукциона (2026-07-10)

В профиле игрока (`ProfilePage.tsx`, `routes/users.ts`) добавлены секции:
- ⚔️ Резня: участия + победы (COUNT из massacre_participants, выжил в completed)
- 📦 Аукцион: куплено/продано лотов (COUNT из auction_history)
- 🎰 Игорный дом: игр, выиграно/проиграно (колонки casino_games_played/won/lost в users)

Обновление статов казино: хелпер `getCasinoStatUpdate(status, bet, payout)` в `casino.ts` вызывается во всех 4 точках завершения игры (start/stand/double/surrender). casino_won — чистая прибыль, casino_lost — чистый убыток.

## Казна замка

Таблица `castle_treasury`, API `GET /api/treasury`, отображается в карточке «Замок» и на `/castle`.
Сгруппировано по userid+username, отсортировано по убыванию total. id0 отфильтрован (`AND l.userid > 0`).
Даты — ISO-строки (`createdat >= '2026-06-23T...'`), **НЕ** `to_timestamp()` (createdat — TEXT в PG).

### Питфол: FK + удаление пользователя

`forum_threads.author_id` и `forum_posts.author_id` → FK на `users(id)`. При `DELETE FROM users` — ошибка если есть темы/посты. **Решение:** FK с `ON DELETE SET NULL` + `LEFT JOIN` + `COALESCE(username, 'Пользователь удалён')` во всех форумных запросах.

```sql
ALTER TABLE forum_threads DROP CONSTRAINT forum_threads_author_id_fkey;
ALTER TABLE forum_threads ALTER COLUMN author_id DROP NOT NULL;
ALTER TABLE forum_threads ADD CONSTRAINT forum_threads_author_id_fkey FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL;
-- аналогично для forum_posts
```

**Все JOIN users в forum.ts должны быть LEFT JOIN** (не INNER), иначе темы/посты удалённых юзеров пропадают из выдачи.

### Питфол: VK Bridge Auth + сброшенный персонаж

`vkBridgeAuth.ts` удалял старого юзера через `DELETE FROM users` при обнаружении сброшенного персонажа. Если у юзера есть форум — FK не даст. **Решение:** `UPDATE SET level=1, currentHp=...` вместо DELETE.

**Автозагрузка при открытии вкладки:**
```tsx
useEffect(() => { if (tab === 2) loadTreasury(treasuryPeriod); }, [tab]);
```
Без этого история пустая, пока пользователь не кликнет по периоду.

Детали реализации: `references/treasury-period.md`.

## db.query с JOIN/булевыми условиями — использовать db.raw

`db.query()` применяет `pgLowerIdentifiers()` и `pgParams()` к SQL. Для запросов с JOIN и булевыми условиями (`= TRUE`) это может давать 0 строк без ошибок. Симптом: запрос возвращает `[]` при наличии данных, `db.raw` с тем же SQL — корректный результат.

**Фикс:** для SELECT с JOIN или `= TRUE / = FALSE` использовать `db.raw` с `$1`-плейсхолдерами:
```typescript
const raw = await db.raw(
    `SELECT mp.*, u.username FROM massacre_participants mp JOIN users u ON mp.user_id = u.id WHERE mp.event_id = $1 AND mp.alive = TRUE`,
    [eventId]
);
const participants = raw.rows as any[];
```

**Где применялось:** massacre battle (загрузка участников), потенциально любой JOIN-запрос.

## HistoryPage: фильтрованный таб — ТОЛЬКО через allEntries

При добавлении нового типа записей в сводку (HistoryPage) **НИКОГДА не использовать отдельный источник данных** для таба. Всегда фильтровать из `allEntries`:

```tsx
// ✅ ПРАВИЛЬНО — идентично тому что во вкладке «Все»
case 'massacre': return allEntries.filter(e => e.type === 'massacre');

// ❌ НЕПРАВИЛЬНО — отдельный массив без поля type, не сортирован
case 'massacre': return massacreEntries;
case 'massacre': return massacreBattles.map(...).sort(...);
```

**Симптом при ошибке:** таб показывает записи из другого типа (обычно privateMessages — иконка чата, розовый шрифт, двоеточие, дата «—»). Потому что renderEntry не находит `type` в объекте и рендерит как `type === 'message'`.

**Причина:** raw API-ответы не содержат поля `type`, а пагинация/сортировка могут работать иначе чем в `allEntries`. `allEntries` уже правильно собран и отсортирован — он единственный надёжный источник для табов.

## Отображение времени — локальный пояс пользователя

**Сервер всегда хранит/передаёт время в UTC** — не трогать.
**Клиент конвертирует в локальный пояс браузера при отображении.**

Файлы:
- `client/src/utils/date.ts` — `fmtSafeDate()`: `toLocaleString('ru-RU')` без `timeZone:'UTC'`
- `client/src/utils/time.ts` — `formatGameTime()` / `formatGameDateTime()`: `getHours()` вместо `getUTCHours()`
- `client/src/utils/time.ts` — `formatLastSeen(value)`: формат «сейчас», «X мин», «X ч.», «X дн.», «Xм», «X г.» для отображения последнего онлайна. Принимает Date, unix-секунды (number), числовую строку, ISO-строку. Используется в GuildPage/GuildViewPage для «Был в игре: N назад».

При добавлении новых форматов времени — всегда локальный пояс на клиенте, сервер не менять.

### Scroll lock — фикс для браузера

При открытии панелей (RightSidebar, чат) нельзя просто ставить `overflow: hidden` — страница прыгает наверх и хедер пропадает. Использовать `position: fixed` на body с сохранением/восстановлением скролла. Применено в `RightSidebar.tsx` и `ChatPanel.tsx`.

### Чат: drag-to-resize — onClick мешает

Заголовок чата используется и для перетаскивания (onMouseDown), и для сворачивания (onClick). После drag onClick закрывает панель. Фикс: `dragMovedRef`, в onClick `if (!dragMovedRef.current)`.

### Инвентарь — сворачивание

Клик по заголовку сворачивает/разворачивает. Стрелка: `▶`/`▼` (текстовые символы), не иконки. Свёрнуто — только заголовок + счётчик слотов. На широких экранах `overflow-hidden` на гриде слотов чтобы не вылезал.

При работе с файлами >500 строк патчи через `patch` ненадёжны:
- JSX-вложенность ломается, закрывающие теги теряются
- replace_all уничтожает файл при разных контекстах замены
- Результат: 4 попытки → 4 отката через git checkout

Безопасные способы:
1. **write_file** — полная перезапись (если файл чисто переписывается)
2. **heredoc через ssh** — только для простых скриптов без сложных кавычек
3. **sed -i** — для однострочных замен (импорты, отдельные строки)
4. **Node.js split script на VPS** — для сплита больших файлов (проверено: guild.ts)

## Real-time обновления через WebSocket (см. references/ws-events-pattern.md)

При рефакторинге проверять:
- `from '../websocket'` → должен быть `from '../events'` (EventBus миграция)
- `async function(): any | null` → `Promise<any>` (TS требует Promise)
- `collCnt?.cnt` на number → уже не объект, `.cnt` не нужен
- `require('../websocket')` в поддиректориях → битый путь, заменить на статический импорт
