# WebSocket → HTTP Polling Migration Recipe

## When to use
- Server OOMs from WS overhead (heartbeat + serverTick + per-connection state)
- VPS < 1GB RAM is the constraint
- Client can tolerate 2-5 second update latency

## Server Changes

### 1. Add REST chat endpoints (`server/src/routes/chat.ts`)
```typescript
// POST /api/chat/send — send public/private/item-link messages
router.post('/chat/send', async (req, res) => {
    const { type, content, targetUserId, itemId, itemData } = req.body;
    // ... insert into chat_messages, return message object
});
```

### 2. Add online users endpoint (`server/src/routes/users.ts`)
```typescript
router.get('/users/online', async (req, res) => {
    const cutoff = Math.floor(Date.now() / 1000) - 300;
    const users = await db.query(
        'SELECT id, username, level FROM users WHERE lastAction > $1 LIMIT 50',
        [cutoff]
    );
    res.json(users);
});
```

### 3. Update lastAction in auth middleware
```typescript
// In auth middleware, after JWT verification:
db.run('UPDATE users SET lastAction = $1 WHERE id = $2', [now, userId]).catch(() => {});
```

### 4. Add lastAction column if missing
```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS lastAction INTEGER DEFAULT 0;
```

### 5. Disable WebSocket in index.ts
```typescript
// import { setupWebSocket } from './websocket';  // disabled
// setupWebSocket(server);                        // disabled
```

## Client Changes (`ChatContext.tsx`)

Replace WebSocket with polling:

```typescript
// Poll intervals
const CHAT_POLL_MS = 3000;     // messages every 3s
const ONLINE_POLL_MS = 10000;  // online users every 10s
const BALANCE_POLL_MS = 5000;  // money/bank every 5s

// Chat polling
useEffect(() => {
    const poll = async () => {
        const res = await fetch('/api/chat/recent?limit=50', { headers: getHeaders() });
        const data = await res.json();
        // deduplicate by id, merge into state
    };
    poll();
    const interval = setInterval(poll, CHAT_POLL_MS);
    return () => clearInterval(interval);
}, [token]);

// Send messages via POST
const sendPublic = (content: string) => {
    fetch('/api/chat/send', {
        method: 'POST',
        headers: { ...getHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'public', content }),
    });
};
```

## Common Pitfalls
- **API returns error object instead of array**: guard with `Array.isArray(data) ? data : []`
- **`/api/users/online` 404**: route must be registered BEFORE `export default router`
- **Auth middleware blocks polling**: use `getHeaders()` which includes Bearer token
- **Memory still grows if polling too aggressive**: 3s/5s/10s intervals are safe; don't poll every 1s
