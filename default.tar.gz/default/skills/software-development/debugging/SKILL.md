---
name: debugging
description: "Language-specific debugging guides: Node.js (--inspect, CDP) and Python (pdb, debugpy, remote-pdb)."
version: 1.0.0
author: Hermes Agent (consolidated from node-inspect-debugger + python-debugpy)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [debugging, nodejs, python, pdb, debugpy, cdp, breakpoints]
    related_skills: [systematic-debugging]
---

# Debugging Guides

Language-specific interactive debugging. For general debugging methodology (root-cause analysis, hypothesis testing), see `systematic-debugging`.

---

## Section 1: Node.js Debugging

### Quick Start: `node inspect` REPL

```bash
node inspect path/to/script.js
# or with tsx
node --inspect-brk $(which tsx) path/to/script.ts
```

The `debug>` prompt accepts these commands:

| Command | Action |
|---|---|
| `c` / `cont` | continue |
| `n` / `next` | step over |
| `s` / `step` | step into |
| `o` / `out` | step out |
| `sb('file.js', 42)` | set breakpoint |
| `sb('funcName')` | break on function |
| `bt` | backtrace (call stack) |
| `list(5)` | show 5 lines around current position |
| `repl` | drop into REPL in current scope (Ctrl+C to exit) |
| `exec expr` | evaluate expression once |

### Attaching to Running Process

```bash
kill -SIGUSR1 <pid>         # enable inspector on running process
node inspect -p <pid>        # attach debugger CLI
```

### Starting with Inspector

```bash
node --inspect script.js           # listen on 127.0.0.1:9229, keep running
node --inspect-brk script.js       # listen AND pause on first line
node --inspect=0.0.0.0:9230 script.js  # custom host:port
```

### Programmatic CDP (automation)

```javascript
const CDP = require('chrome-remote-interface');
const client = await CDP({ port: 9229 });
const { Debugger, Runtime } = client;

Debugger.paused(async ({ callFrames }) => {
  const top = callFrames[0];
  // Walk scopes for locals
  for (const scope of top.scopeChain) {
    const { result } = await Runtime.getProperties({ objectId: scope.object.objectId });
    // ... inspect variables
  }
  await Debugger.resume();
});
// Set breakpoints, then: await Runtime.runIfWaitingForDebugger();
```

### Common Pitfalls
- **`write_file` mangles `!` in identifiers** — `process.env.JWT_SECRET!` becomes `proces...CRET` with literal `...`. Workaround: use `patch` with sed-escape or write via `terminal` heredoc instead. Always verify file content with `xxd` or `md5sum` before deploying.
- **`async` function without `await` returns `Promise<T>` not `T`** — `const x = asyncFn()` gives `[object Promise]`, arithmetic like `x/2` produces `NaN`, comparisons silently fail. Always either `await asyncFn()` or remove `async` from the declaration.
- **`async` in boolean conditions is ALWAYS truthy** — `if (asyncFn())` where `asyncFn` returns `Promise<boolean>` is ALWAYS true regardless of the return value, because Promise objects are truthy. Common symptom: validation that should let some requests through instead rejects ALL requests with 400. Fix: remove `async` from the function (if no `await` in body) or `await` the call.
- **Wrong line numbers in TS source** — breakpoints hit emitted JS. Use `--enable-source-maps` or break in `dist/*.js`.
- **`--inspect` vs `--inspect-brk`** — without `-brk`, script races past breakpoints before attach.
- **Child processes** — `--inspect` on parent does NOT inspect children. Use `NODE_OPTIONS='--inspect-brk'`.
- **`node inspect` needs PTY** — launch with `terminal(pty=true)` for interactive stepping.

### Heap / OOM Analysis

For production crashes with `FatalProcessOutOfMemory`.

**Read GC stats from PM2 error log:**
```bash
pm2 logs game-server --err --lines 30 --nostream | grep -A5 'Last few GCs'
```
Key metric: **mu** (marked/used ratio). `mu = 0.98` = severe leak (nothing freed). `mu = 0.12` = objects freed but allocation rate outruns GC.

**Binary-search leak source** by testing incremental module loads:
```
Express + middleware → Express + routes → +WS (no conn) → +WS+user → +serverTick
```
Each test with `--max-old-space-size=128`, monitor PM2 for restarts over 3 min.

**Prevent promise pile-up** with per-user lock in `setInterval`:
```typescript
const lock = new Set();
if (lock.has(userId)) return; lock.add(userId);
try { /* work */ } finally { lock.delete(userId); }
```

**DB query timeout** prevents hung queries from blocking ticks:
```typescript
const result = await Promise.race([
  db.one('SELECT ...', [id]),
  new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 2000)),
]);
```

**Check available heap:**
```bash
node --max-old-space-size=512 -e "console.log(require('v8').getHeapStatistics().heap_size_limit/1024/1024+'MB')"
```

### Migrate to Bun for OOM Relief

When Node+tsx exceeds available RAM (~400MB baseline on a 955MB VPS), **Bun** cuts memory ~40% by running TypeScript natively (no tsx overhead):

```bash
# Install
curl -fsSL https://bun.sh/install | bash  # requires unzip
export PATH=$HOME/.bun/bin:$PATH

# Run (native TS, no tsx needed)
bun run server/src/index.ts

# PM2 config
pm2 start "PORT=3001 bun run server/src/index.ts" --name game-server --max-memory-restart 400M
```

**Before/after comparison** (955MB VPS, 50+ TS files):
| Metric | Node+tsx | Bun |
|---|---|---|
| Startup RSS | 150-180MB | 97MB |
| After warmup | 250-400MB | 165-200MB |
| Available RAM | 50-100MB | 400-550MB |
| API latency | 3-5ms | 1-2ms |

**Gotcha**: `bun run build` with Vite may hang. Use `npx vite build` for client builds (Bun for server runtime only).

### When Swap Thrashing Masks Real Performance

Symptom: API responds 2-5ms in isolated tests but user sees 20s+ page loads with 96 requests.
Root cause: server RSS exceeds free RAM → kernel swaps → every request waits on disk I/O (16%+ iowait).
Check: `free -h` — if `available < 100MB` and `Swap used > 200MB`, server is swapping regardless of heap limit.
Fix: reduce baseline RSS (Bun migration, disable WS, remove rate-limit) OR increase VPS RAM.

### WebSocket → HTTP Polling When WS Is Too Heavy

On RAM-constrained VPS, WebSocket server (heartbeat + per-connection state + serverTick) can push RSS over limit. Replace with HTTP polling:

**Server side**: Add REST endpoints for chat send, recent messages, online users. Update `lastAction` on each auth'd request for online tracking.
**Client side**: Replace `WebSocket` with `setInterval` polling (chat: 3s, online: 10s, balance: 5s). Use `fetch()` with `getHeaders()` for auth.
**Critical**: Ensure response handling guards against non-array data (`data.lots` might be `{error:"..."}`) — use `Array.isArray(data.lots) ? data.lots : []`.

### write_file Mangles `!` in Identifiers

`write_file` converts `process.env.JWT_SECRET!` into `proces...CRET` (literal `...`). Workaround: use `patch` for single-line fixes, or write via `terminal` heredoc + `scp`. Always verify with `xxd file.ts | head` after writing.

---

## Section 2: Python Debugging

### Tool Selection

| Tool | When |
|---|---|
| `breakpoint()` + pdb | Local, interactive, simplest |
| `python -m pdb` | Launch script under debugger, no source edits |
| `debugpy` | Remote/headless/attach to running process |
| `remote-pdb` | Agent-friendly remote REPL via netcat |

**Start with `breakpoint()`.** It's the cheapest thing that works.

### pdb Quick Reference

| Command | Action |
|---|---|
| `n` | next line (step over) |
| `s` | step into |
| `c` | continue |
| `w` | where (stack trace) |
| `u` / `d` | move up/down stack |
| `p expr` / `pp expr` | print / pretty-print |
| `b file:line` | set breakpoint |
| `b func` | break on function entry |
| `!stmt` | execute arbitrary Python |
| `interact` | drop into full Python REPL |
| `q` | quit |

### Recipe: Local Breakpoint

```python
def compute(x, y):
    result = some_helper(x)
    breakpoint()  # drops into pdb here
    return result + y
```

### Recipe: Debug a pytest Test

```bash
scripts/run_tests.sh tests/test_file.py::test_name --pdb -p no:xdist
# -p no:xdist REQUIRED — pdb does NOT work under xdist
```

### Recipe: Remote Debug with debugpy

```python
# In your code (process waits for debugger):
import debugpy
debugpy.listen(("127.0.0.1", 5678))
debugpy.wait_for_client()
debugpy.breakpoint()  # pause when attached

# Launch with debugpy (no source edits):
python -m debugpy --listen 127.0.0.1:5678 --wait-for-client your_script.py

# Attach to running process:
python -m debugpy --listen 127.0.0.1:5678 --pid <pid>
```

### Recipe: remote-pdb (Agent-Friendly)

```python
from remote_pdb import set_trace
set_trace(host="127.0.0.1", port=4444)  # blocks until connection
```

Then from another terminal: `nc 127.0.0.1 4444` — get a full `(Pdb)` prompt.

`remote-pdb` is the cleanest choice when `debugpy`'s DAP protocol is overkill.

### Common Pitfalls
- **pdb under pytest-xdist silently does nothing** — always use `-p no:xdist`.
- **`breakpoint()` in CI** — `PYTHONBREAKPOINT=0` disables all breakpoints. Check env if breakpoint isn't hitting.
- **`debugpy.listen` doesn't block** — also call `wait_for_client()` or execution races past.
- **Threads** — pdb only debugs current thread. Use debugpy for multithreaded code.
- **`scripts/run_tests.sh` strips credentials** — debug with raw `pytest` first to repro.
