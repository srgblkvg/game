"""
{TEMPLATE_NAME} — {RARITY} {SLOT}
{brief_description}
"""
import bpy
import math
import sys
sys.path.append('/mnt/c/project/game/models')
from dark_fantasy_style import make_material, setup_scene, center_and_export, COLORS

setup_scene()

# ── Materials ──
mat_primary = make_material("PrimaryMat", COLORS["rust_iron"], roughness=0.85, metallic=0.0)

# ── Geometry ──
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))
obj = bpy.context.object
obj.name = "MainMesh"
obj.data.materials.append(mat_primary)

# ── Modify vertices in OBJECT mode ──
# for v in obj.data.vertices:
#     if condition: v.co.x *= modifier

# ── Add details ──

# ── Finalize ──
center_and_export('/mnt/c/project/game/models/output/{filename}.blend')
# export_glb('/mnt/c/project/game/models/output/{filename}.glb')  # needs numpy

print("DONE: {TEMPLATE_NAME}")
