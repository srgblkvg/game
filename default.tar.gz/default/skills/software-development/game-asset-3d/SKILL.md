---
name: game-asset-3d
description: Generate game 3D assets in Blender via Python scripts.
---

# Game Asset 3D Modeling

Blender Python pipeline for generating batches of themed game assets with consistent style.

## Trigger

Use when the user asks to create 3D models for a game — equipment, props,
environment pieces — especially in batches with a shared art style.

See also: `references/dark-fantasy-pipeline.md` (MMO Arena specifics),
`templates/item_script.py` (starter script).

## Workflow

### 1. Establish style (one-time)
Create a shared `style_module.py` with:
- Color palette as a dict
- `make_material(name, color, roughness, metallic)` — PBR material factory
- `setup_scene()` — camera, lighting, world background
- `center_and_export(filepath)` — origin + save
- `export_glb(filepath)` — GLB for web (requires numpy)

### 2. Generate items (one script per item or batch)
Each script:
- Imports the shared style module
- Builds geometry from primitives + modifiers
- Applies materials from the style palette
- Saves `.blend` and optionally `.glb`

### 3. Render previews
Load each `.blend`, set active camera, render with EEVEE at 512x512.

## Project layout

```
models/
├── dark_fantasy_style.py    # shared style module
├── make_helmet.py           # one per item
├── make_sword.py
├── render_previews.py       # batch render
└── output/
    ├── *.blend
    ├── *.glb
    └── preview_*.png
```

## Materials pattern

```python
COLORS = {
    "rust_iron":  (0.18, 0.10, 0.06, 1.0),
    "old_bone":   (0.55, 0.50, 0.40, 1.0),
    "rotten_wood":(0.15, 0.10, 0.05, 1.0),
}

def make_material(name, color, roughness=0.85, metallic=0.0):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
    bsdf.inputs['Base Color'].default_value = color
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic
    out = nodes.new(type='ShaderNodeOutputMaterial')
    mat.node_tree.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    return mat
```

## Build order

Start from lowest rarity (junk, then common, etc.) — establishes the
style on simple models before tackling complex ones.

## Pitfalls

- `origin_set` center='BOTTOM' doesn't exist in Blender 5.0 — use 'MEDIAN'
- EEVEE engine is 'BLENDER_EEVEE', not 'BLENDER_EEVEE_NEXT' (version-dependent)
- GLB export requires `numpy` — install with `sudo apt install python3-numpy`
- WSLg GUI requires `WAYLAND_DISPLAY= GALLIUM_DRIVER=llvmpipe blender`
- `bpy` only exists inside Blender's Python; Pyright will flag it as unresolved — ignore
- Item type hints (weapon/shield/armor/jewelry) come from the game's `slot` field in seed data
