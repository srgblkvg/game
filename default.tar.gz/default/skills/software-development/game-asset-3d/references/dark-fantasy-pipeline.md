# Dark Fantasy Equipment Pipeline

Specifics for the MMO Arena dark fantasy equipment modeling pipeline.

## Project paths

```
/mnt/c/project/game/models/
├── dark_fantasy_style.py     # shared style module
├── make_hod.py               # Скорбный капюшон (helmet)
├── make_sword.py             # Стон могильщика (weapon)
├── make_shield.py            # Гробовая преграда (shield)
├── render_previews.py        # batch renderer
└── output/                   # generated .blend + .png files
```

## Color palette (junk tier)

```python
COLORS = {
    "rust_iron":      (0.18, 0.10, 0.06, 1.0),   # dark rusty metal
    "old_bone":       (0.55, 0.50, 0.40, 1.0),   # aged bone
    "rotten_wood":    (0.15, 0.10, 0.05, 1.0),   # dark decayed wood
    "torn_cloth":     (0.20, 0.18, 0.15, 1.0),   # dirty gray cloth
    "dried_blood":    (0.25, 0.05, 0.03, 1.0),   # dark dried blood
    "tarnished_iron": (0.25, 0.22, 0.18, 1.0),   # dull tarnished metal
    "grave_dirt":     (0.12, 0.09, 0.06, 1.0),   # grave soil
}
```

## Scene setup

- Camera: position (0, -3, 1.5), rotation (75°, 0, 0)
- Sun light: position (5, -5, 8), pale sickly color (0.9, 0.85, 0.7), energy 3
- Fill light: position (-3, -2, 1), cold purple (0.4, 0.3, 0.5), energy 50
- World: near-black void (0.02, 0.02, 0.03)

## Slot → item type mapping

From seed.ts slots:
- `helmet` → hoods, masks, crowns
- `chest` → armor, cuirass
- `gloves` → gauntlets, claws
- `boots` → boots, greaves
- `weapon1` → swords, scythes, blades
- `shield` → shields, barriers
- `amulet` → pendants, talismans
- `ring` → rings, bands
- `belt` → belts, sashes

## Rarity build order

Always start from junk (0) and work upward. Junk items are:
- Simple geometry (few primitives)
- Worn/damaged look (tears, chips, rust)
- Low poly count for browser

## Blender 5.0 quirks

- `bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')` — 'BOTTOM' removed
- Render engine: `'BLENDER_EEVEE'` (not `'BLENDER_EEVEE_NEXT'`)
- WSLg GUI: `WAYLAND_DISPLAY= GALLIUM_DRIVER=llvmpipe blender`
- GLB export needs `sudo apt install python3-numpy`
