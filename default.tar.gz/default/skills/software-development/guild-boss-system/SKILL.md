---
name: guild-boss-system
description: "Use for guild boss, talents, ratings, or boss battle UI."
---

# Гильд-босс — система

## Архитектура

```
server/src/game/guildBoss.ts      — логика (статы, эффекты, таланты)
server/src/routes/guildBoss.ts    — эндпоинты
server/src/db/migrations/         — guildBosses.sql, guildBossBattles.sql
client/src/pages/GuildPage.tsx    — вкладки Босс/Таланты
client/src/components/QuestsBlock.tsx — босс в сайдбаре
```

## Важные правила

1. **Роуты босса ДО guildRoutes**: `guildBossRoutes` регистрируется перед `guildRoutes` в setupRoutes.ts, иначе `/guild/:id` перехватывает `/guild/boss`.
2. **Таланты в отдельном табе**: вкладка «🌟 Таланты» (tab=5), не внутри вкладки Босс.
3. **Два блока талантов**: личные и гильдийские, сетка `grid-cols-2`, прогресс-бар, вклад по 1 очку.
4. **Гильдийские таланты**: только лидер может вкладывать очки.
5. **Иконки статов**: `game-icons:biceps` (S), `game-icons:sprint` (A), `game-icons:shield` (D), `game-icons:crossed-swords` (M).
6. **Босс в сайдбаре**: QuestsBlock, секция «Босс:» под гильд-квестом, HP-бар `h-1`, таймер/«Атаковать» снизу. Переход `/guild?tab=4`.
7. **Респаун**: 5 минут (`BOSS_RESPAWN_DELAY=300`), `respawnAt` в БД и WS.
8. **Название**: «Кровавый исполин».
9. **Описания без сленга**: «Побеждён N раз», «Атака доступна раз в час».
10. **Числа через formatNum()**: HP, урон, рейтинги → 100K, 1.5M. Серебро через formatMoney().
11. **Бой на максимальном HP**: как турнир — бой с `userStats.hp`, текущее HP не сохраняется. Без регенерации перед боем.
12. **Авто-появление в сайдбаре**: после убийства `setTimeout(300000)` для повторного fetch босса.
13. **Еженедельный сброс по средам**: cronjob сбрасывает killCount, currentHp, историю боёв, таймеры атак. Очки талантов сохраняются.

## API

- `GET /guild/boss` — босс, кулдаун, таланты
- `POST /guild/boss/attack` — атака
- `GET /guild/boss/battles` — история атак
- `GET /guild/boss/ratings` — 5 рейтингов (guildTop, personalTop, guildTopList, topHits, topGuildKills)
- `GET /guild/talents` — таланты
- `POST /guild/talents/upgrade` — вклад 1 очка (scope: personal|guild)

## WS

- `guild_boss_update` — HP босса, респаун, гильд-очки, `ratingsChanged`
- `guildBossUpdate` CustomEvent на клиенте → обновление HP, очков, рейтингов

## Pitfalls

### Таланты: проценты стакаются в бою, но отображаются раздельно

В бою эффект талантов суммируется: `getTalentBonus()` = `(playerLevel + guildLevel) * TALENT_EFFECT_PER_LEVEL`. Но в UI личные и гильдийские таланты должны показывать **раздельные** проценты:

```tsx
// ❌ WRONG — оба таба показывают сумму
<span>{t.playerLevel + t.guildLevel}%</span>

// ✅ CORRECT — личные показывают playerLevel, гильдийские — guildLevel
// Личные таланты: <span>{t.playerLevel}%</span>
// Гильдийские таланты: <span>{t.guildLevel}%</span>
```

Без этого оба таба показывают одинаковое число (сумму), и игрок не видит вклад каждого уровня отдельно.

### Неиспользуемые переменные после удаления клиентского таймера

При переходе на WS-оповещения о респауне босса (`a379ca69`) убран клиентский таймер, но стейты `respawnTimer`/`setRespawnTimer` могли остаться. TypeScript билда упадёт с `TS6133`. Удалять.

Аналогично `canTalents` — если объявлен но не используется в рендеринге, удалять.

Тест-аккаунты: Oz777zy(28), TODD(314), Некрохирург(1), Боба(35).
JWT через: `node -e "jwt.sign({userId,role:'player',username},JWT_SECRET,{expiresIn:'1h'})"`.
Не использовать Sallarik(131).
