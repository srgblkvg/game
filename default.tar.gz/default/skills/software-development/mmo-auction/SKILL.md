---
name: mmo-auction
description: Auction lots, price chart, grouping, limits, upgrade stones.
---

# MMO Auction

Auction system for MMO Arena: listing, bidding, buyout, price history charts, grouping by upgrade level.

## Key Files

- Server: `server/src/routes/auction.ts`
- Client: `client/src/pages/AuctionPage.tsx`, `client/src/utils/itemUtils.ts`

## Auction Lot Limits

- Base: 10 lots per player
- Premium: 20 lots
- Server check: `auction.ts` sell endpoint uses `premiumUntil > now` to determine limit
- Client: `maxSlots = character?.premium ? 20 : 10`

## Price History Chart

Chart.js with `react-chartjs-2`. Lightweight, proven.

### Backend endpoint: `GET /api/auction/price-history`

Params: `name`, `slot`, `rarity`, `upgradeLevel`

Groups `auction_history` by day (30 days), returns `avg_price`, `min_price`, `max_price`, `count` per day.

**Pitfall**: `itemData::jsonb->>'slot' = ''` does NOT match NULL. Use `COALESCE(itemData::jsonb->>'slot', '') = ?` for items without slot (materials, runes).

**Pitfall**: `p.day` from `DATE(createdAt::timestamp)` returns full ISO timestamp `2026-07-31T00:00:00.000Z`. Always `p.day.slice(0, 10)` before parsing.

### Client: PriceChart component

Lazy-loads on click. Uses `itemKey = name|slot|rarity_id|upgradeLevel` to detect item changes and reset cache via `useEffect`.

Chart config:
- Labels: `DD.MM` format from `p.day.slice(0, 10).split('-')`
- Y-axis: compact `1.5k`/`2.3M` using thresholds, NOT `formatMoney`
- 3 datasets: avg (yellow fill), min (green dash), max (red dash)
- Height: 120px

## Upgrade Level Grouping

Items with different `upgradeLevel` are SEPARATE auction groups. Affects:

1. **Group key**: `name|slot|rarity_id|upgradeLevel` (was: `name|slot|rarity_id`)
2. **Price history**: includes `upgradeLevel` in WHERE clause and as query param
3. **Similar lots**: filters by `upgradeLevel`
4. **Display**: `+N` badge on images and in names across all views

## Rune/Stone Display

Upgrade stones have `type: 'craft_item'` (for stacking) and `itemType: 'upgrade'` (for display).

**Pitfall**: `getItemImage` must check BOTH `item?.type === 'upgrade'` AND `item?.itemType === 'upgrade'` to show stone icon instead of fragment.

**Pitfall**: Stone drops must include `rarity_display` and `rarity_color` from rarities table (was NULL). Query: `JOIN rarities r ON c.rarity_id = r.id`.

**Pitfall**: Existing stones may have wrong rarity data. Character endpoint validates against DB on every load (batched by craft item IDs). Client fallback: `getRarityDisplay()` from `rarity_id` if `rarity_display` is null.

## Premium Description

`client/src/pages/PremiumPage.tsx` — `📦 +10 слотов аукциона (всего 20)`
