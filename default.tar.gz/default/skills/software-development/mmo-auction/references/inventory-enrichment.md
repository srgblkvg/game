# Inventory Enrichment Pattern

`server/src/routes/character.ts` enriches inventory items with DB-authoritative data.

## Craft Items (batched)

```ts
// Collect unique craft item IDs
const craftIds = [...new Set(
  inventory.filter((i: any) => i.type === 'craft_item' || i.type === 'material')
    .map((i: any) => Number(i.id))
)];

// Single query for all craft data
const craftRows = await db.query(
  `SELECT c.id, c.rarity_id, c.type, c.image, r.display_name as rarity_display, r.color as rarity_color
   FROM craft_items c JOIN rarities r ON c.rarity_id = r.id
   WHERE c.id IN (${craftIds.join(',')})`, []
);
const craftDataMap = {};
for (const row of craftRows) craftDataMap[row.id] = row;
```

## Why Always Validate

Stones dropped before the rarity fix have `rarity_display: "Хлам"` despite correct `rarity_id`. The fix checks:
```ts
const needsUpdate = item.rarity_id === undefined || !item.image
    || item.rarity_display !== craftRow.rarity_display
    || item.rarity_color !== craftRow.rarity_color;
```

This catches mismatched data on every character load without extra queries for items that are already correct.
