---
name: mmo-curse-system
description: Curse system (Soul Crystal) — ranks, two-step flow, code, pitfalls.
---

# Curse System (Soul Crystal / Проклятие)

Uses existing Soul Crystal (craft_items id=23, type='soul_crystal', rarity_id=6) that drops from Hell I-III bosses.

## Flow (two-step) — updated 2026-08-01

1. Place equipment item + Soul Crystal in craft bench (CraftPage)
2. Click «☠ Проклясть» → `POST /craft/curse` — **списывает 100k + кристалл**, сохраняет в БД, возвращает результат
3. If no old curse → auto-applies via `POST /craft/curse/apply` (просто обновляет curse-поля, без списаний)
4. If old curse exists → dialog shows old vs new, player chooses «Заменить» / «Оставить»
5. Кнопки «Оставить»/«Заменить» — без цены. Ресурсы уже списаны на шаге 2. `keepOld: true` оставляет старое проклятие, `keepOld: false` — применяет новое. Закрытие диалога по клику вне — отключено (иначе игрок теряет оплаченный результат).

## Ranks (current: 2026-07-31)

| Rank | Color | Range | Weight | % |
|------|-------|-------|--------|---|
| I | #22c55e (green) | 10–20 | 160 | 80% |
| II | #3b82f6 (blue) | 20–30 | 24 | 12% |
| III | #a855f7 (purple) | 30–40 | 12 | 6% |
| IV | #f97316 (orange) | 40–50 | 3 | 1.5% |
| V | #ef4444 (red) | 50–60 | 1 | 0.5% |

Random stat: S/A/D/M (equal probability). Not scaled by upgradeLevel.

## Code locations

- **Server endpoints:** `routes/craft.ts` → `POST /craft/curse` (списание + превью), `POST /craft/curse/apply` (применение, без списаний)
- **Rank config:** `CURSE_RANKS` in `routes/craft.ts`
- **Stat calculation:** `game/stats.ts` → `currentStats()` — curse added to sums (NOT scaled by upgradeLevel)
- **GameItem interface:** `game/stats.ts` → fields `curseStat`, `curseValue`, `curseRank`, `curseName`, `curseColor`
- **Client UI:** `CraftPage.tsx` → curse button (purple `#7c3aed`) + info block + confirm dialog
- **Tooltip:** `ItemStats.tsx` → shows «☠ Проклятие N: +X к Стат» with rank color
- **Mob drops:** `MYTHIC_RESOURCE_DROPS` in `routes/mobs.ts` — mobs 49 (Инкуб-искуситель) and 54 (Падший серафим)
- **Inventory grouping:** `Inventory.tsx` → `soul_crystal: 'Улучшение'`
- **Type display:** `itemUtils.ts` → `typeNameRu: { soul_crystal: 'Улучшение' }`

## Pitfalls

- **Old-type crystals:** crystals dropped before 2026-07-31 had `itemType: 'material'` or `itemType: 'craft'`. Must fix DB: `UPDATE craft_items SET type = 'soul_crystal' WHERE id = 23;` and fix existing inventory items via Node.js script.
- **Duplicate DB entries:** check for duplicate craft_items rows (id=23 vs id=25).
- **Curse not scaled:** `curseValue` added directly, NOT multiplied by `upgradeLevel`.
- **Button styling:** use solid `#7c3aed` not CSS variable (unreadable in light theme).
- **Money check:** client checks `character.money >= 100000` before enabling button.
- **isCraftItem check:** checks `item.type`, not `item.itemType`. Crystal has `type: 'craft_item'` → passes. The slot filter allows `itemType === 'soul_crystal'`.
- **itemIdx после splice:** в `/curse/apply` СНАЧАЛА сохранить `const item = { ...inventory[itemIdx] }`, ПОТОМ splice кристалла. Если `crystalIdx < itemIdx`, splice сдвигает массив и `inventory[itemIdx]` указывает на другой предмет — порча данных (левая редкость/слот).
- **findIndex с !isCraftItem пропускает крафтовые:** если порча скопировала `type: 'craft_item'`, то `findIndex(i => i.id === itemId && !isCraftItem(i))` возвращает -1. `inventory[-1] = item` — silent no-op (JSON.stringify игнорирует отрицательные ключи). Предмет остаётся на месте с неполными данными.
- **Recovery:** при массовой порче — скрипт обхода всех инвентарей, поиск предметов с curseStat без slot/name/bonuses, удаление + бэкап. См. `references/corruption-cleanup.md`.

## Donate packs

Сундуки с кристаллами душ продаются через YooKassa/VK Payments:
- `curse_small`: 500k + 5 кристаллов (999₽ / 144 голоса)
- `curse_large`: 1M + 10 кристаллов (1799₽ / 258 голосов)

Код: `routes/donate.ts` → `deliverCursePack()`, товары в `yukassa.ts:ITEMS` и `vkPayments.ts:ITEMS`.
Клиент: `CraftPage.tsx` → `CraftPacks` с `curse: true` флагом.
