# Atomic Status Update Pattern (Race Condition Prevention)

**Problem:** When processing "claim" or "complete" actions, checking status THEN updating it leaves a race condition window. Multiple concurrent requests all pass the check, then all update — giving duplicate rewards.

**Classic example:** Quest claim endpoint:
```
1. SELECT status FROM quests WHERE id = ?  → 'active'
2. If status !== 'active' → error
3. Compute reward, give money/XP
4. UPDATE quests SET status = 'claimed'
```
Between steps 1 and 4, another request also sees 'active' and also gives rewards.

**Fix: Atomic UPDATE with WHERE clause, check affected rows BEFORE giving reward:**
```typescript
// Step 1: Atomic claim — only one request succeeds
const result = await db.run(
  "UPDATE daily_quests SET status = 'claimed' WHERE id = ? AND status = 'active'",
  [questId]
);
if (result.changes === 0) {
  return res.status(400).json({ error: 'Already claimed' });
}
// Step 2: Only NOW give rewards — guaranteed single execution
await db.run('UPDATE users SET money = money + ?', [reward]);
```

**Applies to:** quest claim, guild quest claim, any "take/claim/complete" action where rewards are given.

**Client-side defense:** Always add a `useRef` guard to prevent double-clicks:
```typescript
const claimingRef = useRef(false);
const handleClaim = async (id) => {
  if (claimingRef.current) return;
  claimingRef.current = true;
  try { await api('/claim', { id }); }
  finally { claimingRef.current = false; }
};
```

**Files fixed with this pattern (2026-07-31):**
- `server/src/routes/quests.ts` → `/tavern/quests/claim`
- `server/src/routes/guild/guildQuests.ts` → `/guild/quest/claim`
