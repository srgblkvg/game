# Corruption Cleanup (Проклятие)

Когда баг `itemIdx после splice` портит предметы в инвентарях, нужна массовая чистка.

## Типы порчи

| Признак | Причина |
|---------|---------|
| `curseStat` + нет `slot`/`name`/`bonuses` | В `itemIdx` попал не-экипировочный предмет |
| `curseStat` + `type: 'craft_item'` | В `itemIdx` попал крафтовый предмет, экипировка затёрта |
| `id` отсутствует в `craft_items` | Призрак от удалённого дубликата в БД |
| `type: 'craft_item'` + поля `slot`/`bonuses`/`extra` | Экипировка затёрта крафтом, остались лишние поля |

## Скрипт поиска битых предметов

```sql
-- Предметы с curseStat но без слота
SELECT u.id, jsonb_pretty(elem)
FROM users u, jsonb_array_elements(u.inventory::jsonb) elem
WHERE elem->>'curseStat' IS NOT NULL
  AND (elem->>'slot' IS NULL OR elem->>'name' IS NULL);

-- Крафтовые предметы с невалидным id
SELECT u.id, elem->>'name', elem->>'id'
FROM users u, jsonb_array_elements(u.inventory::jsonb) elem
WHERE elem->>'type' = 'craft_item'
  AND (elem->>'id')::int NOT IN (SELECT id FROM craft_items);
```

## Процедура восстановления

1. **Бэкап:** `SELECT id, inventory FROM users WHERE id IN (...)` — сохранить в JSON
2. **Удаление:** `inventory.splice(idx, 1)` для битых, `UPDATE users SET inventory = ?`
3. **Компенсация:** положить замену на склад аукциона через `addToOverflow(uid, item)`
4. **Серебро:** `UPDATE users SET overflowmoney = COALESCE(overflowmoney, 0) + N`

## Пример скрипта компенсации

```ts
import { db } from '../db/index';
import { addToOverflow } from '../routes/overflow';

const item = {
    id: Date.now() + Math.random(),
    name: '...',
    slot: '...',
    rarity_id: 6,
    rarity_display: 'Мифический',
    rarity_color: '#e74c3c',
    bonuses: { s: 0, a: 0, d: 0, m: 0 },
    extra: { ... },
    upgradeLevel: 6,
    image: '...'
};
await addToOverflow(uid, item);
await db.run('UPDATE users SET overflowmoney = COALESCE(overflowmoney, 0) + N WHERE id = ?', [uid]);
```
