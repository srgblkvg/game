---
name: mmo-arena-donate
description: "Donate system for MMO Arena — VK Payments, YooKassa, starter pack, silver exchange."
version: 1.0.0
---

# MMO Arena — Донат-система

Добавление и обработка платных товаров через VK Payments и YooKassa.

## Архитектура

Типы товаров:
- `premium` — продление премиума
- `starter_pack` — одноразовый набор
- `silver` — серебро **в банк** (`users.bank`, НЕ `users.money`)
- `craft_pack` — сундук с материалами (rare/epic)
- `curse_pack` — сундук с кристаллами душ (small/large)
- `rune_pack` — набор рун (×1/×3/×5)
- `mega_craft` — мега/большой набор ремесленника; оба используют type `mega_craft`, различаются по `itemName` в хендлере

Обработка:
- **VK:** `vkPayments.ts` — колбэк, юзер по `oauthProvider='vk' AND oauthId=?`
- **YooKassa:** `yukassa.ts` — webhook, юзер по `userId` из metadata
- **Выдача:** `donate.ts` — `deliverStarterPack()` / `deliverSilver()` / `deliverCraftPack()` / `deliverCursePack()` / `deliverRubyRune()` / `deliverMegaCraftSet()` / `deliverLargeCraftSet()`

## Добавление нового товара

1. В `vkPayments.ts`: запись в `ITEMS` с `type`, `price`, специфичными полями
2. В `yukassa.ts`: запись в `ITEMS` с теми же полями + ценой в рублях
3. В `order_status_change` / `payment.succeeded`: ветка для нового `type`
4. Логика выдачи — в `donate.ts` (новая функция или параметр в существующую)
5. Шаблон выдачи craft_item: найти существующий стак (`type === 'craft_item' && id === item.id`), увеличить `count`, иначе `push` новый. ВСЕГДА стакать — не создавать отдельные записи.

### Шаблон `deliverXxxPack` (для сундуков с серебром + ресурсами)

```typescript
export async function deliverCursePack(userId: number, packType: 'small' | 'large'): Promise<{ success: boolean; error?: string }> {
  const user = await db.one('SELECT id, inventory, money FROM users WHERE id = ?', [userId]) as any;
  const packs = { small: { silver: 500000, crystals: 5 }, large: { silver: 1000000, crystals: 10 } };
  const pack = packs[packType];
  // Получить craft_item из БД по имени
  const item = await db.one("SELECT c.*, r.display_name, r.color FROM craft_items c JOIN rarities r ON c.rarity_id = r.id WHERE c.name = ?", ['Кристалл душ']) as any;
  const inventory = JSON.parse(user.inventory || '[]');
  // Стакаем
  const existing = inventory.find((i: any) => (i.type === 'craft_item' || i.type === 'material') && i.id === item.id);
  if (existing) { existing.count += pack.crystals; }
  else { inventory.push({ type: 'craft_item', id: item.id, name: item.name, rarity_id: item.rarity_id, rarity_display: item.display_name, rarity_color: item.color, count: pack.crystals, itemType: item.type, image: item.image }); }
  const newBank = (user.bank || 0) + pack.silver;
  await db.run('UPDATE users SET inventory = ?, bank = ? WHERE id = ?', [JSON.stringify(inventory), newBank, userId]);
  sendToUser(userId, { type: 'paymentStatus', status: 'success', platform: 'donate' });
  return { success: true };
}
```

### Актуальные цены (2026-08-01)

| item | YooKassa (₽) | VK (голоса) |
|------|-------------|------------|
| curse_small (500k + 5 кристаллов) | 999 | 144 |
| curse_large (1M + 10 кристаллов) | 1799 | 258 |

## Одноразовые покупки

Для товаров "купить один раз":
- Булева колонка в `users` (напр. `starter_pack_purchased`)
- `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` в `donate.ts` (модульный уровень)
- Проверка флага ДО выдачи
- Если ALTER не сработал (OOM при старте) — выполнить вручную на VPS

## Изображения (важно!)

- **items (экипировка):** путь без ведущего слеша: `helmet/helmet_white.webp`
- **craft_items (материалы):** путь С ведущим слешем: `/fragment/fragment_green.webp`

Нормализация на клиенте:
```
const clean = img.startsWith('/') ? img.slice(1) : img;
const url = 'https://mmoarena.ru/' + clean;
```

## Товары (актуальный список)

См. `references/donate-items.md` — полный список товаров VK/YooKassa и состав стартового набора.

## Клиентские страницы

- `StarterPackPage.tsx` — страница `/starter-pack`, превью набора + покупка
- `ShopPage.tsx` — баннер стартового набора (скрывается после покупки)
- `BankPage.tsx` — вкладка "Обмен" (ExchangeTab)
- `CraftPage.tsx` — сундуки (PACKS) с материалами и кристаллами душ, карусель 220px

Паттерн покупки:
- VK: `vkBridge.send('VKWebAppShowOrderBox', { type: 'item', item: '...' })`
- Браузер: `POST /api/yukassa/create-payment { item: '...' }` → `window.open(confirmation_url)`
- Подтверждение: WS-событие `paymentStatus` → обновить UI

## Питфолы

- **Ресурсы (craft_item) ДОЛЖНЫ стакаться — ОДИН предмет с count, НЕ отдельные записи.** Формат: type: craft_item, id: DB_id, count: N, itemType: craft. Перед добавлением искать существующий стак по type === craft_item && id === item.id и суммировать count. Референс: routes/mobs.ts. Симптом: 4 отдельных предмета вместо одного стака.
- **pgLowerIdentifiers** не ломает алиасы без uppercase (rarity_display, display_name) — OK
- **camelRows** добавляет camelCase-дубликаты, но оригинальные snake_case ключи сохраняются
- **craft_items image** — путь с `/`, не забывать strip
- **ALTER TABLE в модуле** — если сервер упал с OOM при старте, DDL не выполнился → сделать вручную
- **JOIN с неоднозначным `id`**: при JOIN двух таблиц с колонкой `id` всегда `SELECT c.id` (не `SELECT id`). Иначе: `column reference "id" is ambiguous`.
- **Preview endpoint → client fallback**: серверный preview может вернуть 500. Клиент должен иметь fallback (другой API endpoint или хардкод-пути к изображениям). Без fallback страница остаётся пустой.
- **ВСЁ донатное серебро идёт в банк (`users.bank`), НЕ в кошелёк (`users.money`).** Все функции выдачи используют `bank` вместо `money`. Клиентские описания должны писать «в банк».
- **VK Payments: `×` (U+00D7) в названии ЛОМАЕТ подпись.** VK конвертирует `×` в `&#215;`, `&` парсится как разделитель urlencoded → title обрезан → подпись не совпадает. Фикс: использовать `x` (ASCII). Подробнее: `references/vk-payments-pitfalls.md`.
