# VK Payments Pitfalls

## `×` → `&#215;` ломает подпись в urlencoded callback

**Симптом**: `order_status_change_test` валится с «Invalid signature», при этом `get_item` проходит. Только на новых товарах, в названии которых есть `×` (U+00D7, multiplication sign).

**Причина**: VK конвертирует `×` в HTML-entity `&#215;` при отправке `order_status_change` callback. Эта entity содержит символ `&`, который в `application/x-www-form-urlencoded` теле работает как разделитель параметров. Express body parser обрезает `item_title` на `&`, теряя остаток строки. Подпись вычисляется от урезанного title → не совпадает.

**Отладка**: добавить в `vkPayments.ts` перед `verifySignature`:
```typescript
if (params.item_title) {
  const hex = Buffer.from(params.item_title, 'utf8').toString('hex');
  logger.info(`[VK Payments DEBUG] item_title hex: ${hex} | raw: ${params.item_title}`);
}
```
Если hex заканчивается на `2623` (`&#`) — это обрезанная HTML-entity.

**Фикс**: заменить `×` на `x` (ASCII) в названии товара в `ITEMS` (и в `vkPayments.ts`, и в `yukassa.ts`). Клиентские названия (CraftPage PACKS) тоже не должны содержать `×`.

**Реальный случай**: название `'Мега набор ремесленника (7 рун + 7 материалов ×200 + 20M)'` → VK слал `item_title=...материалов &#215;200 + 20M)` → парсер обрезал до `...материалов &#` → `verifySignature` всегда возвращал false.
