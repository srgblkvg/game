---
name: mmo-donate
description: "MMO Arena donat/payment system: adding items across VK Payments + YooKassa, delivery functions, craft item stacking, admin logging."
version: 1.1.0
---

# MMO Arena — Донат и платежи

## Архитектура

| Файл | Назначение |
|---|---|
| `server/src/routes/donate.ts` | Функции выдачи: `deliverStarterPack`, `deliverSilver`, `deliverCraftPack`, `deliverCursePack`, `deliverRubyRune` |
| `server/src/routes/vkPayments.ts` | VK Payments колбэк, товары в `ITEMS` |
| `server/src/routes/yukassa.ts` | ЮKassa, товары в `ITEMS`, `processDelivery()` |
| `client/src/pages/StarterPackPage.tsx` | Страница стартового набора |
| `client/src/pages/CraftPage.tsx` | Сундуки с материалами (над рецептами) |
| `client/src/pages/BankPage.tsx` | Вкладка «Обмен» (серебро за донат) |
| `client/src/pages/AdminPanel/AdminDonate.tsx` | Логирование в админке |

## Существующие товары

| Ключ | Тип | VK (гол.) | ₽ | Содержимое |
|---|---|---|---|---|
| `premium_7d` | premium | 14 | 99 | 7 дней премиума |
| `premium_30d` | premium | 42 | 299 | 30 дней премиума |
| `starter_pack` | starter_pack | 14 | 99 | Необычный сет (r2, 9 слотов) + Эссенция мрака (r3) ×4 + 10,000💰 + 7д премиум |
| `silver_10000` | silver | 7 | 49 | 10,000 серебра |
| `silver_50000` | silver | 14 | 99 | 50,000 серебра |
| `silver_100000` | silver | 28 | 199 | 100,000 серебра |
| `silver_500000` | silver | 114 | 799 | 500,000 серебра |
| `silver_1000000` | silver | 200 | 1399 | 1,000,000 серебра |
| `craft_rare` | craft_pack | 14 | 99 | Сердцевина бездны (r4) ×5 + Рунный булыжник ×6 + 10,000💰 |
| `craft_epic` | craft_pack | 28 | 199 | Искра погибели (r5) ×5 + Рунный булыжник ×10 + 30,000💰 |
| `curse_small` | curse_pack | 144 | 999 | Кристалл душ ×5 + 500,000💰 |
| `curse_large` | curse_pack | 258 | 1799 | Кристалл душ ×10 + 1,000,000💰 |
| `ruby_rune_1` | rune_pack | 57 | 399 | Набор рун ×1: Рубина (+50%) + Топаз (+30%) + Аметист (+20%) |
| `ruby_rune_3` | rune_pack | 144 | 999 | Набор рун ×3: Рубина + Топаз + Аметист |
| `ruby_rune_5` | rune_pack | 214 | 1499 | Набор рун ×5: Рубина + Топаз + Аметист |

### Составы наборов (актуальные)

**Стартовый набор** (`deliverStarterPack`):
- Необычная экипировка (rarity_id=2), все 9 слотов
- Эссенция мрака (r3) ×4 — стакается с существующими
- 10,000 серебра
- 7 дней премиума
- Одноразовый (флаг `starter_pack_purchased`)

**Сундук «Редкий»** (`deliverCraftPack`, type='rare'):
- Сердцевина бездны (r4) ×5
- Рунный булыжник (r0) ×6
- 10,000 серебра

**Сундук «Эпический»** (`deliverCraftPack`, type='epic'):
- Искра погибели (r5) ×5
- Рунный булыжник (r0) ×10
- 30,000 серебра

**Набор рун** (`deliverRubyRune`, count):
- Руна Рубина (r6, +50% к улучшению) ×count
- Руна Топаза (r5, +30% к улучшению) ×count
- Руна Аметиста (r4, +20% к улучшению) ×count
- Все три стакаются с существующими рунами в инвентаре

**Сундук «Проклятый»** (`deliverCursePack`, type='small'|'large'):
- small: Кристалл душ ×5 + 500,000💰
- large: Кристалл душ ×10 + 1,000,000💰

### Файлы клиента для каждого товара

| Товар | Страница | Компонент |
|---|---|---|
| premium | `PremiumPage.tsx` | `plans[]` |
| starter_pack | `StarterPackPage.tsx` | preview + кнопка покупки |
| silver | `BankPage.tsx` | Вкладка «Обмен», `tiers[]` |
| craft_pack | `CraftPage.tsx` | `CraftPacks()`, `packs[]` |
| (лейблы) | `AdminPanel/AdminDonate.tsx` | `ITEM_LABELS` |

## Экономический контекст

При пересмотре донат-сумм — см. `references/economy-context.md`: цены магазина, награды квестов, стоимость гильдии/резни/крафта, иерархия материалов и камней.

Сводка системных изменений за 27 июля 2026 (руны, HP-реген, лимит инвентаря, война гильдий, коллекция) — см. `references/july27-changes.md`.

Актуальные составы наборов — см. таблицу выше в разделе «Существующие товары» и подраздел «Составы наборов». При изменении содержимого стартового набора или сундуков: `donate.ts` (сервер) + клиентские страницы (StarterPackPage, CraftPage, BankPage).

## Добавление нового товара — пошагово

### 1. Сервер: функция выдачи (если новый тип)

В `routes/donate.ts`:
```
export async function deliverXxx(userId, ...): Promise<{success, error?}>
```
- Получить user из БД
- Собрать предметы/серебро в inventory (см. pitfall про craft_item ниже)
- `db.run('UPDATE users SET ...')`
- `sendToUser(userId, { type: 'paymentStatus', status: 'success', platform: 'donate' })`
- `logger.info(...)`

Для серебра: использовать готовую `deliverSilver(userId, amount)`.

**Паттерн: выдача нескольких разных предметов в одном паке** (как `deliverRubyRune` — Рубина + Топаз + Аметист):
```typescript
const itemNames = ['Предмет A', 'Предмет B', 'Предмет C'];
const items: any[] = [];
for (const name of itemNames) {
  const item = await db.one('SELECT ... FROM craft_items WHERE name = ?', [name]) as any;
  if (item) items.push(item);
}
// затем для каждого item — стакинг в inventory
for (const item of items) { /* addStack(item, count) */ }
```

### 2. Сервер: VK Payments

`routes/vkPayments.ts`:
- Добавить в `ITEMS` запись с `type`, `price`, `title`
- Обновить union-тип `VkItem.type`
- Добавить `else if (item.type === 'xxx')` в `order_status_change`

### 3. Сервер: ЮKassa

`routes/yukassa.ts`:
- Добавить в `ITEMS`
- Обновить union-тип `ShopItem.type`
- Добавить `else if (itemType === 'xxx')` в `processDelivery()`

### 4. Клиент: кнопка покупки

```typescript
const isVK = document.documentElement.classList.contains('vk-iframe');

// VK:
vkBridge.send('VKWebAppShowOrderBox', { type: 'item', item: 'item_key' })

// Браузер:
fetch('/api/yukassa/create-payment', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
  body: JSON.stringify({ item: 'item_key' }),
}).then(r => r.json()).then(data => window.open(data.confirmation_url, '_blank'))
```

### 5. WS-уведомление об успехе

```typescript
useEffect(() => {
  const handler = () => { /* сообщение об успехе */ };
  window.addEventListener('paymentStatus', handler);
  return () => window.removeEventListener('paymentStatus', handler);
}, []);
```

### 6. Клиент: AdminDonate лейблы + CraftPage ветки

`AdminPanel/AdminDonate.tsx`:
- Добавить запись в `ITEM_LABELS` с ключом товара

`CraftPage.tsx` (если товар показывается там):
- Добавить запись в массив `PACKS`
- Если новый тип контента (не material/stones, не curse) — добавить ветку рендера
- Если товар без серебра — обернуть строку `💰` в `{'silver' in p && ...}`
- Определить `borderColor` для нового типа

### 7. Сервер: yukassa — метаданные для нового типа

Если у товара есть специфичные параметры (count, runeCount и т.д.), добавить их в `metadata` объекта `create-payment` и в `processDelivery()` webhook'а.

## 🔴 Питфол: craft_item — формат и стакинг

Материалы/ресурсы в инвентаре ДОЛЖНЫ быть ОДНИМ объектом с `count`, НЕ отдельными предметами:

```typescript
// ✅ ПРАВИЛЬНО
{ type: 'craft_item', id: 3, name: 'Фрагмент ужаса', rarity_id: 2,
  rarity_display: 'Необычный', rarity_color: '#2ecc71',
  count: 4, itemType: 'craft', image: '/fragment/fragment_green.webp' }

// ❌ НЕПРАВИЛЬНО — без count, отдельными экземплярами
{ id: Date.now(), name: 'Фрагмент ужаса', type: 'craft', ... }
```

При добавлении: найти существующий стак по `(type === 'craft_item' || type === 'material') && id === dbItem.id`. Если есть — `existing.count += qty`. Поле `itemType`: `'craft'` для материалов, `'upgrade'` для камней.

**Симптом:** игрок видит 4 отдельных Фрагмента ужаса вместо одного стака с count:4.

## 🔴 Питфол: пути изображений

- **items (экипировка):** БЕЗ ведущего `/` — `helmet/helmet_white.webp`
- **craft_items (ресурсы):** С ведущим `/` — `/fragment/fragment_green.webp`

Функция для безопасного построения URL:
```typescript
const imageUrl = (img: string | null) => {
  if (!img) return '';
  const clean = img.startsWith('/') ? img.slice(1) : img;
  return 'https://mmoarena.ru/' + clean;
};
```

## Админка: вкладка «Донат»

Эндпоинт: `GET /api/admin/donate/history` — UNION vk_payments + yukassa_payments с JOIN users.

Таблицы:
- `vk_payments` (id, order_id, user_id, character_id, item, status, processed_at, created_at)
- `yukassa_payments` (id, payment_id, user_id, item, days, amount, status, processed_at, created_at)

Паттерн добавления вкладки:
1. Компонент `AdminPanel/AdminXxx.tsx`
2. Импорт + `tabs[]` + `{tab === 'xxx' && <AdminXxx />}` в `AdminPanel.tsx`

## 🔴 Питфол: AdminDonate ITEM_LABELS — всегда обновлять при новых товарах

`client/src/pages/AdminPanel/AdminDonate.tsx` содержит `ITEM_LABELS: Record<string, string>` — человекочитаемые названия товаров для таблицы истории платежей. При добавлении ЛЮБОГО нового товара нужно добавить запись в этот объект, иначе в админке будет показываться голый ключ (например `ruby_rune_1` вместо «Руна Рубина ×1»).

**Симптом:** в истории доната в админке вместо названия товара виден технический ключ.

### CraftPage: условный показ серебра

Не все товары содержат серебро (например руны). Строка `💰 {formatMoney(p.silver)}` должна быть обёрнута в `{'silver' in p && ...}` — иначе для товаров без поля `silver` показывается `💰 undefined`.

### CraftPage: ветки рендера (curse / rune / craft)

При добавлении нового типа товара с уникальным контентом нужно добавить ветку в цепочку условий:
```tsx
{'curse' in p ? ( ... ) : 'rune' in p ? ( ... ) : ( ... )}
```
И borderColor тоже: `p.curse ? '#e74c3c' : p.rune ? '#c0392b' : ...`

### CraftPage: порядок паков — группировать по типу, НЕ по цене

Паки в массиве `PACKS` должны быть сгруппированы по типу товара: материалы → руны → проклятые. НЕ сортировать по цене вперемешку — пользователь явно требует группировку по категориям.

**Порядок (утверждён):** Рунный набор → Большой рунный набор → Набор рун ×1 → ×3 → ×5 → Проклятый → Проклятый II.

### CraftPage: текст «экономия» — НЕ добавлять

Пользователь отверг текст «(экономия N₽)» в описаниях паков. Описание должно быть одинаковым для всех размеров набора («Руны для улучшения предметов»), разница в цене говорит сама за себя.

## 🔴 Питфол: компенсация при ребалансе доната

При изменении содержимого донат-товаров (серебро, предметы, материалы) **нужно компенсировать разницу** всем кто уже купил старую версию. Процесс:

1. Написать Node.js скрипт (`compensate_donate.js`) который:
   - UNION vk_payments + yukassa_payments (status='succeeded') → группирует по user_id + item
   - Для каждого типа платежа считает разницу (новое − старое)
   - Серебро: `UPDATE users SET bank = COALESCE(bank, 0) + разница` (НЕ `money`!)
   - Предметы экипировки (не материалы): INSERT в `overflow_storage`
   - Материалы: в инвентарь через стакинг (см. питфол craft_item)
   - Отправляет сообщение в личку от system (senderId=0) с описанием
2. Запустить через `scp` на VPS и `node compensate_donate.js`
   - Шаблон скрипта: `scripts/compensate_donate.js` — скопировать, обновить COMPENSATION, запустить
   - Для компенсации наборов рун: `scripts/compensate_runes.js` — заточен под довыдачу craft_items (рун) тем кто купил старую версию пака. Кастомизировать `RUNE_ITEMS`, `COUNT_MAP`, `MISSING_ITEMS`.
3. **ВАЖНО:** для system-сообщений (senderId=0) НЕ указывать `"senderGuild"` / `"senderGuildId"` в INSERT — этих колонок может не быть в старых схемах, и `pgLowerIdentifiers` опустит их в lowercase. Правильный INSERT: `INSERT INTO chat_messages (senderId, targetId, content) VALUES (0, $1, $2)`.
4. **🔴 КРИТИЧЕСКИЙ ПИТФОЛ — vk_payments.user_id ≠ character_id:** `vk_payments.user_id` — это VK-ID платформы (большое число вроде 2943464), а `vk_payments.character_id` — игровой ID (маленькое, вроде 131). При запросе покупок для компенсации ВСЕГДА использовать `character_id`:
   ```sql
   SELECT character_id as user_id, item, COUNT(*) as cnt
   FROM vk_payments WHERE character_id > 0 AND item = ANY(...)
   GROUP BY character_id, item
   ```
   **Симптом:** UPDATE/INSERT срабатывают (без ошибок FK), но для несуществующих ID — деньги теряются, предметы на складе у никого, сообщения в чат невидимы. Пользователи с маленькими ID получают компенсацию, с большими VK-ID — нет.
5. **🔴 Серебро — в банк, не в карман:** Пользователь ожидает компенсацию на **банковский счёт** (`bank`), а не в наличные (`money`). Колонка: `users.bank`. Использовать `COALESCE(bank, 0)` — у многих игроков bank может быть NULL. При ошибочном зачислении в `money` — перенести: `UPDATE users SET money = money - amount, bank = COALESCE(bank, 0) + amount` + запись в `bank_operations` (type='deposit').

**Симптом при ошибке чата:** `column "senderGuild" of relation "chat_messages" does not exist` → вся транзакция откатывается, компенсация не применяется.

## Турнирные сообщения в чат

Системные сообщения «Турнир X — регистрация закроется через N мин!» **УБРАНЫ** (2026-07-21). Код удалён из `tournament.ts`. При необходимости вернуть — смотреть историю коммита.
