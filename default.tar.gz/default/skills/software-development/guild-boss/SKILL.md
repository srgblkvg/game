---
name: guild-boss
description: "Guild boss, talents, ratings, and boss battle logs."
category: software-development
---

# Guild Boss & Talents — Architecture & Pitfalls

## Overview

Guild boss system: shared PvE boss per guild, talent trees (personal + guild-wide), ratings, real-time WS updates.

## File Map

| Component | Path |
|-----------|------|
| DB migration | `server/src/db/migrations/guildBosses.sql` |
| DB migration (battle logs) | `server/src/db/migrations/guildBossBattles.sql` |
| Game logic | `server/src/game/guildBoss.ts` |
| Route | `server/src/routes/guildBoss.ts` |
| Client boss tab | `client/src/pages/GuildPage.tsx` |
| Client sidebar | `client/src/components/QuestsBlock.tsx` |
| WS dispatch | `client/src/contexts/ChatContext.tsx` |
| Battle engine (anti-stats) | `server/src/game/battle.ts` (TurnContext + runTurn) |
| Route registration | `server/src/setupRoutes.ts` |

## DB Tables

```
guild_bosses — boss state per guild (currentHp, maxHp, killCount, effects JSON, respawnAt)
guild_boss_battles — attack history (userId, damageDealt, steps JSON, playerWon)
player_guild_talents — personal talents (userId, guildId, talentType, level, progress)
guild_talents — guild-wide talents (guildId, talentType, level, progress)
guild_members — added: lastBossAttackAt, talentPoints
guilds — added: talentPoints
```

### GRANT after new tables
After creating tables via `sudo -u postgres psql`, always run:
```sql
GRANT ALL ON guild_bosses TO game;
GRANT ALL ON player_guild_talents TO game;
GRANT ALL ON guild_talents TO game;
GRANT ALL ON guild_boss_battles TO game;
GRANT ALL ON SEQUENCE guild_boss_battles_id_seq TO game;
```

## API Endpoints

| Method | Path | Auth |
|--------|------|------|
| GET | `/api/guild/boss` | player |
| POST | `/api/guild/boss/attack` | player |
| GET | `/api/guild/boss/battles` | player |
| GET | `/api/guild/boss/ratings` | player |
| GET | `/api/guild/talents` | player |
| POST | `/api/guild/talents/upgrade` | player (guild = leader only) |

## Route Ordering Pitfall

**CRITICAL**: `guildBossRoutes` MUST be registered BEFORE `guildRoutes` in `setupRoutes.ts`. The guild routes have `router.get('/guild/:id', ...)` which matches `/guild/boss` as an ID parameter, returning 404.

```typescript
// ✅ CORRECT order
app.use('/api', guildBossRoutes);
app.use('/api', guildRoutes);

// ❌ WRONG — /guild/:id catches /guild/boss
app.use('/api', guildRoutes);
app.use('/api', guildBossRoutes);
```

## Boss Mechanics

### Stats & Scaling
- Base: S=80, A=50, D=60, M=50, HP=100000, Lvl=20
- Per kill: HP += 50000, stats *= (1 + 0.10 * killCount), level += 5

### Effects
12 random effects picked on respawn. Values scale with killCount via `BOSS_STAT_SCALE` (0.10).
Binary effects (alwaysFirst, execute) don't scale.
Effects stored as JSON in `guild_bosses.effects`, merged into bossStats via `Object.assign()`.

### Respawn
After kill: `respawnAt = now + 300` (5 min). Boss HP = 0 during cooldown.
`getOrCreateBoss()` auto-respawns when `now >= respawnAt`.

### Battle
Uses `runTurn()` like PvE mobs. Player stats via `buildPlayerStats(user, 'pve')` → scout_hq bonus.
Guard faction bonus (+10%). Boss effects applied before battle.

### Cooldown
Per-player: 3600s (1 hour). Stored in `guild_members.lastBossAttackAt`.

## Talent System

### Types
5 talent trees:
- `accuracy` — Меткость (anti-dodge)
- `fortitude` — Стойкость (anti-crit)
- `penetration` — Пробивание (anti-block)
- `control` — Контроль (anti-counter)
- `vampiric` — Антивампиризм

### Cost Formula
`10 * Math.pow(2, currentLevel)` → 10, 20, 40, 80, 160, 320...

### Progress System
Players invest 1 point per click (not full cost upfront).
Each talent has `level` and `progress` columns.
When `progress >= cost`, level increments and progress resets to 0.

### Personal vs Guild
- Personal: any guild member can invest their own points
- Guild: only the guild LEADER can invest guild points

### Data Format
`getPlayerTalents()` / `getGuildTalents()` return `Record<string, { level: number; progress: number }>`.
API response includes `playerLevel`, `playerProgress`, `guildLevel`, `guildProgress`, `playerUpgradeCost`, `guildUpgradeCost`.

## Anti-Stats Integration (battle.ts)

TurnContext fields:
```typescript
antiDodge?: number;          // attacker-side
antiCrit?: number;           // attacker-side
antiBlock?: number;          // attacker-side
antiCounter?: number;        // attacker-side
antiVampiric?: number;       // attacker-side
targetAntiVampiric?: number; // defender-side (reduces attacker's vamp)
```

Applied in runTurn: `Math.max(0, chance - (ctx.antiXxx || 0) / 100)`

## WebSocket Updates

After each attack, `sendToGuild()` broadcasts `guild_boss_update` to all guild members.
ChatContext dispatches `CustomEvent('guildBossUpdate')`.
Client handler pattern:
```typescript
const msg = (e as CustomEvent).detail;
const d = msg.data || msg; // data is nested in .data sub-object
if (d.ratingsChanged) loadBoss();
```

Payload includes: `bossHp`, `bossMaxHp`, `bossKilled`, `respawnAt`, `guildTalentPoints`, `ratingsChanged`.

## Ratings

5 rankings from `guild_boss_battles`:

1. **Guild top-5** — `SUM(damageDealt) GROUP BY userId`
2. **Player rank** — `RANK() OVER (ORDER BY SUM(damageDealt) DESC)`
3. **Guild rank** — same pattern grouped by guildId
4. **Strongest hits** — parse `steps` JSON, find max `damage` from `type==='damage'`
5. **Top guild kills** — `guild_bosses.killCount`

## Client UI Notes

### Tabs
GuildPage tabs: Обзор(0), Постройки(1), Казна(2), Участники(3), Босс(4), Таланты(5).
URL navigation via `?tab=N` and `useSearchParams`.

### Styling
- Boss stat icons use same icons as StatsOverlay: `game-icons:biceps/sprint/shield/crossed-swords`
- BossBattleLog: backgrounds alternate per TURN (`type === 'attack'`), NOT per step
- Talent cards: `grid-cols-2`, blocks `sm:grid-cols-2` side-by-side on desktop
- Mobile ratings: `grid-cols-1 sm:grid-cols-2`
- Sidebar HP bar: `h-1` (matching quest progress bars)

### Text Style
- No abbreviations: "Побеждён N раз", "Атака доступна раз в час"
- Boss name: "Кровавый исполин"
- Talent buttons: "Вложить" (not "Вложить 1")

## Boss Battle Log

Stored in `guild_boss_battles` with full `steps` JSON after each attack.
Endpoint: `GET /guild/boss/battles?userId=X` (optional filter).
Client: auto-loaded with boss data, clickable row → view that player's full log.

## TL;DR Pitfalls

1. **Route order**: guildBossRoutes BEFORE guildRoutes (/:id catches /boss)
2. **WS data nesting**: `msg.data || msg` — data is inside `.data` sub-object
3. **Background alternation**: on `type === 'attack'`, NOT per-step
4. **GRANT after CREATE TABLE**: always grant to `game` user
5. **ALTER guild_members/guilds**: owned by `postgres`, use `sudo -u postgres`
6. **CamelCase in DB**: PG lowercase keys, map explicitly in API responses
7. **Talent format**: objects `{level, progress}`, not plain numbers
8. **Sidebar cooldown**: don't set from WS (other player's attack) — only from initial load
