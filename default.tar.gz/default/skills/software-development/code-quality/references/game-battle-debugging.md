# CSS Animation & Client-Server State Sync Debugging

## CSS Animation Selector Mismatch

**Symptom:** CSS animations defined in stylesheets never fire, even though the
animation class is being applied via JavaScript DOM manipulation.

**Root cause pattern:** The CSS selector targets one element (e.g., a parent with
a specific class), but the JavaScript adds the animation class to a DIFFERENT
element (e.g., a child with only an ID).

**Example from this session:**

```css
/* ❌ WRONG — targets .fighter-card with .attacking class */
.fighter-card.attacking {
  animation: attack-anim 0.6s ease-in-out;
}
```

```js
// JavaScript adds .attacking to frame div (child of .fighter-card)
const leftFrame = document.getElementById('fighter-left');
leftFrame?.classList.add('attacking');
```

The `<div id="fighter-left">` does NOT have class `fighter-card` — that class
is on its parent. So `.fighter-card.attacking` never matches.

**Fix:** Target the actual element receiving the class:

```css
/* ✅ CORRECT — targets the frame element by ID */
#fighter-left.attacking,
#fighter-right.attacking {
  animation: attack-anim 0.6s ease-in-out;
}
```

**Investigation technique:** Use browser DevTools to check which element
actually receives the class at runtime, then verify the CSS selector matches.

---

## Client-Server State Sync: Stamina/HP Regeneration

**Symptom:** UI values (stamina, HP) "jump" up and down erratically — they
appear to fill up, then suddenly snap back to a lower value.

**Root cause:** Both client AND server are independently updating the same
state. The client runs a local regeneration interval, but the server sends
authoritative values in each step that override the client's interpolated
values.

**Example from this session:**

```js
// ❌ Client-side regen interval
setInterval(() => {
    setStamLeft(prev => Math.min(prev + 0.4 * speed, maxStamLeft));
}, 100);

// Server step handler also sets stamina
if (step.type === 'stamina') {
    setStamLeft(step.stamina);  // Overwrites client regen → jump!
}
```

The client regen fills stamina toward max. Each server step arrives and sets
the authoritative value (which is lower because attack cost was deducted).
Result: stamina appears to fill, then snap back down — visually jarring.

**Fix:** Choose ONE source of truth. Remove client-side regen entirely and
rely solely on server-provided values:

```js
// ✅ Server is the single source of truth
if (step.type === 'stamina' && step.stamina !== undefined) {
    setStamLeft(step.stamina);  // Authoritative
}
```

Use CSS transitions on the bar width for visual smoothness instead:

```jsx
<div style={{
    width: `${(stamina / maxStamina) * 100}%`,
    transition: 'width 0.4s ease'  // Smooth animation between server values
}} />
```

---

## HP Bar Not Animating Before Victory Message

**Symptom:** After the final damaging blow, the victory/defeat message appears
instantly with the HP bar still showing the old value (not yet at zero).

**Root cause:** The damage step and the end-of-battle step execute in rapid
succession. The HP state updates from the damage step, but the browser hasn't
rendered the new HP bar width before the "Victory!" message appears.

**Fix:** Add an extra delay after damage-typed steps to give the HP bar
transition time to complete before the next step fires:

```js
const isDamage = battleSteps[next]?.type === 'damage';
await new Promise(r => setTimeout(r, (isDamage ? 1000 : 700) / speedRef.current));
```

This gives the HP bar's CSS transition (0.4s) enough time to animate to zero
before the end-of-battle message renders.

---

## Battle Loop: HP Not Reaching Zero

**Symptom:** After the last damaging blow, the loser's HP stays at 1 instead of
reaching 0. The victory message appears but the HP bar still shows a sliver of
health.

**Root cause:** The loop condition `while (hpA > 1 && hpD > 1)` exits when HP
drops to 1 or below — but `Math.max(0, hp - dmg)` can leave HP at 1 if the
damage leaves exactly 1 HP. The loop ends but the character isn't dead.

**Fix:** Change the condition to `while (hpA > 0 && hpD > 0)` so the loop
continues until someone reaches 0 HP. Also change the winner check:

```ts
// ❌ Before
while (hpA > 1 && hpD > 1) { ... }
const winnerId = hpA <= 1 ? defender.id : attacker.id;

// ✅ After — fight to the death
while (hpA > 0 && hpD > 0) { ... }
const winnerId = hpA <= 0 ? defender.id : attacker.id;
```

---

## Skip Button: Wrong Field Names in Battle Result

**Symptom:** After clicking «Пропустить» (Skip), the HP bars don't update to
the final battle values. The loser's HP stays at max.

**Root cause:** The server response uses `hpAfter` (for attacker) and
`hpDefenderAfter` (for defender), but the client code accesses
`battleResult.attackerHpAfter` which is undefined → `?? 0` fallback prints 0.

**Fix:** Match field names to server response:

```js
// ✅ Correct field names
setHpLeft(Math.max(0, battleResult.hpAfter ?? 0));           // attacker
setHpRight(Math.max(0, battleResult.hpDefenderAfter ?? 0));   // defender
```

**Investigation technique:** Log or inspect the full `battleResult` object
from the server. Compare field names in the JSON response against what the
client destructures.

---

## Removing a Mechanic Entirely (Stamina Case Study)

When a game mechanic doesn't fit the design, remove it thoroughly:

**Server side:**
1. `battle.ts` — Remove all stamina variables, regen, checks, cost deductions,
   and stamina-typed steps from the battle loop.
2. `stats.ts` — Simplify `currentStats()` to skip stamina calculations
   (attackCost, regen). Keep the interface fields for backward compatibility.

**Client side:**
1. `useBattleLogic.ts` — Remove `stamLeft/Right`, `maxStamLeft/Right` state
   and their setters. Remove stamina handlers from `executeStep` and
   `loadOpponent`. Remove from return object.
2. `ArenaPage.tsx` — Remove `stamLeft/Right` destructuring. Set
   `showStamina={false}` on CharacterCard.
3. `CharacterCard.tsx` — Ensure stamina bar only renders when `showStamina`
   is explicitly true (no accidental rendering from stale props).

**Verification:** Run `tsc --noEmit` on both server and client — unused
variables and missing return properties will surface any missed references.

---

## Full-Bleed Cards on Mobile (CSS Pattern)

**Use case:** Action cards that should span viewport edge-to-edge on mobile,
but normal width on desktop.

```tsx
// Outer container: full viewport width on mobile
<div className="w-screen ml-[calc(-50vw+50%)] sm:w-full sm:ml-0">
  {/* Inner scroll: padding matches the block above (e.g., Inventory border) */}
  <div className="flex overflow-x-auto hide-scrollbar px-8">
    {cards.map(...)}
  </div>
</div>
```

**How it works:**
- `w-screen` = `100vw` (full viewport width)
- `ml-[calc(-50vw+50%)]` shifts left by half viewport minus half parent width,
  centering the full-width element regardless of parent padding
- `sm:w-full sm:ml-0` restores normal behavior on desktop breakpoints
- Inner `px-8` (32px) matches the visual boundary of the block above
