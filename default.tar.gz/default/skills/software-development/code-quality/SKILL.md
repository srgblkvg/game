---
name: code-quality
description: "Code quality assurance: systematic debugging (root cause analysis), pre-commit review (security scan + quality gates), and code simplification (parallel 3-agent cleanup)."
version: 1.0.0
author: Hermes Agent (consolidated from systematic-debugging, requesting-code-review, simplify-code)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [code-review, debugging, security, verification, quality, cleanup, refactor]
---

# Code Quality

Three complementary workflows for maintaining code quality: systematic debugging, pre-commit verification, and post-implementation cleanup.

---

## Section 1: Systematic Debugging (4-Phase Root Cause Analysis)

**Core principle:** ALWAYS find root cause before attempting fixes. Symptom fixes are failure.

### Phase 1 — Root Cause Investigation

1. **Read error messages carefully** — they often contain the exact solution.
2. **Reproduce consistently** — trigger it reliably, note exact steps.
3. **Check recent changes** — `git log --oneline -10`, `git diff`.
4. **Gather evidence** in multi-component systems — log data at each boundary.
5. **Trace data flow** — follow the bad value upstream to its source.

### Phase 2 — Pattern Analysis

Find working examples in the same codebase. Compare against references. Identify every difference between working and broken.

### Phase 3 — Hypothesis and Testing

Form ONE hypothesis. Test minimally. One variable at a time. Verify before continuing.

### Phase 4 — Implementation

Create failing test case → implement single fix → verify. **If 3+ fixes failed:** question the architecture, not the next fix.

### Red Flags — STOP and Follow Process

"If you catch yourself thinking: 'Quick fix for now, investigate later' or 'Just try changing X and see if it works' — STOP. Return to Phase 1."

### Pitfall: Fabricating game mechanics / documentation

When writing game documentation, wiki pages, or describing mechanics: **NEVER write from memory or guess.** Always verify against actual source code. Classic failure mode: writing "Божественная редкость" when the seed only has 7 tiers (Хлам→Мифический), or "напитки на 2 часа" when the code says 3600s (1 час). User response: "откуда ты это взял?" — means you fabricated a fact.

**Correct workflow:** read seed.ts for items/rarities, read route files for prices/durations, read App.tsx for all pages (don't guess what a page does from its filename — OrdersPage was guild listing, not "биржевые заявки").

### Pitfall: CSS corruption via patch with escaped newlines

When using `patch` to edit CSS files, literal `\n` in the replacement string can be written into the file as actual backslash-n characters instead of newlines. This corrupts CSS syntax (`Invalid declaration: \n`). Prefer `write_file` for multi-line CSS changes.

### Pitfall: Fixing ONE path when multiple create/buy paths exist

When a bug is reported for a specific action (e.g. "can create guild without money"), check ALL endpoints that perform that action. MMO Arena had TWO guild creation paths: `/orders/create` and `/guild/create`. Fixing only the reported path leaves the other path broken. Symptom: user says "цена указана 1000 а создать могу с балансом 20" — the page they're on uses the unfixed endpoint.

### React: `{0 && <JSX/>}` Renders \"0\" Text\n\nIn React JSX, `{value && <Component />}` evaluates to the value itself when falsy. When `value = 0`, the expression returns `0` — and React renders it as the text \"0\" in the DOM. This is a classic gotcha.\n\n**Bad:** `{collectionBonus && collectionBonus > 0 && <Row />}` — when `collectionBonus = 0`, evaluates to `0`, renders \"0\".\n**Good:** `{(collectionBonus ?? 0) > 0 && <Row />}` — evaluates to `false`, renders nothing.\n**Also good:** `{collectionBonus ? collectionBonus > 0 && <Row /> : null}` or `{!!collectionBonus && ...}`\n\n**When you see mysterious \"0\" or \"00\" text in the UI with no obvious source:** grep for `{... &&` in JSX — one of them is returning a numeric zero.\n\n### Async-Without-Await Pitfall

`async function fn(n) { return n * 2; }` — declared `async` but no `await` inside **returns `Promise<number>`, not `number`**. Using the result directly (`slots = fn(10)`) gives `[object Promise]`. Math on it produces NaN. Loops with NaN conditions never execute. This causes infinite loops, silent failures, and hung requests without visible errors.

**When debugging mysterious NaN, infinite loops, or `[object Promise]` in logs:** grep for `async function` definitions and verify each one actually uses `await`. Remove `async` from functions that don't need it.

**When a validation check ALWAYS fails (never passes for any input):** check for `async` functions used in boolean conditions. `if (asyncFn(item))` where `asyncFn` returns `Promise<boolean>` is ALWAYS true — Promise objects are truthy. Remove `async` or `await` the call.

---

## Section 2: Pre-Commit Code Review

Automated verification pipeline before code lands. **Core principle:** no agent should verify its own work — fresh context finds what you miss.

### Step 1 — Get the Diff

```bash
git diff --cached               # staged changes
git diff                        # unstaged (fallback)
git diff HEAD~1 HEAD            # last commit
```

### Step 2 — Static Security Scan

```bash
# Secrets
git diff --cached | grep "^+" | grep -iE "(api_key|secret|password|token).*=.*['\"][^'\"]{6,}"

# Shell injection
git diff --cached | grep "^+" | grep -E "os\.system\(|subprocess.*shell=True"

# Dangerous eval/exec
git diff --cached | grep "^+" | grep -E "\beval\(|\bexec\("

# SQL injection
git diff --cached | grep "^+" | grep -E "execute\(f\"|\.format\(.*SELECT"
```

### Step 3 — Baseline Tests + Linting

Run the project's test framework and linter. Capture baseline failure count BEFORE your changes (stash, run, pop). Only NEW failures block the commit.

### Step 4 — Self-Review Checklist

- [ ] No hardcoded secrets
- [ ] Input validation on user data
- [ ] SQL queries use parameterized statements
- [ ] File operations validate paths
- [ ] External calls have error handling
- [ ] No debug print/console.log left behind

### Step 5 — Independent Reviewer Subagent

Spawn a reviewer with ONLY the diff. Fresh context + fail-closed rules. The reviewer returns JSON:
```json
{"passed": true/false, "security_concerns": [], "logic_errors": [], "suggestions": [], "summary": "..."}
```

### Step 6 — Auto-Fix Loop (max 2 cycles)

Spawn a fix agent targeting only the reported issues. Re-verify after each fix. After 2 attempts, escalate remaining issues to user.

### Step 7 — Commit

```bash
git add -A && git commit -m "[verified] <description>"
```

---

## Section 3: Code Simplification (Parallel 3-Agent Cleanup)

Review recent changes with three focused reviewers running in parallel, aggregate findings, and apply fixes.

### When to Use

User says: "simplify", "review my code", "clean up my changes." Do NOT auto-run after every edit — it costs three subagents' tokens.

### The Process

**Phase 1 — Identify changes:** `git diff` or scoped variant (`git diff HEAD~1`, `git diff -- src/foo.py`).

**Phase 2 — Launch 3 reviewers in parallel** (batch `delegate_task`):
- **Reviewer 1 (Code Reuse):** Find duplication vs existing utilities. Name the existing thing to use and where it lives.
- **Reviewer 2 (Code Quality):** Flag redundant state, parameter sprawl, copy-paste, leaky abstractions, stringly-typed code.
- **Reviewer 3 (Efficiency):** Find unnecessary work, missed concurrency, hot-path bloat, TOCTOU, memory leaks.

All get the COMPLETE diff + repo path + `terminal/file/search` toolsets.

**Phase 3 — Aggregate and apply:** merge findings, discard false positives, resolve conflicts, apply fixes with `patch/write_file`, verify tests pass.

### Pitfalls
- Give the WHOLE diff to each reviewer, not fragments.
- Reviewers search, they don't guess — require `file:line` evidence.
- Apply ≠ rewrite — keep edits scoped to what the diff touched.
- Large diffs blow context — offer to scope down if >2000 changed lines.

---

## Skill Integration

- **systematic-debugging + test-driven-development:** Write a failing test reproducing the bug → debug systematically → fix root cause → test proves it.
- **simplify-code + requesting-code-review:** Run simplify-code after implementing, then requesting-code-review before committing.
