---
name: achievements
description: Achievements system — tracks, tiers, progress, UI.
---

# Achievements System

## Architecture

- **`server/src/game/achievements.ts`** — track definitions (`ACHIEVEMENT_TRACKS`), `getTrackTier()`, `TRACK_MAP`
- **`server/src/routes/achievements.ts`** — `checkAchievement()`, `trackIncome()`, API routes
- **`client/src/components/AchievementsBlock.tsx`** — collapsible block under BuffsBlock in LeftSidebar
- **DB**: `user_achievements` (user_id, track, progress, highest_tier, achieved_at), `users.total_income`

## Track Definition

```typescript
export interface AchievementTrack {
    key: string;       // 'pvp_wins', 'pve_wins', etc.
    name: string;      // 'PvP побед'
    icon: string;      // '⚔'
    description: string;
    tiers: AchievementTier[];  // 5 tiers: 1=bronze, 2=silver, 3=gold, 4=diamond, 5=legend
}

export interface AchievementTier {
    tier: number;      // 1-5
    name: string;      // 'Бронза'
    icon: string;      // '🥉'
    threshold: number; // progress needed
}
```

## Adding tracking to a route

```typescript
import { checkAchievement, trackIncome } from './achievements';

// After action completes:
checkAchievement(userId, 'track_key').catch(() => {});

// For income (not donate/transfers):
trackIncome(userId, amount).catch(() => {});
```

## API

- `GET /api/achievements` — all tracks with progress, tiers, achieved_at
- `GET /api/achievements/:userId` — public view (only earned, highest_tier > 0)

## Client: AchievementsBlock

- Uses `<Card className="mt-4 w-full">` (match BuffsBlock/StatAllocation style)
- Collapsed by default, `▶/▼` toggle
- `max-h-[11.5rem] overflow-y-auto pr-1` — scrollable, 5 rows visible
- Icons: fixed width `w-5 text-center flex-shrink-0`
- Progress shown as `fmtNum(progress)/fmtNum(maxThreshold)`: 1к, 5М
- 5-segment progress bar per track with tier colors
- Tooltip on hover (desktop) / long-press 500ms (mobile): `createPortal` to `document.body` with `position:fixed` to avoid clipping by overflow container
- Tooltip shows: `{name}: {progress}` + `Следующий: {icon} {tierName} — {threshold}`
- Context menu blocked on mobile via `onContextMenu={e => e.preventDefault()}`
- Integrated in `LeftSidebar.tsx` after BuffsBlock

## Profile: achievements section

`client/src/pages/ProfilePage.tsx`:
- Score only: `🏆 Достижения — {score} очк.` in stats column (right side, alongside PvP/PvE/etc)
- Score = sum of `highest_tier` across all earned tracks: 🥉=1, 🥈=2, 🥇=3, 💎=4, 👑=5 (max 55)
- Fetches from `GET /api/achievements/:userId` → `data.score`
- **DO NOT** put achievements under the character card (left side) — was tried and immediately reverted
- **DO NOT** show the full list in profile — user explicitly asked to keep only the score

## Backfill

```sql
INSERT INTO user_achievements (user_id, track, progress, highest_tier, achieved_at)
SELECT id, 'pvp_wins', COALESCE(wins::integer, 0), 0, '{}' FROM users WHERE id > 0
ON CONFLICT (user_id, track) DO UPDATE SET progress = EXCLUDED.progress;

UPDATE user_achievements SET highest_tier =
  CASE WHEN progress >= 100000 THEN 5 WHEN progress >= 25000 THEN 4
       WHEN progress >= 2500 THEN 3 WHEN progress >= 250 THEN 2 WHEN progress >= 10 THEN 1 ELSE 0 END
WHERE track = 'pvp_wins';
-- Repeat for all tracks with their thresholds (×10 for most, collection/level unchanged)
```

Income backfill: `UPDATE users SET total_income = COALESCE(totalpvemoneywon,0) + COALESCE(totalpvpmoneywon,0) + COALESCE(totaljobmoney,0);`
Collection backfill: **MUST use the `collections` table** (`SELECT COUNT(*) FROM collections WHERE userid = ...`), NOT inventory/equipment JSON. Using `jsonb_array_elements(inventory::jsonb)` gives wrong counts (only current inventory, not historical).
Massacre backfill: count only `alive = true` from `massacre_participants`, not all participations. Winner IS a survivor — no separate +1.

## Current Tracks & Thresholds (×10 multiplier applied 2026-07-31, except collection/level)

| Track | 🥉 | 🥈 | 🥇 | 💎 | 👑 |
|-------|----|----|----|----|----|
| pvp_wins | 10 | 250 | 2.5k | 25k | 100k |
| pve_wins | 10 | 500 | 5k | 50k | 250k |
| craft | 10 | 250 | 1k | 5k | 25k |
| training | 10 | 250 | 1k | 5k | 20k |
| income | 5k | 50k | 500k | 5M | 50M |
| casino | 10 | 250 | 1k | 5k | 20k |
| massacre | 10 | 250 | 1k | 5k | 20k |

**Massacre renamed to ЛК (Лотерея Крови) with icon 🩸, 2026-07-31.**
| collection | 10 | 50 | 100 | 150 | 225 |
| auction | 10 | 250 | 1k | 5k | 20k |
| tournament | 10 | 50 | 250 | 1k | 2.5k |
| level | 10 | 25 | 50 | 75 | 100 |

Income tracks only game earnings — NOT donations or player transfers.
**collection** and **level** are NOT multiplied — collection depends on total in-game items, level max is 100.

## Season System (TODO)

- Leaderboard reset on 20th of each month
- Seasonal achievements: champion (#1), podium (top-3), warrior (top-10)
- Stored with `season_label` (e.g. 'Июль 2026')
- Rewards: titles, premium days, silver

## Pitfalls

- `checkAchievement` uses `ON CONFLICT ... DO UPDATE` — must have UNIQUE(user_id, track) constraint
- `trackIncome` must be called AFTER `money = money + N`, pass post-tax amount
- Income from donations/transfers must NOT call trackIncome
- AchievementsBlock fetches on `character?.id` change
- `fmtNum()`: ≥1M → "1.5М", ≥1000 → "1.5к", else raw number
- Tier colors: bronze=#cd7f32, silver=#aaa, gold=#f59e0b, diamond=#e0245e
- **Tooltip clipping:** tooltips inside `overflow-y-auto` get clipped. Fix: `createPortal` to `document.body` with `position:fixed` + `getBoundingClientRect()`
- **Stray parenthesis in JSX patches:** when editing className strings, a `)` can slip after `>` — renders as literal character at top of list. Double-check after every patch.
- **Public endpoint** returns `tiers` array (thresholds) for profile display — added separately from initial implementation
- **touchstart preventDefault spam:** calling `e.preventDefault()` on `touchstart` while page is scrolling floods console with `[Intervention] Ignored attempt to cancel a touchstart event with cancelable=false`. Fix: omit `preventDefault`, rely on `onContextMenu={e => e.preventDefault()}` for blocking native context menu.
- **Collection backfill:** MUST use `collections` table, not JSON parsing of inventory/equipment. Using JSON gives wrong counts (only current state, not history).
- **Massacre tracking:** count only `alive=true` from `massacre_participants`. All survivors get +1 (including winner — no double count).
- **Massacre backfill MUST JOIN massacre_events:** just counting `alive=true` from `massacre_participants` includes cancelled and gathering events → inflated count (e.g. 5 instead of 3). The profile stats query correctly filters `me.status = 'finished'`. Achievements must match:
  ```sql
  SELECT COUNT(*) FROM massacre_participants mp 
  JOIN massacre_events me ON mp.event_id = me.id
  WHERE mp.user_id = ? AND mp.alive = true AND me.status = 'finished';
  ```
- **Threshold change → MUST recalculate highest_tier in DB.** Changing `ACHIEVEMENT_TRACKS` thresholds does NOT update existing `user_achievements.highest_tier`. Players keep their old tier even if it no longer matches the new thresholds. After ANY threshold change, run an UPDATE on VPS:
  ```sql
  UPDATE user_achievements SET highest_tier = 
    CASE 
      WHEN track = 'track_key' THEN CASE WHEN progress >= <t5> THEN 5 WHEN progress >= <t4> THEN 4 ... END
      ...
      ELSE highest_tier
    END
  WHERE track IN ('changed_tracks');
  ```
  Client needs Ctrl+Shift+R after.
