---
name: mmo-achievements
description: "MMO achievements: 11 tracks, 5 tiers, tracking, UI block."
---

# MMO Arena — Achievement System

## Architecture

- **Tracks config:** `server/src/game/achievements.ts` — 11 tracks × 5 tiers, `getTrackTier()`, `ACHIEVEMENT_TRACKS`
- **Routes:** `server/src/routes/achievements.ts` — `checkAchievement()`, `trackIncome()`, GET endpoints
- **DB:** `user_achievements` (user_id, track, progress, highest_tier, achieved_at), `users.total_income`
- **Client:** `AchievementsBlock.tsx` — in LeftSidebar under BuffsBlock, collapsed by default

## Adding a new track

1. Add entry to `ACHIEVEMENT_TRACKS` in `server/src/game/achievements.ts` with key, name, icon, description, 5 tiers
2. Call `checkAchievement(userId, 'track_key').catch(() => {})` in the relevant route after the action
3. For income: call `trackIncome(userId, amount).catch(() => {})` — also updates `total_income` column

## Track definitions

| Key | Name | Icon | Tiers |
|-----|------|------|-------|
| pvp_wins | PvP побед | ⚔ | 1/25/250/2500/10000 |
| pve_wins | PvE побед | 🐺 | 1/50/500/5000/25000 |
| craft | Крафт | 🔨 | 1/25/100/500/2500 |
| training | Тренировки | 🏋️ | 1/25/100/500/2000 |
| income | Доход | 💰 | 500/5k/50k/500k/5M |
| casino | Казино | 🎰 | 1/25/100/500/2000 |
| massacre | Резня | 💀 | 1/25/100/500/2000 |
| collection | Коллекция | 📦 | 10/50/100/150/189 |
| auction | Аукцион | 📦 | 1/25/100/500/2000 |
| tournament | Турниры | 🏆 | 1/5/25/100/250 |
| level | Уровень | ⭐ | 10/25/50/75/100 |

Tiers: 🥉(1) 🥈(2) 🥇(3) 💎(4) 👑(5)

## Tracking pattern

```typescript
import { checkAchievement, trackIncome } from './achievements';

// After successful action:
checkAchievement(userId, 'track_key').catch(() => {});
// For earned gold (not donations/transfers):
if (goldAmount > 0) trackIncome(userId, goldAmount).catch(() => {});
```

Always use `.catch(() => {})` — achievements must not break main flow.

## Все 11 треков заведены (2026-07-28)

Все треки теперь вызывают `checkAchievement` в соответствующих точках кода:

| Key | Файл | Где вызывается |
|-----|------|---------------|
| pvp_wins | `battle.ts` | Атакующий победитель + защитник победитель |
| pve_wins | `mobs.ts` | После победы над мобом |
| craft | `craft.ts` | 3 точки: крафт рецепта, улучшение, улучшение с рейтингом |
| training | `training.ts` | После тренировки |
| income | `achievements.ts` → `trackIncome()` | Везде где доход |
| casino | `casino.ts` | 4 точки завершения игр |
| massacre | `massacre.ts` | Для выживших в резне |
| collection | `collections.ts` | После INSERT в коллекцию |
| auction | `auction.ts` | 3 точки: expired, buyout, partial (sellerId) |
| tournament | `tournament.ts` | finishTournament + finishTournamentTx (winnerId) |
| level | `db/helpers.ts` → `applyExp()` | `setAchievementProgress(id, 'level', level)` при gained>0 |

## setAchievementProgress — абсолютное значение вместо инкремента

Для треков где прогресс = текущее значение (не инкремент), например уровень персонажа:

```typescript
// achievements.ts — новая функция
export async function setAchievementProgress(userId: number, trackKey: string, value: number): Promise<void> {
    const track = TRACK_MAP.get(trackKey);
    if (!track) return;

    // UPSERT с SET progress = value (не progress + value)
    await db.run(
        `INSERT INTO user_achievements (user_id, track, progress, highest_tier, achieved_at)
         VALUES ($1, $2, $3, 0, '{}'::jsonb)
         ON CONFLICT (user_id, track) DO UPDATE SET progress = $3`,
        [userId, trackKey, value]
    );
    // ... затем проверка tier ...
}

// В месте вызова (applyExp в db/helpers.ts):
if (gained > 0) {
    import('../routes/achievements').then(m =>
        m.setAchievementProgress(userId, 'level', level)
    ).catch(() => {});
}
```

Используется ТОЛЬКО для level-трека. Остальные используют `checkAchievement()` с инкрементом.

## Полная синхронизация (backfill)

При расхождении прогресса с реальной статистикой — синхронизировать ВСЕ треки одним запросом:

## UI patterns (AchievementsBlock)

- Use `<Card className="mt-4 w-full">` — matches StatAllocation/BuffsBlock
- Fixed icon width: `w-5 text-center flex-shrink-0` (prevents ⚔ misalignment)
- Scroll: `max-h-[11.5rem] overflow-y-auto pr-1` (5 rows, pr-1 prevents scrollbar overlap)
- Number formatting: `fmtNum()` — ≥1000 → "1.5к", ≥1000000 → "5М"
- Tooltip: `onMouseEnter`/`onMouseLeave` (desktop), `onTouchStart` timeout 500ms + `onContextMenu preventDefault` (mobile)
- Tooltip content: current progress + next tier with threshold

## camelRows

Add in `db/index.ts`:
```
.replace(/^total_income$/i, 'totalIncome')
```

## Character response

`routes/character.ts` returns `totalIncome: user.totalIncome || 0`.

## Income tracking rules

- ✅ Track: PvE gold, PvP stolen gold, job rewards, quest rewards, auction sales, bank interest, salary
- ❌ Don't track: donations, player-to-player transfers, admin-granted money

## Score system

Each tier gives points: 🥉=1, 🥈=2, 🥇=3, 💎=4, 👑=5. Total = sum of `highest_tier` across all tracks (max 55).

### API response format

**Public endpoint** `GET /api/achievements/:userId`:
```json
{
  "achievements": [{ "key": "pvp_wins", "name": "PvP побед", "icon": "⚔", "progress": 143, "highestTier": 2, "currentTier": { "tier": 2, "name": "Серебро", "icon": "🥈" }, "tiers": [...] }],
  "score": 24
}
```

**Own endpoint** `GET /api/achievements` — returns flat array with `tiers` (includes `achieved`/`current` booleans) and `achievedAt`. Used by AchievementsBlock.

### Profile display

Score shown in stats column as `🏆 Достижения — {score} очк.` (no list). Fetch from `/api/achievements/:userId`, use `data.score`.

```tsx
const [achScore, setAchScore] = useState(0);
fetch(`/api/achievements/${userId}`, { headers: getHeaders() })
  .then(r => r.json())
  .then(data => { if (data?.score !== undefined) setAchScore(data.score); });

// In JSX:
{achScore > 0 && (
  <h3>🏆 Достижения — {achScore} очк.</h3>
)}
```

## Season system (planned, not built)

- Monthly reset on the 20th (project started July 20)
- Top 1/3/10 get seasonal achievements with month label

## Floors / difficulty groups (2026-07-25)

Floors are grouped by difficulty in the UI using `DIFF_MAP` in `server/src/setupRoutes.ts`:

```typescript
const DIFF_MAP: Record<string,number> = {
    'Склеп':0,'Подземелье':0,'Катакомбы':0,'Деревня Пепла':0,
    'Лес Черепов':1,'Старый Тракт':1,'Ядовитые луга':1,'Первый ярус':1,
    'Гнилая Топь':2,'Чёрный Монастырь':2,'Башня Плакальщиц':2,'Некрополь Королей':2,
    'Бездонный Овраг':3,'Врата Бездны':3,
    'Огненные чертоги':4,'Тронный зал':4,
    'Ледяная бездна':5,'Престол падших':5,
};
const DIFF_LABELS = ['Легко','Нормально','Сложно','Ад I','Ад II','Ад III'];
const DIFF_ICONS = ['🟢','🟡','🟠','🔴','🔴','🔴'];
```

Ад II and Ад III are hidden from regular players (only visible to user TODD, id=314):
```tsx
// BestiaryPage.tsx — filter out empty difficulty groups
if (groupFloors.length === 0 && user?.username !== 'TODD') return null;
```

New Ад floors have 2 sub-levels each:
- Ад II: Огненные чертоги (110-115), Тронный зал (118-122)
- Ад III: Ледяная бездна (125-135), Престол падших (140)

Mobs are stored in `mobs` table with their `location` field matching the floor name exactly.

### Floor naming rules (from user corrections)

- Short names only: «Огненные чертоги», not «Ад II, Уровень 1 — Огненные чертоги»
- Don't rename existing floors — only add new ones
- Don't create difficulty categories user didn't ask for (e.g. «Трудно» — created then removed)
- Floors are flat (no parent/child), grouped only by DIFF_MAP in code
- Ад II/III visible only to TODD (username check, not id=1 user check)

### Loot tiers for 100+ mobs

- Смерть (100): gold 400-800, XP 2, 30% leg / 70% mythic
- Ад II (110-122): gold 400-800, XP 3, 45% leg / 50% mythic
- Ад III (125-140): gold 500-1000, XP 4, 20% leg / 80% mythic
- 5% junk upgrade stone already works via existing mobs.ts code

## Floors / difficulty groups (2026-07-25)

Floors are grouped by difficulty in the UI using `DIFF_MAP` in `server/src/setupRoutes.ts`:

```typescript
const DIFF_MAP: Record<string,number> = {
    'Склеп':0,'Подземелье':0,'Катакомбы':0,'Деревня Пепла':0,
    'Лес Черепов':1,'Старый Тракт':1,'Ядовитые луга':1,'Первый ярус':1,
    'Гнилая Топь':2,'Чёрный Монастырь':2,'Башня Плакальщиц':2,'Некрополь Королей':2,
    'Бездонный Овраг':3,'Врата Бездны':3,
    'Огненные чертоги':4,'Тронный зал':4,
    'Ледяная бездна':5,'Престол падших':5,
};
const DIFF_LABELS = ['Легко','Нормально','Сложно','Ад I','Ад II','Ад III'];
const DIFF_ICONS = ['🟢','🟡','🟠','🔴','🔴','🔴'];
```

Ад II and Ад III are hidden from regular players (only visible to user TODD, id=314):
```tsx
// BestiaryPage.tsx
if (groupFloors.length === 0 && user?.username !== 'TODD') return null;
```

New Ад floors have 2 sub-levels each:
- Ад II: Огненные чертоги (110-115), Тронный зал (118-122)
- Ад III: Ледяная бездна (125-135), Престол падших (140)

Mobs are stored in `mobs` table with their `location` field matching the floor name exactly.

## Auction history pagination (2026-07-25)

Server endpoint: `GET /auction/history?page=1&limit=10` returns `{ history, total, page, totalPages }`.

## Auction partial buyout bid refund (2026-07-25)

When a stack lot has a current bid and someone buys part, the difference is refunded:
```typescript
if (lot.currentBidderId && newCurrentBid && newCurrentBid < lot.currentBid) {
    const refund = lot.currentBid - newCurrentBid;
    await db.run('UPDATE users SET money = money + ? WHERE id = ?', [refund, lot.currentBidderId]);
}
```

## Guild quest persistence (2026-07-25)

Guild quest options persist across page reloads via `guilds.quest_options` JSONB:
- GET: return stored options if available, else generate and store
- TAKE: clear quest_options (`'[]'`)
- Use `?` placeholders in db.run (not `$1`)

```sql
ALTER TABLE guilds ADD COLUMN IF NOT EXISTS quest_options JSONB DEFAULT '[]';
```

## Content 100+ (Ад II/III, sets, artifacts) — status

Full design: `IDEAS.md`. DB status (2026-07-25):
- **5 resources** in craft_items (type='material'): Кровь демона, Эссенция гнева, Пыльца фей, Кристалл душ, Чешуя василиска
- **4 artifacts** in items (rarity 7): Кольцо вампира, Амулет ярости, Подкова удачи, Талисман стойкости
- **32 set items** in items (rarity 6): 8 sets × 4 items
- **8 new mobs** in mobs (Ад II 110-122, Ад III 125-140)
- **4 new floors**: Огненные чертоги, Тронный зал, Ледяная бездна, Престол падших
- Items given to TODD (id=314) via sql jsonb_build_object aggregation

NOT done: drop logic, artifact crafting, set bonus calculation.

## User preferences

- «не торопись» — wait for explicit instruction before starting complex multi-step work (floors, mobs)
- Может попросить откатить — «верни предыдущий вариант» → `git revert HEAD`
- «стоп. верни все как было» — немедленно остановиться и откатить БД + код
- Короткие названия этажей — только описательное имя («Огненные чертоги»)
- Не переименовывать существующие этажи — только добавлять новые
- Не выдумывать категории без спроса — удалить если откатили
- Статистика достижений в профиле **справа** в колонке статов (не под карточкой)
- Профиль десктоп: сетка 2-3 колонки Card, CharacterCard + инфо-блок в ряд сверху
- Инфо-блок (достижения/дата/кнопка): справа от CharacterCard, по центру (`justify-center`, `sm:items-stretch`)
- Тултипы через portal в body (не обрезаются overflow-контейнерами)
- Иконки достижений: фиксированная ширина `w-5`
- НЕ вызывать `preventDefault()` на touchstart — passive, будет спамить в консоль

## User preferences

- «не торопись» — wait for explicit instruction before starting complex multi-step work
- Может попросить откатить («верни предыдущий вариант») — использовать `git revert HEAD`
- «не торопись» — ждать явной команды перед сложной многошаговой работой (этажи, мобы). Не начинать без «давай»/«делай».
- Короткие названия этажей — только описательное имя без префиксов («Огненные чертоги», не «Ад II, Уровень 1 — Огненные чертоги»)
- Не переименовывать существующие этажи — только добавлять новые
- Не выдумывать категории без спроса («Трудно», под-группировки) — удалить если откатили
- Статистика достижений в профиле — **справа** в колонке статов (не под карточкой персонажа). Перенос под карточку был откачен.
- Профиль на десктопе: сетка 2-3 колонки карточек (`grid sm:grid-cols-2 lg:grid-cols-3`), каждая секция статистики — отдельная Card
- Информационный блок (достижения/дата/кнопка) — справа от CharacterCard, выровнен по центру (`justify-center`, `sm:items-stretch` на родителе)
- Тултипы — через portal в body, не обрезаются скроллом
- Иконки достижений — фиксированная ширина `w-5` чтобы строки были ровные

## Backfill achievements for existing players

When adding a new track or after initial deploy, recalculate for all users:

```sql
-- Insert progress from existing columns
INSERT INTO user_achievements (user_id, track, progress, highest_tier, achieved_at)
SELECT id, 'pvp_wins', COALESCE(wins::integer, 0), 0, '{}'
FROM users WHERE id > 0
ON CONFLICT (user_id, track) DO UPDATE SET progress = EXCLUDED.progress;

-- Recalculate highest_tier for the track
UPDATE user_achievements SET highest_tier =
  CASE WHEN progress >= 10000 THEN 5 WHEN progress >= 2500 THEN 4
       WHEN progress >= 250 THEN 3 WHEN progress >= 25 THEN 2
       WHEN progress >= 1 THEN 1 ELSE 0 END
WHERE track = 'pvp_wins';
```

### Collection backfill (CRITICAL)

Collection MUST use the `collections` table, NOT inventory JSON:
```sql
UPDATE user_achievements ua SET progress = (
  SELECT COUNT(*) FROM collections c WHERE c.userid = ua.user_id
) WHERE track = 'collection';
```

Using `jsonb_array_elements(inventory::jsonb)` gives wrong counts (only current inventory, not historical).

### Income backfill

Sum historical money fields:
```sql
UPDATE users SET total_income = 
  COALESCE(totalpvemoneywon::integer, 0) + 
  COALESCE(totalpvpmoneywon::integer, 0) + 
  COALESCE(totaljobmoney::integer, 0);
```

### Massacre backfill

```sql
-- MUST filter by alive=true AND status='finished'
UPDATE user_achievements ua SET progress = (
  SELECT COUNT(*) FROM massacre_participants mp 
  JOIN massacre_events me ON mp.event_id = me.id
  WHERE mp.user_id = ua.user_id AND mp.alive = true AND me.status = 'finished'
) WHERE track = 'massacre';

-- NOT just COUNT(*) — that counts all participations including non-finished events.
```

### Massacre: no double-count for winner

The winner IS the last survivor. One `if (s.alive)` check inside the participant loop covers all survivors including the winner:
```typescript
for (const [userId, s] of state) {
    if (s.alive) {
        checkAchievement(userId, 'massacre').catch(() => {});
    }
}
// Do NOT add a separate checkAchievement(winnerId, 'massacre') — it would double-count.
```

## Profile page placement

Achievements are shown in the **right stats column** (alongside PvP/PvE/etc stats), NOT under the character card. Moving them under the character card was tried and immediately reverted by the user. Keep them in the stats column.

Profile layout: on desktop, stats sections use a card grid — 2 cols on tablet, 3 cols on wide screens (`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3`). Each stat section is a `<Card>` with a colored header and `<StatItem>` rows. CharacterCard + achievements/date/message-button are in a flex row above the grid, with the info block vertically centered (`justify-center`) and items aligned center (not start):
```tsx
<div className="flex flex-col sm:flex-row items-center sm:items-stretch gap-6 w-full justify-center">
  <CharacterCard ... />
  <div className="flex flex-col items-center justify-center gap-3 min-w-[160px]">
    {achScore > 0 && <div>🏆 Достижения — {achScore} очк.</div>}
    {profile.createdAt && <div>Дата регистрации: {date}</div>}
    {isOtherUser && <Button>Написать сообщение</Button>}
  </div>
</div>
<div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
  <StatSection title="PvP" ...>...</StatSection>
  ...
</div>
```

Container width: `max-w-4xl` (was `max-w-2xl` before grid layout).

**Pitfall:** right info block must use `sm:items-stretch` (not `sm:items-start`) on the parent flex row so the info column stretches to match CharacterCard height, then `justify-center` centers content vertically within.

## Guild quest persistence

Guild quest options now persist across page reloads via `guilds.quest_options` JSONB column (`ALTER TABLE guilds ADD COLUMN quest_options JSONB DEFAULT '[]'`).

- On first GET /guild/quest: generate 3 options, store in quest_options
- On subsequent GETs: return stored options (don't regenerate)
- On POST /guild/quest/take: clear quest_options (`'[]'`)
- Use `?` placeholders in db.run (not `$1`)

## Tooltip patterns

### Overflow clipping fix
Tooltips inside `overflow-y-auto`/`overflow-hidden` containers get clipped.
**Fix:** render tooltip via `createPortal(..., document.body)` with `position: fixed`.

```tsx
import { createPortal } from 'react-dom';

{showTooltip && rowRef.current && createPortal(
  <div className="fixed z-[100] pointer-events-none"
    style={{
      top: rowRef.current.getBoundingClientRect().top - 8,
      left: rowRef.current.getBoundingClientRect().left + rowRef.current.getBoundingClientRect().width / 2,
      transform: 'translate(-50%, -100%)',
    }}>
    {/* tooltip content */}
  </div>,
  document.body
)}
```

### Mobile long-press (no context menu)

```tsx
// Do NOT call e.preventDefault() on touchstart — it's passive and will spam
// "Ignored attempt to cancel a touchstart event with cancelable=false" in console.
const handleTouchStart = () => {
  longPressRef.current = setTimeout(() => setShowTooltip(true), 500);
};
const handleTouchEnd = () => clearLongPress();
const handleTouchMove = () => clearLongPress();
const handleContextMenu = (e: React.MouseEvent) => {
  e.preventDefault();  // block native context menu
  setShowTooltip(true);
};
```

### Tooltip content
Show current progress + next tier with threshold:
"PvP побед: **5**"
"Следующий: 🥈 Серебро — 25"
Or "Все уровни получены!" if maxed.

## Icon width pitfall

Some emoji (e.g. ⚔) are narrower than others (🐺), causing misaligned rows.
**Fix:** `w-5 text-center flex-shrink-0` on the icon container.

## Content 100+ (Ад II/III, sets, artifacts)

Full design: `IDEAS.md` in project root.

### DB status (2026-07-25)

- **5 resources** in `craft_items` (type='material', rarity 6): Кровь демона, Эссенция гнева, Пыльца фей, Кристалл душ, Чешуя василиска
- **4 artifacts** in `items` (rarity 7, slots amulet/ring/belt): Кольцо вампира, Амулет ярости, Подкова удачи, Талисман стойкости
- **32 set items** in `items` (rarity 6, all slots): 8 sets × 4 items
- **8 new mobs** in `mobs` (Ад II 110-122, Ад III 125-140)
- **4 new floors** in `floors`: Огненные чертоги, Тронный зал, Ледяная бездна, Престол падших

### What's NOT done

- Drop logic for rare resources (5% from mobs) — code was written then reverted
- Artifact crafting — not implemented
- Set bonus calculation — not implemented
- Set items don't drop yet
- No images for resources

### Floor naming rules (from user corrections)

- Short names only: «Огненные чертоги», not «Ад II, Уровень 1 — Огненные чертоги»
- Don't rename existing floors — only add new ones
- Don't create difficulty categories user didn't ask for (e.g. «Трудно» — created then removed)
- Floors are flat (no parent/child), grouped only by DIFF_MAP in code
- Ад II/III visible only to TODD (username check, not id=1)

### Loot tiers for 100+ mobs

- Смерть (100): gold 400-800, XP 2, 30% leg / 70% mythic
- Ад II (110-122): gold 400-800, XP 3, 45% leg / 50% mythic
- Ад III (125-140): gold 500-1000, XP 4, 20% leg / 80% mythic
- 5% junk upgrade stone already works via existing mobs.ts code
