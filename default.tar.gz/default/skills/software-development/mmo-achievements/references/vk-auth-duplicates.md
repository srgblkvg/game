# VK Auth — duplicate character fix

## Problem
Player logs in via VK but lands on a new/fresh character instead of their existing one.

## Diagnosis
```sql
SELECT id, username, oauthprovider, oauthid FROM users WHERE username ILIKE '%<name>%';
```
If `oauthprovider` and `oauthid` are NULL for the main character, the VK auth lookup fails:
```typescript
// vkBridgeAuth.ts:
SELECT id FROM users WHERE oauthProvider = 'vk' AND oauthId = ?
```
Returns nothing → creates a new user.

## Fix
```sql
UPDATE users SET oauthprovider = 'vk', oauthid = '<vk_user_id>' WHERE id = <main_char_id>;
DELETE FROM users WHERE id = <dup_id>;
```

## Pitfalls
- `oauthProvider = 'vk'` — NOT 'vkontakte'
- VK user ID is in login URL params as `vk_user_id`
- If user has forum posts → FK constraint → use UPDATE to reset stats instead of DELETE
