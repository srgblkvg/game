# AchievementsBlock UI — Accepted Patterns

This documents the style corrections the user made during development.

## Container

```tsx
<Card className="mt-4 w-full" data-tutorial="achievements">
```

Uses `<Card>` component (NOT raw divs). `mt-4 w-full` matches StatAllocation and BuffsBlock exactly.

## Header

```tsx
<div className="flex items-center justify-between cursor-pointer select-none" onClick={toggle}>
    <h3 className="text-sm font-semibold">{collapsed ? '▶' : '▼'} 🏆 Достижения</h3>
    <span className="text-xs text-[var(--color-text-muted)]">{earned}/{total}</span>
</div>
```

## Scroll container

```tsx
<div className="mt-2 space-y-2 max-h-[11.5rem] overflow-y-auto pr-1">
```

- `max-h-[11.5rem]` = exactly 5 rows with progress bars
- `pr-1` = prevents scrollbar from overlapping the progress numbers
- No "ещё N" button — user rejected that approach

## Row layout

```tsx
<div className="flex items-center gap-2 text-xs">
    <span className="text-base w-5 text-center flex-shrink-0">{icon}</span>
    <div className="flex-1 min-w-0">...</div>
    <span className="text-[0.6rem] text-[var(--color-text-muted)] whitespace-nowrap">{label}</span>
</div>
```

- Fixed icon width `w-5 text-center flex-shrink-0` = essential for alignment (⚔ is narrower than other emojis)
- Progress numbers right-aligned with `whitespace-nowrap`

## Number formatting

```typescript
function fmtNum(n: number): string {
    if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'М';
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'к';
    return String(n);
}
```

User explicitly asked: "1000 сократить до 'к.'"

## Tooltip

Desktop: `onMouseEnter={() => setShowTooltip(true)}` / `onMouseLeave={() => setShowTooltip(false)}`

Mobile: 
```tsx
const handleTouchStart = () => {
    longPressRef.current = setTimeout(() => setShowTooltip(true), 500);
};
const handleTouchEnd = () => clearLongPress();
const handleContextMenu = (e) => { e.preventDefault(); setShowTooltip(true); };
```

Tooltip shows:
- Current value
- Next unearned tier with icon, name, and threshold
- If all tiers earned: "Все уровни получены!"

## Progress bar colors

```
Bronze (1):  #cd7f32
Silver (2):  #aaa
Gold (3):    #f59e0b
Diamond (4): #e0245e
Legend (5):  #e0245e
Unearned:    var(--color-border-default) at opacity 0.3
```

Current tier = full opacity, other earned = 0.8 opacity.
