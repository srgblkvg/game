# Equip Set Recursing (script pattern)

## When to use
When the user wants to create, modify, or recuse equipment items for a specific player — apply curses, change sets, create new builds.

## Script setup
Create script in `server/src/scripts/` (must be under src/ — tsconfig rootDir restriction).

## Pattern

```typescript
// @ts-nocheck
import { db } from '../db/index';

async function main() {
  const userId = TARGET_ID;
  
  // Read current equipment (handle JSONB vs TEXT)
  const user = await db.one('SELECT equipment, equipment_1, equipment_2, equipment_3 FROM users WHERE id = ?', [userId]) as any;
  const parseEq = (v: any) => typeof v === 'string' ? JSON.parse(v || '{}') : (v && typeof v === 'object' ? v : {});
  
  // Modify equipment
  const eq = parseEq(user.equipment_1);
  for (const key of Object.keys(eq)) {
    eq[key].curseStat = 's';
    eq[key].curseValue = 35;
    eq[key].curseRank = 3;
    eq[key].curseName = 'III';
    eq[key].curseColor = '#a855f7';
  }
  
  // Save back
  const eqStr = JSON.stringify(eq);
  await db.run('UPDATE users SET equipment = ?, equipment_1 = ?::jsonb WHERE id = ?', [eqStr, eqStr, userId]);
  
  // Or create new items for overflow storage
  const item = {
    id: Date.now(),
    name: 'Item Name',
    slot: 'helmet',
    rarity_id: 6,
    rarity_display: 'Мифический',
    rarity_color: '#e74c3c',
    bonuses: { s: 0, a: 26, d: 0, m: 20 },
    extra: { set: 'Буревестник', crit: 0, dodge: 0, counter: 0, fullBlock: 0, ... },
    image: 'helmet/helmet_yellow.webp',
    upgradeLevel: 6,
    curseStat: 's', curseValue: 40, curseRank: 4, curseName: 'IV', curseColor: '#f97316',
  };
  await db.run('INSERT INTO overflow_storage (userid, item, createdat) VALUES (?, ?, ?)',
    [userId, JSON.stringify(item), Math.floor(Date.now() / 1000)]);
}

main().catch(e => { console.error(e); process.exit(1); });
```

## Deploy and run

```bash
cd server && npx tsc
rsync -avz dist/ root@194.226.142.237:/opt/game/server/dist/
ssh root@194.226.142.237 "cd /opt/game/server && node dist/scripts/<name>.js"
```

## Key gotchas
- Use `// @ts-nocheck` at top — script objects don't need strict typing
- JSONB columns: read as objects, write with `?::jsonb` cast
- TEXT `equipment` column: needs JSON.stringify for writes, JSON.parse for reads
- Don't forget `?::jsonb` in UPDATE statements for JSONB columns
- Scripts run on VPS, not locally — must rsync dist/ first
