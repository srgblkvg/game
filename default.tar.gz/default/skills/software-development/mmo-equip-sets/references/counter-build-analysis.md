# Counter-Build Analysis Methodology

## When to counter-build
- Opponent wins repeatedly in arena despite similar level
- Opponent has clear stat dominance in one area (e.g., extreme D + fullBlock)
- You know opponent's equipment from battle logs or profile

## Analysis Steps

### 1. Identify opponent's defensive layer
Read battle logs to determine what's blocking your damage:

| Opponent defense | Signal in battle log | Counter |
|---|---|---|
| High D (block) | "Блок (-NNN)" reduces damage by 60-80% | **blockPen** (Крушитель), raw S damage |
| High fullBlock | "ПОЛНЫЙ БЛОК! Урон: 0" appears often | **Dodge** to avoid hit entirely; **Execute** (Жнец 4) ignores at <10% HP |
| High dodge | "Уклоняется!" frequent | **M** for dodge penalty (denominator 250); **Counter** to punish dodges |
| Counter/retaliation | "Отвечает ударом! Ответный урон: NNN" | **Vampirism** to sustain through chip damage |

### 2. Check set bonuses
Look at opponent's equipment sets in DB:
```sql
SELECT equipment FROM users WHERE id = <opponent_id>;
```
Identify active sets, calculate set bonus multipliers (see SKILL.md set bonus table).

### 3. Find slot conflicts
Some sets share slots and can't both go to 4/4:
- Буревестник (helmet/gloves/amulet/boots) vs Гладиатор (weapon1/shield/helmet/amulet) — conflict on helmet+amulet
- Крушитель (weapon1/shield/gloves/belt) vs Жнец (weapon1/chest/gloves/belt) — conflict on weapon1+gloves+belt

### 4. Build counter set

**Example: Sallarik (Stраж 4 + Берсерк 3)**
- D=1788 → block ~75%
- extra fullBlock=97 → 24% chance
- Counter: Буревестник 4 (dodge×1.2) + Крушитель 2 (blockPen 25%) + artifacts
- BlockPen drops 75% → ~56%. Dodge avoids fullBlock entirely.

### 5. Curse stat selection
- Counter-block build: curse **S** (raw damage to penetrate residual block)
- Dodge stack: curse **A** (diminishing after 2000), then **M** (crit + dodge pen)
- Mixed build with blockPen: curse **S** (damage is the win condition)

## Red Flags in Battle Logs
- FullBlock rate >20% of hits → opponent has extreme fullBlock build, dodge hard-counters
- Block rate >80% of non-fullBlock hits → opponent has high D, need blockPen
- Your dodge rate <15% when calculated >30% → opponent's M is high, case M instead of A
- Ответный удар appearing every 2-3 turns → opponent has Страж 4/4 (30% counter on hit)
