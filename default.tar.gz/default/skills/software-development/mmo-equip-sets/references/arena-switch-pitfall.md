# Arena Equip Switch Pitfall

После переключения таба экипировки на странице Арены **НЕ вызывать `loadOpponent`**.

Причина: смена экипировки не влияет на соперника — его статы считаются из БД независимо. А вызов `loadOpponent(true)` делает `GET /api/arena/opponent?change=true` что списывает 10 монет со счёта. Если денег нет — 400 Bad Request.

**Правильный обработчик (ArenaPage.tsx):**
```typescript
const handleSwitchSet = async (slot: number) => {
    if (slot === activeSlot) return;
    const res = await fetch('/api/character/switch-equip', {
        method: 'POST',
        headers: { ...getHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ slot }),
    });
    if (res.ok) {
        const { fetchCharacter } = await import('../../api/character');
        const fresh = await fetchCharacter();
        setCharacter(fresh);
        // loadOpponent НЕ вызывать — соперник не меняется
    }
};
```
