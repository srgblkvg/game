---
name: mmo-equip-sets
description: Equip sets, set bonus multipliers, item combo analysis.
---

# MMO Arena — Equip Sets & Item Analysis

## Equip Set Switching (I/II/III)

3 слота экипировки с переключением на карточке персонажа.

### DB
`users`: `equipment_1`, `equipment_2`, `equipment_3` (JSONB), `active_equip_slot` (INT DEFAULT 1). `equipment` — всегда активный сет.

Миграция: `UPDATE users SET equipment_1 = equipment::jsonb`.

### API
- `GET /character/me` → `equipment1/2/3`, `activeEquipSlot`
- `POST /character/switch-equip { slot }` — сохраняет текущий в старый слот, загружает новый
- `POST /character/save-equip-set { slot, equipment }` — сохраняет в слот

### Client
`CharacterCard` пропсы: `equipSets`, `activeEquipSlot`, `onSwitchSet`. Табы I/II/III над фреймом.
`LeftSidebar` вызывает API, обновляет character через setCharacter.

**Питфол:** `USER_BATTLE_FIELDS` читает `u.equipment` (всегда активный) — боевой код не меняется.

**Питфол JSONB vs TEXT:** `equipment` — TEXT (нужен JSON.parse), `equipment_1/2/3` — JSONB (pg-драйвер возвращает готовый объект). `JSON.parse(объект)` → `"[object Object]" is not valid JSON`. Хелпер: `v => typeof v === 'string' ? JSON.parse(v||'{}') : (v && typeof v === 'object' ? v : {})`. В UPDATE: `?::jsonb`.

**Питфол switch + state:** после switch-equip загружать character через `fetchCharacter()` целиком — ручное `setCharacter` с `data.equipment` оставляет старые `stats`, экран показывает неверные статы.

**Питфол equip/unequip + equipment_N рассинхрон (КРИТИЧЕСКИЙ):** `/character/equip` (inventory.ts) обновляет только колонку `equipment`, но НЕ `equipment_N` активного слота. `/character/me` читает сначала `equipment_N` (строка 35 character.ts), поэтому после F5 возвращается старая экипировка. Симптомы: «предмет ушёл в инвентарь, но дубликат остался», «после обновления страницы возвращается старая сборка», «нельзя снять забагованный предмет». **Фикс**: после UPDATE equipment в `/character/equip` всегда делать `UPDATE users SET equipment_N = ?::jsonb` для активного слота (N = active_equip_slot || 1). Обе ветки — equip и unequip.

## Item Creation & Recursing

Паттерн для массового создания/модификации предметов с проклятиями — Node.js скрипт на VPS. Подробнее: `references/equip-recursing.md`.

## Set Bonus Multipliers

Сет-бонусы — МНОЖИТЕЛИ к extra-статам, НЕ плоские проценты к шансам:

| Set | Tier | Effect |
|---|---|---|
| Буревестник 4/4 | "+20% уклонение" | `extra.dodge = Math.round(extra.dodge * 1.2)` |
| Страж 2/4 | "+10% блок" | `extra.fullBlock = Math.round(extra.fullBlock * 1.1)` |
| Гладиатор 2/4 | "+15% контратака" | `extra.counter = Math.round(extra.counter * 1.15)` |
| Дуэлянт 2/4 | "+10% контратака" | `extra.counter = Math.round(extra.counter * 1.1)` |
| Дуэлянт 3/4 | "+15% крит" | `extra.crit = Math.round(extra.crit * 1.15)` |

dodge=60 с Буревестником 4/4 → 72 → шанс 72/372=19.4% (не 16.7%+20%=36.7%).

## Available Set Slots

| Set | Slots |
|---|---|
| Буревестник | helmet, gloves, amulet, boots |
| Гладиатор | weapon1, shield, helmet, amulet |
| Берсерк | weapon1, gloves, boots, belt |
| Страж | helmet, chest, shield, ring |
| Крушитель | weapon1, shield, gloves, belt |
| Жнец | weapon1, chest, gloves, belt |
| Дуэлянт | weapon1, shield, ring, amulet |
| Отшельник | helmet, chest, boots, ring |

**Конфликт:** Буревестник и Гладиатор оба занимают helmet+amulet → нельзя оба на 4/4.

## Artifacts (rarity_id=7)

| Name | Slot | Effect | Extra |
|---|---|---|---|
| Кольцо вампира | ring | vampirism 5% | crit 22, counter 18 |
| Подкова удачи | belt | luck +5% all chances | crit 15, dodge 15, counter 10 |
| Талисман стойкости | amulet | resilience 30% | fullBlock 22 |
| Амулет ярости | amulet | rage +20% at HP<30% | crit 20, counter 20 |

**Подкова удачи:** +5 п.п. ко ВСЕМ шансам. Must-have в любой сборке.

## Stat Analysis

- **A > 2000:** база `A/(A+500)` уже ~82% — diminishing returns. Дальше качать M выгоднее.
- **M:** даёт крит И контр-уклонение `1-M/(M+250)`. Универсальнее A на высоких значениях.
- **D < 500:** персонаж получает полный урон врага. Даже dodge-сборке нужен минимум D.

## Curse Pitfall

curseValue **добавляется** к стату, не вычитается. «Проклятие» — чистый бафф. НЕ говорить «отъедает статы».

## Dodge Formula (updated)

```
dodge = A_def/(A_def+500) * (1 - M_atk/(M_atk+250)) / 1.5 + extraDodge/(extraDodge+300) + luckBonus
```
