---
name: curse-system
description: Проклятие предметов — Soul Crystal, ранги, UI крафта, статы.
---

# Curse System (Soul Crystal / Проклятие)

## Architecture

- **`server/src/routes/craft.ts`** — `POST /craft/curse` (preview), `POST /craft/curse/apply` (apply), `CURSE_RANKS`, `rollCurse()`
- **`server/src/game/stats.ts`** — `GameItem` fields (curseStat/Value/Rank/Name/Color), curse added to sums in `currentStats()`
- **`client/src/pages/CraftPage.tsx`** — curse UI: info block, button, confirm dialog, `curseInfo`/`curseConfirm` state
- **`client/src/components/ItemStats.tsx`** — curse display in tooltips
- **`client/src/components/Inventory.tsx`** — `typeLocalization`: soul_crystal → Материалы
- **DB**: `craft_items` (id=23, type='soul_crystal', rarity_id=6), mob drops via `MYTHIC_RESOURCE_DROPS`

## Curse Ranks

```typescript
const CURSE_RANKS = [
    { rank: 1, name: 'I', color: '#22c55e', min: 10, max: 20, weight: 70 },
    { rank: 2, name: 'II', color: '#3b82f6', min: 20, max: 30, weight: 15 },
    { rank: 3, name: 'III', color: '#a855f7', min: 30, max: 40, weight: 11 },
    { rank: 4, name: 'IV', color: '#f97316', min: 40, max: 50, weight: 3 },
    { rank: 5, name: 'V', color: '#ef4444', min: 50, max: 60, weight: 1 },
];
```

Cost: 100k silver + 1 Soul Crystal. Not scaled by upgrade level.

## API Flow (two-step)

1. `POST /craft/curse` `{ itemId }` — preview, no resources consumed.
   Returns `{ oldCurse, newCurse, needsConfirm }`.
2. If `needsConfirm`: client shows dialog with old vs new curse.
   - "Оставить" — closes dialog, nothing consumed.
   - "Заменить" — calls step 3.
3. `POST /craft/curse/apply` `{ itemId, crystalId, curse }` — consumes crystal + 100k, applies curse.
   Returns `{ success, inventory, moneyAfter, curse, oldCurse, message }`.

If no old curse (`needsConfirm=false`), client auto-calls step 3 immediately.

## Stats Integration

`currentStats()` in `game/stats.ts`: curse stat added OUTSIDE the upgrade multiplier loop:
```typescript
if (item.curseStat && item.curseValue && (PRIMARY_STATS as readonly string[]).includes(item.curseStat)) {
    sums[item.curseStat as keyof StatRecord] = (sums[item.curseStat as keyof StatRecord] || 0) + (item.curseValue || 0);
}
```

`GameItem` interface must include: `curseStat?, curseValue?, curseRank?, curseName?, curseColor?`.

## DB Setup

Soul crystal already exists in DB (id=23, type='material' originally). Must update:
```sql
UPDATE craft_items SET type = 'soul_crystal' WHERE id = 23;
```

Drops from Hell I-III bosses via `MYTHIC_RESOURCE_DROPS` (mob id=49 Инкуб, id=54 Серафим, 1% chance).

## Tooltip Display

`ItemStats.tsx`:
```tsx
{item.curseStat && item.curseValue > 0 && (
  <div style={{ color: item.curseColor }}>
    ☠ Проклятие {item.curseName}: +{item.curseValue} к {statNameRu[item.curseStat]}
  </div>
)}
```

## Pitfalls

- **Existing crystal had wrong type**: original crystal id=23 had `type='material'`, code expects `itemType='soul_crystal'`. Must update DB AND existing player inventories via node script.
- **isCraftItem check**: `handleItemClick` must allow `itemType === 'soul_crystal'` alongside `'upgrade'`.
- **Button bg color**: use solid `!bg-[#7c3aed]` not CSS var — `var(--color-accent-purple)` invisible in light theme.
- **Inventory grouping**: add `'soul_crystal': 'Материалы'` to `typeLocalization`.
- **Duplicate crystals**: there were two DB entries (id=23 material, id=25 soul_crystal). Duplicate deleted, id=23 updated.
