---
name: github
description: "Complete GitHub workflow: auth, repos, issues, PRs, code review, CI, and releases via gh CLI or git+curl fallback."
version: 1.0.0
author: Hermes Agent (consolidated from github-auth, github-pr-workflow, github-issues, github-code-review, github-repo-management)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Authentication, Pull-Requests, Issues, Code-Review, Repositories, CI/CD, Git, gh-cli]
---

# GitHub Workflow

Comprehensive guide for all GitHub operations: authentication, repository management, issues, pull requests, code review, CI/CD, and releases. Every section supports two backends: `gh` CLI (preferred when available) and `git` + `curl` (universal fallback).

## Auth Detection

Most operations need a GitHub token. Run this once at the start of any GitHub session:

```bash
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  AUTH="gh"
else
  AUTH="git"
  if [ -z "$GITHUB_TOKEN" ]; then
    if _hermes_env="${HERMES_HOME:-$HOME/.hermes}/.env"; [ -f "$_hermes_env" ] && grep -q "^GITHUB_TOKEN=" "$_hermes_env"; then
      GITHUB_TOKEN=$(grep "^GITHUB_TOKEN=" "$_hermes_env" | head -1 | cut -d= -f2 | tr -d '\n\r')
    elif grep -q "github.com" ~/.git-credentials 2>/dev/null; then
      GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials 2>/dev/null | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
    fi
  fi
  export GITHUB_TOKEN
fi
```

Extract owner/repo from git remote:
```bash
REMOTE_URL=$(git remote get-url origin)
OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')
OWNER=$(echo "$OWNER_REPO" | cut -d/ -f1)
REPO=$(echo "$OWNER_REPO" | cut -d/ -f2)
```

See also: `scripts/gh-env.sh` for a reusable auth bootstrap script.

---

## Section 1: Authentication Setup

### Method A: HTTPS Personal Access Token (No sudo, No gh)

1. User creates token at https://github.com/settings/tokens (scopes: `repo`, `workflow`, `read:org`)
2. Configure credential helper:
   ```bash
   git config --global credential.helper store
   git ls-remote https://github.com/<username>/<any-repo>.git  # triggers auth prompt
   # Username: <github-username>, Password: <paste token, not GitHub password>
   ```
3. Set identity:
   ```bash
   git config --global user.name "Their Name"
   git config --global user.email "their-email@example.com"
   ```

### Method B: SSH Key

```bash
ssh-keygen -t ed25519 -C "their-email@example.com" -f ~/.ssh/id_ed25519 -N ""
cat ~/.ssh/id_ed25519.pub  # add to https://github.com/settings/keys
ssh -T git@github.com  # verify
git config --global url."git@github.com:".insteadOf "https://github.com/"
```

### Method C: gh CLI Login

```bash
gh auth login           # interactive browser (desktop)
echo "<TOKEN>" | gh auth login --with-token  # headless
gh auth setup-git       # wire git credentials
```

### Troubleshooting

| Problem | Solution |
|---------|----------|
| `git push` asks for password | Use token, not password; or switch to SSH |
| `Permission denied` | Token lacks `repo` scope — regenerate |
| `Authentication failed` | Stale cached creds: `git credential reject` |
| SSH port 22 blocked | SSH over HTTPS: add Host github.com Port 443 Hostname ssh.github.com in ~/.ssh/config |

---

## Section 2: Repository Management

### Clone

```bash
git clone https://github.com/owner/repo.git
# or: gh repo clone owner/repo
# Shallow: git clone --depth 1 ...
# Specific branch: git clone --branch develop ...
```

### Create

**gh:**
```bash
gh repo create my-project --public --clone
gh repo create my-project --private --description "desc" --license MIT --clone
gh repo create my-org/my-project --public --clone
```

**curl:**
```bash
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user/repos \
  -d '{"name":"my-project","description":"desc","private":false,"auto_init":true}'
```

### Fork

```bash
gh repo fork owner/repo --clone
# Keep in sync:
git remote add upstream https://github.com/owner/repo.git
git fetch upstream && git merge upstream/main
```

### Repository Settings

```bash
gh repo edit --description "desc" --visibility public --enable-wiki=false
# curl: PATCH /repos/$OWNER/$REPO with JSON body
```

### Releases

```bash
gh release create v1.0.0 --title "v1.0.0" --generate-notes
gh release create v2.0.0 ./dist/binary --notes "notes"
# curl: POST /repos/$OWNER/$REPO/releases
```

### Secrets (GitHub Actions)

```bash
gh secret set API_KEY --body "value"
gh secret set SSH_KEY < ~/.ssh/id_rsa
gh secret list
gh secret delete API_KEY
```

Secrets via curl require encryption with the repo's public key (complex — prefer `gh` for this).

### Removing Tracked Build Artifacts

When `node_modules/`, `dist/`, etc. were committed before `.gitignore`:

```bash
git ls-files server/node_modules/ | git update-index --force-remove --stdin
git ls-files server/dist/ | git update-index --force-remove --stdin
git add -A && git commit -m "Remove build artifacts from tracking; add .gitignore"
```

`.gitignore` pattern scoping: `.env` matches only root; use `**/.env` for nested. `node_modules/` matches at any depth by default.

---

## Section 3: Issues

### View

```bash
gh issue list [--state open] [--label "bug"] [--assignee @me]
gh issue view 42
# curl: GET /repos/$OWNER/$REPO/issues?state=open
```

### Create

```bash
gh issue create --title "Title" --body "Description" --label "bug" --assignee "user"
# curl: POST /repos/$OWNER/$REPO/issues with JSON body
```

Bug report template and feature request template: see `templates/bug-report.md` and `templates/feature-request.md`.

### Manage

```bash
gh issue edit 42 --add-label "priority:high,bug"
gh issue edit 42 --remove-label "needs-triage"
gh issue edit 42 --add-assignee username
gh issue comment 42 --body "Comment text"
gh issue close 42 [--reason "not planned"]
gh issue reopen 42
```

### Triage Workflow

1. List untriaged: `gh issue list --label "needs-triage" --state open`
2. Read each, categorize
3. Apply labels + priority + assignee
4. Comment with triage notes

### Bulk Operations

```bash
gh issue list --label "wontfix" --json number --jq '.[].number' | \
  xargs -I {} gh issue close {} --reason "not planned"
```

---

## Section 4: Pull Request Workflow

### Branch Creation

```bash
git checkout main && git pull origin main
git checkout -b feat/description  # or fix/, refactor/, docs/, ci/
```

Conventional commits: `type(scope): short description` — types: `feat`, `fix`, `refactor`, `docs`, `test`, `ci`, `chore`, `perf`.

See `references/conventional-commits.md` for full format details.

### Push and Create PR

```bash
git push -u origin HEAD

# With gh:
gh pr create --title "feat: description" --body "Summary" [--draft] [--reviewer user1,user2]

# With curl:
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls \
  -d '{"title":"...","body":"...","head":"<branch>","base":"main"}'
```

PR body templates: `templates/pr-body-feature.md` and `templates/pr-body-bugfix.md`.

### CI Status

```bash
gh pr checks                 # one-shot
gh pr checks --watch         # poll until done
# curl: GET /repos/$OWNER/$REPO/commits/$SHA/status
```

### Auto-Fix CI Failures

```bash
gh run list --branch $(git branch --show-current) --limit 5
gh run view <RUN_ID> --log-failed
# Fix files, then:
git add <files> && git commit -m "fix: CI failure" && git push
```

Loop: check → diagnose → fix → push → re-check. Max 3 attempts, then ask user.
CI troubleshooting: `references/ci-troubleshooting.md`.

### Merge

```bash
gh pr merge --squash --delete-branch
gh pr merge --auto --squash --delete-branch  # auto-merge when checks pass
# curl: PUT /repos/$OWNER/$REPO/pulls/N/merge with merge_method
```

---

## Section 5: Code Review

### Review Local Changes (Pre-Push)

```bash
git diff main...HEAD --stat           # scope
git diff main...HEAD                  # full diff
git diff main...HEAD --name-only      # file list

# Scan for issues:
git diff main...HEAD | grep -n "print(\|console\.log\|TODO\|FIXME"
git diff main...HEAD | grep -in "password\|secret\|api_key\|token.*="
git diff main...HEAD | grep -n "<<<<<<\|>>>>>>\|======="  # merge markers
```

### Review Output Format

```
## Code Review Summary

### Critical
- **file:line** — issue + suggestion

### Warnings
- **file:line** — issue + suggestion

### Suggestions
- **file:line** — optional improvement

### Looks Good
- Positive observations
```

Template: `references/review-output-template.md`.

### Review PR on GitHub

```bash
# Gather context
gh pr view 123
gh pr diff 123 --name-only
gh pr checks 123

# Check out locally for full review
git fetch origin pull/123/head:pr-123 && git checkout pr-123

# Post inline comment:
gh api repos/$OWNER/$REPO/pulls/123/comments --method POST \
  -f body="comment" -f path="file.py" -f commit_id="$HEAD_SHA" -f line=45 -f side="RIGHT"

# Submit formal review:
gh pr review 123 --approve --body "LGTM!"
gh pr review 123 --request-changes --body "See inline comments."
```

**Review checklist:** correctness, security (no secrets, input validation, no injection), code quality (clear naming, DRY, focused functions), testing (happy path + error cases), performance (no N+1 queries), documentation (APIs documented).

### Decision: Approve vs Changes vs Comment

- **Approve** — no critical or warning-level issues
- **Request Changes** — any critical or warning-level issue
- **Comment** — observations, nothing blocking

---

## Quick Reference

| Action | gh | curl |
|--------|-----|------|
| List issues | `gh issue list` | `GET /repos/{o}/{r}/issues` |
| Create issue | `gh issue create ...` | `POST /repos/{o}/{r}/issues` |
| Close issue | `gh issue close N` | `PATCH /repos/{o}/{r}/issues/N` |
| Create PR | `gh pr create ...` | `POST /repos/{o}/{r}/pulls` |
| View PR diff | `gh pr diff` | `GET /repos/{o}/{r}/pulls/N` (Accept: diff) |
| Merge PR | `gh pr merge --squash` | `PUT /repos/{o}/{r}/pulls/N/merge` |
| Clone | `gh repo clone o/r` | `git clone https://github.com/o/r.git` |
| Create repo | `gh repo create name` | `POST /user/repos` |
| Create release | `gh release create v1.0` | `POST /repos/{o}/{r}/releases` |
| Set secret | `gh secret set KEY` | `PUT /repos/{o}/{r}/actions/secrets/KEY` |
| Rerun CI | `gh run rerun ID` | `POST /repos/{o}/{r}/actions/runs/ID/rerun` |

Full API reference: `references/github-api-cheatsheet.md`.

---

## Pitfalls

- GitHub disabled password auth — always use token or SSH
- Token must have `repo` scope for push/PR access
- `gh auth login` tokens differ from Copilot OAuth tokens — don't mix them
- `git rm --cached` on large dirs times out — use `git update-index --force-remove --stdin`
- `.env` in `.gitignore` matches only root — use `**/.env` for nested
- Never commit `.env` to public repos — secrets remain in git history even after removal
