---
name: mmo-battle-analysis
description: Analyze battle logs — formulas, set bonuses, stat math.
---

# MMO Arena Battle Analysis

## Quick Formulas (from `game/battle.ts`)

```
dodge  = A_def/(A_def+500) * (1 - M_atk/(M_atk+250)) / 1.5 + extraDodge/(extraDodge+300) + luckBonus
block  = D/(D+500) / 1.5 + fullBlock/(fullBlock+300)
crit   = M/(M+500) / 1.5 + extraCrit/(extraCrit+300) + luckBonus
counter= (M_def+A_def) / ((M_def+A_def)+(M_atk+D_atk)) * 0.5 / 1.5 + extraCounter/(extraCounter+300) + luckBonus
```

Caps: crit 80%, dodge none (Min(0.5) only on extra), block 75%, counter 50%.

## Set Bonuses (from `game/stats.ts`)

| Set | 2pc | 3pc | 4pc |
|---|---|---|---|
| Буревестник | A ×1.1 | alwaysFirst | extra.dodge ×1.2 |
| Страж | extra.fullBlock ×1.1 | all stats ×1.15 | counterOnHit 30% |
| Крушитель | blockPen 25% | extra.crit ×1.1 | all stats ×1.15 |
| Берсерк | all stats ×1.1 | rage +20% at HP<50% | blockPen 20% |
| Дуэлянт | extra.counter ×1.1 | extra.crit ×1.15 | vampirism +5% |
| Жнец | vampirism +5% | all stats ×1.15 | execute <10% HP |
| Гладиатор | +15% dmg + counter ×1.15 | extra.fullBlock ×1.1 | all stats ×1.1 |
| Отшельник | +100% HP regen (out of combat) | poison 3% HP 3 turns | extra.dodge ×1.15 |

## Set Slot Matrix

| Set | weapon1 | shield | helmet | chest | gloves | boots | amulet | ring | belt |
|---|---|---|---|---|---|---|---|---|---|
| Буревестник | | | ✓ | | ✓ | ✓ | ✓ | | |
| Гладиатор | ✓ | ✓ | ✓ | | | | ✓ | | |
| Берсерк | ✓ | | | | ✓ | ✓ | | | ✓ |
| Страж | | ✓ | ✓ | ✓ | | | | ✓ | |
| Крушитель | ✓ | ✓ | | | ✓ | | | | ✓ |
| Жнец | ✓ | | | ✓ | ✓ | | | | ✓ |
| Дуэлянт | ✓ | ✓ | | | | | ✓ | ✓ | |
| Отшельник | | | ✓ | ✓ | | ✓ | | ✓ | |

Impossible: Буревестник 4 + Гладиатор 4 (helmet+amulet conflict). Viable 4+4+2: Буревестник+Берсерк, Страж+Крушитель.

## Analysis Workflow

1. **Extract equipment** from production:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT id, username, equipment FROM users WHERE id IN (...);\""
```

2. **Extract battle steps**:
```bash
ssh root@194.226.142.237 "sudo -u postgres psql -d game -c \"SELECT id, attackerid, defenderid, steps FROM battles WHERE id IN (...);\""
```

3. **Calculate extra stats**: sum each extra stat across 10 slots, apply set multipliers (Буревестник 4pc: dodge ×1.2), convert to %: `value/(value+300)`.

4. **Compare expected vs actual**: count dodge/crit/block/fullBlock in steps, expected = chance × attacks, n > 20 for significance.

## Pitfalls

- **Dodge M penalty**: `M_atk/(M_atk+250)` — fixed from 500 to 250 (2026-08-03).
- **Full block is independent** — checked BEFORE blockChance in runTurn.
- **Set multipliers apply to raw extra values**, not final %.
- **luck** (Подкова удачи): flat +5pp to ALL chances.
- **Curse adds stats**, does NOT subtract.
- **Страж 3pc** multiplies ALL stats (S/A/D/M) ×1.15, including HP.

## Artifacts (rarity=7, no set)

| Name | Slot | Effect | Extra |
|---|---|---|---|
| Подкова удачи | belt | luck +5% all chances | crit 15, dodge 15, counter 10 |
| Кольцо вампира | ring | vampirism 5% | crit 22, counter 18 |
| Талисман стойкости | amulet | resilience 30% | fullBlock 22 |
| Амулет ярости | amulet | rage +20% at HP<30% | crit 20, counter 20 |

## Top 3 builds (existing items only)

🥇 Dodge-вампир: Буревестник 4 + Гладиатор 2 + Подкова + Кольцо вампира + Кольцо травника
- alwaysFirst, dodge×1.2, luck+5%, vamp 5%, extra dodge=(23+15+22)×1.2=72→19.4%

🥈 Сбаланс: Буревестник 4 + Гладиатор 2 + Страж 2 + Подкова + Кольцо вампира

🥉 Жнец-убийца: Жнец 4 + Дуэлянт 2 + Буревестник 2 + Кольцо вампира — vamp 10%, execute
