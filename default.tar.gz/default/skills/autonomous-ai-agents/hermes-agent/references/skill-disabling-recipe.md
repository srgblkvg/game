# Skill Disabling — Reproduction Recipe

## Context

User: srgblkvg, working on MMO game dev project. Wanted to trim down the 36 installed skills to only the 22 relevant ones.

## Skills disabled

| Skill | Reason |
|-------|--------|
| dogfood | QA web apps — not used |
| claude-code | Delegation to Claude Code — not used |
| codex | Delegation to Codex — not used |
| kanban-codex-lane | Kanban worker lane — not used |
| opencode | Delegation to OpenCode — not used |
| jupyter-live-kernel | Data science — not used |
| kanban-orchestrator | Multi-agent queue — not used |
| kanban-worker | Multi-agent worker — not used |
| webhook-subscriptions | Event-driven runs — not used |
| native-mcp | MCP servers — not used |
| debugging-hermes-tui-commands | TUI slash cmd debug — not relevant |
| hermes-s6-container-supervision | Containers — not used |
| subagent-driven-development | Subagent delegation — not used |
| text-rpg-project | Other game project — not used |

## Skills kept (22)

- `hermes-agent` — Hermes configuration
- `mmo-game-dev`, `game-server` — game development
- `database-migration`, `sqlite-to-pg-migration` — DB migrations
- `github-auth`, `github-code-review`, `github-issues`, `github-pr-workflow`, `github-repo-management`, `codebase-inspection` — GitHub workflow
- `plan`, `writing-plans`, `systematic-debugging`, `test-driven-development`, `simplify-code`, `requesting-code-review`, `spike` — software development
- `node-inspect-debugger`, `python-debugpy` — debugging
- `tailwind-css-migration`, `admin-console-scaffold` — frontend

## Exact commands used

```bash
# Attempt 1: hermes config set stores as string (WRONG)
hermes config set skills.disabled '["dogfood", "claude-code", ...]'
# → stored as YAML string, not list

# Attempt 2: still a string
hermes config set skills.disabled '[dogfood, claude-code, ...]'
# → same problem

# Fix: direct YAML manipulation
python3 -c "
import yaml
with open('/home/srg/.hermes/config.yaml') as f:
    cfg = yaml.safe_load(f)
cfg['skills']['disabled'] = [
    'dogfood', 'claude-code', 'codex', 'kanban-codex-lane', 'opencode',
    'jupyter-live-kernel', 'kanban-orchestrator', 'kanban-worker', 'webhook-subscriptions',
    'native-mcp', 'debugging-hermes-tui-commands', 'hermes-s6-container-supervision',
    'subagent-driven-development', 'text-rpg-project'
]
with open('/home/srg/.hermes/config.yaml', 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
"

# Verify
hermes config check
python3 -c "
import yaml
with open('/home/srg/.hermes/config.yaml') as f:
    cfg = yaml.safe_load(f)
d = cfg.get('skills', {}).get('disabled', [])
print(f'Type: {type(d).__name__}, Len: {len(d)}')
"
```

## Result

config.yaml `skills.disabled` now a proper YAML list of 14 items. Takes effect on `/reset`.
